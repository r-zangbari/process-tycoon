import test from 'node:test';
import assert from 'node:assert/strict';
import {rememberCityMove,undoCityMove} from '../js/features/country/model/city-move-history.js';
test('move history persists independently per city and leaves economic buildings intact',()=>{
 const S={cityMaps:{A:[{type:'home',level:2}],B:[{type:'park',level:1}]}};
 rememberCityMove(S,'A',0,[10,20]);rememberCityMove(S,'B',0,[30,40]);
 const restored=JSON.parse(JSON.stringify(S));assert.equal(undoCityMove(restored,'A'),true);
 assert.deepEqual(restored.cityBuildingPositions.A[0],[10,20]);assert.equal(restored.cityMoveHistory.B.length,1);
 assert.deepEqual(restored.cityMaps,S.cityMaps);assert.equal(undoCityMove(restored,'A'),false);
});
test('history is bounded and skips demolished buildings',()=>{
 const S={cityMaps:{A:[{},{}]}};for(let i=0;i<25;i++)rememberCityMove(S,'A',0,[i,i]);
 assert.equal(S.cityMoveHistory.A.length,20);rememberCityMove(S,'A',1,[2,3]);S.cityMaps.A[1]=null;
 assert.equal(undoCityMove(S,'A'),true);assert.deepEqual(S.cityBuildingPositions.A[0],[24,24]);
});
