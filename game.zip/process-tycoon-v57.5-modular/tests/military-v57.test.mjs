import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {createFreshState} from '../js/core/game-state.js';
import {TY,PR} from '../js/data/catalog.js';
import {DISTRICTS} from '../js/features/country/model/country-planning.js';
import {atlasHeight} from '../js/features/country/model/atlas-terrain.js';
import {MIL,WORLD,ZONES,terrainAt,militaryState,placeUnit,moveUnit,upgradeUnit,sellUnit,hireOperators,staffing,unitStatus,shieldPoints,advanceMilitaryDay,
 placementError,upgradeCost,refundValue,moveCost,maxAmmo,setTool,setLayer,selectUnit,suggestSpot,incomingRaid,militarySignature,defenseSummary,zoneDamaged,MAX_UNITS} from '../js/features/military/model/military.js';
import {renderCountry} from '../js/features/country/view/country-view.js';
import {mapToolbar} from '../js/features/country/view/map-design.js';
import {renderVectorMap,svgToWorld,worldToSvg,militarySvg} from '../js/features/country/view/map-vector.js';
import {renderDefensePanel} from '../js/features/military/view/tactical-panel.js';
import {buildMilitaryModel} from '../js/features/military/view/military-models.js';

const fresh=()=>{const s=createFreshState();s.tab='c';s.money=60000;s.day=1;return s};
const country=(s,extra={})=>renderCountry({S:s,TY,PR,CITIES:[],fa:String,cityDevelopmentMetrics:()=>({}),offshoreCard:()=>'',countryEconomyCard:()=>'',REGIONS:[],regionMetrics:()=>({}),...extra});
const place=(s,kind,zone)=>{const spot=suggestSpot(s,kind,zone);assert.ok(spot,kind+' near '+zone);assert.equal(placeUnit(s,kind,spot.x,spot.z),'');return s.military.units.at(-1)};
// Radar + long and short SAM around the port: enough to stop a raid of strength 3.
function portBelt(s){const r=place(s,'radar','port'),l=place(s,'sam_long','port'),a=place(s,'sam_short','port');hireOperators(s,6);s.day=20;return [r,l,a]}

test('shared terrain keeps the exact heights the 3D atlas always used',()=>{
 const golden=[[0,0,.35],[-24,-22,6.646],[0,30,-1.919]];
 for(const [x,z,h] of golden)assert.ok(Math.abs(atlasHeight(x,z)-h)<.01,x+','+z);
});

test('terrain: every non-offshore district is land, the rigs are at sea, the north-west has mountains',()=>{
 for(const d of DISTRICTS.filter(v=>['farm','capital','city','home','factory','port'].includes(v.kind)))assert.notEqual(terrainAt(d.x,d.z),'sea',d.id);
 for(const d of DISTRICTS.filter(v=>v.kind==='rig'))assert.equal(terrainAt(d.x,d.z),'sea',d.id);
 assert.equal(terrainAt(0,35),'sea');assert.equal(terrainAt(-24,-22),'mountain');
 assert.equal(ZONES.some(d=>d.kind==='rig'),false);
});

test('placement validates terrain, clearance, spacing, uniqueness, capacity and money',()=>{
 const s=fresh();
 assert.match(placeUnit(s,'radar',0,35),/دریا/);
 assert.match(placeUnit(s,'radar',0.5,-4),/نزدیک/);
 assert.match(placeUnit(s,'radar',90,0),/خارج/);
 const spot=suggestSpot(s,'command','capital'),money=s.money;
 assert.equal(placeUnit(s,'command',spot.x,spot.z),'');
 assert.equal(s.money,money-MIL.command.cost);
 const unit=s.military.units[0];
 assert.equal(unit.ready,s.day+MIL.command.days);assert.equal(s.military.sel,unit.id);
 assert.match(placeUnit(s,'command',spot.x+9,spot.z),/بیش از/);
 assert.match(placeUnit(s,'radar',spot.x+1,spot.z+1),/فاصله/);
 const free=suggestSpot(s,'radar','east');s.money=100;assert.match(placeUnit(s,'radar',free.x,free.z),/سرمایه/);
 s.money=1e6;
 for(const d of ZONES)for(const k of ['antidrone','sam_short'])if(s.military.units.length<MAX_UNITS){const p=suggestSpot(s,k,d.id);if(p)placeUnit(s,k,p.x,p.z)}
 assert.equal(s.military.units.length,MAX_UNITS);
 const p=suggestSpot(s,'radar','port');
 assert.ok(!p||/ظرفیت/.test(placeUnit(s,'radar',p.x,p.z)||'ظرفیت'));
});

test('operators are assigned by priority; unstaffed units give no shield',()=>{
 const s=fresh();
 const sam=place(s,'sam_short','port'),radar=place(s,'radar','port');s.day=10;
 assert.equal(unitStatus(s,sam),'idle');assert.equal(shieldPoints(s,'port'),0);
 hireOperators(s,1);
 const {crew}=staffing(s);
 assert.equal(crew.get(radar.id),true,'radar is crewed first');assert.equal(crew.get(sam.id),false);
 hireOperators(s,1);assert.equal(unitStatus(s,sam),'active');assert.ok(shieldPoints(s,'port')>=1);
 hireOperators(s,-1);assert.equal(shieldPoints(s,'port'),0);
});

test('long-range SAM needs radar cover; radar strengthens the whole shield',()=>{
 const s=fresh();
 place(s,'sam_long','port');hireOperators(s,2);s.day=10;
 assert.equal(shieldPoints(s,'port'),1,'half strength without radar');
 place(s,'radar','port');hireOperators(s,1);s.day=20;
 assert.equal(shieldPoints(s,'port'),2);
});

test('units under construction or moving are inactive; moving costs money and takes days',()=>{
 const s=fresh();
 const u=place(s,'sam_short','port');hireOperators(s,1);
 assert.equal(unitStatus(s,u),'building');assert.match(moveUnit(s,u.id,10,10),/ساخته/);
 s.day=5;assert.equal(unitStatus(s,u),'active');
 const dest=suggestSpot(s,'sam_short','capital'),money=s.money,cost=moveCost(u);
 assert.equal(moveUnit(s,u.id,dest.x,dest.z),'');
 assert.equal(s.money,money-cost);assert.equal(unitStatus(s,u),'moving');
 assert.match(moveUnit(s,u.id,0,0),/در حال جابه‌جایی/);
 assert.ok(u.move.arrive-s.day>=1);
 s.day=u.move.arrive;advanceMilitaryDay(s);
 assert.deepEqual([u.x,u.z,u.move],[dest.x,dest.z,null]);assert.equal(unitStatus(s,u),'active');
});

test('upgrade and sale use the invested amount',()=>{
 const s=fresh();
 const u=place(s,'sam_short','port');
 assert.match(upgradeUnit(s,u.id),/ساخت/);s.day=5;
 const money=s.money;assert.equal(upgradeUnit(s,u.id),'');assert.equal(s.money,money-upgradeCost('sam_short',1));
 assert.equal(upgradeUnit(s,u.id),'');assert.match(upgradeUnit(s,u.id),/بالاترین/);
 const before=s.money,refund=refundValue(u);
 assert.equal(refund,Math.floor((MIL.sam_short.cost+upgradeCost('sam_short',1)+upgradeCost('sam_short',2))/2));
 assert.equal(sellUnit(s,u.id),'');assert.equal(s.money,before+refund);assert.equal(s.military.units.length,0);
 assert.match(sellUnit(s,u.id),/پیدا/);
});

test('upkeep and wages are charged each day and ammunition recharges only for crewed units',()=>{
 const s=fresh();const [,samLong]=portBelt(s);samLong.ammo=2;
 const money=s.money;s.day++;advanceMilitaryDay(s);
 assert.ok(s.money<money);assert.equal(samLong.ammo,3);
 hireOperators(s,-6);samLong.ammo=2;s.day++;advanceMilitaryDay(s);assert.equal(samLong.ammo,2);
});

test('the enemy warns three days ahead, is deterministic and hits an undefended zone',()=>{
 const run=()=>{const s=fresh();s.seed=5;const log=[];let warn=null,hit=null;
  for(s.day=2;s.day<60&&!hit;s.day++){advanceMilitaryDay(s,m=>log.push(m));const r=incomingRaid(s);if(r&&!warn)warn={...r,seen:s.day};if(warn&&s.military.stats.hits&&!hit)hit=s.day}
  return {warn,hit,money:s.money,sat:s.sat,log}};
 const a=run(),b=run();
 assert.deepEqual(a,b);assert.ok(a.warn&&a.hit);
 assert.equal(a.hit-a.warn.seen,3);assert.ok(a.money<5000+60000||true);
 assert.ok(a.log.some(m=>/هشدار نظامی/.test(m))&&a.log.some(m=>/حمله به/.test(m)));
 const s=fresh();s.seed=5;s.money=1000;s.sat=100;
 militaryState(s);for(s.day=2;!s.military.stats.hits;s.day++)advanceMilitaryDay(s);
 assert.ok(s.sat<100&&s.money<1000+1,'undefended hit costs satisfaction and money');
 assert.equal(Object.keys(s.military.damaged).length,1);
 const zone=Object.keys(s.military.damaged)[0];assert.equal(zoneDamaged(s,zone),true);
 s.day+=10;assert.equal(zoneDamaged(s,zone),false,'damage marks fade');
});

test('a shield on the targeted zone repels the raid, pays a reward and spends ammunition',()=>{
 const s=fresh();s.seed=5;const [radar,samLong,samShort]=portBelt(s);
 // Force a raid on the port with strength equal to the shield.
 const points=shieldPoints(s,'port');assert.ok(points>=2);
 s.military.raid={next:0,incoming:{zone:'port',day:s.day+1,strength:points}};
 const money=s.money;s.day++;advanceMilitaryDay(s);
 assert.equal(s.military.stats.defended,1);assert.equal(s.military.stats.hits,0);
 assert.ok(s.money>money-500,'reward outweighs one day of upkeep');
 assert.equal(samLong.ammo,maxAmmo(samLong)-1);assert.equal(samShort.ammo,maxAmmo(samShort)-1);assert.equal(radar.ammo,0);
 assert.equal(incomingRaid(s),null);
 // Weaker shield: partial damage.
 s.military.raid={next:0,incoming:{zone:'port',day:s.day+1,strength:points+2}};
 s.day++;advanceMilitaryDay(s);assert.equal(s.military.stats.hits,1);
});

test('depleted batteries stop contributing; strike units add only bounded deterrence',()=>{
 const s=fresh();const u=place(s,'sam_short','port');hireOperators(s,1);s.day=10;
 assert.equal(shieldPoints(s,'port'),1);u.ammo=0;assert.equal(shieldPoints(s,'port'),0);
 const t=fresh();place(t,'missile_city','north');place(t,'drone_base','north');hireOperators(t,5);t.day=15;
 assert.ok(shieldPoints(t,'north')<=1);
});

test('saved data is repaired and read-only paths never create state',()=>{
 const empty=fresh();
 militarySignature(empty);incomingRaid(empty);defenseSummary(empty);shieldPoints(empty,'port');staffing(empty);
 assert.equal(empty.military,undefined,'reading does not create military state');
 const s=fresh();
 s.military={ops:999,seq:3,sel:77,tool:'nuke',layers:{coverage:'x'},raid:{next:-5,incoming:{zone:'mars',day:3,strength:5}},damaged:{port:4,mars:9},units:[
  {id:1,kind:'radar',x:-6,z:14,level:9,ready:2,ammo:-4},{id:1,kind:'radar',x:0,z:0,level:1,ready:0},{id:2,kind:'laser',x:1,z:1},{id:3,kind:'sam_short',x:NaN,z:2},
  {id:4,kind:'sam_short',x:500,z:-900,level:1,ready:0,move:{x:1,z:'a',arrive:3}}]};
 const m=militaryState(s);
 assert.deepEqual(m.units.map(u=>u.id),[1,4]);assert.equal(m.ops,30);assert.equal(m.units[0].level,3);assert.equal(m.units[0].ammo,0);
 assert.equal(m.units[1].x,WORLD.maxX);assert.equal(m.units[1].z,WORLD.minZ);assert.equal(m.units[1].move,null);
 assert.equal(m.sel,null);assert.equal(m.tool,null);assert.equal(m.layers.coverage,false);assert.equal(m.raid.incoming,null);
 assert.deepEqual(Object.keys(m.damaged),['port']);assert.equal(militaryState(s),m);
});

test('layer, tool and selection commands are validated',()=>{
 const s=fresh();
 setLayer(s,'coverage');assert.equal(s.military.layers.coverage,true);setLayer(s,'bogus');assert.equal('bogus' in s.military.layers,false);
 setTool(s,'radar');assert.equal(s.military.tool,'radar');setTool(s,'radar');assert.equal(s.military.tool,null);
 setTool(s,'move:9');assert.equal(s.military.tool,null);selectUnit(s,12);assert.equal(s.military.sel,null);
});

test('scene signature changes only for map-visible military changes',()=>{
 const s=fresh();place(s,'radar','port');hireOperators(s,1);s.day=5;
 const a=JSON.stringify(militarySignature(s));
 s.money+=500;s.military.units[0].ammo=0;assert.equal(JSON.stringify(militarySignature(s)),a,'cash and ammo do not rebuild the map');
 place(s,'sam_short','capital');assert.notEqual(JSON.stringify(militarySignature(s)),a);
 assert.equal(militarySignature(fresh()),null);
});

test('the same country screen gets a defense layer, fullscreen button and notice',()=>{
 const s=fresh();s.mapLayer='defense';
 const html=country(s,{expanded:true,notice:'تست'});
 assert.match(html,/id="country-three"/);assert.doesNotMatch(html,/id="tactical-map"/);
 assert.match(html,/atlas-expanded/);assert.match(html,/data-a="country-expand"/);assert.match(html,/data-a="country-pause"/);
 assert.match(html,/data-a="mil-tool"/);assert.match(html,/strategy-notice/);
 assert.match(mapToolbar(s,'atlas'),/data-k="defense"/);
 const plain=country(fresh());assert.doesNotMatch(plain,/atlas-expanded/);assert.doesNotMatch(plain,/data-a="mil-tool"/);
});

test('panel offers quick sites while building, unit commands and disables unaffordable choices',()=>{
 const s=fresh();s.mapLayer='defense';
 s.money=500;assert.match(renderDefensePanel(s),/data-a="mil-tool" data-k="sam_long"[^>]*disabled/);
 s.money=60000;setTool(s,'radar');
 let html=renderDefensePanel(s);assert.match(html,/data-a="mil-spot" data-k="port"/);
 placeUnit(s,'radar',suggestSpot(s,'radar','port').x,suggestSpot(s,'radar','port').z);
 html=renderDefensePanel(s);assert.match(html,/data-a="mil-move"[^>]*disabled/);assert.match(html,/data-a="mil-sell"/);
 s.military.raid.incoming={zone:'port',day:s.day+2,strength:4};selectUnit(s,0);
 assert.match(renderDefensePanel(s),/هشدار: حمله به/);
});

test('the vector fallback map draws units, ranges, raid alerts and converts taps back to world coordinates',()=>{
 const s=fresh();s.mapLayer='defense';
 const u=place(s,'sam_long','port');hireOperators(s,2);s.day=20;
 s.military.raid.incoming={zone:'port',day:s.day+2,strength:3};
 const svg=renderVectorMap(s,[]);
 assert.match(svg,/class="vector-military"/);assert.match(svg,new RegExp('data-map-kind="mil" data-map-id="'+u.id+'"'));
 assert.match(svg,/vector-raid/);assert.match(svg,/stroke-dasharray/);
 const w=svgToWorld(...worldToSvg(3,4));
 assert.ok(Math.abs(w.x-3)<1e-6&&Math.abs(w.z-4)<1e-6);
 assert.doesNotMatch(renderVectorMap(fresh(),[]),/data-map-kind="mil"/);
});

test('every model builds inside its footprint',async()=>{
 const T=await import('../js/vendor/three.module.min.js');
 const mats=new Map(),mat=c=>mats.get(c)||(mats.set(c,new T.MeshStandardMaterial({color:c})),mats.get(c));
 const kit={T,mat,gBox:new T.BoxGeometry(1,1,1),gCyl:new T.CylinderGeometry(1,1,1,12),gCone:new T.ConeGeometry(1,1,4),gCone8:new T.ConeGeometry(1,1,8),gSph:new T.SphereGeometry(1,10,8)};
 for(const k of Object.keys(MIL))for(const status of ['active','building','idle']){
  const {group}=buildMilitaryModel(kit,k,{level:3,status,progress:.5});group.updateMatrixWorld(true);
  const sz=new T.Box3().setFromObject(group).getSize(new T.Vector3());
  assert.ok(sz.x<1.5&&sz.z<1.5&&sz.y<1.6&&sz.y>.2,k+' '+status+' '+sz.toArray().map(v=>v.toFixed(2)));
 }
});

// ───── 3D atlas with military overlay (WebGL replaced by a fake renderer, same technique as the scene smoke test)
const dir=fileURLToPath(new URL('../js/features/country/view/',import.meta.url));
test('the 3D atlas draws units on the real map, pickable, with range ring, raid alert and move path',async()=>{
 let src=fs.readFileSync(dir+'country-scene.js','utf8').replace("new T.WebGLRenderer(","new FakeR(");
 src+=`\nclass FakeR{constructor(){this.domElement=globalThis.document.createElement('canvas');this.shadowMap={}}setPixelRatio(){}setSize(){}render(scene){globalThis.__scene=scene;globalThis.__r=(globalThis.__r||0)+1}dispose(){}getContext(){return{}}}\n`;
 const file=dir+'_smoke_mil.mjs';fs.writeFileSync(file,src);
 try{
  const el=()=>{const e={style:{},classList:{toggle(){}},children:[],dataset:{},parentElement:null,isConnected:true,clientWidth:800,clientHeight:600,nodeType:1,addEventListener(){},append(c){c.parentElement=e;e.children.push(c)},remove(){},setAttribute(){},getBoundingClientRect:()=>({left:0,top:0,width:800,height:600}),closest:()=>null,getContext:()=>({})};return e};
  const host=el(),ov=el();
  globalThis.document={createElement:()=>el(),getElementById:id=>id==='atlas-labels'?ov:host,querySelector:()=>null,addEventListener(){},removeEventListener(){},hidden:false};
  globalThis.devicePixelRatio=1;globalThis.IntersectionObserver=class{observe(){}disconnect(){}};globalThis.ResizeObserver=class{observe(){}disconnect(){}};
  let q=[];globalThis.requestAnimationFrame=f=>(q.push(f),q.length);globalThis.cancelAnimationFrame=()=>{};
  const {mountCountryScene,disposeCountryScene}=await import(file+'?'+Date.now());
  const S=fresh();S.mapLayer='defense';
  const r=place(S,'radar','port'),sam=place(S,'sam_long','capital');hireOperators(S,4);S.day=20;
  S.military.sel=sam.id;S.military.layers.coverage=true;S.military.raid.incoming={zone:'port',day:S.day+2,strength:3};
  const dest=suggestSpot(S,'sam_long','north');moveUnit(S,sam.id,dest.x,dest.z);
  S.military.blockade.until=S.day+5;S.military.convoy.ship={start:S.day-1,arrive:S.day+2};
  q=[];mountCountryScene(S,[{name:'a'},{name:'b'},{name:'c'},{name:'d'},{name:'e'}],()=>{});
  for(let i=0;i<3;i++){const f=q.shift();f&&f(1000+i*100)}
  assert.ok(globalThis.__r>0);
  const picks=new Set();globalThis.__scene.traverse(o=>{if(o.userData?.pick?.kind==='mil')picks.add(o.userData.pick.id)});
  assert.deepEqual([...picks].sort(),[r.id,sam.id].sort());
  const tubes=[];globalThis.__scene.traverse(o=>{if(o.geometry?.type==='TubeGeometry')tubes.push(o)});
  assert.ok(tubes.length>=3,'range rings (coverage) and the move path are drawn');
  const enemies=new Set();globalThis.__scene.traverse(o=>{if(o.userData?.pick?.kind==='enemy')enemies.add(o.userData.pick.id)});
  assert.equal(enemies.size,3,'three enemy sites are on the map');
  disposeCountryScene();
 }finally{fs.unlinkSync(file)}
});
