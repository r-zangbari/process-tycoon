import test from 'node:test';
import assert from 'node:assert/strict';
import {acceptDevelopment,settleDevelopment,advanceStoryCrisis,prepareStoryCrisis,storyFactor} from '../js/features/development/model/development.js';
import {effectiveTradePort} from '../js/features/products/model/trade-conditions.js';
import {createFreshState,normalizeState} from '../js/core/game-state.js';
import * as catalog from '../js/data/catalog.js';
import {COASTAL_BUFFER,waterAction,simulateWaterDay} from '../js/features/water/model/water-supply.js';
import {advanceOffshoreProjects,simulateOffshoreDay,startOffshoreExtension} from '../js/features/offshore/model/offshore.js';
const fresh=()=>{const s=createFreshState();normalizeState(s,catalog);return s};
test('development appears from observed shortages and credits only five future delivery days, once',()=>{
 const s=fresh();s.day=7;s.fr.water=.4;s.dem.water=40;
 assert.equal(acceptDevelopment(s,'water'),false);
 s.u=[{dayEconomics:{day:7,products:[{accepted:4}]}}];
 settleDevelopment(s);assert.equal(acceptDevelopment(s,'water'),true);
 const startingBudget=s.govBudget||0,cash=s.money;
 for(const ratio of [.97,1,.8,1,.95,.97,1,1]){
  s.day++;s.fr.water=ratio;settleDevelopment(s);settleDevelopment(s);
  if(ratio===.8)assert.equal(s.development.offers.water.streak,0);
 }
 assert.equal(s.development.offers.water.status,'complete');
 assert.equal(s.network.water,1);assert.equal(s.govBudget,startingBudget+850);
 assert.equal(s.money,cash);
 s.day++;settleDevelopment(s);assert.equal(s.govBudget,startingBudget+850);
});
test('story disruption gives three days of warning, changes actual port limit and then restores it',()=>{
 const s=fresh();s.day=22;s.port=40;s.u=[{st:'run'}];s.development={productiveDays:5};
 advanceStoryCrisis(s,()=>0);
 assert.equal(s.development.event.startDay,25);assert.equal(effectiveTradePort(s),40);
 s.day=25;advanceStoryCrisis(s,()=>0);assert.equal(effectiveTradePort(s),26);
 const cash=s.money;assert.equal(prepareStoryCrisis(s),true);assert.equal(prepareStoryCrisis(s),false);
 assert.equal(s.money,cash-280);assert.equal(effectiveTradePort(s),36);
 s.day=28;advanceStoryCrisis(s,()=>0);assert.equal(effectiveTradePort(s),40);
 s.day=46;advanceStoryCrisis(s,()=>0);assert.equal(s.development.event.type,'industry');
 s.day=49;assert.equal(storyFactor(s,'industry'),.82);assert.equal(effectiveTradePort(s),40);
});
test('depleted field drains its real buffer without rig charges and opens a finite paid extension once',()=>{
 const s=fresh(),f=s.offshore.oil;
 Object.assign(f,{stage:5,pipelineLevel:1,online:true,reserveInitial:100,reserveRemaining:0,buffer:40});
 const cap=()=>150;
 assert.equal(simulateOffshoreDay(s,cap,()=>{}),12);
 assert.equal(f.buffer,0);assert.equal(s.tanks.crude,40);
 assert.equal(simulateOffshoreDay(s,cap,()=>{}),0);
 let fees=0;const pay=x=>{fees+=x;return true};
 assert.equal(startOffshoreExtension(s,'oil',()=>{},pay),true);
 assert.equal(startOffshoreExtension(s,'oil',()=>{},pay),false);assert.equal(fees,9200);
 for(let i=0;i<10;i++)advanceOffshoreProjects(s,()=>{});
 assert.equal(f.reserveRemaining,9600);assert.equal(f.extensionLevel,1);
 simulateOffshoreDay(s,cap,()=>{});assert.ok(f.producedToday>0);
});
test('old exhausted shut-down save gains new reserve while safety and resume remain explicit',()=>{
 const s=fresh();Object.assign(s.offshore.oil,{stage:5,pipelineLevel:1,online:false,reserveInitial:100,reserveRemaining:0,buffer:0,incident:{kind:'pipeline-leak',day:4}});
 const restored=JSON.parse(JSON.stringify(s));normalizeState(restored,catalog);
 assert.equal(startOffshoreExtension(restored,'oil',()=>{},()=>true),false);
 restored.offshore.oil.incident=null;
 assert.equal(startOffshoreExtension(restored,'oil',()=>{},()=>true),true);
 for(let i=0;i<10;i++)advanceOffshoreProjects(restored,()=>{});
 simulateOffshoreDay(restored,()=>150,()=>{});
 assert.equal(restored.offshore.oil.reserveRemaining,9600);
 assert.equal(restored.offshore.oil.producedToday,0);
});
test('coastal tank refills from paid desalination and only transfers physically stored water',()=>{
 const s=fresh();s.money=10000;s.tanks.power=100;s.tanks.rawwater=150;
 s.waterSupply={sources:{desal:{level:1,connected:true}}};
 assert.equal(waterAction(s,'desal','buffer-build'),true);
 assert.equal(waterAction(s,'desal','buffer-build'),false);
 const cap=()=>150,cash=s.money;
 const first=simulateWaterDay(s,{cap});assert.equal(first.coastalStored,100);
 assert.equal(s.tanks.rawwater,150);assert.equal(s.waterSupply.coastal.stock,100);
 assert.equal(s.money,cash-95);assert.equal(s.tanks.power,92);
 s.day++;s.tanks.rawwater=0;s.tanks.power=100;s.waterSupply.sources.desal.enabled=false;
 simulateWaterDay(s,{cap});
 assert.equal(s.tanks.rawwater,COASTAL_BUFFER.dailyTransfer);assert.equal(s.waterSupply.coastal.stock,55);
 s.day++;s.tanks.rawwater=150;s.waterSupply.coastal.stock=0;s.waterSupply.sources.desal.enabled=true;
 simulateWaterDay(s,{cap});assert.equal(s.waterSupply.coastal.stock,100);
 assert.equal(s.tanks.rawwater,150);
});
