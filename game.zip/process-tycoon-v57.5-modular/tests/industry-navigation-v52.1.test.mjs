import test from 'node:test';import assert from 'node:assert/strict';
import {industryPage,renderIndustrySite} from '../js/features/industrial-site/view/industry-view.js';
import {D} from '../js/data/catalog.js';
test('all process units remain reachable across 12-unit blocks, with stable DCS IDs',()=>{
 const s={u:Array.from({length:37},(_,i)=>({t:i%16,st:i===4?'build':'run',pl:i})),siteMapPage:0};
 const ids=[];
 for(let page=0;page<4;page++){s.siteMapPage=page;const view=industryPage(s);assert.equal(view.pages,4);ids.push(...view.units.map(({i})=>i));const markup=renderIndustrySite(s,D,String);for(const {i}of view.units)assert.ok(markup.includes(`data-hmi="${i}"`))}
 assert.deepEqual(ids,Array.from({length:37},(_,i)=>i));
 s.siteMapPage=999;assert.equal(industryPage(s).page,3);s.siteMapPage=-1;assert.equal(industryPage(s).page,0);
 const markup=renderIndustrySite(s,D,String);assert.match(markup,/data-hmi="4" disabled/);assert.match(markup,/data-hmi="0" >/);
});
test('empty industrial site offers project creation, without inventing productive facilities',()=>{
 const s={u:[],siteMapPage:50};const markup=renderIndustrySite(s,D,String);assert.equal(industryPage(s).page,0);assert.match(markup,/اولین پروژه/);assert.doesNotMatch(markup,/data-hmi=/);
});
