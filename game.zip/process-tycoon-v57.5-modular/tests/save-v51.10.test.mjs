import test from 'node:test';
import assert from 'node:assert/strict';
import { createFreshState, LEGACY_STORAGE_KEY, STORAGE_KEY } from '../js/core/game-state.js';
import { createSaveStore, exportSnapshot, importSnapshot } from '../js/core/save-store.js';
import { GAME_VERSION } from '../js/core/version.js';

const snapshot = day => ({ ...createFreshState(), day, money: 5000 + day });

function memory(entries = []) {
  const data = new Map(entries);
  return { getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, value) };
}

test('migrates the old browser key and imports the previous version backup format', () => {
  const storage = memory([[LEGACY_STORAGE_KEY, JSON.stringify(snapshot(12))]]);
  const save = createSaveStore(() => storage);
  const loaded = save.read();
  assert.equal(loaded.source, 'legacy');
  assert.equal(loaded.state.day, 12);
  assert.equal(save.write(loaded.state), 'saved');
  storage.setItem(LEGACY_STORAGE_KEY, JSON.stringify(snapshot(2)));
  assert.equal(save.read().state.day, 12);

  for (const gameVersion of ['57.3', '57.4']) {
    const backup = { ...exportSnapshot(snapshot(8)), gameVersion };
    assert.equal(importSnapshot(JSON.stringify(backup)).day, 8);
  }
  assert.equal(exportSnapshot(loaded.state).gameVersion, GAME_VERSION);
});

test('a stale tab cannot overwrite a newer save, even if both tabs are on the same day', () => {
  const storage = memory([[STORAGE_KEY, JSON.stringify(snapshot(12))]]);
  const owner = createSaveStore(() => storage), oldTab = createSaveStore(() => storage);
  const current = owner.read().state, old = oldTab.read().state;
  current.money += 150;
  assert.equal(owner.write(current), 'saved');
  assert.equal(oldTab.changed(), true);
  assert.equal(oldTab.write(old), 'conflict');
  assert.equal(oldTab.read().state.money, current.money);
});

test('keeps a previous valid save and automatically loads it when the primary is damaged', () => {
  const storage = memory([[STORAGE_KEY, JSON.stringify(snapshot(7))]]);
  const save = createSaveStore(() => storage);
  save.read();
  assert.equal(save.write(snapshot(8)), 'saved');
  assert.equal(save.previous().day, 7);
  storage.setItem(STORAGE_KEY, '{"u":null}');
  assert.equal(save.read().source, 'previous');
  assert.equal(save.read().state.day, 7);
  assert.equal(save.write(snapshot(9)), 'saved');
  assert.equal(save.previous().day, 7);
});

test('a failed save leaves the current data usable and a rejected file changes nothing', () => {
  const storage = memory([[STORAGE_KEY, JSON.stringify(snapshot(7))]]);
  const setItem = storage.setItem;
  storage.setItem = (key, value) => {
    if (key === STORAGE_KEY) throw Error('quota');
    setItem(key, value);
  };
  const save = createSaveStore(() => storage);
  save.read();
  assert.equal(save.write(snapshot(8)), 'unavailable');
  const malformed = { ...snapshot(42), grid: [] };
  assert.throws(() => importSnapshot(JSON.stringify(exportSnapshot(malformed))), /ساختار/);
  assert.equal(save.read().state.day, 7);
});
