import test from 'node:test';
import assert from 'node:assert/strict';
import { installSaveSession } from '../js/app/save-session.js';
import { STORAGE_KEY } from '../js/core/game-state.js';

function fixture(t, withLock) {
  const elements = new Map(['saveSession', 'saveSessionMessage', 'saveSessionReload'].map(id => [id, {}]));
  const app = { inert: false }, listeners = new Map();
  const game = {
    S: { day: 1 }, canPlay: false, initialSaveSource: 'primary',
    showSaveStatus() {}, saveChanged: () => true,
    reloadSnapshot() { this.S.day++; return 'primary'; },
    draw() {}
  };
  let accept;
  const host = { navigator: {}, addEventListener: (event, handler) => listeners.set(event, handler) };
  if (withLock) host.navigator.locks = { request(name, { signal }, callback) {
    assert.equal(name, STORAGE_KEY);
    assert.equal(signal.aborted, false);
    accept = callback;
    return Promise.resolve();
  } };
  const previousDocument = globalThis.document;
  globalThis.document = { getElementById: id => elements.get(id), querySelectorAll: () => [app] };
  t.after(() => { globalThis.document = previousDocument; });
  const clock = { start() {}, stop() {}, resetElapsed() {}, suspend() {} };
  installSaveSession(game, clock, host);
  return { game, app, elements, listeners, accept: () => accept() };
}

test('the waiting tab starts from the latest save and absorbs a late write from the closing owner', t => {
  const f = fixture(t, true);
  assert.equal(f.app.inert, true);
  assert.equal(f.game.canPlay, false);
  f.accept();
  assert.equal(f.app.inert, false);
  assert.equal(f.game.S.day, 2);
  f.listeners.get('storage')({ key: STORAGE_KEY });
  assert.equal(f.game.S.day, 3);
  assert.equal(f.game.S.paused, true);
  assert.equal(f.app.inert, false);
  f.game.onSaveWritten();
  f.listeners.get('storage')({ key: STORAGE_KEY });
  assert.equal(f.app.inert, true);
  assert.equal(f.elements.get('saveSessionReload').hidden, false);
});

test('a browser without Web Locks blocks playback on a changed shared save', t => {
  const f = fixture(t, false);
  assert.equal(f.game.canPlay, true);
  f.listeners.get('storage')({ key: STORAGE_KEY });
  assert.equal(f.game.canPlay, false);
  assert.equal(f.game.S.paused, true);
});
