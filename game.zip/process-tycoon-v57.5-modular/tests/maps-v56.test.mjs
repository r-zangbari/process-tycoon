import test from 'node:test';
import assert from 'node:assert/strict';
import {simulateWaterDay} from '../js/features/water/model/water-supply.js';
import {atlasRoutes,sceneSignature} from '../js/features/country/view/map-design.js';
import {campusNetwork,cityServiceDistrict,cityServiceMap,countryNetwork,renderCountryNetwork} from '../js/features/country/view/map-operations.js';

function fresh(){
 return {
  day:4,
  money:10_000,
  u:[],
  fr:{water:.6,power:.8},
  dem:{water:20,power:10},
  tanks:{power:100,rawwater:150},
  waterSupply:{reserve:0,sources:{desal:{level:1,connected:true}},coastal:{built:true,stock:20}}
 };
}

test('the water route distinguishes coastal storage and same-day transfer into the raw water tank',()=>{
 const s=fresh();
 const cap=()=>150;
 simulateWaterDay(s,{cap});
 let steps=Object.fromEntries(countryNetwork(s).steps.map(x=>[x.id,x]));
 assert.equal(s.waterSupply.today.coastalStored,100);
 assert.equal(steps.raw.tone,'warn');
 assert.match(steps.coast.note,/مخزن خشکی پر است/);
 assert.equal(steps.city.qty,12);
 s.day++;
 s.tanks.rawwater=70;
 simulateWaterDay(s,{cap});
 steps=Object.fromEntries(countryNetwork(s).steps.map(x=>[x.id,x]));
 assert.equal(s.waterSupply.today.coastalDelivered,45);
 assert.equal(steps.raw.tone,'ok');
 assert.match(steps.coast.note,/سقف انتقال روزانه/);
 s.day++;
 assert.equal(countryNetwork(s).steps[0].qty,undefined);
});

test('the atlas renders the selected layer and real management shortcut without changing state',()=>{
 const s={...fresh(),tab:'c',mapLayer:'services',mapNetwork:'power',mapStep:'power-city'};
 const initial=structuredClone(s);
 assert.deepEqual(atlasRoutes(s).map(x=>x.id),['power-city']);
 assert.equal(atlasRoutes(s)[0].selected,true);
 assert.match(renderCountryNetwork(s),/data-a="dev-open"/);
 assert.deepEqual(s,initial);
 const signature=sceneSignature(s,[]);
 s.money+=1000;
 s.day++;
 assert.equal(sceneSignature(s,[]),signature);
 s.fr.power=.3;
 assert.notEqual(sceneSignature(s,[]),signature);
 s.mapNetwork='feed';
 assert.deepEqual(atlasRoutes(s).map(x=>x.id),['oil','gas','terminal']);
});

test('industry flow uses only the selected running unit’s current feed and storage report',()=>{
 const s=fresh();
 s.u=[{t:1,st:'run',dayEconomics:{day:s.day,feeds:[{product:'rawwater',required:45,delivered:20,missing:25}],products:[{product:'water',accepted:10,spilled:3}]}}];
 assert.equal(campusNetwork(s,0).inputTone,'bad');
 assert.equal(campusNetwork(s,0).outputTone,'warn');
 s.u[0].st='trip';
 assert.equal(campusNetwork(s,0).inputTone,'idle');
 s.u[0].st='run';
 s.day++;
 assert.equal(campusNetwork(s,0).outputTone,'idle');
});

test('city coverage counts parks within two blocks independently of shared utility delivery',()=>{
 const s=fresh(),grid=Array(81).fill(null);
 grid[0]={type:'home',level:1};
 grid[11]={type:'home',level:1};
 grid[2]={type:'park',level:1};
 s.cityMaps={test:grid};
 assert.deepEqual([...cityServiceMap(s,'test')],[[0,true],[11,true]]);
 grid[2]=null;
 grid[18]={type:'service',level:1};
 const district=cityServiceDistrict(s,'test',0);
 assert.equal(district.homes,2);
 assert.equal(district.covered,1);
 assert.deepEqual(district.ratios,{water:.6,power:.8});
});
