import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync,statSync} from 'node:fs';
import {renderProcessFacility,renderOffshoreRig,facilityImagePath,offshoreImagePath} from '../js/features/country/view/strategy-graphics.js';
const root=new URL('../',import.meta.url);
const main=readFileSync(new URL('js/main.js',root),'utf8');
const catalog=JSON.parse(readFileSync(new URL('assets/isometric/asset-manifest.json',root),'utf8'));
const html=readFileSync(new URL('index.html',root),'utf8');

test('image manifest has 16 uniquely mapped facility PNG-derived sprites and two offshore rigs',()=>{
 assert.equal(catalog.units.length,16);
 assert.equal(new Set(catalog.units.map(e=>e.file)).size,16);
 assert.deepEqual(catalog.units.map(e=>e.type),Array.from({length:16},(_,i)=>i));
 for(const {type,file} of catalog.units){
  assert.equal(facilityImagePath(type),`./assets/isometric/${file}`);
  const path=new URL(`assets/isometric/${file}`,root);
  assert.ok(existsSync(path));assert.ok(statSync(path).size>1000);
  assert.match(renderProcessFacility(type,'run'),new RegExp(file.replace('.','\\.')));
 }
 for(const kind of ['oil','gas']){
  const file=`offshore-${kind}.webp`;
  assert.equal(offshoreImagePath(kind),`./assets/isometric/${file}`);
  assert.ok(existsSync(new URL(`assets/isometric/${file}`,root)));
  assert.match(renderOffshoreRig(kind,true),new RegExp(file.replace('.','\\.')));
  assert.doesNotMatch(renderOffshoreRig(kind,false),/\.webp/);
 }
});
test('site map, unit selection, catalog thumbnails and context-only offshore UI remain connected',()=>{
 assert.match(main,/data-hmi="\$\{i\}"/);
 assert.match(main,/renderProcessFacility\(u\.t,u\.st\)/);
 assert.match(main,/class="catalog-art" src="\$\{facilityImagePath\(t\)\}"/);
 assert.match(main,/renderOffshoreRig\(chosen,current\.stage===5,current\.health\)/);
 assert.doesNotMatch(html,/data-t="offshore"/);
});
