import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const main=readFileSync(new URL('../js/main.js',import.meta.url),'utf8');
const gfx=readFileSync(new URL('../js/features/country/view/strategy-graphics.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../css/style.css',import.meta.url),'utf8');
test('city sprites bottom-anchor to lot centers and retain all 81 saved lot indexes',()=>{
 assert.match(main,/translate\(\$\{px\} \$\{py\}\)/);
 assert.match(gfx,/const width=86,height=width\*\(CITY_ART_RATIO\[key\]/);
 assert.match(gfx,/y="\$\{groundY-height\}"/);
 assert.match(main,/const pageStart=cityPage\*24,pageEnd=Math\.min\(81,pageStart\+24\)/);
 assert.match(main,/data-city-cell="\$\{i\}"/);
});
test('national country map hitboxes remain selectable, without black selected square',()=>{
 assert.match(main,/class="national-plot-hit" data-c="\$\{i\}"/);
 assert.doesNotMatch(main,/stroke="#173c35" stroke-width="3"/);
 assert.match(main,/national-selection-aura/);
 assert.match(css,/national-map \.national-plot-hit/);
});
test('regional duplicate buildings are hidden without deleting actual buildings or economic region metrics',()=>{
 assert.doesNotMatch(main,/const bl=S\.grid\.map\(\(b,i\)=>b\?bld/);
 assert.doesNotMatch(main,/\$\{regionLines\}\$\{regionalTownLayers\}/);
 assert.match(main,/REGIONS\.map\(\(\[name\],i\)=>/);
});
