import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState} from '../js/core/game-state.js';
import {effectiveTradePort,tradeConditionsText} from '../js/features/products/model/trade-conditions.js';
import {militaryState,placeUnit,hireOperators,advanceMilitaryDay,strikeSite,sendConvoy,seaStatus,laneCovered,convoyPosition,placementError,suggestSpot,
 CONVOY_COST,CONVOY_PAY,CONVOY_DAYS,BLOCKADE_FACTOR,LANE,ENEMY_SITES} from '../js/features/military/model/military.js';
import {renderDefensePanel} from '../js/features/military/view/tactical-panel.js';
import {renderVectorMap} from '../js/features/country/view/map-vector.js';

const fresh=()=>{const s=createFreshState();s.tab='c';s.money=90000;s.day=1;s.seed=5;s.port=100;return s};
function startBlockade(s){const st=militaryState(s);st.blockade.next=0;s.day=Math.max(s.day,20);advanceMilitaryDay(s);assert.equal(seaStatus(s).blockade,true)}
function nearPoint(s,kind,x,z,reach=16){for(let r=0;r<=reach;r++)for(let k=0;k<36;k++){const a=k*Math.PI/18,px=Math.round((x+Math.cos(a)*r)*10)/10,pz=Math.round((z+Math.sin(a)*r)*10)/10;if(!placementError(s,kind,px,pz))return {x:px,z:pz}}return null}

test('blockade starts late, cuts port capacity and ends by expiry',()=>{
 const s=fresh();s.day=5;const st=militaryState(s);st.blockade.next=0;advanceMilitaryDay(s);
 assert.equal(seaStatus(s).blockade,false,'not before day 18');
 startBlockade(s);
 assert.equal(effectiveTradePort(s),100*BLOCKADE_FACTOR);
 assert.match(tradeConditionsText(s),/محاصرهٔ دریایی/);
 const until=st.blockade.until;s.day=until;advanceMilitaryDay(s);
 assert.equal(seaStatus(s).blockade,false);assert.equal(effectiveTradePort(s),100);assert.ok(st.blockade.next>s.day);
});

test('a strike that cripples the southern fleet breaks the blockade at once; a downed fleet cannot blockade',()=>{
 const s=fresh();startBlockade(s);
 const e=ENEMY_SITES.find(v=>v.id==='s'),p=nearPoint(s,'missile_city',e.x*.9,e.z*.5);assert.ok(p);
 assert.equal(placeUnit(s,'missile_city',p.x,p.z),'');hireOperators(s,3);s.day+=6;const u=s.military.units[0];u.ammo=6;
 let r;for(let i=0;i<3&&seaStatus(s).blockade;i++)r=strikeSite(s,'s');
 assert.equal(seaStatus(s).blockade,false);assert.match(r.message,/محاصره/);assert.equal(effectiveTradePort(s),100);
 s.military.blockade.next=0;s.day+=1;advanceMilitaryDay(s);assert.equal(seaStatus(s).blockade,false,'fleet is down');
});

test('merchant ships: pay on arrival, one at a time, cost money up front',()=>{
 const s=fresh();const money=s.money;
 assert.equal(sendConvoy(s),'');assert.equal(s.money,money-CONVOY_COST);assert.match(sendConvoy(s),/در راه/);
 assert.equal(convoyPosition(s).t,0);
 s.day+=Math.floor(CONVOY_DAYS/2);const mid=convoyPosition(s);assert.ok(mid.t>0&&mid.t<1);assert.ok(Math.abs(mid.x-LANE[0][0])>0);
 s.day=1+CONVOY_DAYS;advanceMilitaryDay(s);
 assert.equal(s.money,money-CONVOY_COST+CONVOY_PAY);assert.equal(s.military.convoy.delivered,1);assert.equal(convoyPosition(s),null);
 s.money=100;assert.match(sendConvoy(s),/سرمایه/);
});

test('in a blockade an uncovered ship is shot down; a covered lane lets it through',()=>{
 const run=cover=>{
  const s=fresh();startBlockade(s);
  if(cover){const p=nearPoint(s,'drone_base',6,26);assert.ok(p);placeUnit(s,'drone_base',p.x,p.z);hireOperators(s,3);s.day+=6;s.military.blockade.until=s.day+10}
  sendConvoy(s);s.day+=CONVOY_DAYS;
  assert.equal(laneCovered(s),cover);advanceMilitaryDay(s);
  return {delivered:s.military.convoy.delivered,lost:s.military.convoy.lost,income:s.military.convoy.income};
 };
 const bare=run(false),escorted=run(true);
 assert.deepEqual([bare.delivered,bare.lost],[0,1]);assert.equal(bare.income,0);
 assert.deepEqual([escorted.delivered,escorted.lost],[1,0]);assert.equal(escorted.income,CONVOY_PAY);
});

test('panel shows blockade status, cover warning and the convoy button; saves are repaired',()=>{
 const s=fresh();
 let html=renderDefensePanel(s);assert.match(html,/مسیر دریایی باز است/);assert.match(html,/data-a="mil-convoy"/);
 startBlockade(s);sendConvoy(s);
 html=renderDefensePanel(s);assert.match(html,/محاصرهٔ دریایی فعال/);assert.match(html,/بدون پوشش/);assert.match(html,/data-a="mil-convoy"[^>]*disabled/);
 const t=fresh();t.military={blockade:{next:'x',until:-4},convoy:{ship:{start:'a',arrive:3},delivered:-1}};
 const m=militaryState(t);assert.equal(m.convoy.ship,null);assert.equal(m.convoy.delivered,0);assert.equal(m.blockade.until,0);assert.equal(m.blockadeOn,false);
});

test('the vector map draws the sea lane, the blockade and the ship',()=>{
 const s=fresh();let svg=renderVectorMap(s,[]);assert.match(svg,/#7fd0ff/);assert.doesNotMatch(svg,/کشتی تجاری ·/);
 startBlockade(s);sendConvoy(s);svg=renderVectorMap(s,[]);
 assert.match(svg,/محاصرهٔ دریایی/);assert.match(svg,/کشتی تجاری ·/);assert.match(svg,/#ff4a3d/);
});
