import test from 'node:test';
import assert from 'node:assert/strict';
import { CITIES } from '../js/data/world-map.js';
import { D, GW, GH, MK, PR, SF, TY, setImportMultiplier } from '../js/data/catalog.js';
import { createFreshState, normalizeState, STORAGE_KEY } from '../js/core/game-state.js';
import { createProcessModel } from '../js/engine/process.js';
import { auditSystemLinks } from '../js/engine/integration-audit.js';
import { installMilitaryActions } from '../js/features/military/actions.js';
import { MIL, militaryState, moveUnit, placementError, terrainAt } from '../js/features/military/model/military.js';
import { atlasHeight } from '../js/features/country/model/atlas-terrain.js';
import { createStarterCityGrid } from '../js/features/country/model/urban-economy.js';
import { effectiveTradePort, remainingTradePort } from '../js/features/products/model/trade-conditions.js';
import { quoteProductTrade } from '../js/features/products/model/product-market.js';
import { simulateWaterDay } from '../js/features/water/model/water-supply.js';
import { countryNetwork } from '../js/features/country/view/map-operations.js';

function fresh() {
  const S = createFreshState();
  normalizeState(S, { D, GW, GH, MK, PR, setImportMultiplier });
  Object.assign(S, { day: 20, money: 50000, tab: 'c', port: 100, mapLayer: 'defense' });
  return S;
}

test('expanded dry ground can be used and a selected location costs only on confirmation', () => {
  const S = fresh(), game = { S, ui: {}, actions: {} };
  installMilitaryActions(game);
  game.actions['mil-tool']({ k: 'radar' });
  assert.ok(atlasHeight(36, -17) > 0.1);
  game.previewDefenseSite(36, -17);
  assert.equal(S.money, 50000);
  assert.equal(S.military.units.length, 0);
  assert.deepEqual(game.ui.defenseSite, { x: 36, z: -17, tool: 'radar' });
  game.actions['mil-confirm']();
  game.actions['mil-confirm']();
  assert.equal(S.money, 50000 - MIL.radar.cost);
  const [u] = S.military.units;
  S.day = u.ready;
  assert.equal(moveUnit(S, u.id, 36, -25), '');
  assert.match(placementError(S, 'radar', 36, -17), /فاصله/);
  assert.match(placementError(S, 'radar', 36, -25), /فاصله/);
  assert.equal(terrainAt(0, 37), 'sea');
});

test('active blockade and regional damage limit the same shared port across views and recover without undoing past use', () => {
  const S = fresh();
  const m = militaryState(S);
  m.blockade.until = S.day + 1;
  m.damaged.port = S.day + 1;
  S.portCapacityToday = 26.25;
  S.portUsedToday = 10;
  S.portRemainingToday = 16.25;
  assert.equal(effectiveTradePort(S), 26.25);
  assert.equal(remainingTradePort(S), 16.25);
  assert.equal(countryNetwork(S, 'feed').steps.find(x => x.id === 'terminal').qty, 16.25);
  assert.equal(quoteProductTrade(S, 'crude', 'buy', 90, { PR, cap: () => 150 }).quantity, 16.25);
  S.day++;
  assert.equal(remainingTradePort(S), 90);
  assert.equal(countryNetwork(S, 'feed').steps.find(x => x.id === 'terminal').qty, 90);
});

test('reopening a source restores output and damage affects only the connected city contribution', () => {
  const base = fresh(), damaged = fresh();
  for (const S of [base, damaged]) {
    Object.assign(S.tanks, { power: 500, water: 500, gas: 500, fuel: 500 });
    S.waterSupply = { sources: { groundwater: { level: 1, connected: true } } };
    S.cityMaps = Object.fromEntries([CITIES[1], CITIES[2]].map(city => {
      const grid = createStarterCityGrid();
      grid[0] = { type: 'shop', level: 1 };
      return [city.name, grid];
    }));
  }
  Object.assign(militaryState(damaged).damaged, { 'water-groundwater': 21, capital: 21 });
  const run = S => {
    const report = simulateWaterDay(S, { cap: () => 150 });
    createProcessModel({ S, TY, SF, PR, MK, cl: (x, a, b) => Math.max(a, Math.min(b, x)), r: () => .5, log() {} })
      .country(1, 0, CITIES);
    return report;
  };
  const output = run(base);
  const narrowed = run(damaged);
  assert.equal(output.quantity, 30);
  assert.equal(narrowed.quantity, 22.5);
  assert.match(narrowed.sources.groundwater.status, /اختلال منطقه‌ای/);
  assert.equal(damaged.urbanToday.tax / base.urbanToday.tax, .875);
  assert.equal(damaged.pop, base.pop);
  damaged.day++;
  assert.equal(simulateWaterDay(damaged, { cap: () => 150 }).quantity, 30);
});

test('audit flags simultaneous contracts that rival one another for the same capacity', () => {
  const S = fresh();
  S.tradeContracts = [
    { remaining: 80, days: 1 },
    { remaining: 60, days: 1 }
  ];
  const initial = structuredClone(S);
  assert.equal(auditSystemLinks(S).links.find(e => e.label === 'تعهدات صادراتی').status, 'warn');
  assert.deepEqual(S, initial);
});

test('the production entry point applies a new blockade and damage before daily contracts', async () => {
  const S = fresh();
  S.day = 19;
  S.tanks.methanol = 100;
  S.hold.methanol = true;
  S.tradeContracts = [{ id: 1, p: 'methanol', qty: 100, remaining: 100, delivered: 0, days: 10, unitPrice: 2, advanceBalance: 0 }];
  const defense = militaryState(S);
  defense.blockade.next = 20;
  defense.raid.next = 99;
  const elements = new Map();
  const old = { document: globalThis.document, storage: globalThis.localStorage, interval: globalThis.setInterval, timeout: globalThis.setTimeout };
  globalThis.localStorage = {
    getItem: key => key === STORAGE_KEY ? JSON.stringify(S) : null,
    setItem() {}
  };
  globalThis.setInterval = () => 1;
  globalThis.setTimeout = () => 1;
  globalThis.document = {
    activeElement: null,
    querySelector: key => {
      if (!key.startsWith('#')) return null;
      if (!elements.has(key)) elements.set(key, { dataset: {}, classList: { toggle() {} }, setAttribute() {} });
      return elements.get(key);
    },
    querySelectorAll: () => [],
    getElementById: () => null,
    addEventListener() {}
  };
  try {
    const { createGame } = await import('../js/app/create-game.js');
    const game = createGame();
    game.tick();
    assert.equal(game.S.day, 20);
    assert.equal(game.S.portCapacityToday, 35);
    assert.equal(game.S.tradeContracts[0].delivered, 35);
    game.S.military.raid.incoming = { zone: 'port', from: 's', day: 21, strength: 1 };
    game.tick();
    assert.equal(game.S.day, 21);
    assert.equal(game.S.portCapacityToday, 26.25);
    assert.equal(game.S.tradeContracts[0].delivered, 61.25);
  } finally {
    globalThis.document = old.document;
    globalThis.localStorage = old.storage;
    globalThis.setInterval = old.interval;
    globalThis.setTimeout = old.timeout;
  }
});
