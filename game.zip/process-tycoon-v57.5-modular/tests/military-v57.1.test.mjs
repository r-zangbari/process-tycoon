import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState} from '../js/core/game-state.js';
import {TY,PR} from '../js/data/catalog.js';
import {ENEMY_SITES,ENEMY_DOWN_DAYS,DAMAGED_BELOW,terrainAt,militaryState,placeUnit,hireOperators,advanceMilitaryDay,unitStatus,shieldPoints,repairUnit,repairCost,strikeSite,
 enemyList,incomingRaid,placementError,staffing,selectUnit,suggestSpot,MIL} from '../js/features/military/model/military.js';
import {renderDefensePanel} from '../js/features/military/view/tactical-panel.js';
import {renderVectorMap} from '../js/features/country/view/map-vector.js';

const fresh=()=>{const s=createFreshState();s.tab='c';s.money=90000;s.day=1;return s};
// A valid land site within `reach` of a point, so tests do not depend on hand-picked coordinates.
function nearPoint(s,kind,x,z,reach=14){
 for(let r=0;r<=reach;r+=1)for(let k=0;k<36;k++){const a=k*Math.PI/18,px=Math.round((x+Math.cos(a)*r)*10)/10,pz=Math.round((z+Math.sin(a)*r)*10)/10;if(!placementError(s,kind,px,pz))return {x:px,z:pz}}
 return null;
}
function forward(s,kind,siteId){const e=ENEMY_SITES.find(v=>v.id===siteId),p=nearPoint(s,kind,e.x*.8,e.z*.8,10);assert.ok(p,'site near '+siteId);assert.equal(placeUnit(s,kind,p.x,p.z),'');return s.military.units.at(-1)}

test('enemy sites are at sea and listed with their state',()=>{
 for(const e of ENEMY_SITES)assert.equal(terrainAt(e.x,e.z),'sea',e.id);
 const s=fresh();const list=enemyList(s);
 assert.equal(list.length,ENEMY_SITES.length);assert.ok(list.every(e=>e.hp===100&&!e.down&&e.shooters===0&&e.nearest===null));
 assert.equal(s.military,undefined,'listing never creates state');
});

test('a strike needs an active armed strike unit in range and explains why not',()=>{
 const s=fresh();
 assert.match(strikeSite(s,'nw').error,/یگان ضربهٔ فعال/);
 assert.match(strikeSite(s,'zz').error,/معتبر/);
 const spot=suggestSpot(s,'drone_base','capital');placeUnit(s,'drone_base',spot.x,spot.z);hireOperators(s,3);s.day=10;
 assert.match(strikeSite(s,'nw').error,/نزدیک‌ترین/);
});

test('strikes damage the site, spend ammunition, and a full strike disables it with loot',()=>{
 const s=fresh();s.seed=5;
 const u=forward(s,'missile_city','nw');hireOperators(s,3);s.day=10;
 const e0=enemyList(s).find(e=>e.id==='nw');assert.equal(e0.shooters,1,'unit in range');
 const money=s.money,ammo=u.ammo;
 let r=strikeSite(s,'nw');assert.ok(r.message,r.error);
 assert.equal(u.ammo,ammo-1);assert.equal(s.military.enemies.nw.hp,100-MIL.missile_city.strike);
 r=strikeSite(s,'nw');r=strikeSite(s,'nw');
 assert.equal(s.military.enemies.nw.hp,0);assert.ok(s.military.enemies.nw.down>s.day);
 assert.equal(s.money,money+600);assert.match(r.message,/غنیمت/);assert.equal(s.military.stats.strikes,3);
 assert.match(strikeSite(s,'nw').error,/از کار افتاده/);
 // After the downtime the site returns weak.
 s.day=s.military.enemies.nw.down;advanceMilitaryDay(s);
 assert.equal(s.military.enemies.nw.down,0);assert.equal(s.military.enemies.nw.hp,40);
});

test('striking the origin of an incoming raid before it lands cancels it',()=>{
 const s=fresh();s.seed=5;
 const u=forward(s,'missile_city','nw');hireOperators(s,3);s.day=10;u.ammo=6;
 militaryState(s).raid.incoming={zone:'north',from:'nw',day:s.day+2,strength:4};
 assert.equal(incomingRaid(s).fromName,ENEMY_SITES[0].name);
 strikeSite(s,'nw');strikeSite(s,'nw');const r=strikeSite(s,'nw');
 assert.match(r.message,/خنثی/);assert.equal(incomingRaid(s),null);assert.ok(s.military.raid.next>s.day+10);
 const before=s.military.stats.hits;s.day+=3;advanceMilitaryDay(s);assert.equal(s.military.stats.hits,before);
});

test('raids launch only from working sites; a weakened site launches weaker raids; all down means a pause',()=>{
 const s=fresh();s.seed=5;militaryState(s);
 for(const e of ENEMY_SITES)s.military.enemies[e.id].down=999;
 s.military.raid.next=0;s.day=30;advanceMilitaryDay(s);
 assert.equal(incomingRaid(s),null);assert.ok(s.military.raid.next>s.day);
 const t=fresh();t.seed=5;militaryState(t);
 for(const e of ENEMY_SITES)if(e.id!=='s')t.military.enemies[e.id].down=999;
 t.military.raid.next=0;t.day=30;advanceMilitaryDay(t);
 assert.equal(incomingRaid(t).from,'s');
 const full=incomingRaid(t).strength;
 const u=fresh();u.seed=5;militaryState(u);
 for(const e of ENEMY_SITES)if(e.id!=='s')u.military.enemies[e.id].down=999;
 u.military.enemies.s.hp=10;u.military.raid.next=0;u.day=30;advanceMilitaryDay(u);
 assert.ok(incomingRaid(u).strength<full);
});

test('a hit damages installations near the target; wrecks are removed; damaged ones stop working until repaired',()=>{
 const s=fresh();s.seed=5;
 const spot=suggestSpot(s,'sam_short','port');placeUnit(s,'sam_short',spot.x,spot.z);hireOperators(s,2);s.day=10;
 const u=s.military.units[0];assert.equal(unitStatus(s,u),'active');
 const logs=[];
 militaryState(s).raid.incoming={zone:'port',from:'s',day:s.day+1,strength:6};u.ammo=0;
 s.day++;advanceMilitaryDay(s,m=>logs.push(m));
 assert.ok(u.hp<100);
 u.hp=DAMAGED_BELOW-5;assert.equal(unitStatus(s,u),'damaged');assert.equal(shieldPoints(s,'port'),0);assert.equal(staffing(s).crew.get(u.id),false);
 const cost=repairCost(u),money=s.money;assert.ok(cost>0);
 assert.equal(repairUnit(s,u.id),'');assert.equal(s.money,money-cost);assert.equal(u.hp,100);assert.equal(unitStatus(s,u),'active');
 assert.match(repairUnit(s,u.id),/سالم/);
 u.hp=10;militaryState(s).raid.incoming={zone:'port',from:'s',day:s.day+1,strength:6};u.ammo=0;
 s.day++;advanceMilitaryDay(s,m=>logs.push(m));
 assert.equal(s.military.units.length,0,'wreck removed');assert.ok(logs.some(m=>/نابود شد/.test(m)));
});

test('crewed units repair slowly on their own',()=>{
 const s=fresh();const spot=suggestSpot(s,'sam_short','port');placeUnit(s,'sam_short',spot.x,spot.z);hireOperators(s,1);s.day=10;
 const u=s.military.units[0];u.hp=60;s.day++;advanceMilitaryDay(s);assert.equal(u.hp,62);
});

test('saved hit points and enemy state are repaired',()=>{
 const s=fresh();
 s.military={units:[{id:1,kind:'radar',x:-6,z:14,level:1,ready:0,hp:-50},{id:2,kind:'sam_short',x:6,z:14,level:1,ready:0,hp:900}],enemies:{nw:{hp:500,down:'x'},zz:{hp:1}},raid:{next:3,incoming:{zone:'port',day:5,strength:3,from:'nope'}}};
 const m=militaryState(s);
 assert.deepEqual(m.units.map(u=>u.hp),[1,100]);
 assert.deepEqual(Object.keys(m.enemies).sort(),ENEMY_SITES.map(e=>e.id).sort());assert.deepEqual(m.enemies.nw,{hp:100,down:0});
 assert.equal(m.raid.incoming.from,'s');
});

test('panel lists enemy sites, shows the origin of a raid and a repair button',()=>{
 const s=fresh();
 let html=renderDefensePanel(s);
 for(const e of ENEMY_SITES)assert.ok(html.includes(e.name));
 assert.match(html,/data-a="mil-strike" data-k="nw"/);
 const spot=suggestSpot(s,'sam_short','port');placeUnit(s,'sam_short',spot.x,spot.z);
 s.military.units[0].hp=50;
 assert.match(renderDefensePanel(s),/data-a="mil-repair"/);
 selectUnit(s,0);s.military.raid.incoming={zone:'port',from:'ne',day:s.day+2,strength:3};
 html=renderDefensePanel(s);assert.ok(html.includes('از '+ENEMY_SITES[1].name));assert.match(html,/tactical-enemy is-origin/);
});

test('the vector map always shows the enemy sites; the origin gets a line to its target',()=>{
 const s=fresh();
 let svg=renderVectorMap(s,[]);
 for(const e of ENEMY_SITES)assert.ok(svg.includes(e.name),e.id);
 s.military=undefined;militaryState(s).raid.incoming={zone:'port',from:'s',day:5,strength:3};
 svg=renderVectorMap(s,[]);assert.match(svg,/stroke-dasharray="10 8"/);
});
