import test from 'node:test';
import assert from 'node:assert/strict';
import {createStarterCityGrid,cityDevelopmentMetrics,summarizeUrbanDevelopment} from '../js/features/country/model/urban-economy.js';
import {auditSystemLinks} from '../js/engine/integration-audit.js';
import {createProcessModel} from '../js/engine/process.js';
import {createFreshState,normalizeState} from '../js/core/game-state.js';
import {D,PR,MK,TY,SF,GW,GH,setImportMultiplier} from '../js/data/catalog.js';
const cities=[{name:'پایتخت'},{name:'بندر جنوبی'}];
const fresh=()=>{const S=createFreshState();normalizeState(S,{D,PR,MK,GW,GH,setImportMultiplier});return S};
const model=S=>createProcessModel({S,TY,SF,PR,MK,cl:(v,a,b)=>Math.max(a,Math.min(b,v)),r:()=>0.5,log:()=>{}});

test('starting city plan is deterministic, 9x9, with populated housing, park and service center',()=>{
 const grid=createStarterCityGrid(),m=cityDevelopmentMetrics(grid);
 assert.equal(grid.length,81);
 assert.deepEqual([m.homes,m.parks,m.services,m.shops],[5,1,1,0]);
 assert.equal(m.pop,28535);
 assert.ok(m.coverage>=0&&m.coverage<=100);
});
test('city construction changes national population, utility demand and tax; unloaded city remains baseline',()=>{
 const maps={},before=summarizeUrbanDevelopment(maps,cities);
 assert.equal(before.population,2*28535);assert.equal(before.developed,0);assert.equal(before.tax,0);
 maps['پایتخت']=createStarterCityGrid();maps['پایتخت'][0]={type:'shop',level:1};
 maps['پایتخت'][2]={type:'home',level:2};
 const after=summarizeUrbanDevelopment(maps,cities);
 assert.ok(after.population>before.population);
 assert.ok(after.demand.power>before.demand.power);
 assert.ok(after.demand.gas>before.demand.gas);
 assert.ok(after.demand.water>before.demand.water);
 assert.ok(after.tax>0);
 assert.equal(after.places['بندر جنوبی'].pop,28535);
});
test('country settlement actually consumes added city utilities and increases population',()=>{
 const a=fresh(),b=fresh();
 for(const S of [a,b])for(const k of ['power','gas','water','fuel'])S.tanks[k]=4000;
 b.cityMaps['پایتخت']=createStarterCityGrid();b.cityMaps['پایتخت'][0]={type:'shop',level:1};
 model(a).country(1,40,cities);model(b).country(1,40,cities);
 assert.ok(b.dem.power>a.dem.power);
 assert.ok(b.dem.gas>a.dem.gas);
 assert.ok(b.dem.water>a.dem.water);
 assert.ok(b.pop>a.pop);
 assert.ok(b.urbanToday.tax>0);
 assert.ok(b.inc.tax>a.inc.tax);
});
test('country uses supplied port remainder for all spot products, not nominal port twice',()=>{
 const S=fresh();S.tanks.methanol=100;S.tanks.ethylene=100;S.hold.methanol=false;S.hold.ethylene=false;
 model(S).country(1,11,cities);
 const sold=Object.values(S.marketDay).reduce((sum,p)=>sum+(p.sold||0),0);
 assert.ok(sold<=11+1e-9,`port shipment ${sold}`);
 assert.ok(sold>0);assert.ok(S.portRemainingToday>=0);
 assert.equal(Math.round(S.portUsedToday),Math.round(S.port-S.portRemainingToday));
});
test('market index affects actual spot price, and recession shock lowers realized demand',()=>{
 const a=fresh(),b=fresh(),c=fresh();
 for(const S of [a,b,c]){S.tanks.methanol=120;S.hold.methanol=false;S.pm.methanol=1;S.salePrice.methanol=1;}
 b.mkt=1.5;c.economy.shock={type:'demand',days:10};
 model(a).country(1,40,cities);model(b).country(1,40,cities);model(c).country(1,40,cities);
 assert.ok(b.marketDay.methanol.unitPrice>a.marketDay.methanol.unitPrice*1.4);
 assert.ok(c.marketDay.methanol.demand<a.marketDay.methanol.demand);
});
test('cross-system audit finds shipping, HSE and offshore pipeline failures but does not modify state',()=>{
 const S=fresh();S.offshore.oil.stage=5;S.offshore.oil.pipelineLevel=0;S.safe=0;S.portRemainingToday=0;
 const old=JSON.stringify(S),result=auditSystemLinks(S);
 assert.ok(result.links.some(x=>x.label.includes('سکوی نفتی')&&x.status==='warn'));
 assert.ok(result.links.some(x=>x.label.includes('پایانه')&&x.status==='warn'));
 assert.ok(result.links.some(x=>x.label.includes('HSE')&&x.status==='warn'));
 assert.ok(result.links.some(x=>x.label.includes('پروژه‌های توسعه ملی')&&x.status==='info'));
 assert.equal(JSON.stringify(S),old);
});
test('old saves migrate to a normalized city/planning state and keep legacy crude extraction',()=>{
 const S=fresh();S.cities=null;S.cityMaps=null;S.portRemainingToday=undefined;S.portUsedToday=undefined;
 S.u=[{t:9,st:'run',v:D[9].v.map(v=>v[2]),eq:D[9].e.map(()=>({h:95,l:1})),h:D[9].v.map(()=>[]),au:D[9].v.map(()=>0),processState:{}}];
 normalizeState(S,{D,PR,MK,GW,GH,setImportMultiplier});
 assert.ok(S.cities&&S.cityMaps);
 assert.ok(S.u[0].t===9&&S.u[0].st==='run');
 assert.equal(S.portRemainingToday,S.port);
});
