import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState,normalizeState,STORAGE_KEY} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';

test('new UI: interconnection report, city construction, offshore imports and prepayment persist',async()=>{
 const initial=createFreshState();normalizeState(initial,{D,PR,MK,GW,GH,setImportMultiplier});
 initial.tab='m';initial.money=500000;initial.govBudget=15000;initial.paused=true;
 initial.port=40;initial.portRemainingToday=10;initial.offshore.oil.stage=0;
 let saved=JSON.stringify(initial);
 globalThis.localStorage={getItem:k=>k===STORAGE_KEY?saved:null,setItem:(k,v)=>{if(k===STORAGE_KEY)saved=v}};
 const refs=new Map(),listeners=new Map();
 const el=name=>refs.get(name)||refs.set(name,{textContent:'',innerHTML:'',className:'',dataset:{},setAttribute(){},classList:{toggle(){}},addEventListener(){},click(){},value:''}).get(name);
 globalThis.document={activeElement:null,querySelector:q=>q.startsWith('#')?el(q):null,querySelectorAll:()=>[],getElementById:()=>null,
  addEventListener:(type,handler)=>listeners.set(type,[...(listeners.get(type)||[]),handler])};
 const oldInterval=globalThis.setInterval;globalThis.setInterval=()=>1;
 const press=(a,props={})=>{const target={dataset:{a,...props},disabled:false,closest(selector){return selector==='button'?this:null}};listeners.get('click')[1]({target});};
 try{
  await import('../js/main.js');
  assert.match(el('#app').innerHTML,/انبار و فروش/);
  press('manage-section',{k:'overview'});
  assert.match(el('#app').innerHTML,/پایش ارتباط بخش‌های بازی/);
  press('manage-section',{k:'inventory'});
  assert.match(el('#app').innerHTML,/ظرفیت آزاد/);
  assert.equal(typeof el('#exportSave').onclick,'function');
  assert.equal(typeof el('#importSaveInput').onchange,'function');
  press('offshore-import',{p:'oil'});
  let S=JSON.parse(saved);
  assert.equal(S.tanks.crude,10);
  assert.equal(S.portRemainingToday,0);
  press('offshore-import',{p:'gas'});
  S=JSON.parse(saved);assert.equal(S.tanks.sourgas,0);
  press('trade-contract',{p:'methanol',q:'500'});
  S=JSON.parse(saved);
  assert.equal(S.tradeContracts.length,1);
  const advance=S.tradeContracts[0].advance;
  assert.ok(advance>0);assert.equal(S.tradeContracts[0].advanceBalance,advance);
  assert.ok(S.money>499000);
  const previous=S.money;
  press('trade-cancel',{id:String(S.tradeContracts[0].id)});
  S=JSON.parse(saved);assert.equal(S.tradeContracts.length,0);assert.ok(S.money<previous-advance);
  // Visit a city without a previous city-management record and build a service center.
  press('offshore-country'); // move to country; use country map 'city-enter' to set city map.
  press('city-enter',{i:'1'});
  // The city-cell route is best tested via the map's delegated click handler.
  for(const handler of listeners.get('click')||[])handler({detail:0,target:{closest:selector=>selector==='[data-city-cell]'?{dataset:{cityCell:'0'}}:null}});
  // If the handler navigated to city view with a valid city cell, construction must not crash.
  press('city-build',{t:'service'});
  const next=JSON.parse(saved);
  assert.equal(next.cityMaps['پایتخت'][0].type,'service');
  assert.ok(next.cities['پایتخت']?.satisfaction>70);
 }finally{globalThis.setInterval=oldInterval;}
});
