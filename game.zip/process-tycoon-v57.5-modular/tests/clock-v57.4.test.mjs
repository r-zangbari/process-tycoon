import test from 'node:test';
import assert from 'node:assert/strict';
import { createProcessClock } from '../js/engine/game-engine.js';

function fixture({ speed = 1, afterTick = () => {} } = {}) {
  const state = { day: 1, spd: speed, paused: false };
  let now = 0, callback, writes = 0, suspensions = 0;
  const clock = createProcessClock({
    getState: () => state,
    tick() { state.day++; afterTick(state); },
    draw() {},
    save() { writes++; },
    onSuspend() { suspensions++; },
    now: () => now,
    schedule(fn) { callback = fn; return 1; },
    cancel() { callback = null; }
  });
  clock.start();
  return {
    state, clock,
    pass(ms) { now += ms; callback?.(); },
    writes: () => writes,
    suspensions: () => suspensions
  };
}

test('a five-minute scheduling gap pauses without running catch-up days', () => {
  const f = fixture({ speed: 4 });
  f.pass(5 * 60 * 1000);
  assert.equal(f.state.day, 1);
  assert.equal(f.state.paused, true);
  assert.equal(f.suspensions(), 1);
  assert.equal(f.writes(), 1);
  f.pass(500);
  assert.equal(f.writes(), 1);
  f.state.paused = false;
  f.clock.resetElapsed();
  f.pass(500);
  assert.equal(f.state.day, 2);
});

test('visibility suspension cancels partial time and requires manual resume', () => {
  const f = fixture();
  f.pass(1000);
  f.clock.suspend();
  f.pass(30 * 1000);
  assert.equal(f.state.day, 1);
  assert.equal(f.state.paused, true);
  f.state.paused = false;
  f.clock.resetElapsed();
  f.pass(500);
  assert.equal(f.state.day, 1);
  f.pass(1000);
  assert.equal(f.state.day, 2);
});

test('a one-day diagnostic pauses after its first tick even with several days budgeted', () => {
  const f = fixture({ speed: 4, afterTick: state => { state.paused = true; } });
  f.pass(1000);
  assert.equal(f.state.day, 2);
  assert.equal(f.writes(), 1);
  f.pass(1000);
  assert.equal(f.writes(), 1);
});
