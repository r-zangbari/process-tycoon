import test from 'node:test';
import assert from 'node:assert/strict';
import {districtLots,HUB_TYPES} from '../js/features/country/model/country-planning.js';
import {createFreshState,normalizeState} from '../js/core/game-state.js';
import {D,TY,SF,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';
import {createProcessModel} from '../js/engine/process.js';
import {renderCountry} from '../js/features/country/view/country-view.js';
import {renderVectorMap} from '../js/features/country/view/map-vector.js';

const state=()=>{const s=createFreshState();normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});s.grid=Array(GW*GH).fill(null);return s};
const model=s=>createProcessModel({S:s,TY,SF,PR,MK,cl:(v,a,b)=>Math.max(a,Math.min(b,v)),r:()=>.5,log(){}});
const all=(...keys)=>Object.fromEntries(keys.map(k=>[k,1]));
const lot=t=>({t,l:1,c:all(...Object.keys(TY[t].need))});
const day=(s,types)=>{s.grid=Array(GW*GH).fill(null);types.forEach((t,i)=>{s.grid[i*3]=lot(t)});s.pd={};s.pm={};s.tanks={power:500,gas:500,water:500,fuel:500,...s.tanks};for(const k of ['power','gas','water','fuel'])s.tanks[k]=500;model(s).country(1,0,[]);return s};

test('every building with a product has a market entry, and only the farm hub takes the new types',()=>{
 for(const [k,t] of Object.entries(TY))if(t.key)assert.ok(MK[t.key],k);
 assert.deepEqual(HUB_TYPES.north,['f','g','l','p']);assert.deepEqual(HUB_TYPES.housing,['h']);assert.deepEqual(HUB_TYPES.energy,['k']);
 const s=state();s.grid[0]=lot('l');s.grid[3]=lot('g');s.grid[6]=lot('p');
 const north=districtLots(s,'north').filter(l=>l.type).map(l=>l.type).sort();
 assert.deepEqual(north,['g','l','p']);
 assert.equal(districtLots(s,'housing').some(l=>l.type),false);assert.equal(districtLots(s,'energy').some(l=>l.type),false);
 const ids=['north','housing','energy'].flatMap(id=>districtLots(s,id).map(l=>l.id));assert.equal(new Set(ids).size,ids.length);
});

test('each new building produces its own product from connected services',()=>{
 const s=state();
 day(s,['g']);assert.equal(s.pd.veg,9);
 day(s,['f']);assert.equal(s.pd.crop,10);
 const dry=state();day(dry,['g']);dry.tanks.power=0;dry.pd={};dry.tanks.water=500;dry.tanks.fuel=500;
 for(const k of ['water','fuel'])dry.tanks[k]=500;dry.tanks.power=0;model(dry).country(1,0,[]);assert.equal(dry.pd.veg,0,'a greenhouse needs power');
});

test('livestock eats crops and a food plant processes the pool: sectors depend on each other',()=>{
 const full=state();day(full,['f','g','l','p']);
 // farm 10 crop -> livestock eats 6 -> plant takes 4 crop + 4 veg
 assert.equal(full.pd.meat,8);assert.equal(full.pd.crop,0);assert.equal(full.pd.veg,5);assert.equal(full.pd.food,14);
 const noFarm=state();day(noFarm,['l']);assert.equal(noFarm.pd.meat,0,'no feed, no meat');
 const half=state();day(half,['f','l','l']);assert.ok(Math.abs(half.pd.meat-(8+8*4/6))<1e-9,'only 10 crop: 6 for the first herd, 4 of 6 for the second');assert.equal(half.pd.crop,0);
 const bare=state();day(bare,['p']);assert.equal(bare.pd.food,0,'nothing to process');
});

test('processing adds value; food lifts the food index and city tax',()=>{
 const raw=state();day(raw,['f','g','l']);const withPlant=state();day(withPlant,['f','g','l','p']);
 assert.ok(withPlant.inc.eco>raw.inc.eco,'processed food is worth more than the raw inputs');
 assert.ok(withPlant.foodIndex>0&&withPlant.foodIndex<=1);assert.equal(state().foodIndex,undefined);
 const none=state();day(none,['f']);assert.equal(none.foodIndex,0);
});

test('hub panel offers every agricultural building and explains the chain; maps draw them',()=>{
 const s=createFreshState();s.tab='c';s.countryHub='north';s.sel=districtLots(s,'north').find(l=>!l.type).id;
 const html=renderCountry({S:s,TY,PR,CITIES:[],fa:String,cityDevelopmentMetrics:()=>({}),offshoreCard:()=>'',countryEconomyCard:()=>'',REGIONS:[],regionMetrics:()=>({})});
 for(const t of ['f','g','l','p'])assert.match(html,new RegExp('data-a="build" data-t="'+t+'"'));
 assert.match(html,/زنجیرهٔ غذا/);assert.doesNotMatch(html,/data-t="k"/);
 s.grid[s.sel]=lot('l');s.grid[s.sel].l=2;
 const svg=renderVectorMap(s,[]);assert.ok(svg.length>1000);
});

test('a hostile strike on a hub halves its output while the damage marker lasts',()=>{
 const s=state();day(s,['f']);assert.equal(s.pd.crop,10);
 const hit=state();hit.military={damaged:{north:hit.day+3}};day(hit,['f','l']);
 assert.equal(hit.pd.crop,5-Math.min(5,6*.5));
 const k=state();k.grid=Array(GW*GH).fill(null);k.grid[0]=lot('k');k.military={damaged:{energy:k.day+3}};k.pd={};k.pm={};for(const x of ['power','gas','water','fuel'])k.tanks[x]=500;model(k).country(1,0,[]);
 const ok=state();ok.grid=Array(GW*GH).fill(null);ok.grid[0]=lot('k');ok.pd={};ok.pm={};for(const x of ['power','gas','water','fuel'])ok.tanks[x]=500;model(ok).country(1,0,[]);
 assert.equal(k.pd.goods,ok.pd.goods/2);
 const over=state();over.military={damaged:{north:over.day-1}};day(over,['f']);assert.equal(over.pd.crop,10,'expired damage has no effect');
});
