import test from 'node:test';import assert from 'node:assert/strict';
import {districtLots,countrySnapshot} from '../js/features/country/model/country-planning.js';
import {createFreshState,normalizeState} from '../js/core/game-state.js';
import {D,TY,SF,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';
import {createProcessModel} from '../js/engine/process.js';
const state=()=>{const s=createFreshState();normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});return s};
test('districts partition empty land and every legacy asset appears exactly once without mutation',()=>{
 const s=state();s.grid[0]={t:'f',l:3,c:{water:1},hub:'energy'};s.grid[1]={t:'k',l:2,c:{gas:1}};
 const before=JSON.stringify(s),all=['north','housing','energy'].flatMap(id=>districtLots(s,id));
 assert.equal(new Set(all.map(l=>l.id)).size,s.grid.length);assert.equal(all.length,s.grid.length);assert.equal(JSON.stringify(s),before);
 assert.equal(districtLots(s,'north').find(l=>l.id===0).level,3);assert.ok(districtLots(s,'energy').some(l=>l.id===1));
});
test('farm connection requires actual shared tank supply; output collapses when either utility is short',()=>{
 const s=state();s.grid=Array(GW*GH).fill(null);s.grid[0]={t:'f',l:1,c:{water:1,fuel:1}};
 const model=createProcessModel({S:s,TY,SF,PR,MK,cl:(v,a,b)=>Math.max(a,Math.min(b,v)),r:()=>.5,log(){}});
 s.tanks.water=100;s.tanks.fuel=0;model.country(1,0,[]);assert.equal(s.pd.crop,0);
 s.pd={};s.tanks.water=100;s.tanks.fuel=100;model.country(1,0,[]);assert.equal(s.pd.crop,10);assert.ok(s.inc.eco>0);assert.ok(s.tanks.water<100);assert.ok(s.tanks.fuel<100);
 const row=countrySnapshot(s).find(p=>p.key==='water');assert.equal(row.demand,10);assert.equal(row.delivery,10);
});
