import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {createFreshState,normalizeState} from '../js/core/game-state.js';import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';
import {offshoreTransferAlerts,renderAlertBubbles} from '../js/features/offshore/view/offshore-alert.js';
const read=f=>fs.readFileSync(new URL('../'+f,import.meta.url),'utf8');
const readCss=(dir='css')=>fs.readdirSync(new URL('../'+dir+'/',import.meta.url),{withFileTypes:true}).flatMap(e=>e.isDirectory()?[readCss(dir+'/'+e.name)]:e.name.endsWith('.css')&&e.name!=='style.css'?[read(dir+'/'+e.name)]:[]).join('\n');
const compactCss=s=>s.replace(/\s*([{};:,])\s*/g,'$1').replace(/\s+/g,' ');
test('bottom dock keeps the five sections and a permanent cash readout',()=>{
 const html=read('index.html'),css=compactCss(readCss());
 for(const t of['i','site','hmi','m','c'])assert.match(html,new RegExp(`data-a="tab" data-t="${t}"`));
 assert.match(html,/id="money-dock"/);assert.match(html,/id="alert-layer"/);
 assert.match(css,/nav#tabs\{position:fixed;inset:auto 0 0 0/);assert.match(read('js/app/draw.js'),/getElementById\('money-dock'\)|\$\('#money-dock'\)/);
});
test('offshore failure that blocks transfer to tanks raises a dismissible warning bubble',()=>{
 const S=createFreshState();normalizeState(S,{D,PR,MK,GW,GH,setImportMultiplier});
 assert.equal(offshoreTransferAlerts(S).length,0);
 Object.assign(S.offshore.oil,{stage:5,project:null,online:true,pipelineLevel:1,pipeHealth:80,incident:{kind:'pipeline-leak',day:7}});
 let a=offshoreTransferAlerts(S);assert.equal(a.length,1);assert.equal(a[0].key,'oil');assert.match(renderAlertBubbles(a),/alert-bubble[\s\S]*ارسال[\s\S]*alert-dismiss/);
 S.offshore.oil.incident={kind:'rig-failure',day:9};a=offshoreTransferAlerts(S);assert.match(a[0].detail,/سکو از کار افتاده/);assert.notEqual(a[0].id,'oil:pipeline-leak:7');
 S.offshore.oil.incident=null;S.offshore.oil.pipeHealth=0;assert.equal(offshoreTransferAlerts(S).length,1);
 S.offshore.oil.pipeHealth=60;assert.equal(offshoreTransferAlerts(S).length,0);
});
test('site-map unit cards offer a restart button beside control room and unit management',()=>{
 const src=read('js/features/industrial-site/view/industry-view.js');assert.match(src,/campus-restart/);assert.match(src,/\['trip',\s*'broken',\s*'off'\]/);
});
test('restart keeps the operator valve opening, setpoint and chosen load instead of resetting to 50%',async()=>{
 const s=createFreshState();normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});s.paused=true;s.money=50000;s.tab='hmi';s.hmiMode='advanced';s.hmiUnit=0;
 s.u=[{t:0,st:'trip',load:120,eq:D[0].e.map(e=>({h:100,l:1,f:null,...(e[1]?{reserve:{h:100,f:null}}:{})})),v:D[0].v.map(v=>v[2]),au:D[0].v.map(()=>0),h:D[0].v.map(()=>[])}];
 s.pid={'0:2':{mode:'manual',mv:73,sp:105},'0:0':{mode:'manual',mv:31}};
 let saved=JSON.stringify(s);const events=new Map(),refs=new Map(),el=q=>refs.get(q)||refs.set(q,{innerHTML:'',textContent:'',dataset:{},setAttribute(){},classList:{toggle(){},add(){}},scrollIntoView(){}}).get(q),old=setInterval;
 globalThis.localStorage={getItem:()=>saved,setItem:(k,v)=>saved=v};globalThis.document={activeElement:null,querySelector:q=>q.startsWith('#')?el(q):null,querySelectorAll:()=>[],getElementById:()=>null,addEventListener:(k,f)=>events.set(k,[...(events.get(k)||[]),f])};globalThis.setInterval=()=>1;
 try{await import('../js/main.js?ui532');events.get('click')[1]({target:{dataset:{a:'restart',i:'0'},disabled:false,closest(sel){return sel==='button'?this:null}}});
  const r=JSON.parse(saved);assert.equal(r.u[0].st,'run');assert.equal(r.u[0].load,120);assert.equal(r.pid['0:2'].mv,73);assert.equal(r.pid['0:0'].mv,31);assert.equal(r.pid['0:2'].sp,105);
 }finally{globalThis.setInterval=old}
});
