import {createHash,randomBytes,randomUUID,timingSafeEqual} from 'node:crypto';

export const goods={water:'آب',fuel:'سوخت',cement:'سیمان',steel:'فولاد',naphtha:'نفتا'};
const production={water:{cost:480,output:20},fuel:{cost:600,output:18},cement:{cost:520,output:16},steel:{cost:900,output:10},naphtha:{cost:650,output:16}};
const beats={steady:'reserve',reserve:'fast',fast:'steady'};
const hour=3600000, day=24*hour, maxStock=5000;
const hash=token=>createHash('sha256').update(token).digest('hex');
export const newWorld=()=>({players:{},offers:{},agreements:{},alliances:{},invites:{},contests:{}});
export class WorldError extends Error {constructor(message,status=400){super(message);this.status=status}}
function requireThat(condition,message,status){
 if(!condition)throw new WorldError(message,status);
}
function text(value,limit=32){
 requireThat(typeof value==='string','نام را وارد کن.');
 const clean=value.trim();
 requireThat(clean.length>=2&&clean.length<=limit&&!/[^\p{L}\p{N} ._\-\u200c]/u.test(clean),'نام باید بین ۲ تا '+limit+' نویسهٔ معتبر باشد.');
 return clean;
}
function integer(value,min,max){
 requireThat(Number.isSafeInteger(value)&&value>=min&&value<=max,'مقدار واردشده خارج از محدوده است.');
 return value;
}
function stockRoom(player,product,quantity){
 requireThat(player.stock[product]+quantity<=maxStock,'مخزن مقصد ظرفیت کافی ندارد.');
}
function playerFor(world,token){
 if(typeof token!=='string'||!/^[0-9a-f]{64}$/.test(token))throw new WorldError('ابتدا وارد حساب آنلاین شو.',401);
 const digest=Buffer.from(hash(token),'hex');
 const player=Object.values(world.players).find(p=>timingSafeEqual(digest,Buffer.from(p.secret,'hex')));
 requireThat(player,'کلید حساب معتبر نیست.',401);
 return player;
}
function prune(records,now,expired){
 for(const [id,record] of Object.entries(records))if(expired(record,now))delete records[id];
}
function recent(records,predicate){return Object.values(records).filter(predicate).reverse().slice(0,100)}
function settleExpired(world,now){
 for(const deal of Object.values(world.agreements)){
  if(['active','offered'].includes(deal.status)&&now>=deal.deadline){
   world.players[deal.buyer].cash+=deal.balance;
   deal.balance=0;deal.status='expired';deal.closed=now;
  }
 }
 for(const contest of Object.values(world.contests)){
  if(['invited','active'].includes(contest.status)&&contest.deadline<=now){
   for(const [id,choice] of Object.entries(contest.choices))world.players[id].stock.fuel+=choice.quantity;
   contest.status='expired';contest.closed=now;
  }
 }
 for(const offer of Object.values(world.offers)){
  if(offer.deadline<=now){
   world.players[offer.seller].stock[offer.product]+=offer.quantity;
   delete world.offers[offer.id];
  }
 }
 prune(world.invites,now,(r,n)=>r.deadline<=n);
 for(const records of [world.agreements,world.contests])prune(records,now,(r,n)=>r.closed&&r.closed+30*day<=n);
}
function availableRoom(world,player,product,quantity){
 const held=Object.values(world.offers).filter(o=>o.seller===player.id&&o.product===product).reduce((v,o)=>v+o.quantity,0);
 const fuelHeld=product==='fuel'?Object.values(world.contests).filter(c=>c.status==='active').reduce((v,c)=>v+(c.choices[player.id]?.quantity||0),0):0;
 stockRoom(player,product,quantity+held+fuelHeld);
}
function visiblePlayer(p){return {id:p.id,name:p.name,alliance:p.alliance,cash:p.cash,stock:p.stock,projects:p.projects,wins:p.wins,freightDelayUntil:p.freightDelayUntil||0}}
function snapshot(world,player,now){
 const member=o=>[o.seller,o.buyer,o.host,o.guest,o.target].includes(player.id);
 return {
  now, me:visiblePlayer(player), people:recent(world.players,p=>p.id!==player.id).map(p=>({id:p.id,name:p.name,alliance:p.alliance})),
  offers:recent(world.offers,()=>true),
  agreements:recent(world.agreements,o=>member(o)),
  alliance:world.alliances[player.alliance]||null,
  invites:recent(world.invites,o=>o.target===player.id),
  contests:recent(world.contests,o=>member(o)).map(({choices,...c})=>({...c,submitted:Object.hasOwn(choices,player.id)}))
 };
}
function createPlayer(world,input,now,joinCode){
 requireThat(!joinCode||input.code===joinCode,'کد ورود این جهان معتبر نیست.',403);
 requireThat(Object.keys(world.players).length<250,'ظرفیت این جهان تکمیل است.',409);
 const name=text(input.name);
 requireThat(!Object.values(world.players).some(p=>p.name.toLocaleLowerCase()===name.toLocaleLowerCase()),'این نام قبلاً ثبت شده است.',409);
 const id=randomUUID(),token=randomBytes(32).toString('hex');
 const player={id,name,secret:hash(token),cash:1600,stock:{water:20,fuel:20,cement:15,steel:8,naphtha:14},projects:{},alliance:null,wins:0};
 world.players[id]=player;
 return {token,...snapshot(world,player,now)};
}
function tradeInput(input){
 requireThat(typeof input.product==='string'&&Object.hasOwn(goods,input.product),'محصول نامعتبر است.');
 return {product:input.product,quantity:integer(input.quantity,1,500),price:integer(input.price,1,200)};
}
function peer(world,id,player){
 const other=typeof id==='string'&&Object.hasOwn(world.players,id)?world.players[id]:null;
 requireThat(other&&other.id!==player.id,'بازیکن مقصد را انتخاب کن.');
 return other;
}
function entry(records,id,message){
 requireThat(typeof id==='string'&&Object.hasOwn(records,id),message,404);
 return records[id];
}
function action(world,me,input,now){
 const id=me.id;
 switch(input.action){
 case 'project':{
  const product=input.product;
  requireThat(typeof product==='string'&&Object.hasOwn(production,product),'پروژه نامعتبر است.');
  const project=production[product];
  requireThat(!me.projects[product]&&me.cash>=project.cost,'پروژه ساخته شده یا نقد کافی نیست.');
  me.cash-=project.cost;me.projects[product]={next:now+6*hour};break;
 }
 case 'collect':{
  const product=input.product;
  requireThat(now>=(me.freightDelayUntil||0),'تحویل پروژه به‌دلیل نتیجهٔ نبرد فعلاً محدود است.');
  requireThat(typeof product==='string'&&Object.hasOwn(production,product)&&me.projects[product]?.next<=now,'پروژه هنوز آمادهٔ تحویل نیست.');
  const project=production[product],alliance=world.alliances[me.alliance];
  const amount=project.output+(alliance?.fund>=60?4:0);
  availableRoom(world,me,product,amount);
  me.stock[product]+=amount;me.projects[product].next=now+6*hour;break;
 }
 case 'offer':{
  const offer=tradeInput(input);
  requireThat(Object.values(world.offers).filter(o=>o.seller===id).length<6,'حداکثر ۶ آگهی هم‌زمان مجاز است.');
  requireThat(me.stock[offer.product]>=offer.quantity,'موجودی کافی نیست.');
  me.stock[offer.product]-=offer.quantity;
  const offerId=randomUUID();
  world.offers[offerId]={id:offerId,seller:id,sellerName:me.name,...offer,deadline:now+3*day};
  break;
 }
 case 'buy':{
  const offer=entry(world.offers,input.id,'آگهی موجود نیست.');
  requireThat(offer.seller!==id,'آگهی متعلق به خودت است.');
  const cost=offer.quantity*offer.price;
  requireThat(me.cash>=cost,'نقد کافی نیست.');availableRoom(world,me,offer.product,offer.quantity);
  me.cash-=cost;me.stock[offer.product]+=offer.quantity;world.players[offer.seller].cash+=cost;
  delete world.offers[offer.id];break;
 }
 case 'withdraw':{
  const offer=entry(world.offers,input.id,'آگهی موجود نیست.');
  requireThat(offer.seller===id,'آگهی متعلق به این حساب نیست.',403);
  me.stock[offer.product]+=offer.quantity;delete world.offers[offer.id];break;
 }
 case 'contract':{
  const buyer=peer(world,input.target,me), shipment=tradeInput(input);
  const days=integer(input.days,1,14);
  requireThat(Object.values(world.agreements).filter(o=>o.seller===id&&['offered','active'].includes(o.status)).length<8,'ابتدا قراردادهای قبلی را تعیین تکلیف کن.');
  const contractId=randomUUID();
  world.agreements[contractId]={id:contractId,seller:id,buyer:buyer.id,sellerName:me.name,buyerName:buyer.name,...shipment,days,delivered:0,balance:0,status:'offered',deadline:now+3*day};break;
 }
 case 'accept-contract':{
  const deal=entry(world.agreements,input.id,'قرارداد پیدا نشد.');
  requireThat(deal.buyer===id&&deal.status==='offered'&&deal.deadline>now,'قرارداد قابل پذیرش نیست.');
  const total=deal.quantity*deal.price;requireThat(me.cash>=total,'نقد برای پیش‌پرداخت کافی نیست.');
  me.cash-=total;deal.balance=total;deal.status='active';deal.deadline=now+deal.days*day;break;
 }
 case 'close-contract':{
  const deal=entry(world.agreements,input.id,'قرارداد پیدا نشد.');
  requireThat(deal.status==='offered'&&(deal.buyer===id||deal.seller===id),'تنها پیشنهاد باز را می‌توان بست.');
  deal.status='declined';deal.closed=now;break;
 }
 case 'deliver':{
  const deal=entry(world.agreements,input.id,'قرارداد پیدا نشد.');
  requireThat(deal.seller===id&&deal.status==='active','تحویل فقط در قرارداد فعال ممکن است.');
  const amount=integer(input.quantity,1,deal.quantity-deal.delivered),buyer=world.players[deal.buyer],cost=amount*deal.price;
  requireThat(me.stock[deal.product]>=amount&&deal.balance>=cost,'موجودی یا اعتبار کافی نیست.');
  availableRoom(world,buyer,deal.product,amount);
  me.stock[deal.product]-=amount;buyer.stock[deal.product]+=amount;me.cash+=cost;
  deal.delivered+=amount;deal.balance-=cost;
  if(deal.delivered===deal.quantity){deal.status='complete';deal.closed=now}break;
 }
 case 'alliance':{
  requireThat(!me.alliance&&me.cash>=150,'عضو اتحاد هستی یا نقد کافی نداری.');
  const name=text(input.name),allianceId=randomUUID();
  requireThat(!Object.values(world.alliances).some(a=>a.name===name),'نام اتحاد قبلاً استفاده شده است.');
  me.cash-=150;me.alliance=allianceId;
  world.alliances[allianceId]={id:allianceId,name,leader:id,members:[id],fund:0};break;
 }
 case 'invite':{
  const target=peer(world,input.target,me),alliance=world.alliances[me.alliance];
  requireThat(alliance?.leader===id&&!target.alliance&&alliance.members.length<12,'دعوت از طرف مدیر اتحاد با جای خالی مجاز است.');
  requireThat(!Object.values(world.invites).some(i=>i.alliance===alliance.id&&i.target===target.id),'دعوت در انتظار است.');
  const inviteId=randomUUID();world.invites[inviteId]={id:inviteId,alliance:alliance.id,name:alliance.name,target:target.id,deadline:now+3*day};break;
 }
 case 'accept-invite':{
  const invite=entry(world.invites,input.id,'دعوت پیدا نشد.');
  const alliance=world.alliances[invite.alliance];
  requireThat(invite.target===id&&!me.alliance&&alliance.members.length<12,'دعوت قابل پذیرش نیست.');
  me.alliance=alliance.id;alliance.members.push(id);delete world.invites[invite.id];break;
 }
 case 'contribute':{
  const alliance=world.alliances[me.alliance];
  requireThat(alliance&&alliance.fund<60,'پروژهٔ مشترک تکمیل شده یا عضویت لازم است.');
  const amount=integer(input.quantity,1,60-alliance.fund);
  requireThat(me.stock.cement>=amount,'سیمان کافی نداری.');
  me.stock.cement-=amount;alliance.fund+=amount;break;
 }
 case 'challenge':{
  const other=peer(world,input.target,me);
  requireThat(!Object.values(world.contests).some(c=>['invited','active'].includes(c.status)&&[c.host,c.guest].some(p=>[id,other.id].includes(p))),'یکی از کشورها درگیر دعوت یا رقابت دیگری است.');
  const contestId=randomUUID();world.contests[contestId]={id:contestId,host:id,guest:other.id,hostName:me.name,guestName:other.name,status:'invited',deadline:now+day,choices:{}};break;
 }
 case 'accept-challenge':
 case 'decline-challenge':{
  const contest=entry(world.contests,input.id,'دعوت رقابت پیدا نشد.');
  requireThat(contest.status==='invited'&&contest.guest===id,'فقط کشور دعوت‌شده تصمیم می‌گیرد.');
  contest.status=input.action==='accept-challenge'?'active':'declined';contest.deadline=now+day;
  if(contest.status==='declined')contest.closed=now;
  break;
 }
 case 'contest-submit':{
  const contest=entry(world.contests,input.id,'رقابت پیدا نشد.');
  requireThat(contest.status==='active'&&[contest.host,contest.guest].includes(id)&&!Object.hasOwn(contest.choices,id),'رقابت فعال یا قابل ثبت نیست.');
  const amount=integer(input.quantity,1,8);requireThat(me.stock.fuel>=amount,'سوخت تدارکات کافی نیست.');
  requireThat(typeof input.plan==='string'&&Object.hasOwn(beats,input.plan),'روش تدارکات را انتخاب کن.');
  me.stock.fuel-=amount;contest.choices[id]={quantity:amount,plan:input.plan};
  if(Object.keys(contest.choices).length===2){
   const a=contest.choices[contest.host],b=contest.choices[contest.guest];
   const hostScore=a.quantity+(beats[a.plan]===b.plan?3:0),guestScore=b.quantity+(beats[b.plan]===a.plan?3:0);
   contest.result={hostScore,guestScore,hostPlan:a.plan,guestPlan:b.plan};
   contest.winner=hostScore===guestScore?null:hostScore>guestScore?contest.host:contest.guest;
   if(contest.winner){
    world.players[contest.winner].wins++;
    const loser=contest.winner===contest.host?contest.guest:contest.host;
    world.players[loser].freightDelayUntil=now+hour;
   }
   else {world.players[contest.host].stock.fuel+=a.quantity;world.players[contest.guest].stock.fuel+=b.quantity}
   contest.status='complete';contest.closed=now;
  }break;
 }
 default:throw new WorldError('فرمان ناشناخته است.');
 }
}
export function applyOnline(world,{kind,token,input={},now=Date.now(),joinCode=''}){
 if(!input||typeof input!=='object'||Array.isArray(input))throw new WorldError('درخواست نامعتبر است.');
 settleExpired(world,now);
 if(kind==='join')return createPlayer(world,input,now,joinCode);
 const me=playerFor(world,token);
 if(kind==='action')action(world,me,input,now);
 else requireThat(kind==='world','مسیر نامعتبر است.',404);
 return snapshot(world,me,now);
}
