import {createServer} from 'node:http';
import {existsSync,mkdirSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import {dirname,extname,resolve,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {applyOnline,newWorld,WorldError} from './online-world.mjs';

const root=fileURLToPath(new URL('../',import.meta.url));
const dataFile=resolve(process.env.TYCOON_DATA||'var/world.json');
const joinCode=process.env.TYCOON_JOIN_CODE||'';
const origin=process.env.TYCOON_PAGES_ORIGIN||'';
const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.glb':'model/gltf-binary','.txt':'text/plain; charset=utf-8'};
let world=existsSync(dataFile)?JSON.parse(readFileSync(dataFile,'utf8')):newWorld();
function commit(next){
 const json=JSON.stringify(next);
 if(json===JSON.stringify(world))return;
 mkdirSync(dirname(dataFile),{recursive:true});
 writeFileSync(dataFile+'.tmp',json,{mode:0o600});
 renameSync(dataFile+'.tmp',dataFile);
 world=next;
}
async function readInput(req){
 let size=0;const pieces=[];
 for await(const chunk of req){
  size+=chunk.length;
  if(size>8192)throw new WorldError('درخواست بیش از اندازه بزرگ است.',413);
  pieces.push(chunk);
 }
 try{return JSON.parse(Buffer.concat(pieces).toString())}
 catch{throw new WorldError('بدنهٔ درخواست نامعتبر است.')}
}
function send(res,status,value){
 res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
 res.end(JSON.stringify(value));
}
const endpoints={'/api/join':'join','/api/world':'world','/api/action':'action'};
const rates=new Map();
function allow(req,kind){
 const now=Date.now(),key=req.socket.remoteAddress||'local';
 for(const [address,r] of rates)if(r.start+60000<now)rates.delete(address);
 const rate=rates.get(key)||{start:now,count:0,joins:0};rates.set(key,rate);
 rate.count++;if(kind==='join')rate.joins++;
 if(rate.count>160||rate.joins>12)throw new WorldError('تعداد درخواست زیاد است؛ کمی بعد تلاش کن.',429);
}
const server=createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');
 try{
  const url=new URL(req.url,'http://localhost'),kind=Object.hasOwn(endpoints,url.pathname)?endpoints[url.pathname]:null;
  if(kind){
   if(origin&&req.headers.origin===origin){
    res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');
    res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');
    res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');
   }
   if(req.method==='OPTIONS'){res.writeHead(204);res.end();return}
   if(req.method!==(kind==='world'?'GET':'POST')){send(res,405,{error:'روش درخواست نامعتبر است.'});return}
   allow(req,kind);
   const input=kind==='world'?{}:await readInput(req);
   // All changes between cloning and commit are synchronous on one server process.
   const next=structuredClone(world);
   const result=applyOnline(next,{kind,input,token:req.headers.authorization?.replace(/^Bearer /,''),joinCode});
   commit(next);send(res,200,result);return;
  }
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405).end();return}
  const file=decodeURIComponent(url.pathname).slice(1)||'index.html';
  const safe=/^(?:index|online|GUIDE-fa|CITY-GUIDE-fa|PRODUCTS-GUIDE-fa)\.html$/.test(file)||/^(?:js|css|assets)\/[a-zA-Z0-9_.\/-]+$/.test(file);
  const absolute=resolve(root,file),type=types[extname(file)];
  if(!safe||file.split('/').some(p=>p.startsWith('.'))||!absolute.startsWith(resolve(root)+sep)||!type||!existsSync(absolute)){res.writeHead(404).end();return}
  res.setHeader('Content-Type',type);res.setHeader('Cache-Control','no-cache');
  if(req.method==='HEAD')res.end();else res.end(readFileSync(absolute));
 }catch(error){
  if(!(error instanceof WorldError))console.error(error.message);
  if(!res.headersSent)send(res,error.status||500,{error:error.status?error.message:'مشکل ذخیره یا پردازش سرور.'});
  else res.end();
 }
});
server.listen(Number(process.env.PORT)||3000,process.env.HOST||'127.0.0.1',()=>console.log('Process Tycoon server listening on '+JSON.stringify(server.address())));
