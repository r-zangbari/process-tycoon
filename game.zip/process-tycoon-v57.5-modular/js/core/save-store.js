import { createFreshState, LEGACY_STORAGE_KEY, normalizeState, STORAGE_KEY } from './game-state.js';
import { D, GH, GW, MK, PR, TY } from '../data/catalog.js';
import { GAME_VERSION } from './version.js';

const PREVIOUS_KEY = STORAGE_KEY + '-previous';
const isRecord = value => value && typeof value === 'object' && !Array.isArray(value);

export function prepareSnapshot(state) {
  if (!isRecord(state) || !Array.isArray(state.u) || !Array.isArray(state.grid) ||
      ![48, GW * GH].includes(state.grid.length) ||
      state.grid.some(lot => lot !== null && (!isRecord(lot) || !Object.hasOwn(TY, lot.t)))) {
    throw Error('ساختار ذخیره ناقص یا ناسازگار است.');
  }
  for (const unit of state.u) {
    const definition = isRecord(unit) && Number.isInteger(unit.t) && D[unit.t];
    if (!definition || !Array.isArray(unit.v) || !Array.isArray(unit.eq) ||
        unit.eq.length > definition.e.length || unit.eq.some(e => !isRecord(e))) {
      throw Error('اطلاعات واحدهای فرایندی در ذخیره معتبر نیست.');
    }
    unit.v = definition.v.map((entry, i) => Number.isFinite(unit.v[i]) ? unit.v[i] : entry[2]);
    unit.h = definition.v.map((_, i) => Array.isArray(unit.h?.[i]) ? unit.h[i] : []);
  }
  for (const lot of state.grid) {
    if (lot && !isRecord(lot.c)) lot.c = {};
  }
  state.log = Array.isArray(state.log) ? state.log.slice(0, 40).map(line => String(line).replace(/[<>]/g, '')) : [];
  state.fx = isRecord(state.fx) ? state.fx : {};
  state.offers = Array.isArray(state.offers) ? state.offers : [];
  state.spd = [1, 2, 4].includes(state.spd) ? state.spd : 1;
  state.paused = typeof state.paused === 'boolean' ? state.paused : true;
  normalizeState(state, { D, PR, MK, GW, GH, setImportMultiplier() {} });
  return state;
}

export function exportSnapshot(state) {
  return { format: 'process-tycoon-save', schemaVersion: 1, gameVersion: GAME_VERSION, savedAt: new Date().toISOString(), state };
}

export function importSnapshot(json) {
  const file = JSON.parse(json);
  if (file?.format !== 'process-tycoon-save' || file.schemaVersion !== 1)
    throw Error('این فایل پشتیبان معتبر بازی نیست.');
  return prepareSnapshot(file.state);
}

function parseSnapshot(raw) {
  if (raw === null) return null;
  try {
    return prepareSnapshot(JSON.parse(raw));
  } catch {
    return null;
  }
}

// Keep the JSON shape compatible. Older builds can only write their own key.
export function createSaveStore(getStorage = () => globalThis.localStorage) {
  let observed = null, lastValid = null;

  function read() {
    try {
      const storage = getStorage();
      observed = storage.getItem(STORAGE_KEY);
      const primary = parseSnapshot(observed);
      lastValid = primary ? observed : null;
      if (primary) return { state: primary, source: 'primary' };
      const previous = parseSnapshot(storage.getItem(PREVIOUS_KEY));
      if (previous) return { state: previous, source: 'previous' };
      if (observed === null) {
        const raw = storage.getItem(LEGACY_STORAGE_KEY), legacy = parseSnapshot(raw);
        if (legacy) {
          lastValid = raw;
          return { state: legacy, source: 'legacy' };
        }
      }
      return { state: prepareSnapshot(createFreshState()), source: observed === null ? 'fresh' : 'damaged' };
    } catch {
      return { state: prepareSnapshot(createFreshState()), source: 'unavailable' };
    }
  }

  function previous() {
    try {
      return parseSnapshot(getStorage().getItem(PREVIOUS_KEY));
    } catch {
      return null;
    }
  }

  function write(state) {
    try {
      const storage = getStorage();
      if (storage.getItem(STORAGE_KEY) !== observed) return 'conflict';
      const raw = JSON.stringify(state);
      if (raw === observed) return 'saved';
      // Preserve the previous valid snapshot before replacing the current one.
      if (lastValid !== null) storage.setItem(PREVIOUS_KEY, lastValid);
      storage.setItem(STORAGE_KEY, raw);
      observed = raw;
      lastValid = raw;
      return 'saved';
    } catch {
      return 'unavailable';
    }
  }

  function hasPrevious() {
    try {
      return getStorage().getItem(PREVIOUS_KEY) !== null;
    } catch {
      return false;
    }
  }

  function changed() {
    try {
      return getStorage().getItem(STORAGE_KEY) !== observed;
    } catch {
      return false;
    }
  }

  return { read, write, previous, hasPrevious, changed };
}
