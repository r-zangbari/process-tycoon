import { normalizeMaintenance } from '../features/maintenance/model/auto-maintenance.js';
// Persistent game state: creation, migration and browser storage.
import { D, PR, MK, GW, GH } from '../data/catalog.js';
import { normalizeOffshoreState } from '../features/offshore/model/offshore.js';
export const LEGACY_STORAGE_KEY = 'process-tycoon-v3';
export const STORAGE_KEY = 'process-tycoon-save';
export const createFreshState = () => ({
  seed: Math.floor(Math.random() * 1e6) + 1, cam: { x: 0, y: 0, k: 1 }, tab: 'i', sel: null, grid: Array.from({ length: GW * GH }, (_, i) => [40, 41, 42, 52, 53, 54].includes(i) ? { t: 'h', l: 1, c: { power: 1, gas: 1, water: 1, fuel: 1 } } : null), offshore: { oil: { stage: 0, health: 100, project: null }, gas: { stage: 0, health: 100, project: null } }, tanks: { power: 0, gas: 0, fuel: 0, water: 0, methanol: 0, ethylene: 0, sulfur: 0 }, tl: {}, hold: {}, pm: { methanol: 1, ethylene: 1, sulfur: 1 }, salePrice: { methanol: 1, ethylene: 1, sulfur: 1 }, marketDay: {}, port: 20, tradeContracts: [], tradeHistory: [], govBudget: 0, govRate: 1, nationalProjects: { refinery: 0, power: 0, petrochem: 0, pipeline: 0 }, economy: { inflation: 100, unemployment: 8, employment: 0, stability: 75, shock: null, relief: 0 }, network: { power: 0, gas: 0, water: 0, fuel: 0 }, sat: 100, inc: {}, pd: {}, dem: {}, fr: {}, pop: 0, money: 5000, day: 1, mkt: 1, safe: 100, u: [], log: ['۵۰۰۰ واحد سرمایه و یک شهرک کوچک دارید. شهرک به برق، گاز، آب و سوخت نیاز دارد؛ با واحدی شروع کنید که نیاز شهر را می‌دهد.'], spd: 1, tutorial: { dismissed: false, done: false }, paused: true, won: false, ops: 1, tr: 0, fx: {}, offers: [], mh: [3000]
});
export function normalizeState(S, { setImportMultiplier, D, PR, MK, GW, GH }) {
  const F = Number.isFinite;
  if (S.grid && S.grid.length === 48) {
    const g = Array(GW * GH).fill(null);
    S.grid.forEach((b, i) => {
      if (b)
        g[(Math.floor(i / 8) + 2) * GW + (i % 8) + 3] = b;
    });
    S.grid = g;
    S.sel = null;
  }
  if (!S.cam)
    S.cam = { x: 0, y: 0, k: 1 };
  if (!S.seed)
    S.seed = 2026;
  S.tanks = S.tanks || {};
  for (const p in PR)
    if (!F(S.tanks[p]))
      S.tanks[p] = 0;
  S.prodLoss = S.prodLoss || {};
  for (const k in PR)
    if (!F(S.prodLoss[k]))
      S.prodLoss[k] = 0;
  S.personnel = S.personnel || { injured: 0, fatalities: 0, injuryDays: 0 };
  for (const k of ['injured', 'fatalities', 'injuryDays'])
    if (!F(S.personnel[k]))
      S.personnel[k] = 0;
  normalizeOffshoreState(S);
  S.cities = S.cities && typeof S.cities === 'object' ? S.cities : {};
  S.cityMaps = S.cityMaps && typeof S.cityMaps === 'object' ? S.cityMaps : {};
  S.alertAck = S.alertAck && typeof S.alertAck === 'object' ? S.alertAck : {};
  S.tradeContracts = Array.isArray(S.tradeContracts) ? S.tradeContracts : [];
  S.tradeHistory = Array.isArray(S.tradeHistory) ? S.tradeHistory : [];
  S.tradeContracts = S.tradeContracts.filter(c => c && PR[c.p]?.[3] && Number.isFinite(c.remaining) && Number.isFinite(c.days));
  S.pm = S.pm || {};
  S.salePrice = S.salePrice || {};
  S.marketDay = S.marketDay || {};
  S.economy = S.economy || { inflation: 100, unemployment: 8, employment: 0, stability: 75, shock: null, relief: 0 };
  for (const k of ['inflation', 'unemployment', 'employment', 'stability', 'relief'])
    if (!F(S.economy[k]))
      S.economy[k] = ({ inflation: 100, unemployment: 8, employment: 0, stability: 75, relief: 0 })[k];
  S.nationalProjects = S.nationalProjects || {};
  for (const p of ['refinery', 'power', 'petrochem', 'pipeline'])
    if (!F(S.nationalProjects[p]))
      S.nationalProjects[p] = 0;
  S.regions = S.regions && typeof S.regions === 'object' ? S.regions : {};
  for (let i = 0; i < 9; i++) {
    S.regions[i] = S.regions[i] || { investment: 0, satisfaction: 70 };
    if (!F(S.regions[i].investment))
      S.regions[i].investment = 0;
    if (!F(S.regions[i].satisfaction))
      S.regions[i].satisfaction = 70;
    S.regions[i].investment = Math.max(0, Math.min(3, S.regions[i].investment));
    S.regions[i].satisfaction = Math.max(0, Math.min(100, S.regions[i].satisfaction));
  }
  S.network = S.network || {};
  for (const p of ['power', 'gas', 'water', 'fuel'])
    if (!F(S.network[p]))
      S.network[p] = 0;
  if (!F(S.govBudget))
    S.govBudget = 0;
  if (!F(S.govRate))
    S.govRate = 1;
  for (const p in PR)
    if (PR[p][3] && !F(S.pm[p]))
      S.pm[p] = 1;
  for (const p in PR)
    if (PR[p][3] && !F(S.salePrice[p]))
      S.salePrice[p] = 1;
  for (const k in MK)
    if (!F(S.pm[k]))
      S.pm[k] = 1;
  S.pid = S.pid || {};
  S.hold = S.hold || {};
  for (const k of ['naphtha', 'crude', 'ammonia', 'steel', 'cement'])
    if (S.hold[k] == null)
      S.hold[k] = true;
  for (const k of ['cs', 'imp', 'pd', 'fr', 'dem', 'tl', 'inc', 'rp', 'ic'])
    S[k] = S[k] || {};
  const dv = {
    bailoutUsed: false, financialGraceDays: 0, diff: 1, infra: 0, esg: 70, eng: 0, ab: 0, mor: 80, sal: 12, money: 0, mkt: 1, safe: 100, sat: 100, port: 20, day: 1, ops: 1, tr: 0, imc: 0
  };
  for (const k in dv)
    if (!F(S[k]))
      S[k] = dv[k];
  setImportMultiplier([1.2, 1.4, 1.7][S.diff] || 1.4);
  if (S.port < 40)
    S.port = 40;
  // Legacy saves did not track a shared daily import/export berth.
  if (!F(S.portRemainingToday))
    S.portRemainingToday = S.port;
  if (!F(S.portUsedToday))
    S.portUsedToday = 0;
  S.portRemainingToday = Math.max(0, Math.min(S.port, S.portRemainingToday));
  S.portUsedToday = Math.max(0, Math.min(S.port, S.portUsedToday));
  if (!Array.isArray(S.rv))
    S.rv = [9000, 11000, 14000];
  S.ms = S.ms || {};
  S.u = Array.isArray(S.u) ? S.u : [];
  S.grid = Array.isArray(S.grid) && S.grid.length === GW * GH ? S.grid : createFreshState().grid;
  S.mh = (S.mh || []).filter(F);
  if (!S.mh.length)
    S.mh = [S.money];
  S.u.forEach((u, ui) => {
    normalizeMaintenance(u, D[u.t]);
    if (u.st === 'build' && !u.prob && u.eq?.length >= D[u.t].e.length)
      u.st = 'ready';
    if (!F(u.load))
      u.load = 100;
    if (!F(u.feedGrade))
      u.feedGrade = 90;
    u.feedGrade = Math.max(70, Math.min(100, u.feedGrade));
    if (!F(u.overloadTicks))
      u.overloadTicks = 0;
    u.au = Array.isArray(u.au) ? u.au : D[u.t].v.map(() => 0);
    u.v = u.v.map((x, k) => F(x) ? x : D[u.t].v[k][2]);
    u.h = (u.h || []).map(a => a.filter(F));
    u.eq.forEach((e, j) => {
      if (!F(e.h))
        e.h = 100;
      e.running = e.running !== false;
      if (D[u.t].e[j]?.[1]) {
        if (!e.reserve)
          e.reserve = { h: 100, f: null, running: false };
        if (!F(e.reserve.h))
          e.reserve.h = 100;
        e.reserve.running = e.reserve.running === true;
        if (e.running === e.reserve.running) {
          e.running = true;
          e.reserve.running = false;
        }
      }
      else if (e.reserve)
        delete e.reserve;
    });
    u.processState = u.processState || {};
    if (typeof u.processState.valveOpen !== 'boolean')
      u.processState.valveOpen = true;
    if (typeof u.processState.pumpStandby !== 'boolean')
      u.processState.pumpStandby = false;
    Object.keys(S.pid).forEach(key => {
      if (key.startsWith(`${ui}:`)) {
        const k = Number(key.split(':')[1]), cfg = S.pid[key];
        if (cfg?.mode === 'auto' && !u.au[k]) {
          cfg.mode = 'manual';
          cfg.integral = 0;
          cfg.previousError = 0;
        }
      }
    });
  });
}
