// توابع کمکی خالص: cl (محدودسازی)، fa/f1 (قالب‌بندی عدد فارسی)، $ (querySelector).
export const cl = (x, a, b) => Math.min(b, Math.max(a, x));
export const fa = n => Number.isFinite(n) ? Math.round(n).toLocaleString('fa-IR') : '۰';
export const f1 = n => !Number.isFinite(n) ? '۰' : n.toFixed(1).replace('.', '٫').replace(/\d/g, c => '۰۱۲۳۴۵۶۷۸۹'[c]);
export const $ = s => document.querySelector(s);
