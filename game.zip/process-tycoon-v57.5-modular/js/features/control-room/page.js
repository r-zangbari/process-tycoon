// صفحه‌ی «اتاق کنترل DCS».
import { D } from '../../data/catalog.js';
import { unitTitle } from '../../engine/unit-names.js';
import { hasEquipmentFaults, recoveryBlock, renderReserveRepairs } from '../maintenance/model/unit-recovery.js';
import { unitExplanation } from '../industry/view/player-help.js';
import { describeFinalElement } from './model/control-elements.js';
import { renderControlRoom } from './view/control-room.js';
import { maintenancePanel } from '../maintenance/view/auto-maintenance.js';
import { renderProcessMimic } from './view/process-mimic.js';
import { cl, f1, fa } from '../../core/format.js';
export function installControlRoomPage(game) {
  const { S, maintenanceCost, partCost } = game;
  // Operator HMI: all displayed values are read from the live simulation state.
  function viewHMI() {
    const commissioned = S.u.map((u, i) => ({ u, i })).filter(x => !['build', 'ready'].includes(x.u.st));
    if (!commissioned.length)
      return `<section class="hmi-shell wide"><div class="hmi-head"><div><span class="hmi-kicker">CONTROL ROOM / DCS</span><h2>اتاق کنترل فرایند</h2><p class="muted">نمایش زنده وضعیت واحدها، متغیرهای فرایندی و آلارم‌های عملیاتی</p></div><span class="tag">بدون واحد راه‌اندازی‌شده</span></div><div class="hmi-empty">هنوز واحدی به بهره‌برداری نرسیده است. پس از راه‌اندازی اولین پروژه، اطلاعات آن در این صفحه نمایش داده می‌شود.</div></section>`;
    let selected = commissioned.find(x => x.i === S.hmiUnit) || commissioned[0];
    const u = selected.u, i = selected.i, d = { ...D[u.t], n: unitTitle(u, D, i) };
    if (S.hmiUnit !== i) {
      S.mimicEq = null;
      S.mimicLoop = null;
    }
    S.hmiUnit = i;
    const stateName = {
      run: 'در سرویس', trip: 'تریپ', broken: hasEquipmentFaults(u) ? 'خارج از سرویس · خرابی' : 'در انتظار راه‌اندازی', tar: 'تعمیرات اساسی', off: 'توقف عمدی'
    }[u.st] || u.st;
    const stateClass = u.st === 'run' ? 'ok' : (['trip', 'broken'].includes(u.st) ? 'bd' : 'wn');
    const alarms = [];
    d.v.forEach((v, k) => {
      const pc = S.pid?.[`${i}:${k}`];
      if (pc?.naturalDays > 0)
        alarms.push(['INFO', 'نوسان ملایم: ' + v[0], pc.naturalCause + '؛ اثر محدود و موقت. وضعیت حلقه را بررسی کن.']);
    });
    if (u.st === 'trip')
      alarms.push(['HIGH', 'تریپ واحد', 'واحد از مدار خارج شده است.']);
    if (u.st === 'broken')
      alarms.push(hasEquipmentFaults(u) ? ['HIGH', 'خرابی واحد', 'خرابی تجهیز اصلی یا رزرو ثبت شده؛ جزئیات تعمیر را بررسی کن.'] : ['INFO', 'در انتظار بازگشت به سرویس', unitExplanation(u)]);
    if (u.st === 'off')
      alarms.push(['INFO', 'توقف عمدی', 'واحد با فرمان اپراتور متوقف شده است.']);
    if (u.st === 'tar')
      alarms.push(['INFO', 'تعمیرات اساسی', 'واحد در دوره تعمیرات اساسی قرار دارد.']);
    if (S.cr?.i === i)
      alarms.push(['HIGH', 'رخداد فعال: ' + game.CR[S.cr.k].t, `زمان پاسخ: ${fa(S.cr.d)} روز باقی‌مانده.`]);
    if (u.feedIncident?.days > 0)
      alarms.push(['MED', 'اختلال خوراک', `کاهش دسترسی خوراک؛ ${fa(u.feedIncident.days)} روز باقی‌مانده.`]);
    if (u.coolingIncident?.days > 0)
      alarms.push(['HIGH', 'افت خنک‌کاری', `افزایش بار حرارتی؛ ${fa(u.coolingIncident.days)} روز باقی‌مانده.`]);
    if (u.instrumentIncident?.days > 0)
      alarms.push(['MED', 'Drift ابزار دقیق', `سیگنال متغیر ${d.v[u.instrumentIncident.k]?.[0] || ''} نیازمند بررسی است.`]);
    if (S.gridIncident?.days > 0)
      alarms.push(['HIGH', 'اختلال برق سایت', `ظرفیت برق محدود است؛ ${fa(S.gridIncident.days)} روز باقی‌مانده.`]);
    d.v.forEach((x, k) => {
      const value = u.v[k], dev = Math.abs(value - x[2]) / Math.max(x[3], .0001);
      if (dev > 1.7)
        alarms.push(['HIGH', 'انحراف شدید: ' + x[0], `مقدار ${f1(value)} ${x[1]}؛ هدف ${f1(x[2])} ${x[1]}.`]);
      else if (dev > 1)
        alarms.push(['MED', 'انحراف فرایندی: ' + x[0], `مقدار ${f1(value)} ${x[1]} از باند کنترل خارج شده است.`]);
    });
    u.eq.forEach((e, j) => {
      if (e.reserve && e.reserve.h < 30)
        alarms.push(['MED', 'سلامت پایین پمپ رزرو: ' + d.e[j][0], `سلامت تجهیز رزرو ${fa(e.reserve.h)}٪ است و در صورت نیاز آماده ورود به مدار نیست.`]);
      if (e.reserve?.f)
        alarms.push(['MED', 'خرابی رزرو: ' + d.e[j][0], 'قطعه و تعمیر تجهیز رزرو را در تجهیزات و نگهداری بررسی کن.']);
      if (e.f)
        alarms.push(['HIGH', 'خرابی تجهیز: ' + d.e[j][0], e.f.st === 0 ? 'قطعه یدکی موردنیاز است.' : e.f.st === 1 ? 'قطعه در مسیر تأمین است.' : 'قطعه رسیده و تجهیز آماده تعمیر است.']);
      if (e.h < 30)
        alarms.push(['MED', 'سلامت پایین تجهیز: ' + d.e[j][0], `سلامت تجهیز ${fa(e.h)}٪ است.`]);
    });
    const variableBlocks = d.v.map((x, k) => {
      const value = u.v[k], dev = Math.abs(value - x[2]) / Math.max(x[3], .0001), level = dev > 1.7 ? 'bd' : dev > 1 ? 'wn' : 'ok', pidKey = `${i}:${k}`, pc = S.pid?.[pidKey] || {}, sp = Number.isFinite(pc.sp) ? pc.sp : x[2], pidAuto = pc.mode === 'auto';
      return `<div class="hmi-pv"><div class="hmi-pv-top"><span>${x[0]}</span><b class="${level}">${f1(value)} <small>${x[1]}</small></b></div><div class="hmi-target">هدف طراحی ${f1(x[2])} ${x[1]} · باند ±${f1(x[3])}</div>${game.chart(u.h[k] || [], sp, x[3], dev > 1.7 ? 'var(--bad)' : dev > 1 ? 'var(--warn)' : 'var(--ok)')}<div class="pid-controls"><label>مقدار هدف SP (${x[1]})<input type="number" step="any" data-pid-sp data-i="${i}" data-k="${k}" value="${sp}" ${u.st !== 'run' ? 'disabled' : ''}></label>${!u.au?.[k] ? `<button type="button" data-a="auto" data-i="${i}" data-k="${k}" ${u.st !== 'run' ? 'disabled' : ''}>خرید و نصب کنترلر PID (${fa(d.cost * .15)})</button>` : `<button type="button" data-a="pid-toggle" data-i="${i}" data-k="${k}" ${u.st !== 'run' ? 'disabled' : ''}>${pidAuto ? 'خودکار AUTO · تغییر به دستی MAN' : 'دستی MAN · فعال‌سازی خودکار AUTO'}</button>`}</div><div class="pid-readout muted">${pidAuto ? `خروجی کنترلر: ${f1((pc.output || 0) * 100)}٪ · ${pc.actuatorTag || describeFinalElement(x[0]).tag} · ${pc.actuatorLabel || describeFinalElement(x[0]).label} · موقعیت محرک: ${f1(pc.mv ?? 50)}٪ · Kp ${pc.kp ?? 0.25} / Ki ${pc.ki ?? 0.06} / Kd ${pc.kd ?? 0.02}` : `MAN · خروجی دستی محرک: ${f1(pc.mv ?? 50)}٪ · ${pc.actuatorTag || describeFinalElement(x[0]).tag}`}<br>هدف دینامیکی مدل: ${f1(pc.processTarget ?? x[2])} ${x[1]} · اثر محرک: ${f1(pc.actuatorEffect || 0)} ${x[1]} · اختلال باقی‌مانده: ${f1(pc.disturbance || 0)} ${x[1]}</div>${pc.naturalDays > 0 ? `<p class="loop-drift">${pc.naturalCause} · اثر هدف ${f1(pc.naturalBias)} ${x[1]} · ${fa(pc.naturalDays)} روز باقی‌مانده. ${pidAuto ? 'AUTO در حال جبران است.' : 'با اصلاح خروجی دستی یا فعال‌کردن AUTO آن را جبران کن.'} این رخداد ملایم جای خرابی واقعی تجهیز نیست.</p>` : ''}<div class="row hmi-actions"><button type="button" data-a="disturb" data-i="${i}" data-k="${k}" ${u.st !== 'run' ? 'disabled' : ''}>اعمال اختلال آزمایشی</button>${u.st === 'run' && !pidAuto ? `<button data-a="adj" data-i="${i}" data-k="${k}" data-s="-1">کاهش خروجی</button><button data-a="adj" data-i="${i}" data-k="${k}" data-s="1">افزایش خروجی</button>` : ''}${u.au[k] && !pidAuto ? '<span class="tag run">کنترلر نصب‌شده · آماده AUTO</span>' : ''}</div></div>`;
    });
    const equipment = u.eq.map((e, j) => {
      const fault = e.f, partActions = fault && fault.st === 0 ? `<button data-a="part" data-i="${i}" data-j="${j}" data-f="0">سفارش قطعه (${fa(partCost(d, j))})</button><button data-a="part" data-i="${i}" data-j="${j}" data-f="1">ارسال فوری (${fa(partCost(d, j) * 2)})</button>` : fault && fault.st === 2 ? `<button class="p" data-a="repair" data-i="${i}" data-j="${j}">تعمیر تجهیز (${fa(d.cost * .04)})</button>` : fault ? '<span class="muted">قطعه در مسیر تأمین است</span>' : '';
      return `<div class="hmi-eq"><div class="hmi-eq-title"><b>${d.e[j][0]}</b><span class="${fault ? 'bd' : e.h < 30 ? 'wn' : 'ok'}">${fault ? (fault.st === 0 ? 'خراب · قطعه لازم' : fault.st === 1 ? 'قطعه در راه' : 'آماده تعمیر') : e.h < 30 ? 'نیازمند توجه' : 'آماده به کار'}</span></div><div class="bar"><i style="width:${cl(e.h, 0, 100)}%;background:${fault ? 'var(--bad)' : e.h < 30 ? 'var(--warn)' : 'var(--ok)'}"></i></div><small class="muted">سلامت اصلی ${fa(e.h)}٪${e.reserve ? ' · سلامت رزرو ' + fa(e.reserve.h) + '٪' : ''} · سطح ${fa(e.l)}</small><div class="row hmi-actions">${partActions}<button data-a="up" data-i="${i}" data-j="${j}" ${e.l >= 4 ? 'disabled' : ''}>ارتقای تجهیز (${fa(d.cost * .3 * e.l)})</button></div></div>`;
    }).join('');
    const alarmHtml = alarms.length ? alarms.map(a => `<div class="hmi-alarm ${a[0].toLowerCase()}"><b>${a[0]}</b><div><strong>${a[1]}</strong><small>${a[2]}</small></div></div>`).join('') : '<div class="hmi-clear">✓ هیچ آلارم فعالی برای این واحد شناسایی نشد.</div>';
    return renderControlRoom({
      S, D, u, d, i, commissioned, stateName, stateClass, alarms, alarmHtml, variableBlocks, equipment: equipment + renderReserveRepairs(u, d, i, fa), maintenance: maintenancePanel(S, u, i, D), commands: `<section class="hmi-panel hmi-command-panel"><div class="hmi-panel-head"><h3>فرمان‌های عملیاتی واحد</h3><span class="muted">فرمان‌ها روی همان واحد انتخاب‌شده اعمال می‌شوند</span></div><div class="row hmi-command-actions"><button data-a="pm" data-i="${i}" ${maintenanceCost(u, d) <= 0 ? 'disabled' : ''}>سرویس دوره‌ای (${fa(maintenanceCost(u, d))})</button><button data-a="tar" data-i="${i}" ${['run', 'trip', 'off'].includes(u.st) ? '' : 'disabled'}>تعمیرات اساسی · ${fa(d.cost * .15)}</button>${u.st === 'run' ? `<button data-a="stop" data-i="${i}">شات‌داون / خروج از سرویس</button>` : ''}${u.st === 'off' ? `<button class="p" data-a="resume" data-i="${i}">راه‌اندازی مجدد پس از توقف · ${fa(d.cost * .02)}</button>` : ''}${u.st === 'trip' ? `<button class="p" data-a="restart" data-i="${i}">راه‌اندازی مجدد پس از تریپ · ${fa(d.cost * .04)}</button>` : ''}${u.st === 'broken' ? (hasEquipmentFaults(u) ? '<span class="tag trip">خرابی ثبت‌شده را در تجهیزات اصلی و رزرو بررسی کن</span>' : `<button class="p" data-a="restart" data-i="${i}">بازگشت به سرویس پس از بررسی · ${fa(d.cost * .04)}</button><span>${recoveryBlock(S, u, i, D) || 'خرابی ثبت نشده؛ منتظر تأیید راه‌اندازی است.'}</span>`) : ''}${u.st === 'tar' ? `<span class="tag tar">تعمیرات اساسی · ${fa(u.tar || 0)} روز باقی‌مانده</span>` : ''}</div><div class="row hmi-command-actions"><b>بار عملیاتی: ${fa(u.load || 100)}٪ · ظرفیت نامی: ${fa(u.ratedCapacity || 100)}٪ · بار ظرفیت: ${fa(u.capacityUse || 100)}٪</b><button data-a="load" data-i="${i}" data-d="-10" ${(+u.load || 100) <= 50 ? 'disabled' : ''}>کاهش بار ۱۰٪</button><button data-a="load" data-i="${i}" data-d="10" ${(+u.load || 100) >= 140 ? 'disabled' : ''}>افزایش بار ۱۰٪</button><button data-a="load" data-i="${i}" data-d="0">بار نامی ۱۰۰٪</button></div><div class="row hmi-command-actions"><b>کیفیت خوراک: ${fa(u.feedGrade || 90)}٪ · مصرف انرژی: ${f1(u.energyUse || 0)} واحد/روز · هزینه انرژی: ${fa(u.energyCost || 0)}</b><button data-a="feed-grade" data-i="${i}" data-d="-5" ${(+u.feedGrade || 90) <= 70 ? 'disabled' : ''}>کاهش کیفیت خوراک</button><button data-a="feed-grade" data-i="${i}" data-d="5" ${(+u.feedGrade || 90) >= 100 ? 'disabled' : ''}>افزایش کیفیت خوراک</button></div><p class="muted hmi-command-note">شات‌داون، راه‌اندازی مجدد، تعمیرات، تغییر بار و کیفیت خوراک از همین پنل قابل انجام است.</p></section>`, mimic: () => renderProcessMimic({
        unit: u, definition: d, formatNumber: f1, unitIndex: i, selectedIndex: Number.isInteger(S.mimicEq) ? S.mimicEq : null, selectedLoop: Number.isInteger(S.mimicLoop) ? S.mimicLoop : null, loopConfigs: d.v.map((_, k) => S.pid?.[`${i}:${k}`]), valveOpen: u.processState?.valveOpen !== false, pumpStandby: u.processState?.pumpStandby === true, processState: u.processState || null, pidLoops: d.v.map((v, k) => ({ name: v[0], unit: v[1], config: S.pid?.[`${i}:${k}`] })).filter(loop => loop.config?.mode === 'auto')
      }), fa, f1
    });
  }
  Object.assign(game, { viewHMI });
}
