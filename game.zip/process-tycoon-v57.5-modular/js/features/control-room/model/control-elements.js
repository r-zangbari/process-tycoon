// Educational mapping from process variable to a final control element.
// This is a simplified game model, not an engineering design calculation.
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
export function describeFinalElement(variableName = '') {
  const name = String(variableName).toLowerCase();
  if (/سطح|لول|level/.test(name))
    return { type: 'valve', tag: 'LV-101', label: 'شیر کنترل ورودی مخزن', direction: 'direct' };
  if (/دبی|جریان|flow/.test(name))
    return {
      type: 'pump', tag: 'FIC-101 / P-101', label: 'سرعت پمپ / دور محرک', direction: 'direct'
    };
  if (/فشار|pressure/.test(name))
    return { type: 'valve', tag: 'PV-101', label: 'شیر کنترل فشار خروجی', direction: 'reverse' };
  if (/دما|temperature/.test(name))
    return { type: 'valve', tag: 'TV-101', label: 'شیر کنترل سیال گرم‌کننده', direction: 'direct' };
  return { type: 'valve', tag: 'CV-101', label: 'شیر کنترل فرایند', direction: 'direct' };
}
export function actuatorPosition(output, direction = 'direct') {
  const signed = direction === 'reverse' ? -Number(output || 0) : Number(output || 0);
  return clamp(50 + signed * 75, 0, 100);
}
