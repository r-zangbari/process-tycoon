// Small, finite process disturbances. AUTO compensates; it does not repair equipment.
export function stepOperatingDrift(config, { span, variableName = '', automatic = false, random = Math.random } = {}) {
  const s = Math.max(.001, Math.abs(Number(span) || 1));
  if (config.naturalDays > 0) {
    config.naturalDays--;
    config.naturalBias = Math.max(-s * .25, Math.min(s * .25, (Number(config.naturalBias) || 0) * .97));
    if (config.naturalDays === 0) {
      config.naturalBias = 0;
      config.naturalCause = '';
    }
  }
  else {
    config.naturalBias = 0;
    if (!automatic && random() < .02) {
      config.naturalDays = 18;
      config.naturalBias = (random() < .5 ? -1 : 1) * s * (.12 + random() * .1);
      config.naturalCause = /فشار/.test(variableName) ? 'افت یا نوسان جزئی فشار؛ نشتی فرایندیِ مدل' : /دما/.test(variableName) ? 'تغییر ملایم انتقال حرارت' : /دبی|جریان/.test(variableName) ? 'تغییر جزئی مقاومت مسیر' : /سطح|لول/.test(variableName) ? 'عدم تعادل جزئی ورودی و خروجی' : 'نوسان ملایم شرایط خوراک';
    }
  }
  return config.naturalBias || 0;
}
