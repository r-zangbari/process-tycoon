// Coupled educational tank / flow model. It is intentionally simplified and
// is not a hydraulic design or plant-control model.
const clamp = (value, low, high) => Math.min(high, Math.max(low, Number(value) || 0));
function findIndex(variables, pattern) {
  return (variables || []).findIndex(item => pattern.test(String(item?.[0] || '')));
}
export function stepUnitProcessModel({ unit, definition, unitIndex, pid = {}, valveOpen = true, pumpStandby = false }) {
  if (!unit || unit.st !== 'run')
    return null;
  const variables = definition.v || [];
  const levelIndex = findIndex(variables, /سطح|لول|level/i);
  const flowIndex = findIndex(variables, /دبی|جریان|flow/i);
  const pumpIndexes = (definition.e || []).map((item, index) => /پمپ|pump/i.test(String(item?.[0] || '')) ? index : -1).filter(index => index >= 0);
  const selectedPumpIndex = pumpIndexes.length ? pumpIndexes[0] : -1;
  const selectedPump = selectedPumpIndex >= 0 ? unit.eq?.[selectedPumpIndex] : null;
  const selectedPumpAsset = selectedPump && pumpStandby && selectedPump.reserve ? selectedPump.reserve : selectedPump;
  const pumpReady = !selectedPumpAsset || (!selectedPumpAsset.f && Number(selectedPumpAsset.h) >= 30 && (!pumpStandby || selectedPump.reserve));
  const lineOpen = valveOpen !== false;
  const pumpRunning = selectedPump ? (pumpStandby ? selectedPump.reserve?.running === true : selectedPump.running !== false) : true;
  const enabled = lineOpen && pumpReady && pumpRunning;
  const flowCfg = flowIndex >= 0 ? (pid[`${unitIndex}:${flowIndex}`] || {}) : {};
  const levelCfg = levelIndex >= 0 ? (pid[`${unitIndex}:${levelIndex}`] || {}) : {};
  const pumpSpeed = clamp(Number.isFinite(flowCfg.mv) ? flowCfg.mv : 50, 0, 100);
  const inletValve = clamp(Number.isFinite(levelCfg.mv) ? levelCfg.mv : 50, 0, 100);
  const flowSpan = flowIndex >= 0 ? Math.max(Number(variables[flowIndex][3]) || 1, 0.001) : 1;
  const pressureIndex = findIndex(variables, /فشار|pressure/i);
  const temperatureIndex = findIndex(variables, /دما|temperature/i);
  const pressureEffect = pressureIndex >= 0 ? clamp((Number(unit.v[pressureIndex]) - Number(variables[pressureIndex][2])) / Math.max(Number(variables[pressureIndex][3]) || 1, .001), -3, 3) : 0;
  const temperatureEffect = temperatureIndex >= 0 ? clamp((Number(unit.v[temperatureIndex]) - Number(variables[temperatureIndex][2])) / Math.max(Number(variables[temperatureIndex][3]) || 1, .001), -3, 3) : 0;
  const nominalFlow = flowIndex >= 0 ? Number(variables[flowIndex][2]) || 0 : 0;
  // A lower operating pressure reduces available hydraulic driving force;
  // the flow controller may compensate, but the disturbance remains visible.
  const coupling = flowSpan * (pressureEffect * .42 + temperatureEffect * .08) + (Number(flowCfg.naturalBias) || 0);
  const flowTarget = enabled ? clamp(nominalFlow + ((pumpSpeed - 50) / 50) * flowSpan * 2.8 + coupling, 0, nominalFlow + flowSpan * 3.5) : 0;
  const state = unit.processState || (unit.processState = {});
  if (flowIndex >= 0) {
    const priorFlow = Number.isFinite(state.flowPv) ? state.flowPv : Number(unit.v[flowIndex] ?? nominalFlow);
    state.flowPv = clamp(priorFlow + (flowTarget - priorFlow) * 0.28, 0, nominalFlow + flowSpan * 3.5);
    unit.v[flowIndex] = state.flowPv;
  }
  let levelPct = null, inflow = 0, outflow = 0;
  if (levelIndex >= 0) {
    const levelPv = clamp(Number(unit.v[levelIndex]), 0, 100);
    const prior = Number.isFinite(state.tankLevelPct) ? clamp(state.tankLevelPct, 0, 100) : levelPv;
    const flowFactor = flowIndex >= 0 ? clamp(state.flowPv / Math.max(nominalFlow, 0.001), 0, 2) : (enabled ? 1 : 0);
    if (enabled) {
      inflow = 0.5 * (inletValve / 50);
      outflow = 0.5 * flowFactor;
    }
    levelPct = clamp(prior + (inflow - outflow) * 0.45 + (enabled ? (Number(levelCfg.naturalBias) || 0) * .02 : 0), 0, 100);
    state.tankLevelPct = levelPct;
    state.inflow = inflow;
    state.outflow = outflow;
    state.levelStatus = levelPct >= 90 ? 'HIGH' : levelPct <= 10 ? 'LOW' : 'NORMAL';
    unit.v[levelIndex] = levelPct;
  }
  return {
    levelPct, inflow, outflow, pressureEffect, temperatureEffect, flowCouplingEffect: coupling, pumpRunning, pumpStandby: !!pumpStandby, pumpReady, valveOpen: lineOpen, flowFactor: nominalFlow ? clamp(state.flowPv / nominalFlow, 0, 2) : 0, pumpSpeed, inletValve, levelStatus: levelIndex >= 0 ? (state.levelStatus || 'NORMAL') : null
  };
}
