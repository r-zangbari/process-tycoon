// رویدادهای DOM اتاق کنترل (کلیک، کیبورد، انتخاب واحد، تغییر setpoint).
import { D } from '../../data/catalog.js';
import { cl, f1 } from '../../core/format.js';
export function installControlRoomEvents(game) {
  const { S, log, save } = game;
  document.addEventListener('keydown', e => {
    const h = e.target.closest && e.target.closest('.site-unit[data-hmi]');
    if (h && (e.key === 'Enter' || e.key === ' ')) {
      e.preventDefault();
      const i = Number(h.dataset.hmi);
      if (Number.isInteger(i) && S.u[i] && !['build', 'ready'].includes(S.u[i].st)) {
        S.hmiUnit = i;
        S.tab = 'hmi';
        game.draw();
        save();
      }
    }
  });
  document.addEventListener('click', e => {
    const h = e.target.closest('[data-hmi]');
    if (h) {
      const i = Number(h.dataset.hmi);
      if (Number.isInteger(i) && S.u[i] && !['build', 'ready'].includes(S.u[i].st)) {
        S.hmiUnit = i;
        S.tab = 'hmi';
        game.draw();
        save();
        window.scrollTo({ top: 0, behavior: matchMedia('(prefers-reduced-motion:reduce)').matches ? 'auto' : 'smooth' });
      }
      return;
    }
    const g = e.target.closest('[data-go]');
    if (g) {
      const i = +g.dataset.go;
      S.flash = { i, t: Date.now() };
      game.draw();
      const el = document.getElementById('u' + i);
      if (el)
        el.scrollIntoView({
          behavior: matchMedia('(prefers-reduced-motion:reduce)').matches ? 'auto' : 'smooth', block: 'center'
        });
      return;
    }
    const tp = e.target.closest('[data-top]');
    if (tp) {
      const el = document.getElementById('sky');
      if (el)
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
  document.addEventListener('click', e => {
    const valve = e.target.closest('[data-mimic-valve]');
    if (valve) {
      const u = S.u[S.hmiUnit];
      if (u && u.st === 'run') {
        u.processState = u.processState || {};
        u.processState.valveOpen = u.processState.valveOpen === false;
        log(u.processState.valveOpen ? 'فرمان OPEN برای شیر XV-101 صادر شد؛ مسیر جریان باز است.' : 'فرمان CLOSE برای شیر XV-101 صادر شد؛ مسیر جریان مسدود است.');
        game.draw();
        save();
      }
      return;
    }
    const pump = e.target.closest('[data-mimic-pump]');
    if (pump) {
      const u = S.u[S.hmiUnit], d = u && D[u.t];
      if (u && d && u.st === 'run') {
        const pumpIndex = d.e.findIndex((item, index) => /پمپ|pump/i.test(String(item?.[0] || '')) && item?.[1]);
        if (pumpIndex < 0) {
          log('این واحد تجهیز پمپ دارای آرایش رزرو تعریف‌شده ندارد.');
          return;
        }
        const asset = u.eq[pumpIndex], nextStandby = !(u.processState?.pumpStandby === true), candidate = nextStandby ? asset.reserve : asset;
        if (!candidate || candidate.f || Number(candidate.h) < 30) {
          log('فرمان رد شد: پمپ ' + (nextStandby ? 'رزرو' : 'اصلی') + ' آماده بهره‌برداری نیست (سلامت باید حداقل ۳۰٪ باشد).');
          return;
        }
        u.processState = u.processState || {};
        u.processState.pumpStandby = nextStandby;
        asset.running = !nextStandby;
        if (asset.reserve)
          asset.reserve.running = nextStandby;
        log(nextStandby ? 'پمپ رزرو وارد سرویس شد و پمپ اصلی به حالت آماده‌به‌کار رفت.' : 'پمپ اصلی وارد سرویس شد و پمپ رزرو به حالت آماده‌به‌کار رفت.');
        game.draw();
        save();
      }
      return;
    }
  });
  document.addEventListener('click', e => {
    const close = e.target.closest('[data-mimic-close]');
    if (close) {
      S.mimicEq = null;
      S.mimicLoop = null;
      game.draw();
      save();
      return;
    }
    const loop = e.target.closest('[data-mimic-loop]');
    if (loop) {
      const k = Number(loop.dataset.mimicLoop), unit = S.u[S.hmiUnit];
      if (unit && D[unit.t]?.v[k]) {
        S.mimicEq = null;
        S.mimicLoop = k;
        game.draw();
        save();
      }
      return;
    }
    const node = e.target.closest('[data-mimic-eq]');
    if (node) {
      const index = Number(node.dataset.mimicEq);
      const unit = S.u[S.hmiUnit];
      if (unit && Number.isInteger(index) && unit.eq[index]) {
        S.mimicEq = index;
        S.mimicLoop = null;
        game.draw();
        save();
      }
      return;
    }
  });
  document.addEventListener('keydown', e => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.closest?.('[data-mimic-eq]')) {
      e.preventDefault();
      e.target.closest('[data-mimic-eq]').click();
    }
  });
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-mimic-scroll]');
    if (!b)
      return;
    const box = b.closest('.mimic-panel')?.querySelector('.mimic-scroll');
    if (box)
      box.scrollBy({
        left: Number(b.dataset.mimicScroll) * Math.max(220, box.clientWidth * .72), behavior: matchMedia('(prefers-reduced-motion:reduce)').matches ? 'auto' : 'smooth'
      });
  });
  document.addEventListener('change', e => {
    const input = e.target.closest?.('[data-pid-sp]');
    if (!input)
      return;
    const i = Number(input.dataset.i), k = Number(input.dataset.k), u = S.u[i], d = u && D[u.t];
    if (!d || !d.v[k])
      return;
    const base = d.v[k][2], span = Math.max(d.v[k][3], 0.0001), value = Number(input.value);
    if (!Number.isFinite(value)) {
      input.value = base;
      return;
    }
    const key = `${i}:${k}`, cfg = S.pid[key] || (S.pid[key] = { kp: 0.25, ki: 0.06, kd: 0.02, integral: 0, previousError: 0, output: 0, mode: 'manual' });
    cfg.sp = cl(value, base - span * 3, base + span * 3);
    cfg.integral = 0;
    cfg.previousError = (cfg.sp - u.v[k]) / span;
    input.value = cfg.sp;
    log(`Setpoint متغیر ${d.v[k][0]} به ${f1(cfg.sp)} ${d.v[k][1]} تنظیم شد.`);
    save();
    game.draw();
  });
  document.addEventListener('change', e => {
    const select = e.target;
    if (!select || select.id !== 'hmi-unit-select')
      return;
    const selectedIndex = Number(select.value);
    const isAvailable = Number.isInteger(selectedIndex) && S.u[selectedIndex] && !['build', 'ready'].includes(S.u[selectedIndex].st);
    if (!isAvailable)
      return;
    S.hmiUnit = selectedIndex;
    S.mimicEq = null;
    S.mimicLoop = null;
    game.ui.hmiSelectionCommit = true;
    try {
      game.draw();
      save();
    }
    finally {
      game.ui.hmiSelectionCommit = false;
    }
  });
}
