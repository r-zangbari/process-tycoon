// اکشن‌های اتاق کنترل (انتخاب واحد، بخش‌ها، PID).
import { D } from '../../data/catalog.js';
export function installControlRoomActions(game) {
  const { S, log, save } = game;
  Object.assign(game.actions, {
    hselect(x) {
      S.hmiUnit = +x.i;
    },
  });
  game.clickHandlers.push((e, b, x, i, a) => {
    if (a === 'hmi-section') {
      S.hmiSection = ['overview', 'controls', 'equipment', 'alarms'].includes(x.k) ? x.k : 'overview';
      S.hmiMode = S.hmiSection === 'overview' ? 'summary' : 'advanced';
      game.draw();
      save();
      return true;
    }
    if (a === 'hmi-loop') {
      S.hmiLoop = Math.max(0, Number(x.k) || 0);
      S.hmiSection = 'controls';
      S.hmiMode = 'advanced';
      game.draw();
      save();
      return true;
    }
    if (a === 'hmi-mode') {
      S.hmiMode = x.v === 'advanced' ? 'advanced' : 'summary';
      S.hmiSection = S.hmiMode === 'advanced' ? 'controls' : 'overview';
      game.draw();
      save();
      return true;
    }
    if (a === 'pid-toggle') {
      const key = `${i}:${+x.k}`, cfg = S.pid[key] || (S.pid[key] = {
        sp: D[S.u[i].t].v[+x.k][2], kp: 0.25, ki: 0.06, kd: 0.02, integral: 0, previousError: 0, output: 0, mv: 50, mode: 'manual'
      });
      if (S.u[i].st !== 'run' || !S.u[i].au?.[+x.k]) {
        log('برای فعال‌سازی AUTO ابتدا باید کنترلر PID این متغیر را خریداری و نصب کنید.');
        return true;
      }
      cfg.mode = cfg.mode === 'auto' ? 'manual' : 'auto';
      if (cfg.mode === 'manual') {
        cfg.integral = 0;
        cfg.previousError = 0;
      }
      else {
        cfg.rampedSp = S.u[i].v[+x.k];
        cfg.sp = Number.isFinite(cfg.sp) ? cfg.sp : D[S.u[i].t].v[+x.k][2];
        cfg.integral = 0;
        cfg.previousError = 0;
      }
      log(`کنترلر PID متغیر ${D[S.u[i].t].v[+x.k][0]} به حالت ${cfg.mode === 'auto' ? 'خودکار' : 'دستی'} رفت.`);
      game.draw();
      save();
      return true;
    }
    return false;
  });
}
