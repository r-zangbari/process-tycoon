// Project portfolio presentation: commissioned projects and projects still in development.
// This module only composes already-rendered project cards; it does not mutate game state.
export function renderProjectSections({ indexes, units, renderUnit, formatNumber, sectionFilter = null }) {
  const commissioned = [];
  const development = [];
  for (const index of indexes) {
    const unit = units[index];
    if (!unit)
      continue;
    const card = renderUnit(unit, index);
    if (unit.st === 'build' || unit.st === 'ready')
      development.push(card);
    else
      commissioned.push(card);
  }
  const section = (title, description, cards, className, emptyText) => `
  <section class="project-section wide ${className}" aria-label="${title}">
   <div class="project-section-head">
    <div>
     <h2>${title}</h2>
     <p class="muted">${description}</p>
    </div>
    <span class="project-count">${formatNumber(cards.length)} پروژه</span>
   </div>
   ${cards.length
    ? `<div class="project-grid">${cards.join('')}</div>`
    : `<div class="project-empty muted">${emptyText}</div>`}
  </section>`;
  return (sectionFilter === 'projects' ? '' : section('پروژه‌های راه‌اندازی‌شده', 'واحدهای تحویل‌شده به بهره‌برداری؛ شامل واحدهای در حال کار، متوقف، تریپ‌کرده و در تعمیرات.', commissioned, 'commissioned-projects', 'هنوز پروژه‌ای به مرحله راه‌اندازی نرسیده است.')) + (sectionFilter === 'operations' ? '' : section('پروژه‌های در حال ساخت و آماده راه‌اندازی', 'پروژه‌هایی که در مرحله ساخت، نصب تجهیزات یا آماده‌سازی برای راه‌اندازی هستند.', development, 'development-projects', 'پروژه‌ای در حال ساخت یا آماده راه‌اندازی وجود ندارد.'));
}
export function renderProjectNavigation(S, fa) {
  const n = S.u.filter(u => ['build', 'ready'].includes(u.st)).length, active = ['operations', 'projects', 'catalog'].includes(S.industrySection) ? S.industrySection : !S.u.length ? 'catalog' : n ? 'projects' : 'operations';
  return `<nav class="project-navigation wide" aria-label="مدیریت صنعت و ساخت پروژه">${[['operations', 'بهره‌برداری', S.u.length - n], ['projects', 'ساخت و راه‌اندازی', n], ['catalog', 'شروع پروژه جدید', null]].map(([k, title, count]) => `<button data-a="industry-section" data-k="${k}" aria-pressed="${active === k}">${title}${count == null ? '' : ' · ' + fa(count)}</button>`).join('')}</nav>`;
}
export function projectStage(u, d, fa) {
  return `<div class="project-stage"><span class="${u.st === 'build' ? 'current' : 'done'}">۱ · نصب تجهیزات ${fa(u.eq.length)}/${fa(d.e.length)}</span><span class="${u.st === 'ready' && !u.su ? 'current' : ''}">۲ · آماده‌سازی</span><span class="${u.su ? 'current' : ''}">۳ · راه‌اندازی ${u.su ? fa(u.su.pos) + '/۵' : ''}</span></div>`;
}
