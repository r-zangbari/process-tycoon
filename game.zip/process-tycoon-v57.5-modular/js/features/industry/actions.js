// اکشن‌های دکمه‌های صنعت (روشن/خاموش، تعمیر، پاداش، تحقیق، قرارداد ...).
import { D, IC, INFN, PR, TECH } from '../../data/catalog.js';
import { recoveryBlock } from '../maintenance/model/unit-recovery.js';
import { changeSafety } from '../safety/model/safety.js';
import { cleanUnitName, unitName } from '../../engine/unit-names.js';
import { clearNavigationHighlight } from '../../ui-kit/navigation-highlight.js';
import { cl, fa } from '../../core/format.js';
export function installIndustryActions(game) {
  const { S, anyOut, log, pay, r, save } = game;
  Object.assign(game.actions, {
    load(x) {
      const u = S.u[+x.i];
      if (!u || !['run', 'trip', 'off'].includes(u.st))
        return;
      const delta = Number(x.d);
      u.load = delta === 0 ? 100 : cl((Number(u.load) || 100) + delta, 50, 140);
      u.overloadTicks = 0;
      log('بار عملیاتی «' + D[u.t].n + '» روی ' + fa(u.load) + '٪ تنظیم شد.');
    },
    'feed-grade'(x) {
      const u = S.u[+x.i];
      if (!u || !['run', 'trip', 'off'].includes(u.st))
        return;
      u.feedGrade = cl((Number(u.feedGrade) || 90) + Number(x.d), 70, 100);
      log('کیفیت خوراک ورودی «' + D[u.t].n + '» روی ' + fa(u.feedGrade) + '٪ تنظیم شد؛ هزینه و کیفیت محصول متناسب تغییر می‌کند.');
    },
    stop(x) {
      const u = S.u[+x.i];
      if (u && u.st === 'run') {
        u.st = 'off';
        log('«' + D[u.t].n + '» به‌صورت عمدی از سرویس خارج شد؛ هزینه‌ی جاری و مصرف خوراک متوقف است.');
      }
    },
    resume(x) {
      const u = S.u[+x.i];
      if (!u || u.st !== 'off')
        return;
      const d = D[u.t], blocked = recoveryBlock(S, u, +x.i, D);
      if (blocked) {
        log(blocked);
        return;
      }
      if (pay(d.cost * .02)) {
        u.v = d.v.map(y => y[2] + (r() < .5 ? -1 : 1) * y[3] * 1.2);
        u.st = anyOut(u) ? 'broken' : 'run';
        log('«' + d.n + '» ' + (u.st === 'run' ? 'دوباره وارد سرویس شد.' : 'هنوز تجهیز خراب دارد؛ ابتدا تعمیر کنید.'));
      }
    },
    ab() {
      const n = S.ab || 0;
      if (n < 3 && pay(4000 * (n + 1))) {
        S.ab = n + 1;
        log('سامانه‌ی کنترل انتشار ارتقا یافت.');
      }
    },
    eng() {
      if ((S.eng || 0) < 3 && pay(3000)) {
        S.eng = (S.eng || 0) + 1;
        log('مهندس متخصص استخدام شد.');
      }
    },
    infra() {
      const n = S.infra || 0;
      if (n < 4 && pay(IC[n])) {
        S.infra = n + 1;
        log('زیرساخت «' + INFN[n] + '» ساخته شد.');
      }
    },
    flt(x) {
      S.flt = x.v;
    },
    srt(x) {
      S.srt = x.v;
    },
    neg() {
      if (S.walk && pay(2000)) {
        S.walk = null;
        S.mor = Math.min(100, S.mor + 30);
        S.sal = Math.round((S.sal || 12) * 1.15 * 10) / 10;
        log('مذاکره موفق شد؛ اپراتورها برگشتند و حقوق ۱۵٪ بالا رفت.');
      }
    },
    contr() {
      if (S.walk && !S.walk.c && pay(800)) {
        S.walk.c = 1;
        log('پیمانکار موقت جایگزین نیمی از نیروها شد.');
      }
    },
    bonus() {
      if (pay(1000)) {
        S.mor = Math.min(100, S.mor + 20);
        log('پاداش و رفاه پرداخت شد؛ روحیه‌ی اپراتورها بهتر شد.');
      }
    },
    tar(x) {
      const u = S.u[+x.i];
      if (!u)
        return;
      const d = D[u.t];
      if ((u.st === 'run' || u.st === 'trip' || u.st === 'off') && pay(d.cost * .15)) {
        u.st = 'tar';
        u.tar = 5;
        log('تعمیرات اساسی «' + d.n + '» شروع شد (۵ روز توقف).');
      }
    },
    restart(x) {
      const ui = +x.i, u = S.u[ui];
      if (!u || !['trip', 'broken'].includes(u.st))
        return;
      const d = D[u.t], blocked = recoveryBlock(S, u, ui, D);
      if (blocked) {
        log(blocked);
        return;
      }
      const keepStandby = !!u.processState?.pumpStandby;
      if (pay(d.cost * .04)) {
        u.v = d.v.map((y, k) => {
          const cfg = S.pid?.[`${ui}:${k}`] || (S.pid[`${ui}:${k}`] = {});
          cfg.integral = 0;
          cfg.previousError = 0;
          cfg.output = 0;
          cfg.disturbance = 0;
          cfg.mv = Number.isFinite(cfg.mv) ? cl(cfg.mv, 0, 100) : 50;
          cfg.sp = Number.isFinite(cfg.sp) ? cl(cfg.sp, y[2] - y[3] * 3, y[2] + y[3] * 3) : y[2];
          cfg.rampedSp = y[2];
          return y[2] + (r() - .5) * y[3] * .04;
        });
        u.st = anyOut(u) ? 'broken' : 'run';
        u.tripReason = null;
        if (u.maintenance)
          u.maintenance.recoveryPending = false;
        u.feedIncident = null;
        u.coolingIncident = null;
        u.instrumentIncident = null;
        u.incidentEquipment = null;
        u.processState = { valveOpen: true, pumpStandby: false, lowFlowTicks: 0 };
        u.eq.forEach((e, j) => {
          if (/پمپ|pump/i.test(String(d.e[j]?.[0] || ''))) {
            const useReserve = !!(e.reserve && !e.reserve.f && e.reserve.h >= 30 && (e.f || keepStandby));
            e.running = !useReserve;
            if (e.reserve)
              e.reserve.running = useReserve;
            if (useReserve)
              u.processState.pumpStandby = true;
          }
        });
        log('راه‌اندازی مجدد «' + d.n + '» با بازنشانی مسیر XV-101؛ بار عملیاتی، بازشدگی دستی شیر/دور پمپ و SP تنظیم‌شده توسط اپراتور حفظ شد و حلقه‌های AUTO به‌صورت تدریجی به SP معتبر می‌رسند. ' + (u.st === 'run' ? 'واحد وارد سرویس شد.' : 'به‌دلیل خرابی تجهیز، واحد هنوز خارج از سرویس است.'));
      }
    },
    tech(x) {
      if (S.rd)
        return;
      const t = TECH.find(q => q[0] === x.k);
      if (!t || (S.tech || {})[t[0]])
        return;
      if (pay(t[3])) {
        S.rd = { k: t[0], d: t[4] };
        log('تحقیق «' + t[1] + '» شروع شد (' + fa(t[4]) + ' روز).');
      }
    },
    step(x) {
      const u = S.u[+x.i];
      if (!u || !u.su)
        return;
      const s = u.su;
      if (+x.k === s.pos)
        s.pos++;
      else {
        s.miss++;
        changeSafety(S, -.5, 'رعایت‌نکردن ترتیب راه‌اندازی', { routine: true, key: x.i + ':startup', unit: Number(x.i), target: 'unit' });
        log('ترتیب اشتباه! خطای ایمنی ثبت شد.');
      }
      if (s.pos >= 5) {
        const d = D[u.t], f = s.miss === 0 ? .8 : s.miss < 3 ? 1.6 : 2.4;
        u.v = d.v.map(y => y[2] + (r() < .5 ? -1 : 1) * y[3] * f);
        u.st = 'run';
        u.su = null;
        S.industrySection = 'operations';
        S.expandedUnit = +x.i;
        log('«' + d.n + '» راه‌اندازی شد' + (s.miss ? ' با ' + fa(s.miss) + ' خطا' : ' بدون خطا') + '.');
      }
    },
    cr(x) {
      game.resolveCr(+x.o);
    },
    line() {
      const n = S.line || 0;
      if (pay(3000 * (n / 100 + 1)))
        S.line = n + 100;
    },
    ctok(x) {
      const c = S.co[+x.o];
      if (!c)
        return;
      S.co.splice(+x.o, 1);
      (S.ct = S.ct || []).push(c);
      log('قرارداد ' + PR[c.p][0] + ' امضا شد.');
    },
    ctno(x) {
      S.co.splice(+x.o, 1);
    },
  });
  game.clickHandlers.push((e, b, x, i, a) => {
    if (a === 'unit-rename') {
      if (S.u[i])
        S.u[i].name = cleanUnitName(document.getElementById('unit-name-' + i)?.value) || unitName(S.u[i], D, i);
      game.draw();
      save();
      return true;
    }
    if (a === 'industry-section') {
      clearNavigationHighlight();
      S.industrySection = x.k;
      game.draw();
      save();
      return true;
    }
    if (a === 'unit-expand') {
      S.expandedUnit = i;
      game.draw();
      return true;
    }
    if (a === 'unit-collapse') {
      S.expandedUnit = null;
      game.draw();
      return true;
    }
    return false;
  });
}
