import { L5 } from '../../../data/catalog.js';

export function nextProjectStep(unit, definition) {
  if (unit.st !== 'build' && unit.st !== 'ready') return null;
  if (unit.prob) return {
    label: 'بررسی ایراد نصب',
    text: 'ایراد نصب ثبت شده است. هزینهٔ رفع فوری و پیامد ادامه را در کارت پروژه بررسی کن.',
    selector: '[data-a="fix"]'
  };
  if (unit.st === 'build') {
    const equipment = definition?.e[unit.eq?.length ?? 0]?.[0];
    return {
      label: 'رفتن به نصب تجهیز',
      text: equipment ? 'تجهیز بعدی برای نصب «' + equipment + '» است.' : 'فهرست تجهیزات و وضعیت نصب پروژه را بررسی کن.',
      selector: '[data-a="install"]'
    };
  }
  if (unit.su && L5[unit.su.pos]) return {
    label: 'رفتن به گام بعدی راه‌اندازی',
    text: 'گام بعدی راه‌اندازی «' + L5[unit.su.pos] + '» است.',
    selector: '[data-a="step"][data-k="' + unit.su.pos + '"]'
  };
  return {
    label: 'رفتن به آماده‌سازی راه‌اندازی',
    text: 'نصب کامل است. هزینهٔ خوراک اولیه را بررسی کن و راه‌اندازی را آغاز کن.',
    selector: '[data-a="start"]'
  };
}
