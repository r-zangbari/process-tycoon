// کارت‌های صفحه‌ی صنعت: نیروی انسانی، بحران، قرارداد، مأموریت، رقبا، ESG و زیرساخت.
import { renderSafetyReport } from '../safety/view/safety-report.js';
import { D, EM, GOAL, IC, INFN, OPN, PR, RIV, SEAS, SF, TECH, TECHN, TY } from '../../data/catalog.js';
import { changeSafety } from '../safety/model/safety.js';
import { cl, f1, fa } from '../../core/format.js';
export function installIndustryCards(game) {
  const { S, log, pay, r, recordSOE } = game;
  function personnelCard() {
    const p = S.personnel || { injured: 0, fatalities: 0, injuryDays: 0 };
    return `<div class="card wide"><h2>ایمنی نیروی انسانی و HSE</h2><div class="row"><span>آسیب‌دیدگی تجمعی: <b class="${p.injured ? 'wn' : 'ok'}">${fa(p.injured || 0)}</b></span><span>تلفات جانی: <b class="${p.fatalities ? 'bd' : 'ok'}">${fa(p.fatalities || 0)}</b></span><span>اپراتور خارج از شیفت: <b>${fa(p.injuryDays > 0 ? 1 : 0)}</b></span><span>نیروی ازدست‌رفته دائمی: <b>${fa(p.fatalities || 0)}</b></span><span>شاخص ایمنی: <b class="${S.safe < 50 ? 'bd' : S.safe < 80 ? 'wn' : 'ok'}">${fa(S.safe)}٪</b></span></div><small class="muted">تصمیم پرخطر یا تأخیر در واکنش می‌تواند به آسیب یا فوت نیروی انسانی منجر شود. هزینه درمان، غرامت، پیگیری قانونی و جریمه از سرمایه کسر می‌شود؛ اقدام ایمن و تخلیه به‌موقع ریسک را کاهش می‌دهد.</small>${renderSafetyReport(S, D)}</div>`;
  }
  function applyPersonnelConsequence(eventKey, unitIndex) {
    const risk = {
      feed: [.08, .005], cooling: [.28, .035], rotating: [.34, .045], instrument: [.16, .012], grid: [.22, .025], leak: [.62, .19], flood: [.27, .025], core: [.48, .14]
    }[eventKey] || [.15, .01];
    const p = S.personnel = S.personnel || { injured: 0, fatalities: 0, injuryDays: 0 };
    const safetyFactor = cl(1 - (S.tr || 0) * .12 + (70 - S.safe) * .004, .45, 1.35);
    const fatal = Math.random() < risk[1] * safetyFactor;
    const injured = !fatal && Math.random() < risk[0] * safetyFactor;
    changeSafety(S, -(fatal ? 22 : injured ? 12 : 2), fatal ? 'حادثه منجر به فوت؛ پیامد ایمنی شدید' : injured ? 'آسیب اپراتور در رخداد عملیاتی' : 'تشدید رخداد یا بی‌اقدامی؛ نزدیک‌به‌حادثه بدون آسیب انسانی', { unit: unitIndex, target: 'controls' });
    if (fatal) {
      p.fatalities = (p.fatalities || 0) + 1;
      const fine = 120000;
      S.money -= fine;
      log(`حادث منجر به فوت یک اپراتور شد؛ غرامت و جریمه قانونی ${fa(fine)} از سرمایه کسر شد.`);
      recordSOE('حادثه انسانی: فوت اپراتور؛ توقف و بررسی HSE الزامی است.', 'HIGH', unitIndex);
    }
    else if (injured) {
      p.injured = (p.injured || 0) + 1;
      p.injuryDays = Math.max(p.injuryDays || 0, 6 + Math.floor(r() * 5));
      const fine = 18000;
      S.money -= fine;
      log(`یک اپراتور آسیب دید و ${fa(fine)} هزینه درمان، غرامت و جریمه از سرمایه کسر شد؛ نیروی انسانی تا پایان درمان در دسترس نیست.`);
      recordSOE('حادثه انسانی: آسیب‌دیدگی اپراتور و خروج موقت از شیفت.', 'HIGH', unitIndex);
    }
    else {
      log('حادثه بدون آسیب انسانی مهار شد؛ با این حال تخطی از رویه ایمنی ثبت شد.');
      recordSOE('نزدیک‌به‌حادثه (Near Miss): اقدام پرخطر بدون آسیب انسانی.', 'MED', unitIndex);
    }
  }
  const CR = {
    feed: {
      t: 'اختلال خوراک ورودی', m: n => `دبی یا کیفیت خوراک ورودی «${n}» دچار نوسان شده است.`, o: [['تأمین خوراک جایگزین (۸۰۰)', 800, 'safe'], ['کاهش بار ۲۰٪ و پایش (رایگان)', 0, 'reduce'], ['ادامه بدون اقدام (پرخطر)', 0, 'risk']]
    },
    cooling: {
      t: 'افت ظرفیت خنک‌کاری', m: n => `دمای فرایند «${n}» به‌علت افت عملکرد سیستم خنک‌کاری در حال افزایش است.`, o: [['راه‌اندازی خنک‌کاری اضطراری (۱۲۰۰)', 1200, 'safe'], ['کاهش بار ۲۵٪ (رایگان)', 0, 'reduce'], ['توقف اضطراری واحد (۳۰۰)', 300, 'trip']]
    },
    rotating: {
      t: 'لرزش/اختلال تجهیز دوار', m: n => `افزایش لرزش در تجهیز دوار «${n}» گزارش شده است.`, o: [['انتقال بار به تجهیز رزرو (۳۰۰)', 300, 'switch'], ['کاهش بار و پایش (رایگان)', 0, 'reduce'], ['ادامه کار بدون اقدام (پرخطر)', 0, 'risk']]
    },
    instrument: {
      t: 'اختلال ابزار دقیق', m: n => `سیگنال یکی از ترانسمیترهای «${n}» مشکوک به انحراف یا Drift است.`, o: [['انتقال حلقه مربوطه به MAN و بررسی (۲۵۰)', 250, 'manual'], ['کاهش بار ۱۵٪ و پایش (رایگان)', 0, 'reduce'], ['ادامه در AUTO (پرخطر)', 0, 'risk']]
    },
    grid: {
      t: 'افت/قطع برق شبکه', m: n => `تأمین برق «${n}» دچار افت شده است.`, o: [['راه‌اندازی ژنراتور اضطراری (۵۰۰)', 500, 'safe'], ['کاهش بار واحدها (رایگان)', 0, 'reduceall'], ['خاموشی کنترل‌شده همه واحدها (۱۰۰)', 100, 'tripall']]
    },
    leak: {
      t: 'نشتی گاز', m: n => `نشتی گاز در «${n}» گزارش شد.`, o: [['ESD و ایزوله کردن (۳۰۰)', 300, 'trip'], ['تخلیه و اعلام وضعیت اضطراری (۸۰۰)', 800, 'evac'], ['ادامه با پایش (پرخطر)', 0, 'risk']]
    },
    flood: {
      t: 'آب‌گرفتگی محوطه', m: n => `آب‌گرفتگی در محوطه‌ی «${n}» شناسایی شده است.`, o: [['پمپ تخلیه و حفاظت تجهیزات (۶۰۰)', 600, 'safe'], ['توقف و محافظت از تجهیزات (۲۰۰)', 200, 'trip'], ['نادیده گرفتن (پرخطر)', 0, 'risk']]
    },
    core: {
      t: 'اختلال خنک‌کاری راکتور', m: n => `اختلال در سیستم خنک‌کاری «${n}».`, o: [['خنک‌سازی اضطراری (۲٬۰۰۰)', 2000, 'safe'], ['کاهش توان و پایش (رایگان)', 0, 'reduce'], ['SCRAM و خاموشی (۵۰۰)', 500, 'trip']]
    }
  };
  function resolveCr(oi) {
    const c = S.cr;
    if (!c)
      return;
    const u = S.u[c.i], def = CR[c.k], o = oi == null ? null : def.o[oi], act = o ? o[2] : 'bad';
    if (o && !pay(o[1]))
      return;
    S.cr = null;
    const clearEffects = x => {
      if (!x)
        return;
      x.feedIncident = null;
      x.coolingIncident = null;
      x.instrumentIncident = null;
      if (c.k === 'grid')
        S.gridIncident = null;
    };
    const trip = x => {
      if (x?.st === 'run') {
        x.st = 'trip';
        clearEffects(x);
      }
    };
    if (act === 'safe') {
      if (c.k === 'feed' && u)
        u.feedIncident = null;
      if (c.k === 'cooling' && u)
        u.coolingIncident = null;
      if (c.k === 'grid')
        S.gridIncident = null;
      log('اقدام اضطراری موفق بود؛ اختلال مهار شد و واحدها در سرویس باقی ماندند.');
      recordSOE('رخداد با اقدام اضطراری مهار شد.', 'INFO', c.i);
    }
    else if (act === 'reduce') {
      if (u) {
        u.load = cl((u.load || 100) - 20, 50, 140);
        if (c.k === 'feed')
          u.feedIncident = { days: 2, factor: .85 };
        if (c.k === 'cooling')
          u.coolingIncident = { days: 2, offset: .3 };
        if (c.k === 'instrument')
          u.instrumentIncident = { days: 2, k: u.instrumentIncident?.k ?? 0, bias: .25 };
      }
      log('بار واحد کاهش یافت؛ رخداد با محدودیت تولید تحت پایش قرار گرفت.');
      recordSOE('بار عملیاتی برای کنترل رخداد کاهش یافت.', 'MED', c.i);
    }
    else if (act === 'reduceall') {
      S.u.forEach(x => {
        if (x.st === 'run')
          x.load = cl((x.load || 100) - 20, 50, 140);
      });
      S.gridIncident = { days: 1, factor: .9 };
      log('بار تمام واحدهای در سرویس ۲۰٪ کاهش یافت.');
      recordSOE('بار کل سایت برای مدیریت افت برق کاهش یافت.', 'MED');
    }
    else if (act === 'switch') {
      if (u) {
        const j = u.incidentEquipment ?? u.eq.findIndex((e, k) => e.reserve && /پمپ|pump/i.test(String(D[u.t].e[k]?.[0] || '')));
        const e = u.eq[j];
        if (e?.reserve && !e.reserve.f && e.reserve.h >= 30) {
          e.running = false;
          e.reserve.running = true;
          u.processState = u.processState || {};
          u.processState.pumpStandby = true;
          u.processState.pumpRunning = true;
          u.eq[j].h = Math.max(0, u.eq[j].h - 2);
          log('تجهیز رزرو وارد سرویس شد؛ تجهیز دارای لرزش از مدار خارج شد.');
          recordSOE('انتقال سرویس به تجهیز رزرو انجام شد.', 'INFO', c.i);
        }
        else {
          u.load = cl((u.load || 100) - 20, 50, 140);
          log('تجهیز رزرو آماده نبود؛ بار واحد کاهش یافت.');
          recordSOE('رزرو در دسترس نبود؛ بار واحد کاهش یافت.', 'MED', c.i);
        }
      }
    }
    else if (act === 'manual') {
      if (u?.instrumentIncident) {
        const key = `${c.i}:${u.instrumentIncident.k}`, cfg = S.pid[key];
        if (cfg) {
          cfg.mode = 'manual';
          cfg.integral = 0;
          cfg.previousError = 0;
        }
        u.instrumentIncident = null;
      }
      log('حلقه مرتبط به MAN منتقل شد؛ بررسی ابزار دقیق لازم است.');
      recordSOE('حلقه کنترلی مشکوک از AUTO خارج شد.', 'INFO', c.i);
    }
    else if (act === 'trip' || act === 'evac') {
      trip(u);
      if (act === 'evac')
        changeSafety(S, 5, 'تخلیه ایمن در واکنش به نشتی', { unit: c.i, target: 'controls' });
      log('واحد به‌صورت ایمن از سرویس خارج شد؛ پس از رفع علت راه‌اندازی مجدد کنید.');
      recordSOE('واحد به فرمان اپراتور ESD/Shutdown شد.', 'HIGH', c.i);
    }
    else if (act === 'tripall') {
      S.u.forEach(trip);
      log('خاموشی کنترل‌شده انجام شد؛ واحدها را پس از پایدارشدن شبکه دوباره راه‌اندازی کنید.');
      recordSOE('خاموشی کنترل‌شده سایت انجام شد.', 'HIGH');
    }
    else {
      applyPersonnelConsequence(c.k, c.i);
      if (u) {
        u.load = cl((u.load || 100) - 10, 50, 140);
        if (c.k === 'rotating') {
          const j = u.incidentEquipment, e = u.eq[j];
          if (e) {
            e.h = Math.max(0, e.h - 18);
            if (e.h < 30) {
              e.f = { st: 0, eta: 0, dl: 0 };
              u.st = 'broken';
            }
          }
        }
        else if (c.k === 'cooling' || c.k === 'core') {
          u.st = 'trip';
          S.money -= c.k === 'core' ? 15000 : 2500;
        }
        else if (c.k === 'leak') {
          u.st = 'broken';
          if (u.eq[0] && !u.eq[0].f)
            u.eq[0].f = { st: 0, eta: 0, dl: 0 };
          S.money -= 2000;
        }
        else if (c.k === 'flood')
          u.eq.forEach(e => e.h = Math.max(0, e.h - 25));
        else if (c.k === 'instrument') {
          u.st = 'trip';
        }
        else if (c.k === 'feed')
          u.feedIncident = { days: 4, factor: .5 };
      }
      if (c.k === 'grid') {
        S.u.forEach(trip);
        S.gridIncident = { days: 3, factor: .4 };
      }
      log('عدم اقدام مناسب باعث تشدید رخداد، خسارت اقتصادی و افت شاخص ایمنی شد.');
      recordSOE('رخداد تشدید شد؛ خسارت عملیاتی ثبت گردید.', 'HIGH', c.i);
    }
  }
  function crisisCard() {
    const c = S.cr;
    if (!c)
      return walkCard() + personnelCard();
    const def = CR[c.k], u = S.u[c.i];
    return walkCard() + personnelCard() + `<div class="card wide" style="border-color:var(--bad)"><h2 class="bd">بحران: ${def.t}</h2><div class="note"><b>${def.m(D[u.t].n)}</b> ${fa(c.d)} روز فرصت تصمیم دارید؛ در غیر این صورت بدترین نتیجه رخ می‌دهد.<div class="row">${def.o.map((o, k) => `<button class="p" data-a="cr" data-o="${k}">${o[0]}</button>`).join('')}</div></div></div>`;
  }
  function contractCard() {
    const ct = S.ct || [], co = S.co || [];
    return `<div class="card"><h2>قراردادها</h2><div class="muted" style="font-size:12px">قیمت قرارداد ثابت و ۲۵٪ بالاتر از پایه است، ولی کسری تحویل جریمه‌ی ۱٫۵ برابر قیمت دارد.</div>${ct.map(c => `<div class="eq"><span>${PR[c.p][0]}: ${fa(c.q)} در روز</span><span class="tag run">${fa(c.d)} روز</span></div>`).join('') || '<div class="muted">قرارداد فعالی ندارید.</div>'}${co.map((c, k) => `<div class="note">پیشنهاد: ${PR[c.p][0]} ${fa(c.q)} در روز، ${fa(c.d)} روز، قیمت ×${f1(c.pr)}<div class="row"><button class="p" data-a="ctok" data-o="${k}">امضا</button><button data-a="ctno" data-o="${k}">رد</button></div></div>`).join('')}</div>`;
  }
  const opsNeed = () => S.u.reduce((a, u) => a + (u.st === 'run' ? OPN[u.t] : 0), 0);
  const opsAvail = () => {
    const unavailable = (S.personnel?.injuryDays > 0 ? 1 : 0) + (S.personnel?.fatalities || 0);
    const base = Math.max(0, (S.ops || 0) - unavailable);
    return S.walk ? Math.floor(base * (1 - S.walk.f * (S.walk.c ? .5 : 1))) : base;
  };
  function walkCard() {
    const w = S.walk;
    if (!w)
      return '';
    return `<div class="card wide" style="border-color:var(--bad)"><h2 class="bd">اپراتورها دست از کار کشیده‌اند</h2><div class="note"><b>در دسترس: ${fa(opsAvail())} از ${fa(S.ops)} اپراتور · ${fa(w.d)} روز مانده</b> تولید و ایمنی واحدها زیر فشار است.<div class="row"><button class="p" data-a="neg">مذاکره و افزایش ۱۵٪ حقوق (۲٬۰۰۰)</button><button data-a="contr" ${w.c ? 'disabled' : ''}>پیمانکار موقت (۸۰۰)</button></div></div></div>`;
  }
  const emission = () => S.u.reduce((a, u) => a + (u.st === 'run' ? EM[u.t] : 0), 0);
  const netWorth = () => S.money - (S.debt || 0) + S.u.reduce((a, u) => a + (u.st === 'build' ? 0 : D[u.t].cost * .8), 0) + S.grid.reduce((a, b) => a + (b ? TY[b.t].cost * b.l * .5 : 0), 0);
  const MS = [
    ['m1', 'تأمین کامل برق کشور', '۱۰ روز با تأمین ≥ ۹۸٪ برق', 10, 5000, () => S.dem.power > 0 && (S.fr.power ?? 1) >= .98],
    ['m2', 'گاز زمستان', '۲۰ روز زمستانی با تأمین ≥ ۹۰٪ گاز', 20, 8000, () => Math.floor(((S.day - 1) % 360) / 90) === 3 && S.dem.gas > 0 && (S.fr.gas ?? 1) >= .9],
    ['m3', 'استقلال خوراک', '۱۵ روز بدون واردات خوراک', 15, 6000, () => S.imc === 0 && S.u.some(u => u.st === 'run')],
    ['m4', 'کشور سبز', '۱۵ روز با ESG ≥ ۸۰٪', 15, 7000, () => S.esg >= 80],
    ['m5', 'شهر بزرگ', 'جمعیت ≥ ۱۶۰٬۰۰۰ نفر', 1, 5000, () => S.pop >= 160000],
    ['m6', 'صادرکننده‌ی بزرگ', 'درآمد صادراتی ≥ ۱٬۰۰۰ در روز', 1, 10000, () => (S.inc.ex || 0) >= 1000]
  ];
  function missionCard() {
    const o = S.ms || {};
    return `<div class="card"><h2>مأموریت‌ها</h2>${MS.map(([k, n, d, nd, rw]) => {
      const m = o[k] || { p: 0, done: 0 };
      return `<div class="eq"><span><b>${n}</b> <span class="muted">${d}</span></span><span>${m.done ? '<span class="tag run">انجام شد</span>' : fa(m.p) + '/' + fa(nd) + ' · جایزه ' + fa(rw)}</span></div>`;
    }).join('')}</div>`;
  }
  function rivalCard() {
    const rows = [['شما', netWorth(), 1], ...(S.rv || []).map((w, i) => [RIV[i], w, 0])].sort((a, b) => b[1] - a[1]);
    return `<div class="card"><h2>رقبا و رتبه‌بندی</h2><div class="muted" style="font-size:12px">ارزش خالص = سرمایه + دارایی‌ها − بدهی. رقبا گاهی قرارداد را قاپ می‌زنند یا قیمت‌شکنی می‌کنند.</div>${rows.map((x, i) => `<div class="eq"><span>${fa(i + 1)}. ${x[2] ? '<b>' + x[0] + '</b>' : x[0]}</span><b>${fa(x[1])}</b></div>`).join('')}</div>`;
  }
  function esgCard() {
    const n = S.ab || 0, em = emission() * Math.pow(.7, n);
    return `<div class="card"><h2>محیط‌زیست (ESG)</h2><div class="row">نمره: <b class="${S.esg < 40 ? 'bd' : S.esg < 70 ? 'wn' : 'ok'}">${fa(S.esg)}٪</b> · شاخص انتشار: <b>${f1(em)}</b></div><div class="muted" style="font-size:12px">بالای ۷۰٪ قیمت صادرات ۱۰٪ بیشتر، زیر ۴۰٪ ده درصد کمتر و زیر ۳۰٪ جریمه. تریپ نمره را کم می‌کند. هر سطح کنترل انتشار، انتشار را ۳۰٪ کم می‌کند.</div><div class="row">کنترل انتشار: <b>${fa(n)}/۳</b> <button data-a="ab" ${n >= 3 ? 'disabled' : ''}>ارتقا (${fa(4000 * (n + 1))})</button></div></div>`;
  }
  function infraCard() {
    const n = S.infra || 0;
    return `<div class="card"><h2>زیرساخت ملی</h2><div class="row">سطح فعلی: <b>${fa(n)}/۴</b></div>${IC.map((c, k) => `<div class="eq"><span>${fa(k + 1)}. ${INFN[k]}</span>${k < n ? '<span class="tag run">ساخته شد</span>' : k === n ? `<button data-a="infra">ساخت (${fa(c)})</button>` : '<span class="muted">قفل</span>'}</div>`).join('')}<div class="muted" style="font-size:12px">هر واحد برای ساخت به سطح زیرساخت مشخصی نیاز دارد. فولاد و سیمان ساخت از مخزن خودتان برداشت می‌شود و کمبودش با قیمت واردات خریده می‌شود.</div></div>`;
  }
  function techCard() {
    const o = S.tech || {};
    return `<div class="card wide"><h2>تحقیق و توسعه</h2>${S.rd ? `<div class="note">در حال تحقیق: <b>${TECHN[S.rd.k]}</b> · ${fa(S.rd.d)} روز مانده</div>` : '<div class="muted" style="font-size:12px">هم‌زمان فقط یک تحقیق ممکن است.</div>'}${TECH.map(([k, n, ds, c, d]) => `<div class="eq"><span><b>${n}</b> <span class="muted">${ds}</span></span>${o[k] ? '<span class="tag run">انجام شد</span>' : `<button data-a="tech" data-k="${k}" ${S.rd ? 'disabled' : ''}>تحقیق (${fa(c)} · ${fa(d)} روز)</button>`}</div>`).join('')}</div>`;
  }
  function statsCard() {
    const T = [0, 0, 0, 0, 0], si = Math.floor(((S.day - 1) % 360) / 90);
    const rows = D.map((d, t) => {
      const us = S.u.filter(u => u.t === t), bl = us.filter(u => u.st === 'build' || u.st === 'ready').length, rn = us.filter(u => u.st === 'run').length, dn = us.length - bl, sp = dn - rn;
      [us.length, dn, bl, rn, sp].forEach((v, k) => T[k] += v);
      return `<tr><td>${d.n}</td><td class="muted">${GOAL[t]}</td><td><b>${fa(dn)}</b></td><td>${fa(bl)}</td><td class="ok">${fa(rn)}</td><td class="${sp ? 'bd' : ''}">${fa(sp)}</td></tr>`;
    }).join('');
    const g = {};
    S.grid.forEach(b => {
      if (b) {
        g[b.t] = g[b.t] || [0, 0];
        g[b.t][0]++;
        g[b.t][1] += b.l;
      }
    });
    return `<div class="card wide"><h2>آمار پروژه‌ها</h2><div class="row"><span class="tag">فصل: ${SEAS[si]}</span><span class="tag">ضریب تقاضا: گاز ×${f1(SF[si].g)} · برق ×${f1(SF[si].p)}</span></div><div style="overflow-x:auto"><table><tr><th>پروژه</th><th>هدف اصلی</th><th>ساخته‌شده</th><th>در حال ساخت</th><th>در حال کار</th><th>متوقف / خراب / تعمیرات</th></tr>${rows}<tr><td><b>جمع</b></td><td></td><td><b>${fa(T[1])}</b></td><td><b>${fa(T[2])}</b></td><td><b>${fa(T[3])}</b></td><td><b>${fa(T[4])}</b></td></tr></table></div><div class="row" style="margin-top:6px">${Object.entries(TY).filter(() => false).map(([k, t]) => `<span class="tag">${t.e} ${t.n}: ${fa((g[k] || [0])[0])} (جمع سطح ${fa((g[k] || [0, 0])[1])})</span>`).join(' ')}</div></div>`;
  }
  Object.assign(game, {
    CR, MS, contractCard, crisisCard, emission, esgCard, infraCard, missionCard, opsAvail, opsNeed, resolveCr, rivalCard, statsCard, techCard
  });
}
