// صفحه‌ی «صنعت»: کارت واحدها، نمودارها و viewIndustry().
import { unitTitle } from '../../engine/unit-names.js';
import { D, GOAL, INF, L5, OPN, TECHN } from '../../data/catalog.js';
import { hasEquipmentFaults, recoveryBlock, renderReserveRepairs } from '../maintenance/model/unit-recovery.js';
import { unitExplanation } from './view/player-help.js';
import { quickButton } from '../maintenance/view/crisis-advisor.js';
import { maintenancePanel } from '../maintenance/view/auto-maintenance.js';
import { projectStage, renderProjectNavigation, renderProjectSections } from './view/project-grid.js';
import { renderProcessFacility } from '../country/view/strategy-graphics.js';
import { cl, f1, fa } from '../../core/format.js';
export function installIndustryPage(game) {
  const { S, feedCost, feedTxt, maintenanceCost, partCost, prodTxt } = game;
  // ---- نمودارها
  function chart(h, c, b, col) {
    const W = 120, H = 40, y = v => H - cl((v - (c - 3 * b)) / (6 * b), 0, 1) * H;
    const pts = h.map((v, i) => ((i / Math.max(1, 39)) * W).toFixed(1) + ',' + y(v).toFixed(1)).join(' ');
    return `<svg class="ch" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="روند"><rect class="z" x="0" y="${H / 3}" width="${W}" height="${H / 3}"/>${h.length > 1 ? `<polyline points="${pts}" stroke="${col}"/>` : ''}</svg>`;
  }
  function moneyChart() {
    const h = S.mh, mn = Math.min(...h), mx = Math.max(...h, mn + 1), W = 120, H = 40;
    const pts = h.map((v, i) => ((i / Math.max(1, h.length - 1)) * W).toFixed(1) + ',' + (H - (v - mn) / (mx - mn) * H).toFixed(1)).join(' ');
    return `<svg class="ch" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="روند سرمایه"><polyline points="${pts}" stroke="var(--brand)"/></svg>`;
  }
  const col = w => w <= 1 ? 'var(--ok)' : w <= 1.7 ? 'var(--warn)' : 'var(--bad)';
  function eqRow(u, i, e, j, d) {
    const nm = d.e[j][0], sb = d.e[j][1], f = e.f;
    let st = '';
    if (f) {
      const lbl = f.st === 0 ? 'نیازمند قطعه' : f.st === 1 ? 'قطعه در راه (' + fa(f.eta) + ' روز)' : 'قطعه رسیده';
      st = `<div class="note">${nm}${sb ? ' (اصلی)' : ''}: ${lbl}.${sb && f.dl > 0 ? ' مهلت استندبای: ' + fa(f.dl) + ' روز' : sb ? ' استندبای هم خراب است' : ''}<div class="row">${f.st === 0 ? `<button data-a="part" data-i="${i}" data-j="${j}" data-f="0">خرید قطعه (${fa(partCost(d, j))})</button><button data-a="part" data-i="${i}" data-j="${j}" data-f="1">ارسال فوری (${fa(partCost(d, j) * 2)})</button>` : ''}${f.st === 2 ? `<button class="p" data-a="repair" data-i="${i}" data-j="${j}">تعمیر (${fa(d.cost * .04)})</button>` : ''}</div></div>`;
    }
    return `<div class="eq"><span>${nm}${sb ? ' <span class="tag">استندبای</span>' : ''} · سطح ${fa(e.l)}</span><span><span class="hp"><i style="width:${e.h}%;background:${e.h > 60 ? 'var(--ok)' : e.h > 30 ? 'var(--warn)' : 'var(--bad)'}"></i></span> <button data-a="up" data-i="${i}" data-j="${j}">ارتقا (${fa(d.cost * .3 * e.l)})</button></span></div>${st}`;
  }
  function unit(u, i) {
    if (!['build', 'ready'].includes(u.st) && S.expandedUnit !== i)
      return `<article class="card compact-unit" id="u${i}"><div class="row"><h3>${fa(i + 1)}. ${unitTitle(u, D, i)}</h3><span class="tag ${u.st}">${({
        run: 'در سرویس', trip: 'تریپ', broken: hasEquipmentFaults(u) ? 'خارج از سرویس · خرابی' : 'در انتظار راه‌اندازی', off: 'متوقف', tar: 'تعمیرات'
      })[u.st] || u.st}</span></div><p>${unitExplanation(u)}</p><div class="row"><span>میانگین سود واحد: ${u.pl == null ? '—' : fa(u.pl)}</span>${u.pl < 0 ? quickButton({ target: 'advisor', index: i, title: 'علت زیان و راه رفع' }) : ''}<span>خوراک: ${u.fs == null ? '—' : fa(u.fs * 100) + '٪'}</span></div><div class="row"><button data-hmi="${i}">اتاق کنترل</button><button data-a="unit-expand" data-i="${i}">جزئیات و تعمیرات</button></div>${maintenancePanel(S, u, i, D, { compact: true })}</article>`;
    const d = D[u.t], T = {
      build: 'در حال ساخت', ready: 'آماده‌ی راه‌اندازی', run: 'در حال کار', trip: 'تریپ', broken: hasEquipmentFaults(u) ? 'خارج از سرویس · خرابی' : 'در انتظار راه‌اندازی', tar: 'تعمیرات اساسی', off: 'متوقف (عمدی)'
    }[u.st];
    let h = `<div class="card${S.flash && S.flash.i === i && Date.now() - S.flash.t < 1800 ? ' flash' : ''}" id="u${i}"><div class="row unit-card-head"><h2>${fa(i + 1)}. ${unitTitle(u, D, i)}</h2><span class="tag ${u.st}">${T}</span><button data-top="1" aria-label="بازگشت به فهرست">↑ فهرست</button><button class="unit-hmi-entry" data-hmi="${i}" ${['build', 'ready'].includes(u.st) ? 'disabled title="پس از راه‌اندازی در دسترس است"' : ''}>ورود به اتاق کنترل</button></div><div class="muted" style="font-size:12px">نوع واحد: ${d.n} · محصول: ${prodTxt(u.t)}</div><div class="muted" style="font-size:12px">زیرساخت لازم: سطح ${fa(INF[u.t])} · اپراتور لازم: ${fa(OPN[u.t])} · میانگین سود روزانه (تخمینی): <b class="${u.pl < 0 ? 'bd' : 'ok'}">${u.pl == null ? '—' : fa(u.pl)}</b> · خوراک: ${feedTxt(u.t)}${u.fs != null && u.st === 'run' ? ' · تأمین ' + fa(u.fs * 100) + '٪' : ''}${u.quality != null && u.st === 'run' ? ' · کیفیت محصول ' + fa(u.quality) + '٪' : ''}</div>`;
    h += `<details class="unit-identity"><summary>نام واحد و مشخصات</summary><label>نام اختصاصی<input id="unit-name-${i}" maxlength="32" value="${unitTitle(u, D, i)}"></label><button data-a="unit-rename" data-i="${i}">ذخیره نام</button></details><p class="note">${unitExplanation(u)}</p>`;
    if (u.st === 'broken' && !hasEquipmentFaults(u))
      h += `<button class="p" data-a="restart" data-i="${i}">بازگشت به سرویس پس از بررسی · ${fa(d.cost * .04)}</button><p>${recoveryBlock(S, u, i, D) || 'تجهیزات سالم‌اند؛ راه‌اندازی را تأیید کن.'}</p>`;
    if (u.st === 'build' || u.st === 'ready') {
      h += projectStage(u, d, fa);
      if (u.prob)
        h += `<div class="note">${u.prob}<div class="row"><button data-a="fix" data-i="${i}" data-n="1">رفع فوری (${fa(d.cost * .08)})</button><button data-a="fix" data-i="${i}" data-n="0">ادامه با ریسک</button></div></div>`;
      h += `<details class="project-equipment"><summary>فهرست تجهیزات و پیشرفت نصب</summary>` + d.e.map((x, j) => `<div class="eq"><span>${x[0]}${x[1] ? ' <span class="tag">استندبای</span>' : ''}</span><span>${j < u.eq.length ? 'نصب‌شده ✓' : ''}</span></div>`).join('') + '</details>';
      if (u.st === 'build' && !u.prob)
        h += `<div class="row"><button class="p" data-a="install" data-i="${i}">نصب ${d.e[u.eq.length][0]} (${fa(d.cost * .2)} + مصالح)</button></div>`;
      if (u.su)
        h += stepUI(u, i);
      else if (u.st === 'ready')
        h += `<div class="row"><button class="p" data-a="start" data-i="${i}">راه‌اندازی واحد (خوراک اولیه ${fa(feedCost(u.t))})</button></div>`;
    }
    else {
      h += d.v.map((x, k) => {
        const v = u.v[k], w = Math.abs(v - x[2]) / x[3];
        return `<div class="var"><div class="l"><span>${x[0]}</span><b style="color:${col(w)}">${f1(v)} ${x[1]}</b></div>${chart(u.h[k], x[2], x[3], col(w))}<div class="row">${u.st === 'run' && S.pid?.[`${i}:${k}`]?.mode !== 'auto' ? `<button data-a="adj" data-i="${i}" data-k="${k}" data-s="-1">کاهش</button><button data-a="adj" data-i="${i}" data-k="${k}" data-s="1">افزایش</button>` : ''}${u.au[k] ? `<span class="tag run">${S.pid?.[`${i}:${k}`]?.mode === 'auto' ? 'PID خودکار' : 'کنترلر نصب‌شده'}</span>` : `<button data-a="auto" data-i="${i}" data-k="${k}">کنترلر خودکار (${fa(d.cost * .15)})</button>`}<span class="muted">هدف: ${f1(x[2])}</span></div></div>`;
      }).join('');
      h += `<div class="note"><b>بار عملیاتی و ظرفیت نامی</b><div class="row"><span>بار خوراک: <b>${fa(u.load || 100)}٪</b></span><span>ظرفیت نامی واحد: <b>${fa(u.ratedCapacity || 100)}٪</b></span><span>بهره‌برداری ظرفیت: <b class="${(u.capacityUse || 100) > 115 ? 'bd' : (u.capacityUse || 100) > 100 ? 'wn' : 'ok'}">${fa(u.capacityUse || 100)}٪</b></span><span>کیفیت: <b>${fa(u.quality ?? 100)}٪</b></span></div><div class="row"><button data-a="load" data-i="${i}" data-d="-10" ${(+u.load || 100) <= 50 ? 'disabled' : ''}>کاهش بار ۱۰٪</button><button data-a="load" data-i="${i}" data-d="10" ${(+u.load || 100) >= 140 ? 'disabled' : ''}>افزایش بار ۱۰٪</button><button data-a="load" data-i="${i}" data-d="0">بار نامی ۱۰۰٪</button></div><div class="row"><span>کیفیت خوراک ورودی: <b>${fa(u.feedGrade || 90)}٪</b></span><button data-a="feed-grade" data-i="${i}" data-d="-5" ${(+u.feedGrade || 90) <= 70 ? 'disabled' : ''}>خوراک اقتصادی‌تر −۵٪</button><button data-a="feed-grade" data-i="${i}" data-d="5" ${(+u.feedGrade || 90) >= 100 ? 'disabled' : ''}>خوراک باکیفیت‌تر +۵٪</button></div><div class="row muted"><span>مصرف انرژی تخمینی: ${f1(u.energyUse || 0)} واحد/روز</span><span>هزینه انرژی: ${fa(u.energyCost || 0)} در روز</span></div><small class="muted">خوراک باکیفیت‌تر هزینه بیشتری دارد اما کیفیت محصول را بهبود می‌دهد؛ بار بالاتر، مصرف انرژی و استهلاک را افزایش می‌دهد.</small></div>`;
      h += u.eq.map((e, j) => eqRow(u, i, e, j, d)).join('') + renderReserveRepairs(u, d, i, fa);
      h += `<div class="row"><button data-a="pm" data-i="${i}" ${maintenanceCost(u, d) <= 0 ? 'disabled' : ''}>سرویس دوره‌ای (${fa(maintenanceCost(u, d))})</button><button data-a="tar" data-i="${i}" ${["run", "trip", "off"].includes(u.st) ? "" : "disabled"}>تعمیرات اساسی (${fa(d.cost * .15)})</button>${u.st === "off" ? `<button class="p" data-a="resume" data-i="${i}">بازگشت به سرویس (${fa(d.cost * .02)})</button>` : `<button data-a="stop" data-i="${i}" ${u.st === "run" ? "" : "disabled"}>خروج عمدی از سرویس</button>`}${u.st === 'trip' ? `<button class="p" data-a="restart" data-i="${i}">راه‌اندازی مجدد (${fa(d.cost * .04)})</button>` : ''}</div>`;
    }
    return h + maintenancePanel(S, u, i, D) + (u.pl < 0 ? quickButton({ target: 'advisor', index: i, title: 'تحلیل زیان در مشاور' }) : '') + (!['build', 'ready'].includes(u.st) ? `<button data-a="unit-collapse">بستن جزئیات</button>` : '') + '</div>';
  }
  function visUnits() {
    const f = S.flt || 'all';
    let ix = S.u.map((u, i) => i).filter(i => {
      const u = S.u[i];
      return f === 'all' || (f === 'run' && u.st === 'run') || (f === 'bad' && ['trip', 'broken'].includes(u.st)) || (f === 'off' && ['off', 'tar', 'build', 'ready'].includes(u.st)) || (f === 'loss' && u.pl != null && u.pl < 0);
    });
    if (S.srt === 'pl')
      ix.sort((a, b) => (S.u[a].pl ?? 1e9) - (S.u[b].pl ?? 1e9));
    return ix;
  }
  function stepUI(u, i) {
    const s = u.su;
    return `<div class="note"><b>مراحل راه‌اندازی: ایمنی ← پمپ ← دما ← فشار ← خروجی (${fa(s.pos)}/۵ · خطا: ${fa(s.miss)})</b><div class="sel" style="flex-direction:column;margin-top:6px">${(S.tutorial && !S.tutorial.dismissed ? [0, 1, 2, 3, 4] : s.o).map(k => `<button ${k < s.pos ? 'disabled' : ''} data-a="step" data-i="${i}" data-k="${k}">${k < s.pos ? '✓ ' : ''}${L5[k]}</button>`).join('')}</div></div>`;
  }
  function viewIndustry() {
    const fxs = [['sanc', 'تحریم'], ['spike', 'جهش قیمت'], ['exp', 'قرارداد صادراتی'], ['strike', 'اعتصاب'], ['rival', 'قیمت‌شکنی رقیب']].filter(x => S.fx[x[0]]).map(x => `<span class="tag">${x[1]}: ${fa(S.fx[x[0]])} روز</span>`).join(' ');
    const projectType = Object.hasOwn(D, Number(S.projectType)) ? Number(S.projectType) : 0;
    const shop = D.map((d, t) => t !== projectType ? '' : `<div class="card catalog-illustrated"><div class="catalog-art-frame"><svg class="catalog-art" viewBox="-95 -145 190 210" role="img" aria-label="${d.n}">${renderProcessFacility(t)}</svg></div><div><b>${d.n}</b><div class="muted" style="font-size:12px">هدف: ${GOAL[t]} · درآمد ایده‌آل: ${fa(d.rev)} در روز · ${fa(d.e.length)} تجهیز · ${fa(OPN[t])} اپراتور<br>خوراک و نیاز: ${feedTxt(t) || 'ندارد'} · محصول: ${prodTxt(t)} · زیرساخت سطح ${fa(INF[t])}</div>${INF[t] > (S.infra || 0) ? '<div class="wn" style="font-size:12px">نیاز به زیرساخت سطح ' + fa(INF[t]) + '</div>' : ''}${d.tech && !(S.tech || {})[d.tech] ? '<div class="wn" style="font-size:12px">نیاز به تحقیق: ' + TECHN[d.tech] + '</div>' : ''}${d.nuc ? '<div class="wn" style="font-size:12px">نیاز به مجوز: آموزش اپراتور ≥ ۲ و ایمنی ≥ ۸۰٪؛ سوخت هسته‌ای فقط وارداتی و گران است</div>' : ''}${game.estimateUI(t)}</div><label class="project-name">نام دلخواه واحد<input id="project-name-${t}" maxlength="32" placeholder="مثلاً ${d.n} امید" autocomplete="off"></label><button class="p" data-a="buy" data-t="${t}" ${(d.nuc && (S.tr < 2 || S.safe < 80)) || (d.tech && !(S.tech || {})[d.tech]) || (INF[t] > (S.infra || 0)) ? 'disabled' : ''}>شروع پروژه (${fa(d.cost * .3)})</button></div>`).join('');
    const off = S.offers.map((o, k) => `<div class="note">${o.txt}<div class="row"><button class="p" data-a="offer" data-o="${k}" data-y="1">${o.t === 'exp' ? 'قبول' : 'مذاکره'}</button><button data-a="offer" data-o="${k}" data-y="0">${o.t === 'exp' ? 'رد' : 'نادیده گرفتن'}</button></div></div>`).join('');
    const ops = `<div id="personnel-management" class="card"><h2>مدیریت و منابع انسانی</h2><div class="row">اپراتورها: <b>${fa(S.ops)}</b> (مورد نیاز: <b>${fa(game.opsNeed())}</b>${S.walk ? ' · در دسترس: <b class="bd">' + fa(game.opsAvail()) + '</b>' : ''}) · آموزش: <b>${fa(S.tr)}/۳</b> · روحیه: <b class="${S.mor < 35 ? 'bd' : S.mor < 60 ? 'wn' : 'ok'}">${fa(S.mor)}٪</b></div><div class="muted" style="font-size:12px">هر واحد تعداد مشخصی اپراتور می‌خواهد (در کارت واحد نوشته شده)؛ کمبود، تولید را کم و نوسان را بیشتر می‌کند. روحیه‌ی پایین می‌تواند به ترک کار موقت اپراتورها برسد. حقوق: ${fa(S.sal || 12)} در روز برای هر نفر. مهندسان متخصص: ${fa(S.eng || 0)}/۳ (هر مهندس ۱۲٪ خرابی کمتر).</div><div class="row"><button data-a="hire">استخدام اپراتور (۱٬۲۰۰)</button><button data-a="bonus">پاداش و رفاه (۱٬۰۰۰)</button><button data-a="eng" ${(S.eng || 0) >= 3 ? 'disabled' : ''}>مهندس متخصص (۳٬۰۰۰ · ۴۰ در روز)</button><button data-a="train" ${S.tr >= 3 ? 'disabled' : ''}>آموزش اپراتورها (${fa(1500 * (S.tr + 1))})</button><button data-a="hse">دوره‌ی ایمنی (۲٬۰۰۰)</button></div>${fxs ? `<div class="row">${fxs}</div>` : ''}${off}<h3 style="font-size:13px;margin:8px 0 2px">روند سرمایه</h3><div class="big">${moneyChart()}</div></div>`;
    const industrySection = ['operations', 'projects', 'catalog'].includes(S.industrySection) ? S.industrySection : !S.u.length ? 'catalog' : S.u.some(u => ['build', 'ready'].includes(u.st)) ? 'projects' : 'operations';
    return game.crisisCard() + renderProjectNavigation(S, fa) + (industrySection === 'catalog' ? `<section class="shop-section wide"><div class="project-section-head"><div><h2>پروژه‌های جدید</h2><label>انتخاب نوع پروژه<select id="project-type">${D.map((d, t) => `<option value="${t}" ${projectType === t ? 'selected' : ''}>${d.n}</option>`).join('')}</select></label><p class="muted">انتخاب واحد صنعتی و آغاز سرمایه‌گذاری</p></div><span class="project-count">${fa(D.length)} طرح</span></div><div class="shop-grid">${shop}</div></section>` : renderProjectSections({
      indexes: visUnits(), units: S.u, renderUnit: unit, formatNumber: fa, sectionFilter: industrySection
    })) + (industrySection === 'operations' ? `<details class="card wide"><summary>نیرو، فیلتر واحدها و بانک</summary>${ops}${game.bank()}${game.advCard()}</details>` : '') + `<div class="card wide"><h2>گزارش رویدادها</h2><div id="log">${S.log.map(l => `<div>${l}</div>`).join('')}</div></div>`;
  }
  Object.assign(game, { chart, viewIndustry });
}
