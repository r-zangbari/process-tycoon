// راهنمای اقدام بعدی بازیکن و برآورد هزینه‌ی پروژه.
import { nextAction, projectEstimate } from './view/player-help.js';
import { D, IMP, PR } from '../../data/catalog.js';
import { quickButton } from '../maintenance/view/crisis-advisor.js';
import { fa } from '../../core/format.js';
export function installIndustryHelp(game) {
  const { S, feedCost, save } = game;
  function estimateUI(t) {
    const e = projectEstimate(S, D[t], PR, IMP, feedCost(t));
    return `<details><summary>برآورد هزینه تا اولین راه‌اندازی: ${fa(e.total)}</summary><p>زمین و مجوز: ${fa(e.land)} · نصب: ${fa(e.install)} · خرید کسری مصالح: ${fa(e.materials)} · خوراک اولیه: ${fa(e.feed)}</p><p>سرمایه باقی‌مانده: ${fa(S.money - e.total)} · خرید خوراک روزانه با قیمت فعلی: ${fa(e.feed)} · کنترلرهای اختیاری: ${fa(e.controllers)}</p><small>برآورد با موجودی و قیمت فعلی؛ رفع ایراد نصب، اپراتور، حقوق، تعمیرات و سایر هزینه‌های بهره‌برداری جدا هستند.</small></details>`;
  }
  function starterPlan() {
    if (S.day > 60 || S.u.length > 3)
      return '';
    const e = projectEstimate(S, D[0], PR, IMP, feedCost(0)), reserve = Math.ceil(feedCost(0) * 10 + 500);
    return `<details class="card wide" open><summary>مسیر پیشنهادی شروع کم‌ریسک</summary><ol><li>صنعت: ابتدا یک پالایشگاه نفت بساز؛ هزینه تکمیل فعلی ${fa(e.total)} است. حداقل ${fa(reserve)} برای ده روز خوراک و حاشیه نقد نگه دار. ${S.money < e.total + reserve ? 'اکنون نقد کافی برای ساخت همراه این ذخیره نداری؛ ابتدا درآمد پایدار جمع کن.' : ''}</li><li>مدیریت محصولات ← انبار و فروش: نفت خام را نگه‌داری کن تا خوراک فروخته نشود؛ مخزن سوخت و فروش روزانه را بررسی کن. قرارداد صادراتی و خرید کنترلرهای متعدد را فعلاً عقب بینداز.</li><li>کشور ← قطب کشاورزی شمالی: بعد از تأمین آب و سوخت، یک مزرعه بساز و شبکه‌هایش را وصل کن؛ محصول کشاورزی درآمد ایجاد می‌کند. تا آن زمان خانه تازه نساز، چون تقاضای خدمات را بیشتر می‌کند.</li><li>پس از پایدار شدن جریان نقد و تأمین خوراک، تصفیه آب را برای آب شهر و کشاورزی اضافه کن؛ کارخانه در مرکز انرژی را پس از تأمین برق و گاز بساز.</li></ol><small>این مسیر پیشنهاد است؛ قیمت بازار، خرابی و ظرفیت واردات روی نتیجه اثر دارند. سود تضمین‌شده نیست.</small></details>`;
  }
  function playerHelp() {
    const a = nextAction(S, D, game.advice().items), t = S.tutorial;
    if (t && !t.done && Object.values(S.marketDay || {}).some(m => m.sold > 0))
      t.done = true;
    return `${starterPlan()}<section class="card wide player-help" aria-label="راهنمای اقدام بعدی"><h2>اقدام پیشنهادی</h2><p>${a.text}</p>${a.fix ? `<p><b>راه رسیدگی:</b> ${a.fix}</p>` : ''}${a.target ? quickButton({ ...a, title: a.label }) : `<button data-a="help-go" data-t="${a.tab}" data-i="${a.index ?? ''}">${a.label}</button>`}${t && !t.dismissed ? `<details open><summary>مسیر اولین تولید و فروش ${t.done ? '✓ تکمیل شد' : ''}</summary><ol><li>از پروژه‌های جدید، یک واحد متناسب با سرمایه انتخاب کن.</li><li>تجهیزات را نصب و مشکلات نصب را برطرف کن.</li><li>خوراک اولیه را بپرداز و مراحل راه‌اندازی را به ترتیب انجام بده.</li><li>زمان را ادامه بده؛ در مدیریت محصولات، تأمین خوراک و فروش را بررسی کن.</li></ol><p>خوراک کسری با هزینه و محدودیت ظرفیت واردات تأمین می‌شود. فروش به نوع محصول، نیاز کشور، موجودی و ظرفیت بندر وابسته است.</p><button data-a="help-dismiss">بستن آموزش</button></details>` : ''}</section>`;
  }
  game.clickHandlers.push((e, b, x, i, a) => {
    if (a === 'help-dismiss') {
      S.tutorial.dismissed = true;
      game.draw();
      save();
      return true;
    }
    if (a === 'help-go' && x.i !== undefined && x.i !== '' && S.u[Number(x.i)]) {
      game.navigateDiagnostic({ target: 'unit', i: x.i });
      return true;
    }
    if (a === 'help-go') {
      S.tab = x.t;
      if (x.t === 'i')
        S.industrySection = S.u.some(u => ['build', 'ready'].includes(u.st)) ? 'projects' : S.u.length ? 'operations' : 'catalog';
      if (x.t === 'm')
        S.manageSection = 'inventory';
      S.flt = 'all';
      game.draw();
      if (x.i !== undefined && x.i !== '')
        document.getElementById('u' + x.i)?.scrollIntoView({ block: 'center' });
      else
        document.querySelector('.shop-section')?.scrollIntoView({ block: 'start' });
      save();
      return true;
    }
    return false;
  });
  Object.assign(game, { estimateUI, playerHelp });
}
