// ویرایش و جابه‌جایی ساختمان‌های شهر (کشیدن، چیدمان ذخیره‌شده).
import { rememberCityMove } from './model/city-move-history.js';
import { CITIES, CITY_PLOT_DEFAULTS, CITY_PLOT_STORAGE, clampCityCoord } from '../../data/world-map.js';
export function installCityEditor(game) {
  const { S, save } = game;
  function loadCityPlotLayout() {
    try {
      const raw = JSON.parse(localStorage.getItem(CITY_PLOT_STORAGE) || 'null'), pts = Array.isArray(raw) ? raw : raw?.points;
      if (Array.isArray(pts) && pts.length === 24 && pts.every(p => Array.isArray(p) && p.length === 2 && p.every(Number.isFinite)))
        return pts.map(p => [clampCityCoord(p[0], 900), clampCityCoord(p[1], 510)]);
    }
    catch { }
    return CITY_PLOT_DEFAULTS.map(p => [...p]);
  }
  const cityPlotLayout = loadCityPlotLayout();
  function cityBuildingPos(city, cell) {
    const stored = S.cityBuildingPositions?.[city]?.[cell];
    return Array.isArray(stored) && stored.length === 2 && stored.every(Number.isFinite)
      ? [clampCityCoord(stored[0], 900), clampCityCoord(stored[1], 510)]
      : [...cityPlotLayout[cell % 24]];
  }
  function setCityBuildingPos(city, cell, x, y, updateDOM = false) {
    if (!city || !Number.isInteger(cell) || cell < 0 || cell >= 81 || !S.cityMaps?.[city]?.[cell])
      return false;
    if (!updateDOM)
      rememberCityMove(S, city, cell, cityBuildingPos(city, cell));
    S.cityBuildingPositions ||= {};
    S.cityBuildingPositions[city] ||= {};
    const pos = [clampCityCoord(x, 900), clampCityCoord(y, 510)];
    S.cityBuildingPositions[city][cell] = pos;
    if (updateDOM) {
      const el = document.querySelector(`.city-free-building[data-city-building="${cell}"]`);
      if (el)
        el.setAttribute('transform', `translate(${pos.join(' ')})`);
    }
    return true;
  }
  function pointFromCityPointer(e, svg) {
    const pt = svg.createSVGPoint();
    pt.x = e.clientX;
    pt.y = e.clientY;
    const m = svg.getScreenCTM();
    if (!m)
      return null;
    const v = pt.matrixTransform(m.inverse());
    return [clampCityCoord(v.x, 900), clampCityCoord(v.y, 510)];
  }

  // A selected building can be arranged in-place as part of normal city gameplay.
  // The map's buildable lot IDs stay fixed; only that one building sprite moves.
  document.addEventListener('pointerdown', e => {
    if (S.cityView == null || game.ui.cityMoveCell == null || !e.isPrimary)
      return;
    const building = e.target.closest?.('[data-city-building]');
    if (!building || Number(building.dataset.cityBuilding) !== game.ui.cityMoveCell)
      return;
    const svg = building.closest('svg.city-world-map'), city = CITIES[Number(S.cityView)];
    if (!svg || !city)
      return;
    const start = pointFromCityPointer(e, svg), pos = cityBuildingPos(city.name, game.ui.cityMoveCell);
    if (!start)
      return;
    game.ui.cityBuildingDrag = {
      pointerId: e.pointerId, svg, building, city: city.name, cell: game.ui.cityMoveCell, start, origin: pos, moved: false
    };
    building.setPointerCapture?.(e.pointerId);
    e.preventDefault();
    e.stopPropagation();
  }, true);
  document.addEventListener('pointermove', e => {
    const d = game.ui.cityBuildingDrag;
    if (!d || e.pointerId !== d.pointerId)
      return;
    const p = pointFromCityPointer(e, d.svg);
    if (!p)
      return;
    const dx = p[0] - d.start[0], dy = p[1] - d.start[1];
    if (Math.hypot(dx, dy) > 1)
      d.moved = true;
    if (d.moved)
      setCityBuildingPos(d.city, d.cell, d.origin[0] + dx, d.origin[1] + dy, true);
    e.preventDefault();
  }, true);
  function finishCityBuildingDrag(e) {
    const d = game.ui.cityBuildingDrag;
    if (!d || e.pointerId !== d.pointerId)
      return;
    if (d.building.hasPointerCapture?.(e.pointerId))
      d.building.releasePointerCapture(e.pointerId);
    game.ui.cityBuildingDrag = null;
    if (d.moved) {
      rememberCityMove(S, d.city, d.cell, d.origin);
      game.draw();
      game.ui.cityClickSuppressUntil = Date.now() + 350;
      save();
      e.preventDefault();
      e.stopPropagation();
    }
  }
  document.addEventListener('pointerup', finishCityBuildingDrag, true);
  document.addEventListener('pointercancel', finishCityBuildingDrag, true);
  document.addEventListener('click', e => {
    if (game.ui.cityClickSuppressUntil > Date.now() && e.target.closest?.('.city-world-map')) {
      e.stopImmediatePropagation();
      e.preventDefault();
      return;
    }
    if (S.cityView == null || game.ui.cityMoveCell == null || game.ui.cityBuildingDrag)
      return;
    const svg = e.target.closest?.('svg.city-world-map');
    if (!svg)
      return;
    if (e.target.closest?.('[data-city-building]')) {
      e.preventDefault();
      e.stopImmediatePropagation();
      return;
    }
    const city = CITIES[Number(S.cityView)];
    if (!city || !S.cityMaps?.[city.name]?.[game.ui.cityMoveCell])
      return;
    // Tap anywhere on the image to place that building; works on mobile without dragging.
    const pos = pointFromCityPointer(e, svg);
    if (!pos)
      return;
    setCityBuildingPos(city.name, game.ui.cityMoveCell, pos[0], pos[1]);
    game.draw();
    save();
    e.stopImmediatePropagation();
    e.preventDefault();
  }, true);
  Object.assign(game, { cityBuildingPos, setCityBuildingPos });
}
