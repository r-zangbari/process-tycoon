// Per-city visual move history; economic cell identities remain unchanged.
export function rememberCityMove(S, city, cell, position) {
  if (!S.cityMaps?.[city]?.[cell] || !Array.isArray(position) || !position.every(Number.isFinite))
    return false;
  S.cityMoveHistory ||= {};
  const history = S.cityMoveHistory[city] ||= [];
  history.push({ cell, position: [...position] });
  if (history.length > 20)
    history.shift();
  return true;
}
export function undoCityMove(S, city) {
  const history = S.cityMoveHistory?.[city];
  if (!Array.isArray(history))
    return false;
  while (history.length) {
    const move = history.pop();
    if (!S.cityMaps?.[city]?.[move.cell] || !Array.isArray(move.position) || move.position.length !== 2 || !move.position.every(Number.isFinite))
      continue;
    S.cityBuildingPositions ||= {};
    S.cityBuildingPositions[city] ||= {};
    S.cityBuildingPositions[city][move.cell] = [...move.position];
    return true;
  }
  return false;
}
