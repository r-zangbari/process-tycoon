// Temporary reductions in the simulation for damaged destinations on the atlas.
const impacts = {
  north: [0.5, 'تولید زنجیرهٔ غذا'],
  housing: [0.5, 'مالیات شهرک'],
  energy: [0.5, 'تولید کالا'],
  capital: [0.75, 'مالیات افزودهٔ شهر'],
  east: [0.75, 'مالیات افزودهٔ شهر'],
  port: [0.75, 'ظرفیت تجارت'],
  'water-groundwater': [0.75, 'برداشت آب خام'],
  'water-surface': [0.75, 'برداشت آب خام'],
  'water-reclaimed': [0.75, 'تولید آب خام از پساب'],
  'water-desal': [0.75, 'آب‌شیرین‌کنی و انتقال ساحلی']
};

export function damageDays(S, region) {
  const until = S.military?.damaged?.[region];
  return Number.isFinite(until) ? Math.max(0, until - S.day) : 0;
}

export function regionalDisruption(S, region) {
  const days = damageDays(S, region);
  const impact = Object.hasOwn(impacts, region) && impacts[region];
  return { days, factor: days && impact ? impact[0] : 1, label: impact ? impact[1] : '' };
}
