// Stable persistent lot IDs; districts own disjoint free land. Existing assets retain IDs.
export const DISTRICTS = [
  {
    id: 'north',
    name: 'قطب کشاورزی',
    kind: 'farm',
    x: -17,
    z: -12,
    description: 'آب و سوخت صنعت ← مزرعه ← محصول و درآمد',
    type: 'f'
  },
  {
    id: 'capital',
    name: 'پایتخت',
    kind: 'capital',
    x: 0,
    z: -4,
    city: 1,
    description: 'محله‌ها، خدمات عمومی و مالیات'
  },
  {
    id: 'east',
    name: 'شهر شرقی',
    kind: 'city',
    x: 18,
    z: -7,
    city: 2,
    description: 'توسعه مسکن، تجارت و خدمات'
  },
  {
    id: 'housing',
    name: 'شهرک مسکونی',
    kind: 'home',
    x: -17,
    z: 5,
    type: 'h',
    description: 'مصرف خدمات و درآمد مالیاتی شرکت'
  },
  {
    id: 'energy',
    name: 'قطب تولید کالا',
    kind: 'factory',
    x: 16,
    z: 8,
    type: 'k',
    description: 'برق، گاز و سوخت ← کارخانه ← کالا و درآمد'
  },
  {
    id: 'port',
    name: 'بندر جنوبی',
    kind: 'port',
    x: 0,
    z: 18,
    description: 'ظرفیت مشترک واردات خوراک و صادرات محصول'
  },
  {
    id: 'oil',
    name: 'میدان نفت دریایی',
    kind: 'rig',
    x: -17,
    z: 29,
    description: 'اکتشاف ← توسعه ← انتقال نفت به مخازن'
  },
  {
    id: 'gas',
    name: 'میدان گاز دریایی',
    kind: 'rig',
    x: 18,
    z: 28,
    description: 'اکتشاف ← توسعه ← انتقال گاز به مخازن'
  },
  {
    id: 'water-groundwater',
    name: 'آبخوان غربی',
    kind: 'water',
    water: 'groundwater',
    x: -29,
    z: -3,
    description: 'چاه، ذخیره آبخوان و خط انتقال آب خام'
  },
  {
    id: 'water-surface',
    name: 'آبریز شمالی',
    kind: 'water',
    water: 'surface',
    x: -1,
    z: -21,
    description: 'برداشت فصلی آب سطحی برای صنعت'
  },
  {
    id: 'water-reclaimed',
    name: 'بازچرخانی شهری',
    kind: 'water',
    water: 'reclaimed',
    x: 29,
    z: -1,
    description: 'جمع‌آوری پساب مصرف واقعی آب شهری و بازیابی'
  },
  {
    id: 'water-desal',
    name: 'آب‌شیرین‌کن ساحلی',
    kind: 'water',
    water: 'desal',
    x: 29,
    z: 19,
    description: 'آب دریای صنعتی با هزینه و مصرف برق بیشتر'
  }
];
// Building types each hub accepts; the agricultural hub hosts the whole farm-to-food chain.
export const HUB_TYPES = { north: ['f', 'g', 'l', 'p'], housing: ['h'], energy: ['k'] };
export function districtLots(S, id) {
  const types = HUB_TYPES[id],
    partition = { north: 0, housing: 1, energy: 2 }[id];
  if (!types) return [];
  return S.grid.flatMap((b, i) =>
    b
      ? types.includes(b.t)
        ? [{ id: i, type: b.t, level: b.l, connected: b.c }]
        : []
      : i % 3 === partition
        ? [{ id: i, type: null, level: 0 }]
        : []
  );
}
export function countrySnapshot(S) {
  return ['power', 'gas', 'water', 'fuel'].map((key) => ({
    key,
    demand: S.dem?.[key] || 0,
    delivery: (S.dem?.[key] || 0) * (S.fr?.[key] ?? 1),
    ratio: S.fr?.[key] ?? 1,
    production: S.pd?.[key] || 0,
    stock: S.tanks?.[key] || 0
  }));
}
export function countryViewKey(S) {
  return S.offshoreView
    ? 'offshore'
    : S.countryHub
      ? 'hub:' + S.countryHub
      : S.cityView != null
        ? 'city:' + S.cityView
        : 'atlas';
}
