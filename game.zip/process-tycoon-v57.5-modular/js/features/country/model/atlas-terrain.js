// Shared height field of the national atlas. The 3D scene, the vector map and the military rules all use this one function,
// so what the player sees as sea, coast, plain or mountain is exactly what placement rules check.
import { DISTRICTS } from './country-planning.js';
export const ATLAS_BOUNDS = Object.freeze({ minX: -43, maxX: 43, minZ: -41, maxZ: 47 });
export const ATLAS_LAND = Object.freeze({ halfWidth: 37, north: -35 });
const cl = (v, a, b) => Math.min(b, Math.max(a, v)), sm = (a, b, x) => {
  const t = cl((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
export const atlasShore = x => 21.5 + 2.5 * Math.sin(x * .13 + 1);
const shore = atlasShore;
export const atlasHeight = (x, z) => {
  const c = shore(x) - z;
  let h = c > 0 ? Math.min(c, 3) * .14 : -Math.min(-c, 8) * .3;
  const m = Math.exp(-(((x + 24) ** 2) + ((z + 22) ** 2)) / 150) * 7;
  h += m * (c > 0 ? 1 : 0) + (c > 0 ? (Math.sin(x * .21 + z * .17) * Math.cos(z * .13 - x * .09) + .5 * Math.sin(x * .5 + z * .43)) * .35 * (1 + m * .3) : 0);
  if (c > 3) {
    const fringe = Math.max(sm(28, 34, Math.abs(x)), sm(26, 32, -z));
    h += fringe * Math.max(0, .32 - h);
  }
  const rx = -20 + (z + 18) * .3, rd = Math.abs(x - rx);
  if (c > 0 && z > -18)
    h -= 1.3 * Math.exp(-((rd / 1.8) ** 2));
  let w = 0;
  for (const d of DISTRICTS)
    w = Math.max(w, sm(7.5, 4.5, Math.hypot(x - d.x, z - d.z)));
  if (c > 0)
    h = h * (1 - w) + .35 * w;
  const e = Math.max(Math.abs(x) - ATLAS_LAND.halfWidth, ATLAS_LAND.north - z, 0);
  return h * (1 - sm(0, 5, e)) - 3 * sm(0, 5, e);
};
