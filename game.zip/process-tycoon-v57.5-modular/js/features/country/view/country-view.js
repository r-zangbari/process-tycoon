import { mapTone } from './map-operations.js';
import { renderWaterOverview } from '../../water/view/water-supply.js';
import { mapToolbar, mapCameraControls, mapSheetHead } from './map-design.js';
import { DISTRICTS, countrySnapshot, countryViewKey } from '../model/country-planning.js';
import { escapeText } from '../../../engine/unit-names.js';
import { defenseCaption, defenseLegend } from '../../military/view/tactical-panel.js';
import { mapButton as btn } from './map-button.js';
import { renderAtlasInspector } from './atlas-inspector.js';
import { renderCityInspector } from './city-inspector.js';
import { renderHubInspector, renderPortInspector } from './hub-inspector.js';

const names = { power: 'برق', gas: 'گاز', water: 'آب', fuel: 'سوخت' };
export function renderCountry({
  S,
  TY,
  PR,
  CITIES,
  fa,
  cityDevelopmentMetrics,
  offshoreCard,
  countryEconomyCard,
  REGIONS,
  regionMetrics,
  sheetOpen = false,
  expanded = false,
  notice = '',
  defenseSite = null
}) {
  const key = countryViewKey(S),
    atlas = key === 'atlas',
    hub = S.countryHub,
    city = S.cityView != null ? CITIES[S.cityView] : null;
  const selected = DISTRICTS.find((d) => d.id === (S.atlasSelected || 'capital')) || DISTRICTS[1];
  const title = atlas
    ? 'کشور'
    : S.offshoreView
      ? 'پهنهٔ فراساحل'
      : city
        ? city.name === 'مرکز شمالی'
          ? 'شهر شمالی'
          : city.name
        : DISTRICTS.find((d) => d.id === hub)?.name || 'کشور';
  let panel;
  if (atlas) panel = renderAtlasInspector(S, CITIES, selected, defenseSite);
  else if (city) panel = renderCityInspector(S, city, fa, cityDevelopmentMetrics);
  else if (hub === 'port') panel = renderPortInspector(S, fa);
  else if (S.offshoreView)
    panel =
      '<h2>مدیریت میادین</h2><p>اکتشاف و توسعه، خط انتقال، سلامت و وضعیت دریا بر خوراک واقعی مخازن اثر دارند.</p><p>فرمان‌های هر میدان در پایین نقشه قرار دارند.</p>';
  else panel = renderHubInspector(S, hub, TY, fa);
  const services = countrySnapshot(S);
  const swatch = (tone, label) => `<span><i style="background:${mapTone(tone)}"></i>${label}</span>`;
  let legend = '';
  if (atlas && S.mapLayer === 'defense') legend = defenseLegend();
  else if (atlas)
    legend =
      S.mapLayer === 'services'
        ? `<div class="map-legend">${swatch('ok', 'تأمین برقرار')}${swatch('warn', 'محدود')}${swatch('bad', 'کسری یا اختلال')}${swatch('idle', 'بدون جریان ثبت‌شده')}<small>با انتخاب مسیر جزئیات و اقدام مرتبط را ببین.</small></div>`
        : '<div class="map-legend"><span><i class="legend-road"></i>راه ارتباطی</span></div>';
  if (city && S.mapLayer === 'services')
    legend = `<div class="map-legend">${swatch('ok', 'خانه نزدیک پارک یا مرکز خدمات')}${swatch('bad', 'خانه خارج از پوشش محلی')}</div>`;
  return `<section class="atlas wide country-atlas${expanded ? ' atlas-expanded' : ''}">
    <div class="atlas-heading"><div><span class="atlas-kicker">PROCESS EMPIRE / NATIONAL PLANNING</span><h1>${title}</h1><p>صنعت را به زندگی، توسعه و تجارت وصل کن.</p></div><div class="row">${!atlas ? btn('atlas-home', '← کشور') : ''}${btn('country-expand', expanded ? 'خروج از تمام‌صفحه' : 'نقشهٔ تمام‌صفحه', `aria-pressed="${expanded}"`)}${expanded ? btn('country-pause', S.paused ? 'ادامهٔ زمان' : 'توقف زمان') : ''}${btn('tab', 'نقشهٔ صنعت', 'data-t="site"')}${btn('port-trade', 'بازار و تجارت')}${btn('dev-open', 'قراردادهای توسعه')}${btn('water-open', 'منابع آب', 'data-k="groundwater"')}${btn('legacy-open', 'شهر من و افتخارات')}</div></div>
    <div class="atlas-stats"><div><small>سرمایه شرکت</small><b>${fa(S.money)}</b></div><div><small>بودجه عمومی</small><b>${fa(S.govBudget)}</b></div><div><small>جمعیت</small><b>${fa(S.pop)}</b></div><div><small>رضایت</small><b>${fa(S.sat)}٪</b></div></div>${mapToolbar(S, atlas ? 'atlas' : city ? 'city' : 'region')}
    <div class="atlas-workspace">
      <div class="atlas-stage">
        <div id="country-three" data-view="${key}" role="region" aria-label="نقشه سه‌بعدی ${title}"></div>${mapCameraControls(S)}${(atlas || city?.kind === 'capital') && S.development?.offers?.water?.status === 'complete' ? '<strong class="water-network-badge">شبکهٔ آب تقویت شد</strong> ' : ''}<div class="atlas-caption">${atlas && S.mapLayer === 'defense' ? defenseCaption(S) : 'اسکرول صفحه آزاد است؛ برای چرخش نقشه «کنترل دوربین» را فعال کن.'}</div>
        <div id="atlas-labels" class="atlas-labels" aria-hidden="true"></div></div>
      <aside id="country-inspector" class="atlas-inspector map-inspector ${sheetOpen ? 'map-sheet-open' : ''}">${mapSheetHead()}${notice ? `<p class="strategy-notice" role="status">${escapeText(notice)}</p>` : ''}${panel}</aside></div><button class="map-show-inspector" data-a="ops-show">بازکردن جزئیات نقشه</button>${legend}
    <details class="atlas-flow" open><summary>تراز واقعی خدمات امروز</summary>
      <div class="atlas-table"><table><thead><tr><th>خدمت</th><th>تولید</th><th>موجودی</th><th>نیاز</th><th>تحویل</th><th>تأمین</th></tr></thead><tbody>${services.map((p) => `<tr><th>${names[p.key]}</th><td>${fa(p.production)}</td><td>${fa(p.stock)}</td><td>${fa(p.demand)}</td><td>${fa(p.delivery)}</td><td class="${p.ratio < 0.7 ? 'bd' : 'ok'}">${fa(p.ratio * 100)}٪</td></tr>`).join('')}</tbody></table></div><p>آمار پس از گذشت روز به‌روز می‌شود. تولید صنعت ← مخزن ← تلفات شبکه ← مصرف شهر و قطب‌ها ← مالیات و درآمد ← توسعه. کمبود تأمین، تولید مزارع و کارخانه‌ها را محدود می‌کند.</p></details>${S.offshoreView ? offshoreCard() : ''}${renderWaterOverview(S)}
    <details class="atlas-policy"><summary>خزانه، شبکه‌های ملی و سیاست اقتصادی</summary>${countryEconomyCard()}<h3>توسعه مناطق</h3><div class="atlas-region-grid">${REGIONS.map(
      ([name], i) => {
        const m = regionMetrics(i);
        return `<article><h4>${name}</h4><p>رضایت ${fa(m.satisfaction)}٪ · سرمایه‌گذاری ${fa(m.level)}/۳</p>${btn('regional-invest', `توسعه محلی · ${fa(3500 * (m.level + 1))}`, `data-i="${i}"`, m.level >= 3 || S.govBudget < 3500 * (m.level + 1))}${[
          ['power', 'برق', 1700],
          ['gas', 'گاز', 1900],
          ['water', 'آب', 1600],
          ['roads', 'راه', 1300]
        ]
          .map(([p, n, c]) => {
            const lv = m.infra[p] || 0;
            return `<div class="atlas-service"><span>${n} · ${fa(lv)}/۳</span>${btn('regional-infra', fa(c * (lv + 1)), `data-i="${i}" data-p="${p}"`, lv >= 3 || S.govBudget < c * (lv + 1))}</div>`;
          })
          .join('')}</article>`;
      }
    ).join(
      ''
    )}</div><p>سرمایه‌گذاری منطقه‌ای در رضایت و شاخص توسعه اثر دارد؛ کاهش تلفات تحویل خدمات از شبکه ملی انجام می‌شود.</p></details>
    <div class="atlas-log" role="status">${S.log[0] || ''}</div></section>`;
}
