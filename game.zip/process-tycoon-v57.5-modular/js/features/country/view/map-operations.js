import { effectiveTradePort, remainingTradePort, tradeConditionsText } from '../../products/model/trade-conditions.js';
import { D, IN, OPN, OUT, PR } from '../../../data/catalog.js';
import { COASTAL_BUFFER, waterNetwork } from '../../water/model/water-supply.js';
import { developmentSummary } from '../../development/model/development.js';
import { districtIndex, districtDesign } from '../../legacy/model/legacy-development.js';
import { safeCityGrid } from '../model/urban-economy.js';
import { escapeText } from '../../../engine/unit-names.js';
import { analyzeUnit } from '../../maintenance/model/unit-diagnostics.js';
export const NETWORKS = { water: 'آب', power: 'برق', feed: 'خوراک' };
export const networkKey = S => Object.hasOwn(NETWORKS, S.mapNetwork) ? S.mapNetwork : 'water';
const level = (qty, need) => need > 0 ? (qty / need < .7 ? 'bad' : qty / need + .00001 < 1 ? 'warn' : 'ok') : 'idle';
const number = x => Number.isFinite(x) ? x.toLocaleString('fa-IR', { maximumFractionDigits: 1 }) : '—';
const serviceTone = { ok: '#29a798', warn: '#e3ab55', bad: '#cf615b', idle: '#778b86' };
export const mapTone = t => serviceTone[t] || serviceTone.idle;
const actions = (action, label, attrs = '') => `<button type="button" data-a="${action}" ${attrs}>${escapeText(label)}</button>`;
const routeStep = (id, title, qty, note, tone = 'idle') => ({ id, title, qty, note, tone });
export function countryNetwork(S, key = networkKey(S)) {
  if (key === 'water') {
    const water = waterNetwork(S);
    const today = water.today?.day === S.day ? water.today : null;
    const source = water.sources.desal;
    const intake = today?.sources?.desal;
    const direct = today ? Math.max(0, today.quantity - (today.coastalStored || 0)) : null;
    const raw = (S.tanks?.rawwater || 0);
    const plants = S.u.filter(u => u.t === 1 && !['build', 'ready'].includes(u.st));
    const records = plants.filter(u => u.dayEconomics?.day === S.day).map(u => u.dayEconomics);
    const feeds = records.flatMap(r => r.feeds || []).filter(f => f.product === 'rawwater');
    const used = feeds.reduce((a, f) => a + f.delivered, 0);
    const need = feeds.reduce((a, f) => a + f.required, 0);
    const made = records.flatMap(r => r.products || []).filter(p => p.product === 'water').reduce((a, p) => a + p.accepted, 0);
    const spill = records.flatMap(r => r.products || []).filter(p => p.product === 'water').reduce((a, p) => a + p.spilled, 0);
    const demand = S.dem?.water || 0, delivered = demand * (S.fr?.water ?? 1);
    const links = [
      routeStep('source', 'آب‌شیرین‌کن ساحلی', intake?.quantity, !source.level ? 'ساخته نشده' : !source.connected ? 'خط انتقال وصل نیست' : !source.enabled || !source.target ? 'تولید متوقف است' : intake?.status || 'گزارش پس از گذشت روز', intake?.quantity > 0 ? 'ok' : source.level ? 'warn' : 'idle'),
      routeStep('coast', 'مخزن ساحلی', water.coastal.built ? water.coastal.stock : null, !water.coastal.built ? 'ساخت مخزن اختیاری است؛ آب می‌تواند مستقیم به خشکی برسد.' : 'تحویل امروز ' + number(today?.coastalDelivered) + ' از سقف ' + number(today?.coastalCapacity ?? COASTAL_BUFFER.dailyTransfer) + (today?.coastalStatus ? ' · ' + today.coastalStatus : ''), today?.coastalDelivered > 0 ? 'ok' : water.coastal.stock > 0 ? 'warn' : 'idle'),
      routeStep('raw', 'مخزن مشترک آب خام', raw, 'ورود مستقیم از همهٔ منابع ' + number(direct) + ' · دریافت از ذخیره ساحلی ' + number(today?.coastalDelivered) + (intake?.quantity > 0 && direct === 0 ? ' · امروز تولید ساحل به ذخیره رفت.' : ''), direct > 0 || today?.coastalDelivered > 0 ? 'ok' : intake?.quantity > 0 ? 'warn' : 'idle'),
      routeStep('treatment', 'تصفیه‌خانه‌ها', records.length ? made : null, plants.length ? records.length ? 'خوراک ' + number(used) + ' از ' + number(need) + ' · آب تولیدی ذخیره‌شده' + (spill > 0 ? ' · کمبود فضای مخزن ' + number(spill) : '') : 'هیچ گزارش تولیدی برای امروز ثبت نشده است.' : 'واحد تصفیه‌خانه ساخته نشده است.', plants.length ? spill > 0 ? 'warn' : level(used, need) : 'bad'),
      routeStep('city', 'شبکهٔ شهر و قطب‌ها', demand > 0 ? delivered : null, demand > 0 ? 'نیاز ' + number(demand) + ' · کسری ' + number(Math.max(0, demand - delivered)) : 'نیاز آب هنوز در تراز روزانه ثبت نشده است.', level(delivered, demand))
    ];
    return { steps: links, links: [['water-groundwater', 'energy', 'raw'], ['water-surface', 'energy', 'raw'], ['water-reclaimed', 'energy', 'raw'], ['water-desal', 'energy', 'raw'], ['energy', 'capital', 'city']] };
  }
  if (key === 'power') {
    const need = S.dem?.power || 0, delivered = need * (S.fr?.power ?? 1), generated = S.pd?.power;
    return {
      steps: [routeStep('generation', 'تولید برق', generated, 'موجودی مخزن مشترک ' + number(S.tanks?.power || 0), generated > 0 ? 'ok' : 'idle'), routeStep('power-city', 'شبکهٔ برق شهر', need > 0 ? delivered : null, need > 0 ? 'نیاز ' + number(need) + ' · کسری ' + number(Math.max(0, need - delivered)) : 'نیاز هنوز ثبت نشده است.', level(delivered, need))], links: [['energy', 'capital', 'power-city']]
    };
  }
  const offshore = ['oil', 'gas'].map(name => {
    const field = S.offshore?.[name] || {};
    return routeStep(name, name === 'oil' ? 'میدان نفت و انتقال به بندر' : 'میدان گاز و انتقال خوراک', field.deliveredToday, field.incident ? 'اختلال عملیاتی فعال است.' : field.pipelineIsolated ? 'خط ایزوله است.' : !field.pipelineLevel ? 'خط انتقال وصل نیست.' : 'موجودی بافر ' + number(field.buffer || 0) + ' · ذخیرهٔ قابل برداشت ' + number(field.reserveRemaining), field.incident || field.pipelineIsolated ? 'bad' : field.deliveredToday > 0 ? 'ok' : field.pipelineLevel ? 'warn' : 'idle');
  });
  const free = remainingTradePort(S), capacity = effectiveTradePort(S);
  return {
    steps: [...offshore, routeStep('terminal', 'پایانهٔ مشترک', free, 'ظرفیت مؤثر ' + number(capacity) + ' · ' + tradeConditionsText(S), free <= 0 ? 'bad' : capacity < S.port ? 'warn' : 'ok')],
    links: [['oil', 'port', 'oil'], ['gas', 'energy', 'gas'], ['port', 'energy', 'terminal']]
  };
}
const stepActions = {
  source: () => actions('atlas-select', 'مدیریت آب‌شیرین‌کن', 'data-k="water-desal"'),
  coast: () => actions('atlas-select', 'مدیریت مخزن ساحلی', 'data-k="water-desal"'),
  raw: () => actions('dev-stock', 'بازکردن مخزن آب خام', 'data-k="rawwater"'),
  treatment: () => actions('ops-treatment', 'مشاهدهٔ تصفیه‌خانه‌ها'),
  city: () => actions('dev-open', 'قرارداد توسعهٔ آب'),
  generation: () => actions('dev-project', 'مشاهدهٔ پروژهٔ تولید برق', 'data-i="13"'),
  'power-city': () => actions('dev-open', 'قرارداد توسعهٔ برق'),
  oil: () => actions('atlas-offshore', 'مدیریت میادین'),
  gas: () => actions('atlas-offshore', 'مدیریت میادین'),
  terminal: () => actions('port-trade', 'مدیریت تجارت')
};
export function renderCountryNetwork(S) {
  const key = networkKey(S), { steps } = countryNetwork(S, key);
  const selected = steps.find(x => x.id === S.mapStep) || steps.at(-1);
  const unit = key === 'water' ? 'هزار مترمکعب' : key === 'power' ? 'واحد برق' : 'واحد بازی';
  const contract = developmentSummary(S).find(x => x.key === key && x.status !== 'waiting');
  return `<div class="ops-network">
 <div class="ops-network-legend"><b>${NETWORKS[key]}</b><span>فعال · محدود · متوقف</span></div>
 <ol class="ops-steps">${steps.map(p => `<li><button type="button" data-a="ops-step" data-k="${p.id}" class="ops-step ${p.tone}" aria-pressed="${p === selected}"><span>${p.title}</span><b>${number(p.qty)}</b></button></li>`).join('')}</ol>
 <div class="ops-selected ${selected.tone}"><h3>${selected.title}</h3><p>${escapeText(selected.note)}</p><p>${number(selected.qty)} ${unit} · ${['coast', 'raw', 'terminal'].includes(selected.id) ? 'موجودی / ظرفیت فعلی' : 'گزارش روز بازی'}</p>${stepActions[selected.id]()}</div>
 ${contract ? `<p>قرارداد توسعه · ${contract.status === 'complete' ? 'تکمیل شد' : number(contract.streak) + ' از ' + number(contract.daysRequired) + ' روز'}</p>` : ''}
 ${key === 'water' ? '<small>مسیر مفهومی است. آب در مخزن مشترک جمع می‌شود و تحویل شهر به یک تولیدکنندهٔ خاص منتسب نیست.</small>' : ''}
</div>`;
}
export function campusNetwork(S, index) {
  const u = S.u[index];
  if (!u)
    return null;
  const running = u.st === 'run', record = u.dayEconomics?.day === S.day ? u.dayEconomics : null;
  const feeds = Object.keys(IN[u.t] || {}).map(p => ({ p, stats: record?.feeds?.find(x => x.product === p) }));
  const outputs = Object.keys(OUT[u.t] || {}).map(p => ({ p, stats: record?.products?.find(x => x.product === p) }));
  const missing = feeds.some(x => x.stats && !x.stats.optional && x.stats.missing > 0.001);
  const lost = outputs.some(x => x.stats?.spilled > 0.001);
  return {
    feeds, outputs, running, record, missing, lost, inputTone: !running || !record ? 'idle' : missing ? 'bad' : 'ok', outputTone: !running || !record ? 'idle' : lost ? 'warn' : 'ok'
  };
}
export function renderCampusNetwork(S, index) {
  const { feeds, outputs, running, record } = campusNetwork(S, index);
  const u = S.u[index], built = u.st !== 'build' && u.st !== 'ready';
  const primary = built && u.eq && u.v ? analyzeUnit(S, index, { D, PR, OPN }).primary : null;
  const status = !running ? 'واحد جریان فعال ندارد.' : !record ? 'هنوز گزارش تازه‌ای ثبت نشده است.' : 'تراز اندازه‌گیری‌شدهٔ امروز';
  const list = (entries, input) => entries.map(({ p, stats }) => {
    const info = input ? (stats ? 'تحویل ' + number(stats.delivered) + ' از ' + number(stats.required) + (stats.missing > 0.001 ? ' · کسری ' + number(stats.missing) : '') : 'نیاز اسمی ' + number(IN[u.t][p])) :
      (stats ? 'ذخیره ' + number(stats.accepted) + (stats.spilled > 0.001 ? ' · ازدست‌رفته ' + number(stats.spilled) : '') : 'تولید اسمی ' + number(OUT[u.t][p]));
    return `<li><span>${PR[p][0]} · ${info}</span>${actions('dev-stock', 'مخزن ' + PR[p][0], `data-k="${p}"`)}</li>`;
  }).join('');
  return `<section class="ops-campus"><h3>مسیر خوراک، محصول و مخزن</h3><p>${status}</p>${primary ? `<p><b>نیازمند توجه</b> · ${escapeText(primary.title)}</p>` : ''}
 <div class="ops-campus-flow"><div><b>خوراک</b><ul>${list(feeds, true) || '<li>بدون خوراک مادی ثبت‌شده</li>'}</ul></div>
 <div><b>محصول</b><ul>${list(outputs, false) || '<li>بدون محصول ثبت‌شده</li>'}</ul></div></div></section>`;
}
export function cityServiceMap(S, cityName) {
  const grid = safeCityGrid(S.cityMaps?.[cityName]);
  const support = grid.flatMap((b, i) => b?.type === 'service' || b?.type === 'park' ? [i] : []);
  return new Map(grid.flatMap((b, i) => b?.type === 'home' ? [[i, support.some(j => Math.abs(i % 9 - j % 9) + Math.abs(Math.floor(i / 9) - Math.floor(j / 9)) <= 2)]] : []));
}
export function cityServiceDistrict(S, cityName, id) {
  const district = Number.isInteger(id) ? districtIndex(id) : 4;
  const homes = [...cityServiceMap(S, cityName)].filter(([i]) => districtIndex(i) === district);
  const covered = homes.filter(([, hasService]) => hasService).length;
  const ratios = { water: S.fr?.water, power: S.fr?.power };
  const recorded = Object.keys(ratios).some(p => Number.isFinite(ratios[p]) && S.dem?.[p] > 0);
  const tone = homes.length ? level(covered, homes.length) : 'idle';
  return { district, homes: homes.length, covered, tone, ratios, recorded };
}
export function renderCityServices(S, city) {
  const id = Number.isInteger(S.cityCell) ? S.cityCell : 40;
  const d = cityServiceDistrict(S, city.name, id), design = districtDesign(S, city.name, id);
  const text = p => S.dem?.[p] > 0 && Number.isFinite(d.ratios[p]) ? number(d.ratios[p] * 100) + '٪' : 'بدون گزارش';
  return `<section class="ops-city"><h3>خدمات محلهٔ ${escapeText(design.name)}</h3><p>${number(d.covered)} از ${number(d.homes)} ساختمان مسکونی نزدیک پارک یا مرکز خدمات قرار دارد.</p>
<p>تأمین آب در شبکهٔ مشترک ${text('water')} · برق ${text('power')}</p>
<small>رنگ قطعه دسترسی محلی به پارک و مرکز خدمات را نشان می‌دهد. درصد آب و برق از شبکهٔ سراسری می‌آید.</small></section>`;
}
