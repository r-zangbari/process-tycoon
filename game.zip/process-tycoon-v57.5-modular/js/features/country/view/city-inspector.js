import { renderCityDesign } from '../../legacy/view/legacy-center.js';
import { cityDesign, LANDMARKS } from '../../legacy/model/legacy-development.js';
import { renderCityServices } from './map-operations.js';
import { cityDevelopmentMetrics } from '../model/urban-economy.js';
import { mapButton as btn } from './map-button.js';

export function renderCityInspector(S, city, fa, metrics = cityDevelopmentMetrics) {
  let panel;
  const grid = S.cityMaps?.[city.name] || [],
    b = S.cityCell != null ? grid[S.cityCell] : null,
    m = metrics(grid),
    lv = S.cities?.[city.name]?.level || 0;
  panel = `<small>ساخت از بودجه عمومی</small><h2>${S.cityCell == null ? 'یک قطعه انتخاب کن' : 'قطعه ' + fa(S.cityCell + 1)}</h2><p>جمعیت ${fa(m.pop)} · پوشش خدمات ${fa(m.coverage)}٪</p>`;
  const ornament = cityDesign(S, city.name).placements[S.cityCell],
    landmark = ornament && LANDMARKS[ornament.item];
  if (S.cityCell != null)
    panel += landmark
      ? `<p>قطعه بنای شاخص ${landmark.name} است؛ مدیریت در بخش زیباسازی.</p>`
      : b
        ? `<p>${{ home: 'مسکونی', shop: 'تجاری', service: 'خدمات', park: 'پارک' }[b.type]} · سطح ${fa(b.level)}/۳</p>${btn('city-building-upgrade', 'ارتقا · ' + fa({ home: 500, shop: 750, service: 1200, park: 350 }[b.type] * b.level), '', b.level >= 3 || S.govBudget < { home: 500, shop: 750, service: 1200, park: 350 }[b.type] * b.level)}${btn('city-building-demolish', 'تخریب و بازگشت بخشی از بودجه')}`
        : `<div class="atlas-build">${[
            ['home', 'مسکونی', 850],
            ['shop', 'تجاری', 1250],
            ['service', 'خدمات', 2100],
            ['park', 'پارک', 650]
          ]
            .map(([t, n, c]) => btn('city-build', `${n} · ${fa(c)}`, `data-t="${t}"`, S.govBudget < c))
            .join('')}</div>`;
  if (S.mapLayer === 'services') panel = renderCityServices(S, city) + panel;
  panel += renderCityDesign(S, city, Number.isInteger(S.cityCell) ? S.cityCell : null);
  panel += `<hr>${btn('city-upgrade', `خدمات سراسری شهر · ${fa(6000 * (lv + 1))}`, `data-i="${S.cityView}"`, lv >= 3 || S.govBudget < 6000 * (lv + 1))}<details><summary>انتخاب قطعه با صفحه‌کلید</summary><div class="atlas-lots">${Array.from({ length: 81 }, (_, i) => btn('city-cell', fa(i + 1), `data-i="${i}" aria-pressed="${S.cityCell === i}"`)).join('')}</div></details>`;
  return panel;
}
