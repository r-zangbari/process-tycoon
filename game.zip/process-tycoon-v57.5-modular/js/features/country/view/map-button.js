export const mapButton = (a, label, extra = '', disabled = false) =>
  `<button data-a="${a}" ${extra} ${disabled ? 'disabled' : ''}>${label}</button>`;
