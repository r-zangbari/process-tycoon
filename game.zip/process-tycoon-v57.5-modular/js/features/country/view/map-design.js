import { remainingTradePort } from '../../products/model/trade-conditions.js';
import { NETWORKS, networkKey, countryNetwork, campusNetwork, mapTone } from './map-operations.js';
import { DISTRICTS, countryViewKey, districtLots } from '../model/country-planning.js';
import { militarySignature } from '../../military/model/military.js';
export const MAP_COLORS = {
  land: '#b1be91', road: '#6c8175', water: '#357b8c', power: '#ecc372', gas: '#a7bac4', fuel: '#d49672', ok: '#67bca4', warn: '#e4ba68', bad: '#d98277'
};
export const MAP_ROUTES = [['north', 'capital', 'road'], ['capital', 'east', 'road'], ['housing', 'capital', 'road'], ['capital', 'energy', 'power'], ['capital', 'port', 'road'], ['oil', 'port', 'fuel'], ['gas', 'energy', 'gas'], ['water-groundwater', 'energy', 'water'], ['water-surface', 'energy', 'water'], ['water-reclaimed', 'energy', 'water'], ['water-desal', 'energy', 'water']];
export function mapToolbar(S, screen = 'atlas') {
  const layers = screen === 'atlas' ? [['overview', 'نمای کلی'], ['services', 'شبکه‌ها'], ['defense', 'دفاع و نظامی']] : screen === 'city' ? [['overview', 'نمای محله'], ['services', 'خدمات محله']] : [];
  const options = layers.map(([id, label]) => `<button data-a="atlas-display" data-k="${id}" aria-pressed="${(layers.some(([key]) => key === S.mapLayer) ? S.mapLayer : 'overview') === id}">${label}</button>`).join('');
  const networks = screen === 'atlas' && S.mapLayer === 'services' ? Object.entries(NETWORKS).map(([id, label]) => `<button data-a="ops-network" data-k="${id}" aria-pressed="${networkKey(S) === id}">${label}</button>`).join('') : '';
  return `<div class="map-toolbar" aria-label="نمایش نقشه">${options ? `<div class="map-layer-switch" role="group" aria-label="لایه نقشه">${options}</div>` : ''}${networks ? `<div class="ops-network-tabs" role="group" aria-label="انتخاب شبکه">${networks}</div>` : ''}<div class="row"><button data-a="atlas-display" data-k="labels" aria-pressed="${S.mapLabels !== false}">نام‌ها ${S.mapLabels === false ? 'خاموش' : 'روشن'}</button><button data-a="atlas-display" data-k="time">${S.mapTime === 'night' ? 'نور شب' : 'نور روز'}</button><button data-a="map-graphics">نمای سبک</button><span class="map-renderer-note" role="status"></span></div></div>`;
}
export function atlasRoutes(S) {
  if (S.mapLayer === 'services') {
    const { links, steps } = countryNetwork(S);
    return links.map(([a, b, id]) => {
      const step = steps.find(x => x.id === id);
      const selected = (steps.some(x => x.id === S.mapStep) ? S.mapStep : steps.at(-1).id) === id;
      return {
        a, b, id, color: mapTone(step.tone), active: step.tone === 'ok' || step.tone === 'warn', selected, road: false
      };
    });
  }
  return MAP_ROUTES.filter(([a, , kind]) => kind === 'road').map(([a, b]) => ({ a, b, color: MAP_COLORS.road, road: true }));
}
export function mapSheetHead() {
  return '<div class="map-sheet-head"><b>جزئیات انتخاب</b><button type="button" data-a="ops-close">بستن پنل</button></div>';
}
export function mapCameraControls(S) {
  const canFocus = S.tab === 'site' ? Number.isInteger(S.siteSelectedUnit) : (countryViewKey(S) === 'atlas' || S.cityView != null && S.cityCell != null || ['north', 'energy', 'housing'].includes(S.countryHub) && S.sel != null);
  return `<div class="atlas-camera"><button data-a="atlas-camera" data-k="toggle" aria-pressed="false">کنترل دوربین</button><button data-a="atlas-camera" data-k="reset">نمای کامل</button><button data-a="atlas-camera" data-k="focus" ${canFocus ? '' : 'disabled'}>تمرکز</button><button data-a="atlas-camera" data-k="in" aria-label="بزرگ‌نمایی">＋</button><button data-a="atlas-camera" data-k="out" aria-label="کوچک‌نمایی">−</button></div>`;
}
export function layoutLots(S, CITIES) {
  const city = S.cityView != null, grid = city ? (S.cityMaps?.[CITIES[S.cityView]?.name] || []) : null;
  const lots = city ? Array.from({ length: 81 }, (_, id) => ({ id, type: grid[id]?.type, level: grid[id]?.level || 1 })) : districtLots(S, S.countryHub);
  const cols = city ? 9 : Math.min(8, Math.max(1, Math.ceil(Math.sqrt(lots.length)))), rows = Math.ceil(lots.length / cols), spacing = 6.2;
  return {
    city, cols, rows, spacing, lots: lots.map((l, j) => ({
      ...l, x: (j % cols - (cols - 1) / 2) * spacing, z: (Math.floor(j / cols) - (rows - 1) / 2) * spacing, selected: l.id === (city ? S.cityCell : S.sel)
    }))
  };
}
// Read-only scene snapshot. Daily cash and unshown offshore timers must not rebuild geometry.
export function sceneSignature(S, CITIES) {
  const key = S.tab === 'site' ? 'industry:' + Math.floor((Number(S.siteMapPage) || 0)) : countryViewKey(S);
  const industry = S.tab === 'site', serviceAtlas = key === 'atlas' && S.mapLayer === 'services';
  const selectedUnit = industry && Number.isInteger(S.siteSelectedUnit) ? campusNetwork(S, S.siteSelectedUnit) : null;
  return JSON.stringify([key, industry ? null : S.mapLayer, S.mapLabels, S.mapTime, industry ? null : Math.floor(((S.day - 1) % 360) / 90),
    industry ? S.siteSelectedUnit : S.atlasSelected, industry ? null : S.sel, industry ? null : S.cityCell, S.seed,
    serviceAtlas ? atlasRoutes(S).map(({ id, color, active, selected }) => [id, color, active, selected]) : null,
    selectedUnit ? [selectedUnit.inputTone, selectedUnit.outputTone] : null,
    industry ? null : S.development?.offers?.water?.status === 'complete',
    industry ? null : !!S.waterSupply?.coastal?.built,
    industry ? S.legacy?.industry : S.legacy?.cities,
    industry ? S.u.map(u => [u.t, u.st, u.name, u.st === 'build' ? u.eq?.length : null]) : S.grid,
    S.cityView != null ? S.cityMaps?.[CITIES[S.cityView]?.name] : null, industry ? null : S.cities,
    !industry && key.startsWith('hub:') ? ['power', 'gas', 'water', 'fuel'].map(p => Math.round((S.fr?.[p] ?? 1) * 10)) : null,
    industry ? null : ['oil', 'gas'].map(k => {
      const o = S.offshore?.[k] || {};
      return [o.stage, Math.round((o.health ?? 100) / 10), o.pipelineLevel, o.incident?.kind, o.pipelineIsolated];
    }),
    key === 'atlas' && (S.inc?.ex || 0) > 0, key === 'atlas' ? militarySignature(S) : null]);
}
export function projectedLabelLayout(items, width, height) {
  const placed = [];
  return [...items].sort((a, b) => (b.priority || 0) - (a.priority || 0)).map(item => {
    const w = Math.min(width - 16, Math.max(60, item.text.length * 6.2 + 18)), h = 25, x = Math.max(8 + w / 2, Math.min(width - 8 - w / 2, item.x));
    for (const offset of [0, -29, 29, -58, 58]) {
      const y = item.y + offset;
      if (y < 52 || y > height - 48)
        continue;
      const rect = { left: x - w / 2, right: x + w / 2, top: y - h / 2, bottom: y + h / 2 };
      if (placed.some(b => !(rect.right + 5 < b.left || rect.left - 5 > b.right || rect.bottom + 3 < b.top || rect.top - 3 > b.bottom)))
        continue;
      placed.push(rect);
      return { ...item, x, y, visible: true };
    }
    return { ...item, visible: false };
  });
}
export function districtStatus(S, d) {
  if (d.kind === 'rig') {
    const o = S.offshore?.[d.id];
    return o?.stage === 5 ? (o.incident ? 'اختلال فعال' : 'توسعه‌یافته') : 'اکتشاف و توسعه';
  }
  const lots = districtLots(S, d.id);
  return lots.length ? lots.filter(l => l.type).length.toLocaleString('fa-IR') + ' بنای ساخته‌شده' : d.kind === 'port' ? Math.round(remainingTradePort(S)).toLocaleString('fa-IR') + ' ظرفیت آزاد' : 'مدیریت شهر';
}
