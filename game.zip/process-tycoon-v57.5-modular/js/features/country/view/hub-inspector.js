import { remainingTradePort, effectiveTradePort } from '../../products/model/trade-conditions.js';
import { districtLots, HUB_TYPES } from '../model/country-planning.js';
import { mapButton as btn } from './map-button.js';

const serviceNames = { power: 'برق', gas: 'گاز', water: 'آب', fuel: 'سوخت' };

export function renderHubInspector(S, hub, TY, fa) {
  let panel;
  const lotButton = (l) =>
    btn(
      'hub-cell',
      `${l.type ? TY[l.type].n : 'زمین'} ${fa(l.id + 1)}`,
      `data-i="${l.id}" aria-pressed="${S.sel === l.id}"`
    );

  const lots = districtLots(S, hub),
    b = S.sel != null ? S.grid[S.sel] : null,
    types = HUB_TYPES[hub] || [];
  panel = `<small>ساخت از سرمایه شرکت</small><h2>${S.sel == null ? 'یک زمین انتخاب کن' : (b ? TY[b.t].n : 'زمین خالی') + ' · ' + fa(S.sel + 1)}</h2>`;
  if (S.sel != null && lots.some((l) => l.id === S.sel))
    panel += b
      ? `<p>سطح ${fa(b.l)}/۳</p>${Object.keys(TY[b.t].need)
          .map(
            (p) =>
              `<div class="atlas-service"><span>${serviceNames[p]} · نیاز ${fa(TY[b.t].need[p] * b.l)}</span>${b.c[p] ? '<b>متصل</b>' : btn('conn', 'اتصال · ۱۰۰', `data-p="${p}"`, S.money < 100)}</div>`
          )
          .join(
            ''
          )}${btn('cup', 'ارتقا · ' + fa(TY[b.t].cost * b.l * 1.2), '', b.l >= 3 || S.money < TY[b.t].cost * b.l * 1.2)}${btn('demo', 'تخریب و بازگشت ۳۰٪ ارزش')}`
      : types
          .map((tp) =>
            btn(
              'build',
              `ساخت ${TY[tp].e} ${TY[tp].n} · ${fa(TY[tp].cost)}`,
              `data-t="${tp}"`,
              S.money < TY[tp].cost
            )
          )
          .join('');
  panel += `${hub === 'north' ? '<p class="muted"><b>زنجیرهٔ غذا:</b> مزرعه و گلخانه محصول می‌دهند؛ دامداری از محصول مزرعه علوفه می‌خورد و گوشت و لبنیات تولید می‌کند؛ کارخانهٔ فراوری از همهٔ این‌ها غذای فرآوری‌شده می‌سازد. همه برق، آب و سوخت می‌خواهند و غذای بیشتر مالیات شهرها را تا ۱۲٪ بالا می‌برد.' + (S.foodIndex != null ? ' شاخص غذای امروز: ' + fa(Math.round(S.foodIndex * 100)) + '٪.' : '') + '</p>' : ''}<p class="muted">اتصال با تأمین تفاوت دارد؛ خدمات متصل فقط در صورت موجودی کافی در مخازن تحویل می‌شوند.</p><details><summary>فهرست زمین‌ها · ${fa(lots.length)}</summary><div class="atlas-lots">${lots.map(lotButton).join('')}</div></details>`;
  return panel;
}

export function renderPortInspector(S, fa) {
  let panel;
  panel = `<small>دروازه تجارت</small><h2>ظرفیت ${fa(effectiveTradePort(S))} در روز</h2><p>مصرف امروز ${fa(S.portUsedToday || 0)} · باقی‌مانده ${fa(remainingTradePort(S))}</p><p>خوراک وارداتی، قراردادها و فروش نقدی از ظرفیت مشترک استفاده می‌کنند.</p>${btn('port', 'توسعه بندر · ' + fa((1500 * S.port) / 20), '', S.money < (1500 * S.port) / 20)}${btn('port-trade', 'واردات، صادرات و قراردادها')}`;
  return panel;
}
