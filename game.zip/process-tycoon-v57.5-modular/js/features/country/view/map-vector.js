import { mapTone, campusNetwork, cityServiceMap } from './map-operations.js';
import {
  cityDesign,
  districtDesign,
  STYLES,
  industryAppearance,
  PALETTES,
  placementDefinition,
  districtIndex
} from '../../legacy/model/legacy-development.js';
import { ornamentArt, styleArt, campusPaletteArt } from '../../legacy/view/legacy-art.js';
import { unitName } from '../../../engine/unit-names.js';
import { DISTRICTS, countryViewKey } from '../model/country-planning.js';
import { ATLAS_BOUNDS, atlasHeight } from '../model/atlas-terrain.js';
import { D } from '../../../data/catalog.js';
import { industryPage } from '../../industrial-site/view/industry-view.js';
import {
  renderNationalHub,
  renderCityBuilding,
  renderProcessFacility,
  renderOffshoreRig
} from './strategy-graphics.js';
import { atlasRoutes, layoutLots, sceneSignature } from './map-design.js';
import { ROLE_COLORS } from '../../military/view/military-models.js';
import {
  MIL,
  militaryState,
  staffing,
  unitStatus,
  effectiveRange,
  incomingRaid,
  zoneDamaged,
  STATUS_TEXT,
  ZONES,
  enemyList,
  seaStatus,
  LANE
} from '../../military/model/military.js';
const esc = (s) =>
    String(s ?? '').replace(
      /[&<>"']/g,
      (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]
    ),
  num = (n) => Math.round(n).toLocaleString('fa-IR');
const tree = (x, y, s = 1) =>
  `<g transform="translate(${x} ${y}) scale(${s})"><ellipse cy="6" rx="11" ry="4" fill="#284f4233"/><path d="M0 2v-19" stroke="#8d785a" stroke-width="4"/><path d="M-12-7L0-34 12-7Z" fill="#487b61"/><path d="M0-34L12-7H0Z" fill="#365f52"/></g>`;
const farm = () =>
  `<g><path d="M-51 6L-8-18 49 9 5 32Z" fill="#8ca961" stroke="#d9ce96"/>${[0, 1, 2, 3, 4].map((i) => `<path d="M${-43 + i * 9} ${9 - i * 5}l48 23" stroke="${i % 2 ? '#b2bd6e' : '#6f9255'}" stroke-width="5"/>`).join('')}<path d="M-8-15l16-10 19 11v25l-16 8-19-9z" fill="#d69d77"/><path d="M-13-16L4-34 30-17 11-7Z" fill="#9f624f"/></g>`;
const greenhouse = () =>
  `<g><path d="M-51 6L-8-18 49 9 5 32Z" fill="#c8b88a" stroke="#e5dcae"/><path d="M-30 8L-4-8 30 9 4 25Z" fill="#9fd9cf" stroke="#eaf8f4" stroke-width="2"/><path d="M-30 8v-14L-4-22 30-5V9L4 25Z" fill="#cdeee7" opacity=".85" stroke="#eaf8f4"/><path d="M-30-6L-4-22 30-5 4 11Z" fill="#eaf8f4" opacity=".9"/>${[0, 1, 2].map((i) => `<path d="M${-18 + i * 12} ${-2 - i * 3}l18 9" stroke="#5fae4a" stroke-width="4"/>`).join('')}</g>`;
const barn = () =>
  `<g><path d="M-51 6L-8-18 49 9 5 32Z" fill="#a3b36f" stroke="#d9ce96"/><path d="M-26 4l-2-14 18-10 24 12v14l-18 10z" fill="#a8553c"/><path d="M-30-8L-9-22 18-9 -3 5Z" fill="#7a3a2a"/><path d="M32 4l8 4v-26l-8-4z" fill="#c9ccc4"/><ellipse cx="14" cy="22" rx="5" ry="3" fill="#f2f0ea"/><ellipse cx="26" cy="17" rx="5" ry="3" fill="#f2f0ea"/><path d="M-38 16l36 17M-38 16V8M-2 33v-8" stroke="#c9a56b" stroke-width="2.5" fill="none"/></g>`;
const foodPlant = () =>
  `<g><path d="M-51 6L-8-18 49 9 5 32Z" fill="#b9bdb0" stroke="#dfe2d6"/><path d="M-30 4l-2-12 24-12 36 18v12l-24 12z" fill="#d9d6cb"/><path d="M-32-8l24-12 36 18-24 12z" fill="#e8e4d8"/><path d="M-10 6l30 14" stroke="#6c9c58" stroke-width="4"/><path d="M26-14V-36" stroke="#8f9b9b" stroke-width="7"/><ellipse cx="-24" cy="20" rx="8" ry="5" fill="#e0e3dc"/></g>`;
const art = (kind, level = 1) =>
  kind === 'farm' || kind === 'f'
    ? farm()
    : kind === 'g'
      ? greenhouse()
      : kind === 'l'
        ? barn()
        : kind === 'p'
          ? foodPlant()
          : kind === 'factory' || kind === 'k'
            ? renderNationalHub('industrial', level)
            : ['h', 'home', 'park', 'shop', 'service'].includes(kind)
              ? renderCityBuilding(kind === 'h' ? 'home' : kind, level)
              : renderNationalHub(kind, level);
const target = (kind, id, label, content) =>
  `<g class="map-target" role="button" tabindex="0" data-map-kind="${kind}" data-map-id="${id}" aria-label="${esc(label)}"><title>${esc(label)}</title>${content}</g>`;
const tag = (text, x, y, selected = false, detail = false) =>
  `<g class="vector-label ${selected ? 'selected' : ''} ${detail ? 'map-label-detail' : ''}" transform="translate(${x} ${y})"><rect x="-${Math.max(44, text.length * 3.3 + 12)}" y="-13" width="${Math.max(88, text.length * 6.6 + 24)}" height="26" rx="8"/><text text-anchor="middle" dominant-baseline="central">${esc(text)}</text></g>`;
let atlasLandOutline;
function landOutline() {
  if (atlasLandOutline) return atlasLandOutline;
  const { minX, maxX, minZ, maxZ } = ATLAS_BOUNDS, north = [], south = [];
  for (let x = minX; x <= maxX; x++) {
    let first, last;
    for (let z = minZ; z <= maxZ; z += 0.5) {
      if (atlasHeight(x, z) < 0.1) continue;
      first ??= z;
      last = z;
    }
    if (first === undefined) continue;
    north.push(worldToSvg(x, first).map(v => v.toFixed(1)).join(' '));
    south.push(worldToSvg(x, last).map(v => v.toFixed(1)).join(' '));
  }
  atlasLandOutline = 'M' + [...north, ...south.reverse()].join('L') + 'Z';
  return atlasLandOutline;
}
function districtPoint(d) {
  return worldToSvg(d.x, d.z);
}
function atlas(S) {
  const routes = atlasRoutes(S)
    .map(({ a, b, id, color, road, active, selected }) => {
      const p = districtPoint(DISTRICTS.find(d => d.id === a)),
        q = districtPoint(DISTRICTS.find(d => d.id === b));
      const d = `M${p}Q${(p[0] + q[0]) / 2} ${(p[1] + q[1]) / 2 - 18} ${q}`;
      const line = `<path class="vector-route ${road ? '' : 'service-route'}" d="${d}" stroke="${color}" stroke-width="${selected ? 12 : road ? 9 : 7}" ${road || active ? '' : 'stroke-dasharray="8 7"'}/>`;
      return id
        ? target(
            'network',
            id,
            'جزئیات مسیر',
            `<path d="${d}" fill="none" stroke="transparent" stroke-width="27" pointer-events="stroke"/>${line}`
          )
        : line;
    })
    .join('');
  const land = landOutline();
  const river = Array.from({ length: 42 }, (_, i) => {
    const z = i - 17;
    return worldToSvg(-20 + (z + 18) * 0.3, z).join(' ');
  }).join('L');
  return `<defs>
    <linearGradient id="map-ocean" x2="0" y2="1"><stop stop-color="#346f7e"/><stop offset="1" stop-color="#204d61"/></linearGradient>
    <linearGradient id="map-land" x2="1" y2="1"><stop stop-color="#c9d3ab"/><stop offset="1" stop-color="#92ad86"/></linearGradient>
    <clipPath id="atlas-land-clip"><path d="${land}"/></clipPath>
  </defs>
  <rect width="900" height="600" fill="url(#map-ocean)"/>
  <path d="${land}" fill="#172e3b" transform="translate(0 11)" opacity=".35"/>
  <path d="${land}" fill="url(#map-land)" stroke="#e8d7a9" stroke-width="5"/>
  <g clip-path="url(#atlas-land-clip)"><path d="M${river}" stroke="#729c9a" stroke-width="12" fill="none"/>
  <g transform="translate(${worldToSvg(-24, -22)})" fill="#879886" stroke="#788d7b"><path d="M-47 12L-10-55 25 14Z"/><path d="M-15 18L27-44 64 18Z"/><path d="M11-20L27-44 43-19 28-25Z" fill="#e2e5cf" stroke="none"/></g>
  ${Array.from({ length: 27 }, (_, i) => tree(73 + ((i * 53) % 754), 68 + ((i * 41) % 342), 0.59 + (i % 3) * 0.18)).join('')}</g>
  ${routes}<path d="M100 497q70-19 128 2M380 555q74-20 139-4M697 460q70-16 143-4" stroke="#bad4cf" stroke-width="2" opacity=".25" fill="none"/>${DISTRICTS.map(
    (d) => {
      const [x, y] = districtPoint(d),
        selected = d.id === (S.atlasSelected || 'capital'),
        rig = d.kind === 'rig',
        built = S.offshore?.[d.id]?.stage === 5,
        lv = d.city != null ? 1 + (S.cities?.[d.city === 1 ? 'پایتخت' : 'مرکز شرقی']?.level || 0) : 1;
      return target(
        'district',
        d.id,
        d.name,
        `<g transform="translate(${x} ${y})"><ellipse cy="20" rx="66" ry="24" fill="${rig ? '#8dbdb222' : '#506f4b22'}" ${selected ? 'stroke="#f4cf7f" stroke-width="4"' : ''}/><g transform="scale(${rig ? 0.48 : 0.8})">${d.water ? `<ellipse cy="5" rx="32" ry="16" fill="#5c98a7"/><rect x="-32" y="-35" width="64" height="40" fill="#82b4be"/><ellipse cy="-35" rx="32" ry="16" fill="#d4e9dd"/><path d="M-45 20H-15V-8M34 8H58" stroke="#3e7f91" stroke-width="8" fill="none"/>` : rig ? renderOffshoreRig(d.id, built, S.offshore?.[d.id]?.health) : art(d.kind, lv)}</g>${(d.id === 'capital' && S.development?.offers?.water?.status === 'complete') || (d.water === 'desal' && S.waterSupply?.coastal?.built) ? '<g transform="translate(43 10)"><ellipse cy="6" rx="16" ry="7" fill="#205b65"/><path d="M-16 6V-16H16V6Z" fill="#2b97a8"/><ellipse cy="-16" rx="16" ry="7" fill="#d9f3ea"/></g>' : ''}${S.mapLabels === false ? '' : tag(d.name, 0, rig ? 72 : 62, selected, !selected && !'capital north east port'.split(' ').includes(d.id))}</g>`
      );
    }
  ).join(
    ''
  )}<text x="824" y="568" class="vector-water-title" text-anchor="end">دریای جنوبی</text><g transform="translate(839 82)" class="map-compass"><path d="M0-22L8 8 0 3-8 8Z" fill="#f1dcaa"/><text text-anchor="middle" y="-29">شمال</text></g>`;
}
function lotMap(S, CITIES) {
  const { city, cols, rows, lots, spacing } = layoutLots(S, CITIES),
    scale = Math.min(8, 550 / ((cols + rows) * spacing * 0.55)),
    project = (x, z) => [450 + (x - z) * scale * 0.85, 300 + (x + z) * scale * 0.42],
    extent = (Math.max(cols, rows) * spacing) / 2 + 2;
  const services = city && S.mapLayer === 'services' ? cityServiceMap(S, CITIES[S.cityView].name) : null;
  const corners = [
    [-extent, -extent],
    [extent, -extent],
    [extent, extent],
    [-extent, extent]
  ]
    .map(([x, z]) => project(x, z).join(','))
    .join(' ');
  return `<rect width="900" height="600" fill="#adc0b0"/><polygon points="${corners}" fill="#5b7e6b" transform="translate(0 12)"/><polygon points="${corners}" fill="#8da68a" stroke="#ddd5b2" stroke-width="5"/>${Array.from(
    { length: cols + 1 },
    (_, i) => {
      const x = (i - cols / 2) * spacing,
        a = project(x, (-rows * spacing) / 2),
        b = project(x, (rows * spacing) / 2);
      return `<path d="M${a}L${b}" stroke="#64796f" stroke-width="${scale * 1.15}"/>`;
    }
  ).join('')}${Array.from({ length: rows + 1 }, (_, i) => {
    const z = (i - rows / 2) * spacing,
      a = project((-cols * spacing) / 2, z),
      b = project((cols * spacing) / 2, z);
    return `<path d="M${a}L${b}" stroke="#64796f" stroke-width="${scale * 1.15}"/>`;
  }).join('')}${[...lots]
    .sort((a, b) => a.x + a.z - (b.x + b.z))
    .map((l) => {
      const [x, y] = project(l.x, l.z),
        w = spacing * scale * 0.77,
        h = w * 0.5,
        cityName = city ? CITIES[S.cityView].name : '',
        district = city ? districtDesign(S, cityName, l.id) : null,
        placement = city ? cityDesign(S, cityName).placements[l.id] : null;
      return target(
        city ? 'city-lot' : 'lot',
        l.id,
        `${placement ? placementDefinition(placement.item)?.name || 'آیتم' : l.type ? 'ساختمان' : 'زمین'} ${num(l.id + 1)}`,
        `<g transform="translate(${x} ${y})"><path d="M0 ${-h}L${w} 0 0 ${h} ${-w} 0Z" fill="${l.selected ? '#ddc48c' : services?.has(l.id) ? mapTone(services.get(l.id) ? 'ok' : 'bad') : city ? STYLES[district.style].ground : l.type ? '#c2c8a8' : '#aebc96'}" stroke="${l.selected ? '#fff3bc' : '#d6dbb9'}" stroke-width="${l.selected ? 3 : 1}"/>${l.type ? `<g transform="translate(0 -6) scale(${Math.min(0.65, w / 60)})">${city ? styleArt(art(l.type, l.level), district.style) : art(l.type, l.level)}</g>` : `<path d="M-5 0h10M0-5v10" stroke="#6c8b75" stroke-width="1.4"/>`}${placement ? `<g transform="translate(${l.type ? w * 0.52 : 0} ${l.type ? 6 : -5}) scale(${Math.min(l.type ? 0.36 : 0.65, w / 66)})">${ornamentArt(placement.item, placement.level, placement.days > 0)}</g>` : ''}${city && S.mapLabels !== false && [10, 13, 16, 37, 40, 43, 64, 67, 70].includes(l.id) && cityDesign(S, cityName).districts[districtIndex(l.id)] ? `<text text-anchor="middle" y="${h + 16}" font-size="12" fill="#325c49" stroke="#f0eed5" stroke-width="3" paint-order="stroke">${esc(district.name)}</text>` : ''}${S.mapLabels === false ? '' : `<text y="${h - 3}" class="lot-number ${l.selected ? '' : 'map-label-detail'}" text-anchor="middle">${num(l.id + 1)}</text>`}</g>`
      );
    })
    .join('')}`;
}
function campusLinks(S, units) {
  const pos = units.findIndex(({ i }) => i === S.siteSelectedUnit);
  if (pos < 0) return '';
  const data = campusNetwork(S, S.siteSelectedUnit),
    x = 115 + (pos % 6) * 133,
    start = pos < 6 ? 252 : 380;
  const flow = (offset, y, tone) =>
    `<path d="M${x + offset} ${start} V${y} H${x + offset + (offset < 0 ? -30 : 30)}" fill="none" stroke="${mapTone(tone)}" stroke-width="7" stroke-linecap="round" ${data.running ? '' : 'stroke-dasharray="6 5"'}/>`;
  return (
    (data.feeds.length ? flow(-11, 280, data.inputTone) : '') +
    (data.outputs.length ? flow(11, 330, data.outputTone) : '')
  );
}
function campus(S) {
  const { units } = industryPage(S),
    appearance = industryAppearance(S),
    palette = PALETTES[appearance.palette];
  return `<rect width="900" height="600" fill="#b6c8b9"/><path d="M50 70H850V544H50Z" fill="#a6b59b" stroke="#e4debb" stroke-width="7"/><path d="M50 305H850M450 70V544" stroke="#58716b" stroke-width="38"/><path d="M50 305H850M450 70V544" stroke="#c4ccab" stroke-width="2" stroke-dasharray="12 14"/><path d="M60 280H840M60 330H840" stroke="#d4b67a" stroke-width="5"/>${campusLinks(S, units)}${Array.from(
    { length: 12 },
    (_, j) => {
      const x = 115 + (j % 6) * 133,
        y = j < 6 ? 216 : 465,
        e = units[j];
      return `<g transform="translate(${x} ${y})"><path d="M-55-108H55V34H-55Z" fill="${e && e.i === S.siteSelectedUnit ? '#ead49e' : e ? '#d4d9bd' : '#a1b197'}" stroke="${e && e.i === S.siteSelectedUnit ? '#fff2b8' : '#e6e3c7'}" stroke-width="2"/>${e ? target('unit', e.i, unitName(e.u, D, e.i), `<rect x="-55" y="-108" width="110" height="175" fill="transparent" pointer-events="all"/><g transform="scale(.66)">${campusPaletteArt(renderProcessFacility(e.u.t, e.u.st), S)}${e.u.st === 'build' ? '<path d="M-42 12V-92H44M-27 -92v104M25 -92v25" fill="none" stroke="#f9c261" stroke-width="4" stroke-dasharray="8 4"/>' : ''}</g>${S.mapLabels === false ? '' : tag(num(e.i + 1) + ' · ' + (unitName(e.u, D, e.i).length > 15 ? unitName(e.u, D, e.i).slice(0, 14) + '…' : unitName(e.u, D, e.i)), 0, 54, e.i === S.siteSelectedUnit, e.i !== S.siteSelectedUnit)}`) : '<text class="lot-number" text-anchor="middle" y="-25">زمین توسعه</text>'}</g>`;
    }
  ).join(
    ''
  )}${Array.from({ length: 15 + appearance.garden * 5 }, (_, i) => tree(55 + ((i * 55) % 790), 572 - Math.floor(i / 15) * 28, 0.65)).join('')}${appearance.office ? `<g transform="translate(785 95) scale(${0.6 + appearance.office * 0.12})">${renderCityBuilding('service', appearance.office)}</g>` : ''}${appearance.sign ? `<g transform="translate(450 530)"><rect x="-135" y="-25" width="270" height="40" rx="8" fill="${palette.dark}" stroke="${palette.accent}" stroke-width="3"/><text text-anchor="middle" y="0" font-size="17" fill="#fff">${esc(appearance.name)} · ${appearance.logo === 'leaf' ? '❧' : appearance.logo === 'drop' ? '◉' : '⚙'}</text></g>` : ''}`;
}
function marine(S, port) {
  return `<rect width="900" height="600" fill="#347e8c"/>${
    port
      ? `<path d="M0 0H900V120L675 200 400 150 0 220Z" fill="#adbf99" stroke="#e2d4a7" stroke-width="7"/><g transform="translate(450 290) scale(2.7)">${renderNationalHub('port', 1)}</g><path d="M180 415l250 60 150-60" fill="#edf0cf" stroke="#23566a" stroke-width="4"/><path d="M180 415l40 31 210 46 150-60v-17l-150 60Z" fill="#c78b67"/>${tag('پایانه مشترک · ' + num(S.port) + ' واحد در روز', 450, 545)}`
      : ['oil', 'gas']
          .map((id, i) => {
            const x = i ? 660 : 245,
              o = S.offshore?.[id] || {};
            return target(
              'district',
              id,
              id === 'oil' ? 'میدان نفت' : 'میدان گاز',
              `<g transform="translate(${x} 255) scale(1.4)">${renderOffshoreRig(id, o.stage === 5, o.health)}</g>${tag(id === 'oil' ? 'میدان نفت دریایی' : 'میدان گاز دریایی', x, 490)}<path d="M${x} 430L450 580" stroke="${o.pipelineLevel ? '#dfba76' : '#a3bab3'}" stroke-width="6" stroke-dasharray="12 9"/>`
            );
          })
          .join('')
  }`;
}
// ───── v57: military layer on the isometric fallback map ─────
// One projection for terrain, markers, range overlays and touch picking.
const WX = [8.9, 1.05, 450],
  WY = [-0.32, 5.8, 288];
export const worldToSvg = (x, z) => [WX[0] * x + WX[1] * z + WX[2], WY[0] * x + WY[1] * z + WY[2]];
export function svgToWorld(sx, sy) {
  const det = WX[0] * WY[1] - WX[1] * WY[0],
    X = sx - WX[2],
    Y = sy - WY[2];
  return { x: (WY[1] * X - WX[1] * Y) / det, z: (-WY[0] * X + WX[0] * Y) / det };
}
const glyphSvg = (kind, c) => {
  const s = `stroke="${c}" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"`;
  if (kind === 'radar')
    return `<path d="M-8 4A9 9 0 0 1 8 4M-5 7A5 5 0 0 1 5 7" ${s}/><circle cy="7" r="1.8" fill="${c}"/>`;
  if (kind === 'command')
    return `<path d="M0-9L2.6-3 9-2.6 4 1.6 5.6 8 0 4.6-5.6 8-4 1.6-9-2.6-2.6-3Z" fill="${c}"/>`;
  if (kind === 'sam_short') return `<path d="M-5 8L0-8 5 8" ${s}/>`;
  if (kind === 'sam_long') return `<path d="M-9 8L-4-8 1 8M-1 8L4-8 9 8" ${s}/>`;
  if (kind === 'antidrone') return `<circle r="5.5" ${s}/><path d="M-9 0H9M0-9V9" ${s}/>`;
  if (kind === 'drone_base') return `<path d="M0-8L8 6 0 3-8 6Z" fill="${c}"/>`;
  return `<path d="M0-9L3-3V5L6 9H-6L-3 5V-3Z" fill="${c}"/>`;
};
const hex = (r) =>
  Array.from({ length: 6 }, (_, i) => {
    const a = Math.PI / 6 + (i * Math.PI) / 3;
    return `${(Math.cos(a) * r).toFixed(1)},${(Math.sin(a) * r).toFixed(1)}`;
  }).join(' ');
export function militarySvg(S, defenseSite) {
  const parts = [],
    zone = (id) => DISTRICTS.find((d) => d.id === id),
    raid = incomingRaid(S);
  if (raid && zone(raid.zone)) {
    const d = zone(raid.zone),
      [x, y] = worldToSvg(d.x, d.z);
    parts.push(
      `<g class="vector-raid" transform="translate(${x.toFixed(1)} ${y.toFixed(1)})" pointer-events="none"><ellipse cy="14" rx="96" ry="50" fill="#ff4a3d22" stroke="#ff4a3d" stroke-width="5" stroke-dasharray="11 7"/>${tag('هدف حمله · ' + num(raid.daysLeft) + ' روز', 0, -58, true)}</g>`
    );
  }
  {
    const q = seaStatus(S),
      [a, b] = worldToSvg(...LANE[0]),
      [c, d] = worldToSvg(...LANE[1]);
    parts.push(
      `<path d="M${a.toFixed(1)} ${b.toFixed(1)}L${Math.min(866, c).toFixed(1)} ${Math.min(566, d).toFixed(1)}" stroke="${q.blockade ? '#ff4a3d' : '#7fd0ff'}" stroke-width="3" stroke-dasharray="4 7" pointer-events="none"/>`
    );
    if (q.blockade)
      parts.push(
        `<g transform="translate(${((a + Math.min(866, c)) / 2 + 40).toFixed(1)} ${((b + Math.min(566, d)) / 2).toFixed(1)})" pointer-events="none">${tag('محاصرهٔ دریایی · ظرفیت ' + num(Math.round(q.factor * 100)) + '٪', 0, 0, true, false)}</g>`
      );
    if (q.convoy) {
      const [sx, sy] = worldToSvg(q.convoy.x, q.convoy.z);
      parts.push(
        `<g transform="translate(${Math.min(866, sx).toFixed(1)} ${Math.min(566, sy).toFixed(1)})" pointer-events="none"><path d="M-16 0H16L10 9H-10Z" fill="#2f6f9f" stroke="#fff" stroke-width="2"/><rect x="-5" y="-9" width="9" height="9" fill="#fff"/>${tag('کشتی تجاری · ' + num(q.convoy.daysLeft) + ' روز', 0, 26, false, false)}</g>`
      );
    }
  }
  for (const e of enemyList(S)) {
    const [x0, y0] = worldToSvg(e.x, e.z),
      x = Math.min(866, Math.max(34, x0)),
      y = Math.min(566, Math.max(34, y0)),
      edge = x !== x0 || y !== y0,
      c = e.down ? '#8a8a8a' : '#ff5a4a';
    if (e.origin && raid && zone(raid.zone)) {
      const d = zone(raid.zone),
        [tx, ty] = worldToSvg(d.x, d.z);
      parts.push(
        `<path d="M${x.toFixed(1)} ${y.toFixed(1)}L${tx.toFixed(1)} ${ty.toFixed(1)}" stroke="#ff4a3d" stroke-width="3" stroke-dasharray="10 8" pointer-events="none"/>`
      );
    }
    parts.push(
      `<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)})" pointer-events="none"><circle r="20" fill="#3a2a2e" stroke="${c}" stroke-width="${e.origin ? 5 : 3}"/><path d="M-8 9V-9H8V9M-12-9H12" stroke="#ffd2cc" fill="none" stroke-width="2.4"/>${tag(e.name + ' · ' + num(e.hp) + '٪' + (e.down ? ' · از کار افتاده' : '') + (edge ? ' ↗' : ''), 0, 38, e.origin, false)}</g>`
    );
  }
  if (S.military) {
    const m = militaryState(S, false),
      defense = S.mapLayer === 'defense',
      { crew } = staffing(S),
      active = m.units.filter((u) => unitStatus(S, u, crew) === 'active');
    for (const d of ZONES)
      if (zoneDamaged(S, d.id)) {
        const [x, y] = worldToSvg(d.x, d.z);
        parts.push(
          `<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)})" pointer-events="none"><ellipse cy="14" rx="80" ry="40" fill="none" stroke="#e4903c" stroke-width="4"/>${tag(d.name + ' · آسیب‌دیده', 0, -48, false, true)}</g>`
        );
      }
    for (const u of m.units) {
      const def = MIL[u.kind],
        selected = u.id === m.sel;
      if (defense && (selected || m.layers.coverage)) {
        const [x, y] = worldToSvg(u.x, u.z),
          r = effectiveRange(S, u, active),
          c = ROLE_COLORS[def.role];
        parts.push(
          `<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="${(r * WX[0]).toFixed(1)}" ry="${(r * WY[1]).toFixed(1)}" fill="${c}22" stroke="${c}" stroke-width="2.5" stroke-dasharray="9 7" pointer-events="none"/>`
        );
      }
      if (u.move) {
        const [a, b] = worldToSvg(u.x, u.z),
          [c2, d2] = worldToSvg(u.move.x, u.move.z);
        parts.push(
          `<path d="M${a.toFixed(1)} ${b.toFixed(1)}L${c2.toFixed(1)} ${d2.toFixed(1)}" stroke="#f5e29a" stroke-width="3" stroke-dasharray="8 7" pointer-events="none"/><circle cx="${c2.toFixed(1)}" cy="${d2.toFixed(1)}" r="12" fill="none" stroke="#f5e29a" stroke-width="3" pointer-events="none"/>`
        );
      }
    }
    for (const u of m.units) {
      const def = MIL[u.kind],
        st = unitStatus(S, u, crew),
        [x, y] = worldToSvg(u.x, u.z),
        c = st === 'idle' ? '#e28a7f' : ROLE_COLORS[def.role],
        selected = u.id === m.sel;
      const label = def.name + ' · ' + STATUS_TEXT[st];
      parts.push(
        target(
          'mil',
          u.id,
          label,
          `<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)})" ${st === 'building' || st === 'moving' ? 'opacity=".75"' : ''}>${selected ? '<circle r="27" fill="#ffe08a33" stroke="#ffe08a" stroke-width="3"/>' : ''}<ellipse cy="14" rx="19" ry="7" fill="#1c3a3a55"/><polygon points="${hex(19)}" fill="#12282d" stroke="${c}" stroke-width="${selected ? 4 : 3}" ${st === 'building' ? 'stroke-dasharray="5 4"' : ''}/>${glyphSvg(u.kind, c)}${st === 'idle' ? '<path d="M-17 15L17-15" stroke="#e28a7f" stroke-width="3.4"/>' : ''}${Array.from({ length: u.level > 1 ? u.level : 0 }, (_, i) => `<circle cx="${(i - (u.level - 1) / 2) * 8}" cy="28" r="2.8" fill="${c}"/>`).join('')}${defense || selected ? tag(label, 0, 42, selected, !selected) : ''}</g>`
        )
      );
    }
  }
  if (S.mapLayer === 'defense' && defenseSite && defenseSite.tool === S.military?.tool) {
    const [x, y] = worldToSvg(defenseSite.x, defenseSite.z);
    parts.push(`<circle class="tactical-placement" cx="${x}" cy="${y}" r="14" fill="#56dd9e55" stroke="#b2ffcf" stroke-width="3" pointer-events="none"/>`);
  }
  return `<g class="vector-military">${parts.join('')}</g>`;
}
export function renderVectorMap(S, CITIES, defenseSite = null) {
  const key = S.tab === 'site' ? 'industry' : countryViewKey(S);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 600" style="background:${['atlas', 'offshore', 'hub:port'].includes(key) ? '#347e8c' : '#adc0b0'}" class="vector-world ${S.mapTime === 'night' ? 'night' : ''}" aria-label="نمای ایزومتریک تعاملی" role="group">${key === 'industry' ? campus(S) : key === 'atlas' ? atlas(S) + militarySvg(S, defenseSite) : key === 'offshore' || key === 'hub:port' ? marine(S, key === 'hub:port') : lotMap(S, CITIES)}</svg>`;
}
export function createVectorScene(host, key, onSelect) {
  let node = host,
    callback = onSelect,
    signature = '',
    zoom = 1,
    pan = { x: 0, y: 0 },
    userOn = null,
    down = null,
    lastState;
  const on = () => userOn ?? !!node.closest?.('.atlas-expanded');
  const view = () => {
    const svg = node.querySelector('svg');
    svg?.classList.toggle('map-near', zoom > 1.2);
    svg?.setAttribute(
      'viewBox',
      `${450 - 450 / zoom + pan.x} ${300 - 300 / zoom + pan.y} ${900 / zoom} ${600 / zoom}`
    );
  };
  const worldAt = (e) => {
    const svg = node.querySelector('svg'),
      m = svg?.getScreenCTM?.();
    if (!m || !svg.createSVGPoint) return null;
    const pt = svg.createSVGPoint();
    pt.x = e.clientX;
    pt.y = e.clientY;
    const q = pt.matrixTransform(m.inverse());
    return svgToWorld(q.x, q.y);
  };
  const choose = (e) => {
    if (lastState?.military?.tool && lastState.mapLayer === 'defense' && key === 'atlas' && e.type === 'click' && e.detail !== 0) {
      const w = worldAt(e);
      if (w) {
        callback({ kind: 'ground', x: w.x, z: w.z });
        return;
      }
    }
    const g = e.target.closest?.('[data-map-kind]');
    if (!g) return;
    if (e.type === 'keydown' && !['Enter', ' '].includes(e.key)) return;
    if (e.type === 'keydown') e.preventDefault();
    callback({
      kind: g.dataset.mapKind,
      id: ['lot', 'city-lot', 'unit', 'mil'].includes(g.dataset.mapKind)
        ? Number(g.dataset.mapId)
        : g.dataset.mapId
    });
  };
  const pointerDown = (e) => {
    if (down && !down.released) {
      down.moved = true;
      return;
    }
    down = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y, target: e.target, moved: false };
    if (on()) node.setPointerCapture?.(e.pointerId);
  };
  const pointerMove = (e) => {
    if (!down) return;
    if (Math.hypot(e.clientX - down.x, e.clientY - down.y) > 7) down.moved = true;
    if (!on()) return;
    pan.x = down.px - ((e.clientX - down.x) * 900) / node.clientWidth / zoom;
    pan.y = down.py - ((e.clientY - down.y) * 600) / node.clientHeight / zoom;
    view();
  };
  const pointerUp = (e) => {
    if (down) {
      if (Math.hypot(e.clientX - down.x, e.clientY - down.y) > 7) down.moved = true;
      down.released = true;
    }
  };
  const click = (e) => {
    const valid = down && !down.moved;
    down = null;
    if (e.detail === 0 || valid) choose(e);
  };
  const wheel = (e) => {
    if (!on()) return;
    e.preventDefault();
    zoom = Math.max(0.65, Math.min(3.5, zoom * (e.deltaY < 0 ? 1.15 : 0.87)));
    view();
  };
  const bind = (n) => {
    n.addEventListener('pointerdown', pointerDown);
    n.addEventListener('pointermove', pointerMove);
    n.addEventListener('pointerup', pointerUp);
    n.addEventListener('click', click);
    n.addEventListener('pointercancel', cancel);
    n.addEventListener('keydown', choose);
    n.addEventListener('wheel', wheel, { passive: false });
  };
  const cancel = () => {
    down = null;
  };
  const unbind = (n) => {
    n.removeEventListener('pointerdown', pointerDown);
    n.removeEventListener('pointermove', pointerMove);
    n.removeEventListener('pointerup', pointerUp);
    n.removeEventListener('click', click);
    n.removeEventListener('pointercancel', cancel);
    n.removeEventListener('keydown', choose);
    n.removeEventListener('wheel', wheel);
  };
  bind(node);
  return {
    key,
    renderer: 'vector',
    attach(n, f) {
      callback = f;
      if (node !== n) {
        unbind(node);
        node = n;
        signature = '';
        bind(node);
      }
      node.dataset.renderer = 'vector';
      node.style.touchAction = on() ? 'none' : 'pan-y';
      const button = document.querySelector('[data-a="atlas-camera"][data-k="toggle"]');
      if (button) {
        button.setAttribute('aria-pressed', String(on()));
        button.textContent = on() ? 'پایان کنترل دوربین' : 'کنترل دوربین';
      }
    },
    update(S, CITIES, defenseSite) {
      lastState = S;
      const next = sceneSignature(S, CITIES) + JSON.stringify(defenseSite ?? null);
      if (next !== signature) {
        const focus = node.querySelector(':focus')?.dataset.mapId;
        signature = next;
        node.innerHTML = renderVectorMap(S, CITIES, defenseSite);
        view();
        if (focus != null) node.querySelector(`[data-map-id="${focus}"]`)?.focus({ preventScroll: true });
      }
    },
    cameraAction(command) {
      if (command === 'toggle') {
        userOn = !on();
        node.style.touchAction = on() ? 'none' : 'pan-y';
        const b = document.querySelector('[data-a="atlas-camera"][data-k="toggle"]');
        if (b) {
          b.setAttribute('aria-pressed', String(on()));
          b.textContent = on() ? 'پایان کنترل دوربین' : 'کنترل دوربین';
        }
      } else if (command === 'reset') {
        zoom = 1;
        pan = { x: 0, y: 0 };
      } else if (command === 'focus') {
        const id = lastState?.atlasSelected || 'capital';
        const selected = (lastState?.mapLayer === 'defense' && lastState.military?.units?.find(u => u.id === lastState.military.sel))
          || DISTRICTS.find(d => d.id === id);
        if (key === 'atlas' && selected) {
          const [x, y] = districtPoint(selected);
          zoom = 1.7;
          pan = { x: x - 450, y: y - 300 };
        } else {
          const id = key.startsWith('industry:')
              ? lastState?.siteSelectedUnit
              : lastState?.cityView != null
                ? lastState?.cityCell
                : lastState?.sel,
            g = node.querySelector(`[data-map-id="${id}"]`);
          if (g) {
            const box = g.getBBox();
            zoom = 2;
            pan = { x: box.x + box.width / 2 - 450, y: box.y + box.height / 2 - 300 };
          }
        }
      } else zoom = Math.max(0.65, Math.min(3.5, zoom * (command === 'in' ? 1.2 : 1 / 1.2)));
      view();
    },
    dispose() {
      unbind(node);
      node.innerHTML = '';
    }
  };
}
