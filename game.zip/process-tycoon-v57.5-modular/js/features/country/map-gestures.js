// حرکت و زوم نقشه با موس و لمس.
import { CELL, GH, GW } from '../../data/catalog.js';
import { cl } from '../../core/format.js';
export function installMapGestures(game) {
  const { S, save } = game;
  const nightI = () => {
    const p = (Date.now() / 1000 % 90) / 90, d = Math.abs(p - .8);
    return d < .2 ? (1 - d / .2) * .55 : 0;
  };
  function nightUpdate() {
    const n = document.getElementById('night'), sv = document.getElementById('cmap'), I = nightI();
    if (n)
      n.setAttribute('opacity', I.toFixed(2));
    if (sv)
      sv.classList.toggle('night', I > .2);
  }
  function camApply() {
    const g = document.getElementById('cam');
    if (g)
      g.setAttribute('transform', `translate(${S.cam.x} ${S.cam.y}) scale(${S.cam.k})`);
  }
  const mp = new Map();
  let mg = null;
  let mapMoved = 0;
  const unitK = () => {
    const sv = document.getElementById('cmap');
    return sv ? GW * CELL / sv.getBoundingClientRect().width : 1;
  };
  function clampCam() {
    const c = S.cam;
    c.k = cl(c.k, 1, 3.5);
    c.x = cl(c.x, GW * CELL * (1 - c.k), 0);
    c.y = cl(c.y, GH * CELL * (1 - c.k), 0);
  }
  function zoomAt(f, px, py) {
    const c = S.cam, k = cl(c.k * f, 1, 3.5), r = k / c.k;
    c.x = px - (px - c.x) * r;
    c.y = py - (py - c.y) * r;
    c.k = k;
    clampCam();
    camApply();
  }
  const toV = (e) => {
    const sv = document.getElementById('cmap'), r = sv.getBoundingClientRect(), u = GW * CELL / r.width;
    return [(e.clientX - r.left) * u, (e.clientY - r.top) * u];
  };
  document.addEventListener('pointerdown', e => {
    if (!e.target.closest || !e.target.closest('#mapbox') || e.target.closest('button'))
      return;
    mp.set(e.pointerId, [e.clientX, e.clientY]);
    mg = { x: e.clientX, y: e.clientY, cx: S.cam.x, cy: S.cam.y };
  }, true);
  document.addEventListener('pointermove', e => {
    if (!mp.has(e.pointerId))
      return;
    const o = mp.get(e.pointerId);
    if (mp.size === 2) {
      const n = [...mp.entries()], other = n.find(([id]) => id !== e.pointerId)[1], d0 = Math.hypot(o[0] - other[0], o[1] - other[1]);
      mp.set(e.pointerId, [e.clientX, e.clientY]);
      const d1 = Math.hypot(e.clientX - other[0], e.clientY - other[1]);
      if (d0 > 0) {
        const [vx, vy] = toV({ clientX: (e.clientX + other[0]) / 2, clientY: (e.clientY + other[1]) / 2 });
        zoomAt(d1 / d0, vx, vy);
      }
      mapMoved = Date.now();
      return;
    }
    mp.set(e.pointerId, [e.clientX, e.clientY]);
    if (!mg)
      return;
    const u = unitK(), dx = e.clientX - mg.x, dy = e.clientY - mg.y;
    if (Math.hypot(dx, dy) > 8 || Date.now() - mapMoved < 300) {
      mapMoved = Date.now();
      S.cam.x = mg.cx + dx * u;
      S.cam.y = mg.cy + dy * u;
      clampCam();
      camApply();
    }
  });
  const mUp = e => {
    if (mp.delete(e.pointerId) && !mp.size) {
      mg = null;
      save();
    }
  };
  document.addEventListener('pointerup', mUp);
  document.addEventListener('pointercancel', mUp);
  document.addEventListener('wheel', e => {
    if (!e.target.closest || !e.target.closest('#mapbox'))
      return;
    e.preventDefault();
    const [vx, vy] = toV(e);
    zoomAt(e.deltaY > 0 ? .87 : 1.15, vx, vy);
  }, { passive: false });
  Object.assign(game, { camApply, mapMoved, nightUpdate, zoomAt });
}
