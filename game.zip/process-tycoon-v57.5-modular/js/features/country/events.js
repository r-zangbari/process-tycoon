// رویدادهای DOM نقشه‌ی کشور (انتخاب میدان، سلول شهر).
import { CITIES } from '../../data/world-map.js';
export function installCountryEvents(game) {
  const { S, save } = game;
  document.addEventListener('click', e => {
    const field = e.target.closest && e.target.closest('[data-offshore-select]');
    if (field && S.tab === 'c' && S.offshoreView) {
      S.offshoreMapSelected = field.dataset.offshoreSelect === 'gas' ? 'gas' : 'oil';
      game.draw();
      save();
      return;
    }
    const marine = e.target.closest && e.target.closest('[data-offshore-country]');
    if (marine && S.tab === 'c' && !S.offshoreView) {
      game.actions['offshore-country-select']({ p: marine.dataset.offshoreCountry });
      game.draw();
      save();
      return;
    }
    const cityCell = e.target.closest && e.target.closest('[data-city-cell]');
    if (cityCell && S.cityView != null) {
      S.cityCell = Number(cityCell.dataset.cityCell);
      game.ui.cityMoveCell = null;
      game.draw();
      save();
      return;
    }
    const city = e.target.closest && e.target.closest('[data-city]');
    if (city && Date.now() - game.mapMoved > 300) {
      const i = Number(city.dataset.city);
      if (Number.isInteger(i) && CITIES[i]) {
        S.citySelected = i;
        S.sel = null;
        game.draw();
        save();
      }
      return;
    }
    const t = e.target.closest && e.target.closest('[data-c]');
    if (t && Date.now() - game.mapMoved > 300) {
      S.citySelected = null;
      S.sel = +t.dataset.c;
      game.draw();
      save();
    }
  });
  document.addEventListener('keydown', e => {
    if (e.key !== 'Enter' && e.key !== ' ')
      return;
    const target = e.target.closest?.('[data-city-cell],[data-offshore-select],[data-offshore-country]');
    if (target) {
      e.preventDefault();
      target.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    }
  });
}
