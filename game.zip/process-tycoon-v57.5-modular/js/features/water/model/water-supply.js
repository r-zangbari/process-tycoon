import { regionalDisruption } from '../../country/model/region-disruption.js';

// Game-scale water catchments. Quantities use the catalog's thousand m³ unit.
export const WATER_SOURCES = {
  groundwater: {
    name: 'آب زیرزمینی', location: 'آبخوان غربی', capacity: 30, cost: .22, power: .008, build: 650, line: 250, days: 2, description: 'چاه ارزان؛ برداشت از ذخیره محدود آبخوان با تغذیه آهسته.'
  },
  surface: {
    name: 'آب سطحی', location: 'حوضه آبریز شمال', capacity: 55, cost: .14, power: .005, build: 1100, line: 350, days: 3, description: 'برداشت رودخانه؛ ظرفیت و تغذیه در تابستان کمتر است.'
  },
  reclaimed: {
    name: 'بازچرخانی پساب', location: 'مرکز بازچرخانی شهری', capacity: 45, cost: .18, power: .012, build: 1300, line: 300, days: 3, description: 'پیش‌تصفیه فاضلاب جمع‌آوری‌شده از مصرف واقعی آب شهری روزهای قبل.'
  },
  desal: {
    name: 'شیرین‌سازی آب دریا', location: 'ساحل جنوبی', capacity: 100, cost: .95, power: .08, build: 4800, line: 700, days: 5, description: 'آب صنعتی شیرین‌شده؛ هزینه و برق بیشتر، بدون محدودیت آبخوان یا رودخانه.'
  }
};
export const COASTAL_BUFFER = { cost: 900, capacity: 120, dailyTransfer: 45 };
const keys = Object.keys(WATER_SOURCES), cl = (v, a, b) => Math.max(a, Math.min(b, Number(v) || 0)), finite = (v, f) => Number.isFinite(Number(v)) ? Number(v) : f;
export function waterNetwork(S) {
  const a = S.waterSupply || {}, sources = {};
  for (const k of keys) {
    const v = a.sources?.[k] || {};
    sources[k] = {
      level: Math.floor(cl(v.level, 0, 3)), project: Math.floor(cl(v.project, 0, 20)), connected: !!v.connected, enabled: v.enabled !== false, target: cl(finite(v.target, 1), 0, 1)
    };
  }
  return {
    reserve: Math.max(0, finite(a.reserve, 1000)), sources, ground: cl(finite(a.ground, 1200), 0, 1200), surface: cl(finite(a.surface, 1800), 0, 1800), sewage: cl(a.sewage, 0, 300), lastDay: a.lastDay, collectionDay: a.collectionDay, collection: a.collection || null, today: a.today || null, coastal: {
      built: !!a.coastal?.built, release: a.coastal?.release !== false, stock: a.coastal?.built ? cl(a.coastal.stock, 0, COASTAL_BUFFER.capacity) : 0
    }
  };
}
export function waterSeason(S) {
  return [1.05, .45, .8, .9][Math.floor(((Math.max(1, Number(S.day) || 1) - 1) % 360) / 90)];
}
export function waterAction(S, key, action) {
  if (!Object.hasOwn(WATER_SOURCES, key))
    return false;
  const w = waterNetwork(S), a = w.sources[key], d = WATER_SOURCES[key];
  let amount = 0;
  if (key === 'desal' && action === 'buffer-build') {
    if (!a.level || !a.connected || w.coastal.built || S.money < COASTAL_BUFFER.cost)
      return false;
    S.money -= COASTAL_BUFFER.cost;
    w.coastal.built = true;
    S.waterSupply = w;
    return true;
  }
  if (key === 'desal' && action === 'buffer-toggle') {
    if (!w.coastal.built)
      return false;
    w.coastal.release = !w.coastal.release;
    S.waterSupply = w;
    return true;
  }
  if (action === 'build' && !a.level && !a.project) {
    amount = d.build;
    if (S.money < amount)
      return false;
    a.project = d.days;
  }
  else if (action === 'connect' && a.level && !a.connected && !a.project) {
    amount = d.line;
    if (S.money < amount)
      return false;
    a.connected = true;
  }
  else if (action === 'upgrade' && a.level > 0 && a.level < 3 && !a.project) {
    amount = d.build * a.level * .8;
    if (S.money < amount)
      return false;
    a.project = d.days;
  }
  else if (action === 'toggle' && a.level && a.connected && !a.project)
    a.enabled = !a.enabled;
  else if (action === 'target' && a.level)
    a.target = a.target >= 1 ? .5 : a.target >= .5 ? 0 : 1;
  else
    return false;
  S.money -= amount;
  S.waterSupply = w;
  return true;
}
export function simulateWaterDay(S, { cap }) {
  const w = waterNetwork(S);
  if (w.lastDay === S.day)
    return w.today;
  w.lastDay = S.day;
  w.ground = Math.min(1200, w.ground + 10);
  w.surface = Math.min(1800, w.surface + 40 * waterSeason(S));
  const day = {
    day: S.day, quantity: 0, cost: 0, power: 0, sources: {}, coastalStored: 0, coastalDelivered: 0, coastalStatus: 'مخزن ساحلی ساخته نشده'
  };
  const coast = w.coastal, coastalReady = w.sources.desal.connected && coast.built;
  if (coast.built)
    day.coastalStatus = !coast.release ? 'تحویل خودکار متوقف است' : !coastalReady ? 'خط ساحل وصل نیست' : 'ذخیره اولیه خالی است';
  if (coastalReady && coast.release) {
    const free = Math.max(0, cap('rawwater') - (S.tanks.rawwater || 0));
    const transfer = COASTAL_BUFFER.dailyTransfer * regionalDisruption(S, 'water-desal').factor;
    day.coastalCapacity = transfer;
    day.coastalDelivered = Math.min(coast.stock, transfer, free);
    if (coast.stock > 0)
      day.coastalStatus = free <= 0 ? 'مخزن خشکی پر است' : day.coastalDelivered < coast.stock ? free < transfer ? 'فضای مخزن خشکی محدود است' : 'سقف انتقال روزانه رسید' : 'ذخیره قابل تحویل منتقل شد';
    if (transfer < COASTAL_BUFFER.dailyTransfer && coast.stock > 0) day.coastalStatus += ' · اختلال ساحلی';
    coast.stock -= day.coastalDelivered;
    S.tanks.rawwater = (S.tanks.rawwater || 0) + day.coastalDelivered;
  }
  for (const k of ['surface', 'reclaimed', 'groundwater', 'desal']) {
    const a = w.sources[k], d = WATER_SOURCES[k], report = day.sources[k] = { quantity: 0, cost: 0, power: 0, status: 'ساخته نشده' };
    if (a.project > 0) {
      a.project--;
      report.status = 'ساخت / ارتقا در جریان';
      if (a.project === 0) {
        a.level = Math.min(3, a.level + 1);
        report.status = a.connected ? 'تکمیل شد؛ تولید از روز بعد' : 'ساخت تکمیل شد؛ خط انتقال را وصل کن';
      }
      continue;
    }
    if (!a.level)
      continue;
    if (!a.connected) {
      report.status = 'خط انتقال وصل نیست';
      continue;
    }
    if (!a.enabled || a.target === 0) {
      report.status = 'متوقف توسط بازیکن';
      continue;
    }
    const region = regionalDisruption(S, 'water-' + k);
    const requested = d.capacity * a.level * a.target * region.factor * (k === 'surface' ? waterSeason(S) : 1), free = Math.max(0, cap('rawwater') - (S.tanks.rawwater || 0)), available = k === 'groundwater' ? w.ground : k === 'surface' ? w.surface : k === 'reclaimed' ? w.sewage * .75 : Infinity, power = Math.max(0, S.tanks.power || 0) / d.power, budget = Math.max(0, S.money - w.reserve) / d.cost;
    const reserveSpace = k === 'desal' && coastalReady ? COASTAL_BUFFER.capacity - coast.stock : 0;
    const qty = Math.max(0, Math.min(requested, free + reserveSpace, available, power, budget));
    report.status = free + reserveSpace <= 0 ? 'مخزن آب خام پر است' : available <= 0 ? k === 'reclaimed' ? 'پساب جمع‌آوری‌شده موجود نیست' : 'ذخیره منبع به پایان رسیده' : power <= 0 ? 'برق مخزن کافی نیست' : budget <= 0 ? 'ذخیره نقد مانع هزینه بهره‌برداری است' : qty + 1e-6 < requested ? 'تولید محدود به مخزن، منبع، برق یا نقد' : 'در حال تأمین';
    if (region.factor < 1) report.status += ' · اختلال منطقه‌ای';
    if (qty <= 0)
      continue;
    const cost = qty * d.cost, energy = qty * d.power, stored = Math.max(0, qty - free);
    S.tanks.rawwater = (S.tanks.rawwater || 0) + qty - stored;
    coast.stock += stored;
    day.coastalStored += stored;
    S.tanks.power = Math.max(0, (S.tanks.power || 0) - energy);
    S.money -= cost;
    if (k === 'groundwater')
      w.ground -= qty;
    if (k === 'surface')
      w.surface -= qty;
    if (k === 'reclaimed')
      w.sewage = Math.max(0, w.sewage - qty / .75);
    report.quantity = qty;
    report.cost = cost;
    report.power = energy;
    day.quantity += qty;
    day.cost += cost;
    day.power += energy;
  }
  S.pd ||= {};
  S.cs ||= {};
  S.pd.rawwater = (S.pd.rawwater || 0) + day.quantity - day.coastalStored + day.coastalDelivered;
  S.cs.power = (S.cs.power || 0) + day.power;
  w.today = day;
  S.waterSupply = w;
  return day;
}
export function collectUrbanWastewater(S, { urbanDemand = 0, housingDemand = 0, deliveryRatio = 0 } = {}) {
  const w = waterNetwork(S);
  if (w.collectionDay === S.day)
    return 0;
  w.collectionDay = S.day;
  const delivered = Math.max(0, urbanDemand + housingDemand) * cl(deliveryRatio, 0, 1), generated = delivered * .6, limit = w.sources.reclaimed.level ? 300 : 0, accepted = Math.max(0, Math.min(generated, limit - w.sewage));
  w.sewage += accepted;
  w.collection = { day: S.day, delivered, generated, accepted };
  S.waterSupply = w;
  return accepted;
}
