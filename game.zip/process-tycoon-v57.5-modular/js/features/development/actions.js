// اکشن‌های توسعه‌ی کشور.
import { acceptDevelopment, prepareStoryCrisis } from './model/development.js';
import { PR } from '../../data/catalog.js';
export function installDevelopmentActions(game) {
  const { S, log } = game;
  Object.assign(game.actions, {
    'dev-open'() {
      S.tab = 'm';
      S.manageSection = 'development';
    },
    'dev-accept'(x) {
      acceptDevelopment(S, x.k);
    },
    'dev-prepare'() {
      if (prepareStoryCrisis(S))
        log('خدمات جایگزین بحران داستانی رزرو شد.');
    },
    'dev-project'(x) {
      const t = Number(x.i);
      if (t !== 1 && t !== 13)
        return;
      S.tab = 'i';
      S.industrySection = 'catalog';
      S.projectType = t;
    },
    'dev-stock'(x) {
      S.tab = 'm';
      S.manageSection = 'inventory';
      if (Object.hasOwn(PR, x.k || '')) {
        S.marketProduct = x.k;
        S.marketFilter = 'all';
        S.marketPage = Math.floor(Object.keys(PR).indexOf(x.k) / 12);
      }
    },
  });
}
