// Contracts measure delivery after the regular country settlement.
export const DEVELOPMENT = {
  water: { title: 'آب پایدار برای شهر', project: 1, output: 36, reward: 850 },
  power: { title: 'برق پایدار برای شهر', project: 13, output: 90, reward: 1050 }
};
const daysRequired = 5;
export function developmentState(S) {
  if (!S.development || typeof S.development !== 'object' || Array.isArray(S.development))
    S.development = { offers: {}, productiveDays: 0, lastDelivery: 0, lastCrisisDay: 0 };
  return S.development;
}
export function developmentSummary(S) {
  const state = S.development || {}, offers = state.offers || {};
  return Object.entries(DEVELOPMENT).map(([key, def]) => {
    const demand = Math.max(0, S.dem?.[key] || 0);
    const delivered = demand * Math.max(0, Math.min(1, S.fr?.[key] || 0));
    return {
      key, ...def, demand, delivered, shortage: demand - delivered,
      status: offers[key]?.status || 'waiting', streak: offers[key]?.streak || 0, daysRequired
    };
  });
}
export function acceptDevelopment(S, key) {
  if (!Object.hasOwn(DEVELOPMENT, key))
    return false;
  const d = developmentState(S), offer = d.offers?.[key];
  if (offer?.status !== 'offered')
    return false;
  offer.status = 'active';
  offer.acceptedDay = S.day;
  return true;
}
export function settleDevelopment(S, log = () => { }) {
  const d = developmentState(S);
  if (d.lastDelivery === S.day)
    return;
  d.lastDelivery = S.day;
  const producing = (S.u || []).some(u => u.dayEconomics?.day === S.day && u.dayEconomics.products?.some(p => p.accepted > 0));
  if (producing)
    d.productiveDays = (d.productiveDays || 0) + 1;
  d.offers ??= {};
  for (const info of developmentSummary(S)) {
    const { key, demand, delivered, status, daysRequired, title, reward } = info;
    if (status === 'waiting' && d.productiveDays > 0 && demand > 0 && info.shortage > demand * .05 && !Object.values(d.offers).some(o => ['offered', 'active'].includes(o.status))) {
      d.offers[key] = { status: 'offered', streak: 0 };
      log('فرصت توسعهٔ کشور: ' + title);
    }
    if (status !== 'active')
      continue;
    const offer = d.offers[key];
    if (offer.acceptedDay >= S.day)
      continue;
    offer.streak = demand > 0 && delivered >= demand * .95 ? (offer.streak || 0) + 1 : 0;
    if (offer.streak < daysRequired)
      continue;
    offer.status = 'complete';
    offer.completedDay = S.day;
    S.govBudget = (S.govBudget || 0) + reward;
    S.network ??= {};
    S.network[key] = Math.min(4, (S.network[key] || 0) + 1);
    log('قرارداد «' + title + '» تکمیل شد؛ شبکه تقویت شد و کمک توسعه به بودجه عمومی رسید.');
  }
}
export function advanceStoryCrisis(S, roll = Math.random, log = () => { }) {
  const existing = S.development;
  if (!existing)
    return;
  const d = existing;
  if (d.event?.endDay <= S.day) {
    log('بحران داستانی پایان یافت؛ ظرفیت به وضعیت عادی برگشت.');
    d.event = null;
    d.lastCrisisDay = S.day;
  }
  if (d.event?.startDay === S.day)
    log('بحران داستانی آغاز شد؛ ظرفیت عملیاتی را بررسی کن.');
  if (d.event || S.day < 22 || d.productiveDays < 5 || !(S.u || []).some(u => u.st === 'run'))
    return;
  if (d.lastCrisisDay && (S.day - d.lastCrisisDay < 18 || roll() >= .16))
    return;
  const type = (d.crisisCount || 0) % 2 === 0 ? 'port' : 'industry';
  d.crisisCount = (d.crisisCount || 0) + 1;
  d.event = { type, startDay: S.day + 3, endDay: S.day + 6, prepared: false };
  log(type === 'port' ? 'هشدار داستانی: سه روز تا احتمال اختلال تجاری ساحل.' : 'هشدار داستانی: سه روز تا اختلال خدمات صنعتی.');
}
export function prepareStoryCrisis(S) {
  const event = S.development?.event;
  if (!event || event.prepared || S.day >= event.endDay || S.money < 280)
    return false;
  S.money -= 280;
  event.prepared = true;
  return true;
}
export function storyFactor(S, type) {
  const event = S.development?.event;
  if (event?.type !== type || S.day < event.startDay || S.day >= event.endDay)
    return 1;
  const alternateRoute = type === 'port' && S.port >= 80;
  if (event.prepared || alternateRoute)
    return .9;
  return type === 'port' ? .65 : .82;
}
