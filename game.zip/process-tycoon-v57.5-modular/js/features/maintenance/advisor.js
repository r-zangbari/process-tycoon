// مشاور بحران، تشخیص مشکل واحد و نگهداری خودکار.
import { D, OPN, PR } from '../../data/catalog.js';
import { recommendations } from './model/unit-diagnostics.js';
import { renderAdvisorReport, renderRecommendation } from './view/crisis-advisor.js';
import { highlightNavigationTarget } from '../../ui-kit/navigation-highlight.js';
import { normalizeMaintenance, purchaseMaintenance } from './model/auto-maintenance.js';
import { nextProjectStep } from '../industry/model/project-progress.js';
export function installMaintenanceAdvisor(game) {
  const { S, log, pay, save } = game;
  Object.assign(game.actions, {
    adv() {
      if (!S.adv && pay(1000)) {
        S.adv = 1;
        log('مشاور بحران استخدام شد.');
      }
    },
  });
  function diagnosticContext() {
    return { D, PR, OPN };
  }
  function advice() {
    return recommendations(S, diagnosticContext());
  }
  function advCard() {
    const data = advice();
    return `<section id="crisis-advisor" class="card wide advisor"><h2>مشاور بحران و علت زیان</h2>${!S.adv ? `<p>تشخیص اولیه و مسیر رسیدگی در «اقدام پیشنهادی» نمایش داده می‌شود. مشاور، ریز تسویه و راه رفع همه واحدهای زیان‌ده را یکجا بررسی می‌کند.</p><button class="p" data-a="adv">استخدام مشاور (۱٬۰۰۰ · حقوق ۱۵ در روز)</button>` : `<p>علت‌ها از داده ثبت‌شده همان واحد استخراج می‌شوند. ابتدا مسئله ایمنی و تولید، سپس فروش و هزینه را بررسی کن.</p>${data.items.length ? data.items.slice(0, 5).map(r => renderRecommendation(r)).join('') : '<p class="ok">در داده‌های موجود مشکل فوری شناسایی نشد.</p>'}<h3>گزارش واحدهای زیان‌ده</h3>${data.reports.filter(r => r.loss).map((r, i) => renderAdvisorReport(r, S, PR, i === 0 || S.advisorUnit === r.index)).join('') || '<p>واحد در سرویس با نتیجه منفی ثبت نشده است.</p>'}<p class="muted">حقوق مهندسان و نیروی مازاد، هزینه مشاور، بهره وام، جرایم و انتقال به بودجه عمومی هزینه‌های مشترک شرکت‌اند و در سود هر واحد تخصیص داده نشده‌اند. تشخیص واحد، تضمین سود نقد کل شرکت نیست.</p>`}</section>`;
  }
  game.clickHandlers.push((e, b, x, i, a) => {
    if (a.startsWith('maintenance-')) {
      handleMaintenanceAction(a, x);
      return true;
    }
    if (a === 'diagnostic-go') {
      navigateDiagnostic(x);
      return true;
    }
    return false;
  });
  // Native button click supports Enter/Space without synthetic pointer events.
  function navigateDiagnostic(x) {
    if (x.target === 'development') {
      S.tab = 'm';
      S.manageSection = 'development';
      game.draw();
      save();
      game.scrollMarketTo(document.getElementById('development-contracts'));
      return;
    }
    const target = x.target, raw = Number(x.i), index = x.i !== undefined && x.i !== '' && Number.isInteger(raw) && S.u[raw] ? raw : null;
    let anchor = '';
    if (target === 'time' && S.cr) {
      log('پیش از ثبت روز تازه، بحران فعال را تعیین تکلیف کن.');
      S.tab = 'i';
      game.draw();
      save();
      document.getElementById('app')?.scrollIntoView({ block: 'start' });
      return;
    }
    if (target === 'time') {
      S.diagnosticPauseDay = S.day + 1;
      S.paused = false;
      game.clock?.resetElapsed();
      game.draw();
      save();
      return;
    }
    const projectStep = index == null ? null : nextProjectStep(S.u[index], D[S.u[index].t]);
    if (target === 'controls' && index != null && !projectStep) {
      S.tab = 'hmi';
      S.hmiUnit = index;
      S.hmiMode = 'advanced';
      S.hmiSection = 'controls';
      anchor = 'hmi-unit-select';
    }
    else if ((target === 'unit' || target === 'project' || target === 'controls') && index != null) {
      S.tab = 'i';
      S.industrySection = ['build', 'ready'].includes(S.u[index]?.st) ? 'projects' : 'operations';
      S.flt = 'all';
      S.expandedUnit = index;
      anchor = 'u' + index;
    }
    else if (target === 'personnel') {
      S.tab = 'i';
      anchor = 'personnel-management';
    }
    else if (target === 'crisis') {
      S.tab = 'i';
      anchor = 'app';
    }
    else if (target === 'advisor') {
      S.tab = 'm';
      S.manageSection = 'overview';
      S.advisorUnit = index;
      anchor = index != null && S.adv ? 'advisor-unit-' + index : 'crisis-advisor';
    }
    else {
      S.tab = 'm';
      S.manageSection = ({
        finance: 'finance', trade: 'trade', research: 'research', maintenance: 'maintenance', offshore: 'fields'
      })[target] || 'inventory';
      anchor = target === 'maintenance' && index != null ? 'maintenance-unit-' + index : target === 'finance' ? 'company-finance' : x.p ? 'product-' + x.p : 'app';
    }
    if (x.p && Object.hasOwn(PR, x.p)) {
      S.marketProduct = x.p;
      S.marketFilter = 'all';
      S.marketPage = Math.floor(Object.keys(PR).indexOf(x.p) / 12);
    }
    game.draw();
    save();
    const el = document.getElementById(anchor);
    if (target === 'advisor' && el?.tagName === 'DETAILS')
      el.open = true;
    const destination = projectStep && el?.id === 'u' + index
      ? el.querySelector(projectStep.selector) || el
      : el;
    destination?.scrollIntoView({ block: 'center', behavior: 'auto' });
    if (destination) {
      highlightNavigationTarget(destination);
      destination.focus?.({ preventScroll: true });
    }
  }
  function handleMaintenanceAction(action, x) {
    if (action === 'maintenance-filter') {
      S.maintenanceFilter = ['all', 'attention', 'enabled', 'unowned'].includes(x.k) ? x.k : 'all';
      game.draw();
      save();
      return;
    }
    if (action === 'maintenance-center') {
      S.tab = 'm';
      S.manageSection = 'maintenance';
      game.draw();
      save();
      document.getElementById('maintenance-fleet')?.scrollIntoView({ block: 'start' });
      return;
    }
    const i = Number(x.i), u = S.u[i], d = u && D[u.t];
    if (!u || !d)
      return;
    if (action === 'maintenance-open') {
      S.tab = 'i';
      S.industrySection = ['build', 'ready'].includes(S.u[i]?.st) ? 'projects' : 'operations';
      S.expandedUnit = i;
      S.flt = 'all';
      game.draw();
      save();
      document.getElementById('maintenance-unit-' + i)?.scrollIntoView({ block: 'center' });
      return;
    }
    const m = normalizeMaintenance(u, d);
    if (action === 'maintenance-buy') {
      if (purchaseMaintenance(S, i, D))
        log('مجوز نگهداری خودکار «' + d.n + '» خریداری و فعال شد؛ قطعه و تعمیر هزینه جدا دارند.');
      else
        log(m.owned ? 'این واحد قبلاً مجوز دارد.' : 'نقد کافی یا شرایط خرید مجوز فراهم نیست.');
    }
    else if (m.owned) {
      if (action === 'maintenance-toggle') {
        m.enabled = !m.enabled;
        m.status = m.enabled ? 'فعال؛ ارزیابی روز بعد' : 'غیرفعال شده توسط بازیکن';
        log('نگهداری خودکار «' + d.n + '» ' + (m.enabled ? 'فعال' : 'غیرفعال') + ' شد.');
      }
      if (action === 'maintenance-restart')
        m.restart = !m.restart;
      if (action === 'maintenance-shipping') {
        const modes = ['smart', 'normal', 'urgent'];
        m.shipping = modes[(modes.indexOf(m.shipping) + 1) % 3];
      }
      if (action === 'maintenance-reserve') {
        const reserves = [0, 1000, 5000];
        m.reserve = reserves[(reserves.indexOf(m.reserve) + 1) % 3];
      }
      if (action === 'maintenance-limit')
        m.limitMultiplier = (m.limitMultiplier || 1) % 3 + 1;
    }
    game.draw();
    save();
  }
  Object.assign(game, { advCard, advice, navigateDiagnostic });
}
