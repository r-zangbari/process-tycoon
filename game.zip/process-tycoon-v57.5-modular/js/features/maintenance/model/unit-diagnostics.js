import { hasEquipmentFaults } from './unit-recovery.js';
import { nextProjectStep } from '../../industry/model/project-progress.js';
const finite = v => Number.isFinite(v) ? v : 0;
const num = v => finite(v).toLocaleString('fa-IR', { maximumFractionDigits: 1 });
const issue = (code, priority, title, evidence, fix, target, index, product) => ({ code, priority, title, evidence, fix, target, index, product });
export function analyzeUnit(S, index, { D, PR, OPN = [] }) {
  const u = S.u[index], d = D[u.t], running = u.st === 'run',
    ledger = running && u.dayEconomics?.day === S.day ? u.dayEconomics : null, causes = [];
  if (nextProjectStep(u, d))
    return { index, name: d.n, ledger: null, causes, loss: false, recovering: false };
  const push = (code, priority, title, evidence, fix, target, product) => causes.push(issue(code, priority, title, evidence, fix, target, index, product));
  if (u.st === 'trip' || u.st === 'broken')
    push('trip', 110, 'واحد خارج از سرویس است', u.st === 'trip' ? 'حفاظت واحد عمل کرده است.' : hasEquipmentFaults(u) ? 'تجهیز اصلی یا رزرو خرابی ثبت‌شده دارد.' : 'خرابی تجهیز ثبت نشده است؛ واحد در انتظار تأیید بازگشت به سرویس مانده است.', u.st === 'broken' && !hasEquipmentFaults(u) ? 'در DCS موانع آمادگی را بررسی کن؛ اگر مانعی نیست «بازگشت به سرویس پس از بررسی» را بزن. تعمیر یا خرید قطعه اضافی لازم نیست.' : 'پیش از راه‌اندازی مجدد، آلارم، باز بودن مسیر و آماده بودن تجهیزات را بررسی و علت را رفع کن.', 'controls');
  if (u.processState?.valveOpen === false && (running || u.st === 'trip' || u.st === 'broken'))
    push('isolation', 108, 'شیر ورودی بسته است', 'XV-101 مسیر ورودی را ایزوله کرده است.', 'در DCS علت ایزوله‌سازی را بررسی کن؛ فقط پس از رفع علت و تأیید آماده‌بودن مسیر، فرمان مناسب را بده.', 'controls');
  (u.eq || []).forEach((e, j) => {
    if (e.f || e.reserve?.f) {
      const f = e.f || e.reserve.f;
      push('equipment-' + j, 109, 'خرابی ' + d.e[j][0], f.st === 0 ? 'قطعه هنوز سفارش نشده است.' : f.st === 1 ? 'قطعه در مسیر است؛ زمان رسیدن ' + num(f.eta) + ' روز.' : 'قطعه رسیده و تعمیر در انتظار اقدام است.', f.st === 0 ? 'در مدیریت واحد قطعه را سفارش بده و هزینه و زمان ارسال را بررسی کن.' : f.st === 1 ? 'تا رسیدن قطعه وضعیت رزرو و سلامت آن را پایش کن.' : 'در مدیریت واحد تعمیر تجهیز را تکمیل و سپس آماده‌بودن آن را بررسی کن.', u.maintenance?.owned && u.maintenance?.enabled ? 'maintenance' : 'unit');
    }
  });
  for (const [k, variable] of (running ? d.v : []).entries()) {
    const pv = u.v?.[k], span = variable[3];
    if (Number.isFinite(pv) && span > 0 && Math.abs(pv - variable[2]) / span > 1.3)
      push('deviation-' + k, Math.abs(pv - variable[2]) / span > 2.5 ? 106 : 90, 'انحراف ' + variable[0], `مقدار فعلی ${num(pv)} ${variable[1]}؛ هدف طراحی ${num(variable[2])}؛ نیم‌پهنای باند ${num(span)}.`, 'در DCS مقدار PV، هدف SP، حالت حلقه و علت اختلال را بررسی کن. جهت حرکت محرک را از نوع آن تعیین کن؛ فرمان افزایش یا کاهش کورکورانه پیشنهاد نمی‌شود.', 'controls');
  }
  if (ledger) {
    for (const feed of ledger.feeds) {
      if (feed.missing > .001) {
        const labels = [];
        if (feed.policyLimited)
          labels.push('محدودیت تنظیم خودکار خرید');
        if (feed.cashLimited)
          labels.push('محدودیت نقدینگی خرید');
        if (feed.portLimited)
          labels.push('محدودیت ظرفیت بندر');
        push('feed-' + feed.product, (feed.optional ? 82 : 94) + 4 * Math.min(1, feed.missing / Math.max(feed.required, .001)), 'کسری ' + PR[feed.product][0], `نیاز ${num(feed.required)}؛ تأمین ${num(feed.delivered)}؛ کسری ${num(feed.missing)}. ${feed.optional ? 'خوراک اختیاری است و ضریب کیفیت/خروجی را کم کرده است.' : 'خوراک الزامی است و تولید را محدود کرده است.'} ${labels.join(' و ')}`, feed.cashLimited ? 'ابتدا هزینه واردات و بودجه نقد شرکت را در مالی بررسی کن؛ وام فقط نقدینگی موقت ایجاد می‌کند.' : feed.portLimited ? 'در تجارت، سهم قرارداد و واردات خوراک از بندر را بررسی کن؛ سپس ظرفیت یا برنامه تحویل را اصلاح کن.' : 'در انبار، موجودی خوراک و امکان تأمین داخلی را بررسی کن. خرید همان خوراک یا تولید داخلی را با نیاز واحد هماهنگ کن.', feed.cashLimited ? 'finance' : feed.portLimited ? 'trade' : 'inventory', feed.product);
      }
    }
    for (const output of ledger.products) {
      if (output.spilled > .001)
        push('storage-' + output.product, 96, 'کمبود فضای مخزن ' + PR[output.product][0], `از ${num(output.requested)} تولید، ${num(output.accepted)} ذخیره شد و ${num(output.spilled)} به علت نبود جا از دست رفت. هزینه عملیات این روز پرداخت شده است.`, 'در ردیف همین محصول، موجودی و نگه‌داری خوراک را بررسی کن؛ فروش یا مصرف را آزاد کن، ظرفیت مخزن را افزایش بده یا بار واحد را با خروجی قابل جذب هماهنگ کن.', 'inventory', output.product);
    }
    if (ledger.factors.operator < .999)
      push('operators', 93, 'کمبود اپراتور در واحدهای فعال', `نیروی در دسترس ${num(ledger.factors.availableOperators)} از ${num(ledger.factors.requiredOperators)} مورد نیاز؛ ضریب تولید ناشی از نیروی انسانی ${num(ledger.factors.operator * 100)}٪.`, 'در منابع انسانی، تعداد نیروی حاضر، مصدوم، اعتصاب و نیاز واحدهای فعال را بررسی کن؛ سپس استخدام یا برنامه سرویس واحدها را اصلاح کن.', 'personnel');
    if (ledger.factors.strike < 1)
      push('strike', 99, 'اعتصاب ظرفیت تولید را کم کرده است', `ضریب تولید ناشی از اعتصاب ${num(ledger.factors.strike * 100)}٪ است.`, 'در منابع انسانی مذاکره یا تأمین نیروی موقت را بررسی کن.', 'personnel');
    if (ledger.factors.feedIncident < 1)
      push('feed-incident', 95, 'اختلال عملیاتی خوراک ثبت شده است', `ضریب تولید ناشی از رخداد خوراک ${num(ledger.factors.feedIncident * 100)}٪.`, 'در تصمیم بحران، وضعیت رخداد و اقدام‌های مربوط به خوراک را بررسی کن.', 'crisis');
    if (ledger.factors.story < 1)
      push('story-incident', 96, 'بحران داستانی ظرفیت تولید را کم کرده است', `ظرفیت این روز به ${num(ledger.factors.story * 100)}٪ رسید.`, 'از «توسعه کشور» مدت اختلال و امکان رزرو خدمات جایگزین را بررسی کن.', 'development');
    if (ledger.factors.grid < 1)
      push('grid-incident', 95, 'اختلال شبکه تولید را محدود کرده است', `ضریب شبکه ${num(ledger.factors.grid * 100)}٪؛ این افت ناشی از خرید خوراک نیست.`, 'در تصمیم بحران اختلال شبکه و زمان باقی‌مانده را بررسی کن.', 'crisis');
    if (ledger.factors.avgHealth < 70)
      push('wear', 82, 'فرسودگی تجهیزات مصرف انرژی را افزایش داده است', `میانگین سلامت تجهیزات ${num(ledger.factors.avgHealth)}٪؛ هزینه انرژی روز ${num(ledger.costs.energy)}.`, 'در مدیریت واحد وضعیت تجهیزات و هزینه سرویس را بررسی کن؛ سرویس بدون رفع خرابی قطعه جایگزین تعمیر نیست.', 'unit');
    if (ledger.factors.quality < 85)
      push('quality', 83, 'کیفیت محصول پایین است', `کیفیت ${num(ledger.factors.quality)}٪؛ ضریب خروجی ناشی از کیفیت ${num(ledger.factors.qualityFactor * 100)}٪.`, 'در DCS انحراف PV از محدوده طراحی، وضعیت کنترلرها، اضافه‌بار و سلامت تجهیز را بررسی کن؛ خرید خوراک گران‌تر به‌تنهایی تضمین سود نیست.', 'controls');
    if (ledger.factors.capacityUse > 100)
      push('overload', 88, 'بار بالاتر از ظرفیت نامی تجهیزات', `بهره‌برداری ظرفیت ${num(ledger.factors.capacityUse)}٪؛ هزینه انرژی ${num(ledger.costs.energy)}.`, 'بار را در DCS با ظرفیت نامی هماهنگ کن؛ سپس تغییر تولید، کیفیت و هزینه انرژی را در روز بعد مقایسه کن.', 'controls');
    for (const product of ledger.products) {
      const p = product.product;
      if (PR[p]?.[3] && S.hold?.[p])
        push('held-' + p, 71, 'فروش نقدی ' + PR[p][0] + ' روی نگه‌داری است', 'این وضعیت می‌تواند درآمد نقدی را عقب بیندازد. ارزش موجودی با سود نقدی یکسان نیست.', 'در انبار، نیاز خوراک واحدهای پایین‌دستی را بررسی کن؛ فقط مازاد را برای فروش آزاد کن.', 'inventory', p);
    }
    if (ledger.costs.feedImported > 0 && ledger.profit < 0)
      push('import-cost', 76, 'خوراک وارداتی سهمی از هزینه روز است', `خرید خوراک ${num(ledger.costs.feedImported)} از هزینه کل ${num(ledger.totalCost)}؛ درآمد منتسب ${num(ledger.revenue)}.`, 'در انبار مصرف هر خوراک را بررسی کن. سپس برآورد پروژه تأمین داخلی را با هزینه واردات مقایسه کن؛ ساخت واحد جدید را بدون برآورد سرمایه و هزینه جاری شروع نکن.', 'inventory', ledger.feeds.slice().sort((a, b) => b.importCost - a.importCost)[0]?.product);
    const low = ledger.products.filter(p => p.accepted > 0 && p.unitValue < PR[p.product][2] * .3 && !S.hold?.[p.product]);
    for (const product of low) {
      const p = product.product, exportable = PR[p][3], m = (ledger.market || S.marketDay)?.[p], port = ledger.port || { capacity: S.port, used: S.portUsedToday, remaining: S.portRemainingToday };
      const full = exportable && port.capacity > 0 && port.remaining <= .001 && port.used >= port.capacity - .001;
      push('realization-' + p, exportable ? 82 : 78, 'درآمد منتسب کم برای ' + PR[p][0], `ارزش منتسب هر واحد ${num(product.unitValue)} در برابر قیمت پایه ${num(PR[p][2])}. ` + (exportable ? (full ? 'بندر امروز به سقف مشترک رسیده است.' : `فروش نقدی ${num(m?.sold)} و تقاضای بازار ${num(m?.demand)}؛ از این آمار به‌تنهایی نمی‌توان پر بودن بندر را نتیجه گرفت.`) : `تقاضای کشور ${num(S.dem?.[p])} و ظرفیت خط صادرات برق ${num(p === 'power' ? S.line : 0)}.`), exportable ? (full ? 'ظرفیت مشترک، مصرف واردات و قراردادها را در تجارت بررسی کن؛ سپس درباره توسعه بندر تصمیم بگیر.' : 'در ردیف محصول، موجودی، قیمت انتخابی و تقاضای بازار را مقایسه کن. افزایش قیمت ممکن است تقاضا را کمتر کند.') : 'در انبار و کشور، نیاز مصرف‌کنندگان و مازاد تولید را بررسی کن؛ برای برق امکان خط انتقال را بسنج یا بار را با تقاضا هماهنگ کن.', exportable && full ? 'trade' : 'inventory', p);
    }
    if (ledger.profit < 0)
      push('cost-gap', 60, 'درآمد منتسب امروز هزینه را پوشش نداده است', `${num(ledger.revenue)} درآمد منتسب − ${num(ledger.totalCost)} هزینه = ${num(ledger.profit)} نتیجه امروز.`, 'ردیف‌های هزینه و عوامل ثبت‌شده را به ترتیب اولویت بررسی کن. اگر با رفع گلوگاه‌ها زیان ادامه داشت، بار یا برنامه سرویس را با مقایسه نتیجه روز بعد تغییر بده.', 'controls');
    if (ledger.profit >= 0 && u.pl < 0)
      push('recovering', 42, 'نتیجه امروز بهتر شده؛ میانگین هنوز منفی است', `نتیجه امروز ${num(ledger.profit)}؛ میانگین هموارشده ${num(u.pl)}.`, 'چند روز نتیجه را پایش کن؛ میانگین با تأخیر بهبود می‌یابد. صرفاً به علت منفی ماندن میانگین، توقف پیشنهاد نمی‌شود.', 'controls');
  }
  else if (u.st === 'run' && u.pl < 0)
    push('missing-ledger', 74, 'برای علت دقیق، یک روز داده تازه لازم است', 'این ذخیره میانگین سود دارد ولی ریز تسویه مربوط به روز جاری ثبت نشده است.', 'زمان را یک روز ادامه بده؛ سپس گزارش درآمد، خوراک، هزینه و تولید ازدست‌رفته همین واحد را دوباره باز کن.', 'time');
  causes.sort((a, b) => b.priority - a.priority);
  return {
    index, name: d.n, ledger, causes, primary: causes[0], loss: u.st === 'run' && (u.pl < 0 || ledger?.profit < 0), recovering: ledger?.profit >= 0 && u.pl < 0
  };
}
export function recommendations(S, ctx) {
  const reports = S.u.map((_, i) => analyzeUnit(S, i, ctx)), items = [];
  if (S.cr)
    items.push(issue('crisis', 130, 'بحران فعال نیاز به تصمیم دارد', 'رخداد عملیاتی هنوز بسته نشده است.', 'شرح رخداد و پیامد هر گزینه را بخوان و اقدام مناسب را انتخاب کن؛ پیش از رفع علت، راه‌اندازی مجدد نکن.', 'crisis'));
  for (const report of reports) {
    const p = report.primary;
    if (p && (report.loss || p.priority >= 88 || ['trip', 'broken'].includes(S.u[report.index].st)))
      items.push({ ...p, title: report.name + '؛ ' + p.title });
  }
  if (S.money < 0)
    items.push(issue('cash', 101, 'نقد شرکت منفی است', `کسری نقد ${num(-S.money)}؛ بدهی ${num(S.debt)}.`, 'در مالی، هزینه جاری و تعهدات را بررسی کن. وام هزینه بهره دارد و علت زیان عملیاتی را رفع نمی‌کند.', 'finance'));
  S.u.forEach((u, i) => {
    const step = nextProjectStep(u, ctx.D[u.t]);
    if (step) items.push({
      ...issue('project-' + i, 35, ctx.D[u.t].n, step.text, '', 'project', i),
      label: step.label
    });
  });
  return { reports, items: items.sort((a, b) => b.priority - a.priority) };
}
