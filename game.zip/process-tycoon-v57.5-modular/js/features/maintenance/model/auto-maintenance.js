const fmt = n => Math.round(n).toLocaleString('fa-IR');
// Industrial maintenance runs only on simulation days, never on rendering or wall-clock timers.
export const maintenanceLicenseCost = d => Math.max(600, Math.ceil(d.cost * .12 / 50) * 50);
export const maintenanceDailyBase = d => Math.max(500, Math.ceil(d.cost * .35 / 50) * 50);
export function normalizeMaintenance(u, d) {
  const m = u.maintenance && typeof u.maintenance === 'object' ? u.maintenance : {};
  m.owned = m.owned === true;
  m.enabled = m.owned && m.enabled === true;
  m.restart = m.restart !== false;
  m.shipping = ['normal', 'urgent', 'smart'].includes(m.shipping) ? m.shipping : 'smart';
  m.reserve = [0, 1000, 5000].includes(m.reserve) ? m.reserve : 1000;
  m.limitMultiplier = [1, 2, 3].includes(m.limitMultiplier) ? m.limitMultiplier : 1;
  m.history = Array.isArray(m.history) ? m.history.slice(0, 20) : [];
  m.spentToday = Number.isFinite(m.spentToday) ? Math.max(0, m.spentToday) : 0;
  m.totalSpent = Number.isFinite(m.totalSpent) ? Math.max(0, m.totalSpent) : 0;
  m.status = typeof m.status === 'string' ? m.status : m.owned ? 'آماده ارزیابی' : 'خریداری نشده';
  u.maintenance = m;
  return m;
}
export function purchaseMaintenance(S, index, D) {
  const u = S.u[index], d = u && D[u.t];
  if (!d)
    return false;
  const m = normalizeMaintenance(u, d);
  if (m.owned || ['build', 'ready'].includes(u.st))
    return false;
  const cost = maintenanceLicenseCost(d);
  if (S.money < cost)
    return false;
  S.money -= cost;
  m.owned = true;
  m.enabled = true;
  m.status = 'فعال؛ ارزیابی در روز بعد';
  m.licensePaid = cost;
  return true;
}
export function advancePartOrders(S, D, log) {
  S.u.forEach(u => (u.eq || []).forEach((e, j) => {
    for (const [role, asset] of [['اصلی', e], ['رزرو', e.reserve]]) {
      if (asset?.f?.st === 1) {
        asset.f.eta = Math.max(0, (Number(asset.f.eta) || 0) - 1);
        if (asset.f.eta === 0) {
          asset.f.st = 2;
          log('قطعه ' + D[u.t].e[j][0] + ' ' + role + ' رسید؛ آماده تعمیر.');
        }
      }
    }
  }));
}
export function requestPart({ u, d, j, role = 'main', fast = false, pay, random = Math.random }) {
  const e = role === 'reserve' ? u.eq[j]?.reserve : u.eq[j];
  if (!e?.f || e.f.st !== 0)
    return false;
  const cost = d.cost * (d.e[j][1] ? .08 : .16) * (fast ? 2 : 1);
  if (!pay(cost))
    return false;
  e.f.st = 1;
  e.f.eta = fast ? 1 : 2 + Math.floor(random() * 3);
  return { cost, days: e.f.eta };
}
export function finishRepair({ u, d, j, role = 'main', pay }) {
  const e = role === 'reserve' ? u.eq[j]?.reserve : u.eq[j];
  if (!e?.f || e.f.st !== 2)
    return false;
  const cost = d.cost * .04;
  if (!pay(cost))
    return false;
  e.f = null;
  e.h = Math.max(e.h, 85);
  return { cost };
}
function operatingReadiness(S, u, index, ctx) {
  const { D, OPN, IN, OPT, PR, importMultiplier, availableOperators } = ctx, d = D[u.t];
  if (d.nuc)
    return 'بازگشت این واحد به تأیید دستی نیاز دارد';
  if (u.processState?.valveOpen === false)
    return 'شیر XV-101 بسته است؛ مسیر را دستی بررسی کن';
  if (S.cr?.i === index || u.feedIncident?.days > 0 || u.coolingIncident?.days > 0 || u.instrumentIncident?.days > 0 || S.gridIncident?.days > 0)
    return 'رخداد عملیاتی فعال است؛ ابتدا علت را رفع کن';
  if ((u.load || 100) > (u.ratedCapacity || 100))
    return 'بار از ظرفیت نامی بیشتر است';
  if (u.eq.length < d.e.length || u.eq.some(e => e.f || e.reserve?.f || e.h < 30))
    return 'تجهیزات هنوز کامل و آماده نیستند';
  if ((S.safe ?? 100) < 50)
    return 'شاخص ایمنی برای بازگشت خودکار کافی نیست';
  if (d.v.some((v, k) => !Number.isFinite(u.v[k]) || Math.abs(u.v[k] - v[2]) / Math.max(v[3], .001) > 1.5))
    return 'متغیر فرایند خارج از باند بازگشت خودکار است؛ DCS را بررسی کن';
  if (u.st === 'trip' && !['equipment', 'process', 'overload'].includes(u.tripReason))
    return 'علت تریپ قدیمی یا نامشخص است؛ تأیید دستی لازم است';
  const currentNeed = S.u.reduce((n, x) => n + (x.st === 'run' ? OPN[x.t] : 0), 0);
  if (availableOperators() < currentNeed + OPN[u.t])
    return 'اپراتور کافی برای واحدهای فعال و این واحد وجود ندارد';
  let feedCash = 0, ships = 0;
  for (const [p, qty] of Object.entries(IN[u.t] || {})) {
    if (OPT[u.t]?.[p])
      continue;
    const missing = Math.max(0, qty * (u.load || 100) / 100 - (S.tanks[p] || 0));
    feedCash += missing * PR[p][2] * importMultiplier();
    if (!['power', 'gas', 'water', 'rawwater', 'steam'].includes(p))
      ships += missing;
  }
  if (ships > (ctx.remainingPort?.() ?? S.port))
    return 'ظرفیت اولیه واردات خوراک برای بازگشت کافی نیست';
  if (S.money - u.maintenance.reserve - d.cost * .04 < feedCash)
    return 'نقد لازم برای خوراک اولیه و حاشیه ذخیره کافی نیست';
  return null;
}
export function runAutoMaintenance(S, ctx) {
  const { D, log, recordSOE = () => { }, random = Math.random } = ctx;
  for (let index = 0; index < S.u.length; index++) {
    const u = S.u[index], d = D[u.t], m = normalizeMaintenance(u, d);
    if (m.lastDay === S.day)
      continue;
    m.lastDay = S.day;
    m.spentToday = 0;
    if (!m.owned) {
      m.status = 'خریداری نشده';
      continue;
    }
    if (!m.enabled) {
      m.status = 'غیرفعال؛ سفارش‌های قبلی در مسیر می‌مانند';
      continue;
    }
    if (['build', 'ready', 'off', 'tar'].includes(u.st)) {
      m.status = u.st === 'off' ? 'توقف عمدی؛ دخالت خودکار انجام نمی‌شود' : 'ساخت، راه‌اندازی اولیه یا تعمیرات اساسی؛ در انتظار';
      continue;
    }
    const dailyLimit = maintenanceDailyBase(d) * m.limitMultiplier;
    let wait = null, ordered = 0, repaired = 0;
    const event = (text, cost = 0) => {
      m.history.unshift({ day: S.day, text, cost });
      m.history.length = Math.min(20, m.history.length);
      log('نگهداری خودکار «' + d.n + '»: ' + text);
      recordSOE(text, 'INFO', index);
    };
    const pay = cost => {
      if (m.spentToday + cost > dailyLimit + .00001) {
        wait = 'سقف هزینه روزانه؛ برای اقدام بعدی ' + fmt(Math.ceil(cost)) + ' لازم است';
        return false;
      }
      if (S.money - cost < m.reserve) {
        wait = 'حفظ ذخیره نقد؛ برای اقدام بعدی ' + fmt(Math.ceil(cost)) + ' لازم است';
        return false;
      }
      S.money -= cost;
      m.spentToday += cost;
      m.totalSpent += cost;
      return true;
    };
    // Arrived parts have priority over new purchases.
    for (const phase of ['repair', 'order'])
      for (let j = 0; j < u.eq.length; j++)
        for (const role of ['main', 'reserve']) {
          const asset = role === 'reserve' ? u.eq[j].reserve : u.eq[j];
          if (!asset?.f)
            continue;
          const name = d.e[j][0] + (role === 'reserve' ? ' رزرو' : ' اصلی');
          if (phase === 'repair' && asset.f.st === 2) {
            const result = finishRepair({ u, d, j, role, pay });
            if (result) {
              repaired++;
              if (['broken', 'trip'].includes(u.st))
                m.recoveryPending = true;
              event('تعمیر ' + name + '؛ هزینه ' + fmt(result.cost), result.cost);
            }
          }
          if (phase === 'order' && asset.f?.st === 0) {
            const fast = m.shipping === 'urgent' || m.shipping === 'smart' && (!d.e[j][1] || (asset.f.dl || 0) <= 3);
            const result = requestPart({ u, d, j, role, fast, pay, random });
            if (result) {
              ordered++;
              event('سفارش ' + name + (fast ? ' فوری' : ' عادی') + '؛ تحویل ' + fmt(result.days) + ' روز؛ هزینه ' + fmt(result.cost), result.cost);
            }
          }
        }
    const pending = u.eq.flatMap(e => [e, e.reserve]).filter(e => e?.f);
    let restarted = false;
    if (['trip', 'broken'].includes(u.st) && pending.length === 0) {
      if (!m.restart)
        wait = 'بازگشت خودکار خاموش است؛ تعمیرات انجام می‌شود';
      else if (u.st === 'broken' && !m.recoveryPending)
        wait = 'خرابی بدون سابقه تعمیر؛ تأیید دستی لازم است';
      else {
        const reason = operatingReadiness(S, u, index, ctx);
        if (reason)
          wait = reason;
        else if (m.lastRestartDay != null && S.day - m.lastRestartDay < 3)
          wait = 'وقفه سه‌روزه پس از تلاش قبلی؛ از تکرار راه‌اندازی جلوگیری شد';
        else if (pay(d.cost * .04)) {
          u.v = d.v.map(v => v[2]);
          S.pid = S.pid || {};
          d.v.forEach((v, k) => {
            const cfg = S.pid[`${index}:${k}`] || (S.pid[`${index}:${k}`] = { mode: 'manual' });
            cfg.integral = 0;
            cfg.previousError = 0;
            cfg.output = 0;
            cfg.disturbance = 0;
            cfg.mv = Number.isFinite(cfg.mv) ? Math.max(0, Math.min(100, cfg.mv)) : 50;
            cfg.rampedSp = v[2];
            cfg.sp = Number.isFinite(cfg.sp) ? Math.max(v[2] - v[3] * 3, Math.min(v[2] + v[3] * 3, cfg.sp)) : v[2];
          });
          u.eq.forEach((e, j) => {
            if (/پمپ|pump/i.test(d.e[j][0])) {
              e.running = true;
              if (e.reserve)
                e.reserve.running = false;
            }
          });
          u.processState = { ...u.processState, pumpStandby: false, pumpRunning: true, lowFlowTicks: 0 };
          u.st = 'run';
          u.overloadTicks = 0;
          u.tripReason = null;
          m.recoveryPending = false;
          m.lastRestartDay = S.day;
          restarted = true;
          event('بازگشت مشروط به سرویس پس از بررسی آمادگی؛ هزینه ' + fmt(d.cost * .04), d.cost * .04);
        }
      }
    }
    const inTransit = pending.filter(e => e.f.st === 1).length;
    m.status = wait ? 'نیازمند توجه: ' + wait : restarted ? 'تعمیر و بازگشت به سرویس انجام شد' : inTransit ? 'در انتظار تحویل ' + fmt(inTransit) + ' قطعه' : pending.length ? 'در انتظار قطعه یا بودجه' : repaired ? 'تعمیر انجام شد؛ پایش واحد ادامه دارد' : ordered ? 'سفارش ثبت شد' : 'پایش فعال؛ خرابی نیازمند قطعه وجود ندارد';
  }
}
