// اتصال کنترل‌های صدا و آزادسازی موتور صدا هنگام بستن صفحه.
import { mountAudioControls } from './view/audio-controls.js';
export function installAudioWiring(game) {
  const { S, gameAudio, save } = game;
  mountAudioControls({
    getState: () => S, engine: gameAudio, save, draw: game.draw
  });
  if (typeof window !== 'undefined')
    window.addEventListener('pagehide', e => {
      if (!e.persisted)
        gameAudio.dispose();
    });
}
