import { remainingTradePort } from './model/trade-conditions.js';
// بازار محصولات: خرید و فروش، مخازن، قراردادهای صادراتی.
import { IMP, PR } from '../../data/catalog.js';
import { executeProductTrade } from './model/product-market.js';
import { productRule, saveProductRule } from './model/product-automation.js';
import { cl, f1, fa } from '../../core/format.js';
export function installProductMarket(game) {
  const { S, cap, log, pay, r, save } = game;
  Object.assign(game.actions, {
    tank(x) {
      const n = (S.tl[x.p] || 0) + 1;
      if (pay(800 * n))
        S.tl[x.p] = n;
    },
    hold(x) {
      S.hold[x.p] = !S.hold[x.p];
    },
    price(x) {
      const p = x.p;
      if (!PR[p] || !PR[p][3])
        return;
      const old = Number(S.salePrice[p]) || 1;
      S.salePrice[p] = cl(Math.round((old + (+x.d) * .1) * 10) / 10, .7, 1.5);
      log('استراتژی قیمت ' + PR[p][0] + ' به ×' + f1(S.salePrice[p]) + ' تغییر کرد؛ تقاضای بازار متناسب با قیمت تعدیل می‌شود.');
    },
    'trade-contract'(x) {
      const p = x.p, qty = Math.max(100, Math.min(5000, Math.round((Number(x.q) || 500) / 100) * 100));
      if (!PR[p]?.[3] || S.tradeContracts.length >= 4)
        return;
      const unit = PR[p][2] * (S.pm[p] || 1) * (S.salePrice[p] || 1) * (S.mkt || 1);
      const price = unit * 1.12, advance = qty * price * .2;
      S.money += advance; // Buyer advances 20% cash; it is offset against delivered invoices.
      const c = {
        id: Date.now() + Math.floor(r() * 10000), p, qty, remaining: qty, days: 20, unitPrice: price, advance, advanceBalance: advance, delivered: 0
      };
      S.tradeContracts.push(c);
      log(`قرارداد صادرات ${PR[p][0]} به میزان ${fa(qty)} واحد امضا شد؛ پیش‌دریافت ${fa(advance)} به سرمایه افزوده شد و هنگام تحویل از صورتحساب کسر می‌شود.`);
    },
    'trade-import'(x) {
      if (PR[x.p]?.[3])
        performMarketTrade(x.p, 'buy', Number(x.q) || 500);
    },
    'trade-cancel'(x) {
      const c = S.tradeContracts.find(c => String(c.id) === String(x.id));
      if (!c)
        return;
      const penalty = Math.max(0, c.remaining * c.unitPrice * .08), refund = Number.isFinite(c.advanceBalance) ? Math.max(0, c.advanceBalance) : 0;
      S.money -= penalty + refund;
      S.tradeContracts = S.tradeContracts.filter(q => q !== c);
      log(`قرارداد ${PR[c.p][0]} لغو شد؛ پیش‌دریافت مصرف‌نشده ${fa(refund)} بازپرداخت و جریمه فسخ ${fa(penalty)} اعمال شد.`);
    },
    port() {
      if (pay(1500 * S.port / 20))
        S.port += 20;
    },
  });
  function tradeCard() {
    const products = Object.entries(PR).filter(([p, v]) => v[3]);
    const contracts = (S.tradeContracts || []).map(c => `<div class="eq"><span><b>${PR[c.p][0]}</b> · مانده ${fa(c.remaining)} / ${fa(c.qty)} · ${fa(c.days)} روز</span><span><b>${fa(c.unitPrice)}</b> / واحد <button data-a="trade-cancel" data-id="${c.id}">فسخ</button></span></div>`).join('');
    const history = (S.tradeHistory || []).slice(0, 5).map(h => `<div class="eq"><span>${PR[h.p]?.[0] || h.p} · ${h.status} · ${fa(h.delivered)} از ${fa(h.qty)}</span><small>روز ${fa(h.day)}${h.penalty ? ` · جریمه ${fa(h.penalty)}` : ''}</small></div>`).join('');
    return `<section class="card wide"><h2>تجارت خارجی، قرارداد و واردات</h2><p class="muted">قراردادها از موجودی مخزن تحویل می‌شوند و با ظرفیت روزانه پایانه مشترک‌اند. ۲۰٪ ارزش قرارداد در زمان امضا به‌عنوان پیش‌دریافت به سرمایه اضافه می‌شود؛ مبلغ آن هنگام تحویل از صورتحساب کسر می‌شود. بخش مصرف‌نشده پیش‌دریافت در فسخ یا نقض قرارداد بازپرداخت می‌شود؛ نقض قرارداد جریمه هم دارد.</p><div class="trade-grid">${products.map(([p, [n]]) => `<div class="card"><b>${n}</b><div class="muted">موجودی: ${fa(S.tanks[p] || 0)} · ظرفیت آزاد: ${fa(Math.max(0, cap(p) - (S.tanks[p] || 0)))}</div><div class="row"><button data-a="trade-contract" data-p="${p}" data-q="500" ${S.tradeContracts.length >= 4 ? 'disabled' : ''}>قرارداد صادرات ۵۰۰</button><button data-a="trade-contract" data-p="${p}" data-q="1500" ${S.tradeContracts.length >= 4 ? 'disabled' : ''}>قرارداد ۱۵۰۰</button></div><button data-a="trade-import" data-p="${p}" data-q="500" ${(remainingTradePort(S)) <= 0 || (S.tanks[p] || 0) >= cap(p) ? 'disabled' : ''}>واردات تا ۵۰۰ واحد</button></div>`).join('')}</div><h3>قراردادهای فعال (${fa(S.tradeContracts.length)}/۴)</h3>${contracts || '<div class="muted">قرارداد فعالی وجود ندارد.</div>'}<h3>سوابق تجارت</h3>${history || '<div class="muted">هنوز سابقه‌ای ثبت نشده است.</div>'}<div class="muted">ظرفیت کل پایانه: ${fa(S.port)} واحد/روز · مصرف‌شده امروز: ${fa(S.portUsedToday || 0)} · باقی‌مانده: ${fa(remainingTradePort(S))}. واردات دستی، واردات خودکار خوراک (به‌جز یوتیلیتی‌های محلی)، صادرات قراردادی و فروش نقدی از یک سقف مشترک استفاده می‌کنند.</div></section>`;
  }
  game.clickHandlers.push((e, b, x, i, a) => {
    if (a.startsWith('market-')) {
      handleMarketAction(a, x);
      return true;
    }
    if (a === 'port-trade') {
      S.tab = 'm';
      S.manageSection = 'trade';
      game.draw();
      save();
      return true;
    }
    return false;
  });
  function performMarketTrade(product, side, quantity) {
    const receipt = executeProductTrade(S, product, side, quantity, { PR, cap, importMultiplier: IMP });
    log(receipt.ok ? `${side === 'buy' ? 'خرید' : 'فروش'} ${f1(receipt.quantity)} ${PR[product][1]} ${PR[product][0]}؛ ${side === 'buy' ? 'پرداخت' : 'دریافت'} ${f1(receipt.total)}. ${receipt.reason}` : receipt.reason);
  }
  function scrollMarketTo(el) {
    if (!el)
      return;
    const height = ['body > header'].reduce((sum, key) => {
      const node = document.querySelector(key);
      return sum + (node && typeof getComputedStyle === 'function' && ['sticky', 'fixed'].includes(getComputedStyle(node).position) ? node.getBoundingClientRect().height : 0);
    }, 0);
    el.style?.setProperty('scroll-margin-top', Math.ceil(height + 16) + 'px');
    el.scrollIntoView({ block: 'start' });
  }
  function handleMarketAction(action, x) {
    if (action === 'market-show') {
      scrollMarketTo(document.getElementById('trade-desk'));
      return;
    }
    if (action === 'market-program-toggle') {
      S.marketAutomation ||= {};
      S.marketAutomation.enabled = S.marketAutomation.enabled === false;
      game.draw();
      save();
      return;
    }
    if (action === 'market-rule-save' && Object.hasOwn(PR, x.p)) {
      const read = key => document.getElementById('auto-market-' + key), number = key => Number(read(key)?.value) || 0;
      const raw = {
        buy: !!read('buy')?.checked, emergency: !!read('emergency')?.checked, sellMode: read('sellMode')?.value, ...Object.fromEntries(['min', 'target', 'max', 'reserve', 'maxBuy', 'minSell', 'quantityLimit'].map(k => [k, number(k)]))
      };
      saveProductRule(S, x.p, raw, PR);
      S.marketAutomation.reserve = Math.max(0, number('cashReserve'));
      S.marketAutomation.dailyLimit = Math.max(0, number('dailyLimit'));
      log('تنظیم خودکار ' + PR[x.p][0] + ' ذخیره شد؛ از روز بعد ارزیابی می‌شود.');
      game.draw();
      save();
      return;
    }
    if (action === 'market-page') {
      S.marketPage = Math.max(0, Number(x.page) || 0);
      game.draw();
      save();
      scrollMarketTo(document.querySelector('.tank-yard'));
      return;
    }
    if (action === 'market-back') {
      scrollMarketTo(document.getElementById('product-market'));
      return;
    }
    if (action === 'market-filter') {
      S.marketFilter = x.k;
      S.marketPage = 0;
      game.draw();
      save();
      return;
    }
    if (action === 'market-tank' && Object.hasOwn(PR, x.p)) {
      S.marketProduct = x.p;
      game.draw();
      save();
      return;
    }
    if (action === 'market-preset' && Object.hasOwn(PR, x.p) && ['hold', 'feed', 'surplus'].includes(x.k)) {
      const a = productRule(S, x.p, PR);
      a.buy = x.k === 'feed';
      a.sellMode = x.k === 'surplus' ? 'threshold' : 'off';
      if (x.k === 'feed')
        a.emergency = true;
      if (x.k === 'surplus') {
        a.min = 20;
        a.target = 55;
        a.max = 85;
        a.reserve = Math.max(30, a.reserve);
      }
      saveProductRule(S, x.p, a, PR);
      S.marketNotice = {
        product: x.p, text: 'برنامه ذخیره شد؛ از روز بعد و در حدود بودجه و قیمت تعیین‌شده اجرا می‌شود.'
      };
      game.draw();
      save();
      return;
    }
    if (action === 'market-config' && Object.hasOwn(PR, x.p))
      S.marketProduct = x.p;
    if (action === 'market-select' && Object.hasOwn(PR, x.p)) {
      S.marketProduct = x.p;
      S.marketSide = x.k === 'sell' ? 'sell' : 'buy';
    }
    if (action === 'market-side')
      S.marketSide = x.k === 'sell' ? 'sell' : 'buy';
    if (action === 'market-quantity')
      S.marketQuantity = Number(x.q);
    if (action === 'market-execute')
      performMarketTrade(x.p, x.k, Number(document.getElementById('market-quantity')?.value ?? x.q));
    game.draw();
    save();
    if (action === 'market-select')
      document.getElementById('trade-desk')?.scrollIntoView({ block: 'center' });
    if (action === 'market-config') {
      const details = document.getElementById('product-advanced-' + x.p);
      if (details)
        details.open = true;
      document.getElementById('product-automation')?.scrollIntoView({ block: 'start' });
    }
  }
  Object.assign(game, { performMarketTrade, scrollMarketTo, tradeCard });
}
