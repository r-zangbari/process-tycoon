// Exact reconciliation of one simulation tick; internal inventory valuation is excluded from cash.
export function closeCashDay(S, opening) {
  const current = (S.u || []).filter(u => u.dayEconomics?.day === S.day).map(u => u.dayEconomics), feed = current.reduce((n, e) => n + (e.costs?.feedImported || 0), 0), energy = current.reduce((n, e) => n + (e.costs?.energy || 0), 0), a = S.autoMarketDay?.day === S.day ? S.autoMarketDay : {}, stockBuy = a.expense || 0, stockSell = a.income || 0, water = S.waterSupply?.today?.day === S.day ? S.waterSupply.today.cost || 0 : 0, closing = S.money;
  S.cashDay = {
    day: S.day, opening, closing, stockBuy, stockSell, feed, energy, water, other: closing - opening + stockBuy - stockSell + feed + energy + water
  };
  return S.cashDay;
}
