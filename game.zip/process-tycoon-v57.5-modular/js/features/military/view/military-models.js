// v57 — 3D models of the military installations. Pure construction code: it only needs Three.js and the
// scene's shared geometry/material helpers, so it can be tested in Node without WebGL.
// Every model fits a footprint of about 1 × 1 and is scaled up by the scene.
import { MIL } from '../model/military.js';
export const ROLE_COLORS = { command: '#e8c25a', sensor: '#5ec8b8', defense: '#6fa8ff', strike: '#ef7b6b' };
const CONCRETE = '#b3b7aa', DARK = '#46565a', OLIVE = '#6f7d5a', WHITE = '#e8ece6', RED = '#c0463c', STEEL = '#8f9b9b';
// kit: {T, mat(color), gBox, gCyl, gCone, gCone8, gSph, beacon(group,status,y)}
export function buildMilitaryModel(kit, kind, { level = 1, status = 'active', progress = 1 } = {}) {
  const { T, mat, gBox, gCyl, gCone, gCone8, gSph } = kit;
  const g = new T.Group(), anim = [];
  const P = (geo, c, sx, sy, sz, px, py, pz, rx = 0, ry = 0, rz = 0, parent = g) => {
    const m = new T.Mesh(geo, mat(c));
    m.scale.set(sx, sy, sz);
    m.position.set(px, py + sy / 2, pz);
    m.rotation.set(rx, ry, rz);
    m.castShadow = m.receiveShadow = true;
    parent.add(m);
    return m;
  };
  const role = MIL[kind]?.role || 'defense', accent = ROLE_COLORS[role];
  const slab = (w = 1, d = 1) => P(gBox, CONCRETE, w, .07, d, 0, 0, 0);
  const dot = (x, y, z, s, c) => {
    const m = new T.Mesh(gSph, mat(c));
    m.scale.setScalar(s);
    m.position.set(x, y, z);
    g.add(m);
    return m;
  };
  if (status === 'building') {
    // Construction site: slab, corner poles, cross beam and a half-grown core that rises with progress.
    slab();
    for (const [x, z] of [[-.42, -.42], [.42, -.42], [-.42, .42], [.42, .42]])
      P(gCyl, '#d9a441', .025, .55, .025, x, .07, z);
    P(gBox, '#d9a441', .9, .03, .03, 0, .6, -.42);
    P(gBox, '#d9a441', .9, .03, .03, 0, .6, .42);
    P(gBox, accent, .46, .04 + .36 * Math.min(1, Math.max(0, progress)), .46, 0, .07, 0);
    return { group: g, anim };
  }
  if (kind === 'command') {
    slab();
    P(gBox, '#8a9a86', .72, .3, .56, 0, .07, .05);
    P(gBox, '#5d6e6a', .78, .05, .62, 0, .37, .05);
    for (let i = 0; i < 4; i++)
      P(gBox, DARK, .1, .07, .02, -.27 + i * .18, .2, .34);
    P(gCyl, WHITE, .035, .85, .035, .28, .42, -.18);
    P(gBox, WHITE, .3, .03, .03, .28, 1.05, -.18);
    P(gBox, WHITE, .03, .03, .3, .28, 1.12, -.18);
    dot(.28, 1.3, -.18, .07, accent);
    P(gCyl, '#d8c06a', .1, .12, .1, -.3, .42, -.1);
  }
  else if (kind === 'radar') {
    slab(.9, .9);
    P(gCyl, STEEL, .1, .5, .1, 0, .07, 0);
    P(gBox, DARK, .34, .1, .34, 0, .07, 0);
    const dish = new T.Group();
    dish.position.set(0, .64, 0);
    g.add(dish);
    const bowl = new T.Mesh(gSph, mat(WHITE));
    bowl.scale.set(.42, .1, .3);
    bowl.position.set(0, .08, 0);
    bowl.rotation.x = -.75;
    dish.add(bowl);
    P(gCyl, STEEL, .02, .3, .02, 0, .04, .15, Math.PI / 2.4, 0, 0, dish);
    anim.push(t => {
      dish.rotation.y = t * 1.1;
    });
  }
  else if (kind === 'sam_short' || kind === 'sam_long') {
    const long = kind === 'sam_long';
    slab(long ? 1 : .85, long ? 1 : .85);
    P(gBox, OLIVE, long ? .8 : .62, .12, long ? .8 : .62, 0, .07, 0);
    const rack = new T.Group();
    rack.position.set(0, .3, long ? -.05 : 0);
    rack.rotation.x = -.85;
    g.add(rack);
    const cols = long ? [-.22, .22] : [0], rows = long ? [-.16, .16] : [0];
    for (const x of cols)
      for (const y of rows) {
        P(gBox, DARK, .2, .62, .2, x, y, 0, 0, 0, 0, rack);
        P(gCone8, RED, .14, .14, .14, x, y + .62, 0, 0, 0, 0, rack);
      }
    if (long)
      P(gBox, '#566a62', .3, .22, .22, .25, .19, .28);
    P(gCyl, STEEL, .05, .3, .05, -.28, .19, .28);
  }
  else if (kind === 'antidrone') {
    slab(.8, .8);
    P(gBox, OLIVE, .4, .16, .4, 0, .07, 0);
    P(gCyl, STEEL, .03, .9, .03, 0, .23, 0);
    for (let i = 0; i < 4; i++)
      P(gBox, WHITE, .34 - .06 * i, .02, .02, 0, .45 + i * .14, 0);
    for (const s of [-1, 1])
      P(gCone8, accent, .07, .22, .07, s * .26, .23, .16);
    const ring = new T.Mesh(gCyl, mat(accent));
    ring.scale.set(.3, .015, .3);
    ring.position.set(0, .9, 0);
    g.add(ring);
    anim.push(t => {
      const k = .3 + .12 * Math.sin(t * 3);
      ring.scale.set(k, .015, k);
    });
  }
  else if (kind === 'drone_base') {
    slab(1.05, 1.05);
    P(gBox, DARK, .26, .03, .98, .34, .07, 0);
    for (let i = 0; i < 5; i++)
      P(gBox, WHITE, .03, .032, .1, .34, .07, -.4 + i * .2);
    P(gBox, CONCRETE, .46, .22, .38, -.22, .07, -.26);
    P(gBox, '#6c7a72', .5, .06, .42, -.22, .29, -.26);
    P(gBox, DARK, .34, .14, .03, -.22, .07, -.06);
    const drone = P(gBox, WHITE, .2, .025, .28, .34, .17, .15);
    P(gBox, accent, .05, .03, .2, .34, .19, .15);
    anim.push(t => {
      drone.position.y = .19 + .04 * Math.sin(t * 2);
    });
    P(gCyl, STEEL, .025, .45, .025, -.38, .07, .34);
  }
  else { // missile_city
    P(gCone8, '#7b7f72', .58, .32, .58, 0, 0, 0);
    P(gCyl, DARK, .4, .05, .4, 0, .3, 0);
    for (const [x, z, h] of [[-.22, -.1, .62], [.2, -.14, .5], [0, .2, .56]]) {
      P(gCyl, WHITE, .065, h, .065, x, .34, z);
      P(gCone8, RED, .07, .14, .07, x, .34 + h, z);
    }
    P(gBox, DARK, .34, .08, .18, .0, .3, -.36);
    P(gBox, '#6c7a72', .2, .1, .2, .38, .3, .3);
  }
  // Level pips along the front edge.
  for (let i = 1; i < level; i++)
    P(gBox, '#e8c25a', .09, .05, .09, -.4 + i * .14, .07, .58);
  if (status === 'idle' || status === 'active' || status === 'moving')
    kit.beacon?.(g, status === 'idle' ? 'bad' : status === 'moving' ? 'warn' : 'ok', {
      command: 1.5, radar: 1, sam_short: .8, sam_long: .85, antidrone: 1.15, drone_base: .55, missile_city: 1.05
    }[kind] || 1);
  return { group: g, anim };
}
