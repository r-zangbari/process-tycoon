import { regionalDisruption } from '../../country/model/region-disruption.js';
// v59 — Side panel and map controls of the tactical layer. Pure markup; commands run through data-a buttons.
import {
  MIL,
  MIL_KINDS,
  ROLES,
  MAX_UNITS,
  MAX_OPERATORS,
  OPERATOR_HIRE,
  OPERATOR_WAGE,
  SHIELD_CAP,
  militaryState,
  staffing,
  unitStatus,
  STATUS_TEXT,
  effectiveRange,
  upgradeCost,
  refundValue,
  moveCost,
  maxAmmo,
  operatorsNeeded,
  dailyUpkeep,
  defenseSummary,
  terrainAt,
  incomingRaid,
  ZONES,
  enemyList,
  repairCost,
  DAMAGED_BELOW,
  placementError,
  seaStatus,
  CONVOY_COST,
  CONVOY_PAY,
  BLOCKADE_FLEET_HP
} from '../model/military.js';
import { escapeText } from '../../../engine/unit-names.js';

const fa = (n) => Number(n).toLocaleString('fa-IR');
const btn = (a, label, extra = '', disabled = false) =>
  `<button data-a="${a}" ${extra} ${disabled ? 'disabled' : ''}>${label}</button>`;
export function defenseCaption(S) {
  const m = militaryState(S, false);
  if (m.tool?.startsWith('move:'))
    return 'مقصد جدید را روی نقشه لمس کن و سپس جابه‌جایی را در پنل تأیید کن.';
  if (m.tool)
    return (
      'جای «' +
      MIL[m.tool].name +
      '» را روی نقشه یا از فهرست انتخاب کن و سپس ساخت را تأیید کن.'
    );
  return 'یگان‌ها روی همین نقشهٔ کشور هستند. یک یگان را انتخاب کن تا برد و وضعیتش دیده شود؛ برای جابه‌جایی «جابه‌جایی» را بزن.';
}
function statusLine(S, u, crew) {
  const st = unitStatus(S, u, crew);
  if (st === 'building') return `در حال ساخت · ${fa(Math.max(0, u.ready - S.day))} روز مانده`;
  if (st === 'moving') return `در راه مقصد · ${fa(Math.max(0, u.move.arrive - S.day))} روز مانده`;
  return STATUS_TEXT[st];
}
function palette(S, m) {
  return `<div class="tactical-palette">${MIL_KINDS.map((k) => {
    const d = MIL[k],
      count = m.units.filter((u) => u.kind === k).length,
      full = m.units.length >= MAX_UNITS || (d.max && count >= d.max);
    return btn(
      'mil-tool',
      `<b>${d.name}</b><small>${ROLES[d.role]} · ${fa(d.cost)} · اپراتور ${fa(d.ops)} · برد ${fa(d.range)}</small>`,
      `data-k="${k}" aria-pressed="${m.tool === k}" title="${escapeText(d.desc)}"`,
      S.money < d.cost || full
    );
  }).join('')}</div>`;
}
function operatorsBlock(S, m) {
  const need = operatorsNeeded(S),
    { used } = staffing(S);
  return `<h3>اپراتورها</h3><p>استخدام‌شده ${fa(m.ops)} از ${fa(MAX_OPERATORS)} · نیاز یگان‌ها ${fa(need)} · در خدمت ${fa(used)}</p>
 <p class="muted">هر اپراتور ${fa(OPERATOR_HIRE)} استخدام و ${fa(OPERATOR_WAGE)} حقوق روزانه دارد. یگان بدون اپراتور کامل کار نمی‌کند؛ فرماندهی، رادار و پدافند اول تأمین می‌شوند.</p>
 <div class="tactical-row">${btn('mil-hire', '+۱', 'data-k="1" aria-label="استخدام یک اپراتور"', S.money < OPERATOR_HIRE || m.ops >= MAX_OPERATORS)}${btn('mil-hire', '+۳', 'data-k="3" aria-label="استخدام سه اپراتور"', S.money < 3 * OPERATOR_HIRE || m.ops + 3 > MAX_OPERATORS)}${btn('mil-hire', '−۱', 'data-k="-1" aria-label="تعدیل یک اپراتور"', m.ops < 1)}</div>`;
}
function zonesBlock(S) {
  const rows = defenseSummary(S);
  const content = rows.map(r => {
    const impact = regionalDisruption(S, r.zone);
    const detail = impact.days ? `<small>${impact.label} در ${fa(impact.factor * 100)}٪ ظرفیت معمول · ${fa(impact.days)} روز دیگر</small>` : '';
    return `<div class="tactical-zone"><span>${r.name}${detail}</span><i style="--p:${r.points / SHIELD_CAP}"></i><b>${fa(r.points)}/${fa(SHIELD_CAP)}</b></div>`;
  }).join('');
  return `<h3>حفاظت مناطق</h3><div class="tactical-zones">${content}</div>
 <p class="muted">هر امتیاز از شدت رخداد کم می‌کند. دفاع کامل پاداش دارد. یگان‌های پدافندی مشارکت‌کننده مهمات مصرف می‌کنند.</p>`;
}
function unitBlock(S, m, u, crew) {
  const d = MIL[u.kind],
    active = m.units.filter((v) => unitStatus(S, v, crew) === 'active'),
    mountain = terrainAt(u.x, u.z) === 'mountain';
  const range = effectiveRange(S, u, active),
    idle = unitStatus(S, u, crew) === 'idle';
  return `<small>${ROLES[d.role]}</small><h2>${d.name} · سطح ${fa(u.level)}</h2><p>${d.desc}</p>
 <p class="map-district-status ${idle ? 'bd' : ''}">${statusLine(S, u, crew)}</p>
 <div class="tactical-facts"><span>برد مؤثر <b>${fa(Math.round(range * 10) / 10)}</b></span><span>اپراتور <b>${fa(d.ops)}</b></span>${d.ammo ? `<span>مهمات <b>${fa(u.ammo)}/${fa(maxAmmo(u))}</b></span>` : ''}<span>هزینهٔ روزانه <b>${fa(Math.round(d.upkeep * (1 + 0.2 * (u.level - 1))))}</b></span><span>زمین <b>${mountain ? 'کوهستان' : 'دشت'}</b></span><span>سلامت <b>${fa(u.hp)}٪</b></span>${d.strike ? `<span>قدرت ضربه <b>${fa(Math.round(d.strike * (1 + 0.25 * (u.level - 1))))}</b></span>` : ''}</div>
 ${idle ? `<p class="bd">اپراتور آزاد کافی نیست؛ از بخش اپراتورها استخدام کن.</p>` : ''}
 ${btn('mil-move', m.tool === 'move:' + u.id ? 'لغو جابه‌جایی' : `جابه‌جایی · ${fa(moveCost(u))}`, `data-i="${u.id}" aria-pressed="${m.tool === 'move:' + u.id}"`, u.ready > S.day || !!u.move)}
 ${u.hp < 100 ? btn('mil-repair', `تعمیر · ${fa(repairCost(u))}`, `data-i="${u.id}"`, u.ready > S.day || !!u.move || S.money < repairCost(u)) : ''}
 ${btn('mil-upgrade', u.level >= 3 ? 'بالاترین سطح' : `ارتقا به سطح ${fa(u.level + 1)} · ${fa(upgradeCost(u.kind, u.level))}`, `data-i="${u.id}"`, u.level >= 3 || u.ready > S.day || !!u.move || S.money < upgradeCost(u.kind, u.level))}
 ${btn('mil-sell', `فروش · بازگشت ${fa(refundValue(u))}`, `data-i="${u.id}"`)}
 ${btn('mil-select', 'بستن', 'data-i="0"')}`;
}
function threatBlock(S) {
  const r = incomingRaid(S),
    m = militaryState(S, false);
  const stats =
    m.stats.defended || m.stats.hits || m.stats.strikes
      ? `<p class="muted">دفع‌شده ${fa(m.stats.defended)} · آسیب‌دیده ${fa(m.stats.hits)} · پاداش ${fa(m.stats.earned)} · هزینهٔ بازسازی ${fa(m.stats.lost)} · حمله‌های ما ${fa(m.stats.strikes)} · غنیمت ${fa(m.stats.loot)}</p>`
      : '';
  if (!r)
    return `<p class="map-district-status">تهدید فعالی دیده نمی‌شود؛ دشمن هر چند روز یک منطقه را می‌آزماید، معمولاً ضعیف‌ترین پدافند.</p>${stats}`;
  const points = (defenseSummary(S).find((z) => z.zone === r.zone) || {}).points || 0;
  return `<p class="map-district-status bd"><b>هشدار: حمله به «${r.name}»${r.fromName ? ' از ' + r.fromName : ''}</b> · ${fa(r.daysLeft)} روز مانده · شدت ${fa(r.strength)} · حفاظت فعلی ${fa(points)}${points >= r.strength ? ' (کافی)' : ' (ناکافی)'}</p><p class="muted">با شدت ${fa(r.strength)} و حفاظت ${fa(points)}، آسیب ${fa(Math.max(0, r.strength - points))} امتیاز می‌شود. پدافند را نزدیک آن منطقه بساز یا جابه‌جا کن (جابه‌جایی چند روز طول می‌کشد)، یا پایگاه مبدأ را پیش از موعد از کار بینداز.</p>${stats}`;
}
function enemiesBlock(S) {
  const list = enemyList(S);
  return `<h3>پایگاه‌های دشمن</h3><div class="tactical-enemies">${list
    .map((e) => {
      const state = e.down
        ? `از کار افتاده · ${fa(e.daysDown)} روز تا بازسازی`
        : e.shooters
          ? `${fa(e.shooters)} یگان در برد و مسلح`
          : e.nearest == null
            ? 'یگان ضربه‌ای فعال نداری'
            : `نزدیک‌ترین یگان ضربه ${fa(Math.round(e.nearest))} واحد دورتر است`;
      return `<div id="tactical-rival-${e.id}" class="tactical-enemy${e.origin ? ' is-origin' : ''}"><span><b>${e.name}</b>${e.origin ? ' · مبدأ حملهٔ در راه' : ''}</span><i style="--p:${e.hp / 100}"></i><small>سلامت ${fa(e.hp)}٪ · ${state}</small>${btn('mil-strike', e.down ? 'خاموش' : 'حمله', `data-k="${e.id}"`, e.down || !e.shooters)}</div>`;
    })
    .join(
      ''
    )}</div><p class="muted">پایگاه‌ها از دریا حمله را آغاز می‌کنند. شهر موشکی و پایگاه پهپادی با مهمات به آن‌ها ضربه می‌زنند؛ ضربهٔ کامل پایگاه را چند روز از کار می‌اندازد و غنیمت می‌دهد.</p>`;
}
function seaBlock(S) {
  const q = seaStatus(S);
  const lane = q.blockade
    ? `<p class="map-district-status bd"><b>محاصرهٔ دریایی فعال</b> · ${fa(q.daysLeft)} روز دیگر · ظرفیت تجارت ${fa(Math.round(q.factor * 100))}٪ · سلامت ناوگان دشمن ${fa(q.fleetHp)}٪</p><p class="muted">با ضربه به «ناوگان دشمن جنوب» تا سلامت زیر ${fa(BLOCKADE_FLEET_HP + 1)}٪ محاصره شکسته می‌شود.</p>`
    : '<p class="map-district-status">مسیر دریایی باز است.</p>';
  const ship = q.convoy
    ? `<p>کشتی تجاری در راه · ${fa(q.convoy.daysLeft)} روز مانده${q.blockade ? (q.covered ? ' · مسیر زیر پوشش' : ' · مسیر بدون پوشش؛ در خطر سرنگونی') : ''}</p>`
    : '';
  return `<h3>تجارت دریایی</h3>${lane}${ship}${btn('mil-convoy', `ارسال کشتی تجاری · ${fa(CONVOY_COST)} (درآمد ${fa(CONVOY_PAY)})`, '', !!q.convoy || S.money < CONVOY_COST)}<p class="muted">در محاصره، کشتی بدون پوشش پدافند یا یگان ضربهٔ مسلح (کنار مسیر) سرنگون می‌شود. رسیده ${fa(q.stats.delivered)} · از دست رفته ${fa(q.stats.lost)}</p>`;
}
function spotButtons(S, m) {
  if (!m.tool) return '';
  return `<details id="tactical-placement-list" class="tactical-section"><summary>انتخاب موقعیت از فهرست مناطق</summary><div class="atlas-destinations">${ZONES.map((d) => btn('mil-spot', 'نزدیک ' + d.name, `data-k="${d.id}"`)).join('')}</div></details>`;
}
function placementConfirmation(S, m, site) {
  if (!site || site.tool !== m.tool) return '';
  const unit = m.units.find(u => 'move:' + u.id === m.tool);
  const kind = unit?.kind || m.tool;
  const cost = unit ? moveCost(unit) : MIL[kind].cost;
  const error = placementError(S, kind, site.x, site.z, unit?.id);
  return `<div class="tactical-confirm"><p>${escapeText(error || 'موقعیت روی نقشه علامت‌گذاری شد.')}</p>${btn('mil-confirm', (unit ? 'تأیید جابه‌جایی' : 'تأیید ساخت') + ' · ' + fa(cost), '', !!error || S.money < cost)}</div>`;
}
export function renderDefensePanel(S, { districtPanel = '', defenseSite = null } = {}) {
  const m = militaryState(S, false),
    { crew } = staffing(S),
    sel = m.units.find((u) => u.id === m.sel);
  const upkeep = Math.round(dailyUpkeep(S));
  let head;
  if (m.tool?.startsWith('move:')) {
    const u = m.units.find((v) => 'move:' + v.id === m.tool);
    head = `<small>جابه‌جایی</small><h2>${u ? MIL[u.kind].name : ''}</h2><p>مقصد را روی نقشه انتخاب کن. یگان تا رسیدن غیرفعال می‌ماند.</p>${placementConfirmation(S, m, defenseSite)}${btn('mil-cancel', 'لغو')}${spotButtons(S, m)}`;
  } else if (m.tool) {
    const d = MIL[m.tool];
    head = `<small>ساخت</small><h2>${d.name}</h2><p>${d.desc}</p><p>هزینه ${fa(d.cost)} · ${fa(d.days)} روز ساخت</p>${placementConfirmation(S, m, defenseSite)}${btn('mil-cancel', 'لغو ساخت')}${spotButtons(S, m)}`;
  } else if (sel) head = unitBlock(S, m, sel, crew);
  else
    head = `<small>دفاع و آمادگی کشور</small><h2>پدافند و یگان‌های نظامی</h2><p>${fa(m.units.length)} از ${fa(MAX_UNITS)} یگان · هزینهٔ روزانه ${fa(upkeep)}</p>`;
  const units = m.units.length
    ? `<h3>یگان‌های من</h3><div class="atlas-destinations">${m.units.map((u) => btn('mil-select', `${MIL[u.kind].name}${u.level > 1 ? ' ' + fa(u.level) : ''}`, `data-i="${u.id}" aria-pressed="${m.sel === u.id}"`)).join('')}</div>`
    : '';
  const cover = btn(
    'mil-layer',
    'نمایش برد همهٔ یگان‌ها',
    `data-k="coverage" aria-pressed="${!!m.layers.coverage}"`
  );
  const section = (key, label, body, open = false) => `<details id="tactical-${key}" class="tactical-section"${open ? ' open' : ''}><summary>${label}</summary>${body}</details>`;
  return `${head}${threatBlock(S)}${section('units', 'ساخت و انتخاب یگان', palette(S, m) + units + cover, !m.tool && !sel)}${section('guard', 'حفاظت مناطق و اپراتورها', zonesBlock(S) + operatorsBlock(S, m))}${section('trade', 'تجارت دریایی', seaBlock(S))}${section('rivals', 'حریف‌های بازی', enemiesBlock(S))}${districtPanel ? section('district', 'مدیریت مقصد جغرافیایی', districtPanel) : ''}`;
}
export function defenseLegend() {
  return `<div class="map-legend defense-legend"><span><i style="background:#e8c25a"></i>فرماندهی</span><span><i style="background:#5ec8b8"></i>کشف و هشدار</span><span><i style="background:#6fa8ff"></i>پدافند</span><span><i style="background:#ef7b6b"></i>ضربه</span><small>نشان قرمز یعنی بدون اپراتور؛ حلقهٔ قرمز روی نقشه یعنی هدف حملهٔ دشمن.</small></div>`;
}
