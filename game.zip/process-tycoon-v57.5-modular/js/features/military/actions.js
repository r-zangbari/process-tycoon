// اکشن‌های لایه‌ی دفاعی/نظامی.
import { MIL, hireOperators, militaryState, moveUnit, placementError, placeUnit, repairUnit, selectUnit, sellUnit, setLayer, setTool, snapMapPoint, strikeSite, sendConvoy, suggestSpot, upgradeUnit } from './model/military.js';
export function installMilitaryActions(game) {
  const { S } = game;
  function previewDefenseSite(x, z) {
    const m = militaryState(S, false), tool = m.tool;
    if (S.mapLayer !== 'defense' || !tool) return;
    const unit = m.units.find(u => 'move:' + u.id === tool);
    const kind = unit?.kind || tool;
    x = snapMapPoint(x);
    z = snapMapPoint(z);
    const error = unit && Math.hypot(x - unit.x, z - unit.z) < 0.5
      ? 'مقصد همان جای فعلی است.'
      : placementError(S, kind, x, z, unit?.id);
    game.ui.defenseSite = error ? null : { tool, x, z };
    game.ui.countryNotice = error;
    game.ui.mapSheetOpen = true;
  }
  game.previewDefenseSite = previewDefenseSite;

  Object.assign(game.actions, {
    'mil-layer'(x) {
      setLayer(S, x.k);
    },
    'mil-tool'(x) {
      setTool(S, x.k);
      game.ui.defenseSite = null;
      game.ui.countryNotice = '';
      if (militaryState(S).tool) {
        militaryState(S).sel = null;
        game.ui.mapSheetOpen = true;
      }
    },
    'mil-cancel'() {
      setTool(S, null);
      game.ui.defenseSite = null;
      game.ui.countryNotice = '';
    },
    'mil-select'(x) {
      selectUnit(S, Number(x.i));
      game.ui.defenseSite = null;
      game.ui.countryNotice = '';
      game.ui.mapSheetOpen = true;
    },
    'mil-move'(x) {
      setTool(S, 'move:' + Number(x.i));
      game.ui.defenseSite = null;
      game.ui.countryNotice = '';
      game.ui.mapSheetOpen = true;
    },
    'mil-upgrade'(x) {
      game.ui.countryNotice = upgradeUnit(S, Number(x.i)) || 'یگان ارتقا یافت.';
    },
    'mil-sell'(x) {
      game.ui.countryNotice = sellUnit(S, Number(x.i)) || 'یگان فروخته شد و بخشی از هزینه برگشت.';
    },
    'mil-hire'(x) {
      game.ui.countryNotice = hireOperators(S, Number(x.k)) || '';
    },
    'mil-repair'(x) {
      game.ui.countryNotice = repairUnit(S, Number(x.i)) || 'یگان تعمیر شد.';
    },
    'mil-convoy'() {
      game.ui.countryNotice = sendConvoy(S) || 'کشتی تجاری به راه افتاد.';
    },
    'mil-strike'(x) {
      const r = strikeSite(S, x.k);
      game.ui.countryNotice = r.error || r.message;
    },
    'mil-spot'(x) {
      const m = militaryState(S), tool = m.tool;
      if (!tool)
        return;
      const move = tool.startsWith('move:'), unit = move ? m.units.find(u => 'move:' + u.id === tool) : null, kind = move ? unit?.kind : tool;
      const spot = kind && suggestSpot(S, kind, x.k, unit?.id);
      if (!spot) {
        game.ui.defenseSite = null;
        game.ui.countryNotice = 'جای مناسبی کنار این مقصد پیدا نشد؛ روی نقشه خودت انتخاب کن.';
        return;
      }
      previewDefenseSite(spot.x, spot.z);
    },
    'mil-confirm'() {
      const site = game.ui.defenseSite, tool = militaryState(S, false).tool;
      if (!site || S.mapLayer !== 'defense' || site.tool !== tool) return;
      const move = tool.startsWith('move:');
      const error = move
        ? moveUnit(S, Number(tool.slice(5)), site.x, site.z)
        : placeUnit(S, tool, site.x, site.z);
      if (!error) game.ui.defenseSite = null;
      game.ui.countryNotice = error || (move ? 'یگان به‌سوی مقصد حرکت کرد؛ تا رسیدن غیرفعال است.' : 'ساخت «' + MIL[tool].name + '» شروع شد.');
    },
  });
}
