// v59 — Tactical layer: defense and strike installations placed on the national map.
// Pure game rules only (fictional, game-level numbers). The canvas lives in ui/tactical-map.js.
import { DISTRICTS } from '../../country/model/country-planning.js';
import { damageDays } from '../../country/model/region-disruption.js';
import { ATLAS_BOUNDS, atlasHeight } from '../../country/model/atlas-terrain.js';

export const WORLD = ATLAS_BOUNDS;
export const MAX_UNITS = 14;
export const MAX_OPERATORS = 30;
export const OPERATOR_HIRE = 150;
export const OPERATOR_WAGE = 6;
export const SHIELD_CAP = 4;
const MIN_GAP = 5;
export const DAMAGED_BELOW = 30;
const SPLASH = 9;
// Districts with lots of surrounding buildings need more clearance than single-building sites.
const clearance = (d) => (['north', 'housing', 'energy'].includes(d.id) ? 10 : 6.5);
// Districts the hostile raids can strike (offshore rigs are out of reach of the land defenses).
export const ZONES = DISTRICTS.filter((d) => d.kind !== 'rig');
export const ZONE_POINTS = Object.fromEntries(ZONES.map((d) => [d.id, [d.x, d.z]]));
// Hostile launch sites at sea, one per approach. They are the origin of every raid and can be struck back.
export const ENEMY_SITES = [
  { id: 'nw', name: 'پایگاه دشمن شمال‌غرب', x: -31, z: -39 },
  { id: 'ne', name: 'پایگاه دشمن شمال‌شرق', x: 31, z: -39 },
  { id: 's', name: 'ناوگان دشمن جنوب', x: 2, z: 35 }
];
export const ENEMY_DOWN_DAYS = 6;
// Sea lane used by merchant ships (offshore of the port, towards the open sea) and the blockade rules.
export const LANE = [
  [0, 24],
  [12, 41]
];
export const LANE_COVER = [6, 32.5];
export const CONVOY_COST = 1200,
  CONVOY_PAY = 1800,
  CONVOY_DAYS = 3;
export const BLOCKADE_FACTOR = 0.35,
  BLOCKADE_MAX_DAYS = 12,
  BLOCKADE_FLEET_HP = 40;
const zoneName = (id) => DISTRICTS.find((d) => d.id === id)?.name || id;

export const ROLES = { command: 'فرماندهی', sensor: 'کشف و هشدار', defense: 'پدافند', strike: 'ضربه' };
// Order = staffing priority: when operators are short, the first units in this list are crewed first.
export const MIL = {
  command: {
    name: 'مرکز فرماندهی',
    role: 'command',
    cost: 1200,
    days: 3,
    ops: 2,
    range: 12,
    max: 1,
    upkeep: 10,
    speed: 5,
    moveCost: 0.4,
    desc: 'یگان‌های نزدیک را هماهنگ می‌کند: ۱۰٪ برد بیشتر برای هر یگان فعال در شعاع پوشش.'
  },
  radar: {
    name: 'رادار هشدار زودهنگام',
    role: 'sensor',
    cost: 600,
    days: 2,
    ops: 1,
    range: 15,
    upkeep: 4,
    speed: 8,
    moveCost: 0.3,
    mountain: 1.25,
    desc: 'تهدید را زودتر می‌بیند: پدافند دوربرد زیر چتر رادار با تمام توان کار می‌کند و پوشش منطقه ۲۵٪ قوی‌تر می‌شود. روی کوهستان برد بیشتری دارد.'
  },
  sam_long: {
    name: 'پدافند دوربرد',
    role: 'defense',
    cost: 1800,
    days: 4,
    ops: 2,
    range: 13,
    ammo: 6,
    upkeep: 12,
    speed: 5,
    moveCost: 0.35,
    shield: 2,
    needsRadar: true,
    desc: 'پوشش گسترده؛ بدون چتر رادار فقط نصف توان دارد.'
  },
  sam_short: {
    name: 'پدافند کوتاه‌برد',
    role: 'defense',
    cost: 700,
    days: 2,
    ops: 1,
    range: 7,
    ammo: 8,
    upkeep: 5,
    speed: 8,
    moveCost: 0.3,
    shield: 1,
    desc: 'ارزان و چابک؛ برای حفاظت از یک منطقهٔ مهم.'
  },
  antidrone: {
    name: 'ضدپهپاد و جنگ الکترونیک',
    role: 'defense',
    cost: 900,
    days: 2,
    ops: 1,
    range: 6,
    ammo: 10,
    upkeep: 6,
    speed: 8,
    moveCost: 0.3,
    shield: 1,
    desc: 'برد کوتاه ولی مهمات زیاد؛ لایهٔ آخر دفاع در برابر تهدیدهای کم‌هزینه.'
  },
  drone_base: {
    name: 'پایگاه پهپادی',
    role: 'strike',
    cost: 1500,
    days: 3,
    ops: 2,
    range: 17,
    ammo: 12,
    upkeep: 9,
    speed: 6,
    moveCost: 0.35,
    deterrence: 0.5,
    strike: 30,
    desc: 'برد ضربهٔ متوسط. بازدارندگی: منطقه‌های داخل برد کمی کمتر آسیب می‌بینند. با آن به پایگاه‌های دشمن حمله می‌کنی.'
  },
  missile_city: {
    name: 'شهر موشکی زیرزمینی',
    role: 'strike',
    cost: 2600,
    days: 5,
    ops: 3,
    range: 22,
    ammo: 6,
    upkeep: 18,
    speed: 4,
    moveCost: 0.5,
    deterrence: 0.5,
    strike: 45,
    desc: 'برد ضربهٔ بلند و سخت‌شده؛ جابه‌جایی کند و گران است. روی کوهستان کمتر دیده می‌شود. با آن به پایگاه‌های دشمن حمله می‌کنی.'
  }
};
export const MIL_KINDS = Object.keys(MIL);

const clamp = (v, a, b) => (Number.isFinite(v) ? Math.min(b, Math.max(a, v)) : a);
const whole = (v, a, b) => Math.floor(clamp(v, a, b));
const dist = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);

// ───────── Terrain (the 3D atlas height field decides sea / beach / plain / mountain) ─────────
export function terrainAt(x, z) {
  const h = atlasHeight(x, z);
  return h < 0.1 ? 'sea' : h > 2.4 ? 'mountain' : 'land';
}
export function isCoastal(x, z, reach = 3) {
  if (terrainAt(x, z) === 'sea') return false;
  for (const [dx, dz] of [
    [reach, 0],
    [-reach, 0],
    [0, reach],
    [0, -reach]
  ])
    if (terrainAt(x + dx, z + dz) === 'sea') return true;
  return false;
}

// ───────── State ─────────
export function upgradeCost(kind, level) {
  return Math.round(MIL[kind].cost * 0.7 * level);
}
export function investedCost(unit) {
  let sum = MIL[unit.kind].cost;
  for (let l = 1; l < unit.level; l++) sum += upgradeCost(unit.kind, l);
  return sum;
}
export function refundValue(unit) {
  return Math.floor(investedCost(unit) * 0.5);
}
export function maxAmmo(unit) {
  const d = MIL[unit.kind];
  return d.ammo ? Math.floor(d.ammo * (1 + 0.25 * (unit.level - 1))) : 0;
}
export function moveCost(unit) {
  return Math.round(MIL[unit.kind].cost * MIL[unit.kind].moveCost);
}

// Seeded and deterministic: the same save always gets the same raid schedule.
const rand = (S, salt) => {
  const x = Math.sin((Number(S.seed) || 7) * 12.9898 + S.day * 78.233 + salt * 37.719) * 43758.5453;
  return x - Math.floor(x);
};
const initialBlockadeDay = (S) => 20 + Math.floor(rand({ seed: S.seed, day: 0 }, 2) * 6);
const initialRaidDay = (S) => 14 + Math.floor(rand({ seed: S.seed, day: 0 }, 1) * 5);
const NORMAL = new WeakSet();
// Idempotent: a state object normalised in this session is returned as-is so callers can mutate it safely.
export function militaryState(S, create = true) {
  if (S.military && NORMAL.has(S.military)) return S.military;
  const v = S.military || {};
  const seen = new Set();
  const units = (Array.isArray(v.units) ? v.units : [])
    .filter(
      (u) =>
        u &&
        Object.hasOwn(MIL, u.kind) &&
        Number.isFinite(u.x) &&
        Number.isFinite(u.z) &&
        Number.isSafeInteger(u.id) &&
        u.id > 0 &&
        !seen.has(u.id) &&
        seen.add(u.id)
    )
    .slice(0, MAX_UNITS)
    .map((u) => {
      const level = whole(u.level, 1, 3),
        base = {
          id: u.id,
          kind: u.kind,
          x: clamp(u.x, WORLD.minX, WORLD.maxX),
          z: clamp(u.z, WORLD.minZ, WORLD.maxZ),
          level,
          ready: whole(u.ready, 0, 1e9),
          hp: whole(u.hp ?? 100, 1, 100)
        };
      const mv =
        u.move &&
        Number.isFinite(u.move.x) &&
        Number.isFinite(u.move.z) &&
        Number.isSafeInteger(u.move.arrive)
          ? {
              x: clamp(u.move.x, WORLD.minX, WORLD.maxX),
              z: clamp(u.move.z, WORLD.minZ, WORLD.maxZ),
              arrive: u.move.arrive
            }
          : null;
      return { ...base, move: mv, ammo: whole(u.ammo ?? maxAmmo(base), 0, maxAmmo(base)) };
    });
  const layers = { coverage: v.layers?.coverage === true };
  const sel = units.some((u) => u.id === v.sel) ? v.sel : null;
  const tool = Object.hasOwn(MIL, v.tool)
    ? v.tool
    : typeof v.tool === 'string' && v.tool.startsWith('move:') && units.some((u) => 'move:' + u.id === v.tool)
      ? v.tool
      : null;
  const stats = {
    intercepts: whole(v.stats?.intercepts, 0, 1e9),
    earned: whole(v.stats?.earned, 0, 1e12),
    defended: whole(v.stats?.defended, 0, 1e9),
    strikes: whole(v.stats?.strikes, 0, 1e9),
    loot: whole(v.stats?.loot, 0, 1e12),
    hits: whole(v.stats?.hits, 0, 1e9),
    lost: whole(v.stats?.lost, 0, 1e12)
  };
  const inc = v.raid?.incoming,
    zone =
      inc &&
      Object.hasOwn(ZONE_POINTS, inc.zone) &&
      Number.isSafeInteger(inc.day) &&
      Number.isSafeInteger(inc.strength)
        ? { zone: inc.zone, day: whole(inc.day, 0, 1e9), strength: whole(inc.strength, 1, 9) }
        : null;
  const damaged = Object.fromEntries(
    Object.entries(v.damaged && typeof v.damaged === 'object' ? v.damaged : {})
      .filter(([k, d]) => Object.hasOwn(ZONE_POINTS, k) && Number.isSafeInteger(d))
      .map(([k, d]) => [k, whole(d, 0, 1e9)])
  );
  const siteOk = (id) => ENEMY_SITES.some((e) => e.id === id);
  const enemies = Object.fromEntries(
    ENEMY_SITES.map((e) => {
      const o = v.enemies?.[e.id];
      return [e.id, { hp: whole(o?.hp ?? 100, 0, 100), down: whole(o?.down ?? 0, 0, 1e9) }];
    })
  );
  const blockade = {
    next: whole(v.blockade?.next ?? initialBlockadeDay(S), 0, 1e9),
    until: whole(v.blockade?.until, 0, 1e9)
  };
  const ship =
    v.convoy?.ship && Number.isSafeInteger(v.convoy.ship.start) && Number.isSafeInteger(v.convoy.ship.arrive)
      ? { start: whole(v.convoy.ship.start, 0, 1e9), arrive: whole(v.convoy.ship.arrive, 0, 1e9) }
      : null;
  const convoy = {
    ship,
    delivered: whole(v.convoy?.delivered, 0, 1e9),
    lost: whole(v.convoy?.lost, 0, 1e9),
    income: whole(v.convoy?.income, 0, 1e12)
  };
  const raid = {
    next: whole(v.raid?.next ?? initialRaidDay(S), 0, 1e9),
    incoming: zone && siteOk(inc.from) ? { ...zone, from: inc.from } : zone && { ...zone, from: 's' }
  };
  const state = {
    units,
    ops: whole(v.ops, 0, MAX_OPERATORS),
    seq: Math.max(whole(v.seq, 0, 1e9), ...units.map((u) => u.id)),
    sel,
    tool,
    layers,
    stats,
    raid,
    damaged,
    enemies,
    blockade,
    convoy,
    blockadeOn: blockade.until > S.day,
    shield: {}
  };
  if (!S.military && !create) {
    state.shield = Object.fromEntries(Object.keys(ZONE_POINTS).map((k) => [k, 0]));
    return state;
  }
  NORMAL.add(state);
  S.military = state;
  state.shield = computeShield(S);
  return state;
}

// ───────── Staffing, status and coverage ─────────
export function staffing(S) {
  const st = militaryState(S, false);
  let free = st.ops;
  const crew = new Map();
  const order = [...st.units].sort(
    (a, b) => MIL_KINDS.indexOf(a.kind) - MIL_KINDS.indexOf(b.kind) || a.id - b.id
  );
  for (const u of order) {
    if (u.ready > S.day || u.move || u.hp < DAMAGED_BELOW) {
      crew.set(u.id, false);
      continue;
    }
    const need = MIL[u.kind].ops;
    if (free >= need) {
      free -= need;
      crew.set(u.id, true);
    } else crew.set(u.id, false);
  }
  return { crew, free, used: st.ops - free };
}
export function operatorsNeeded(S) {
  const st = militaryState(S, false);
  return st.units.reduce((n, u) => n + MIL[u.kind].ops, 0);
}
export function unitStatus(S, u, crew = staffing(S).crew) {
  if (u.ready > S.day) return 'building';
  if (u.move) return 'moving';
  if (u.hp < DAMAGED_BELOW) return 'damaged';
  return crew.get(u.id) ? 'active' : 'idle';
}
export const STATUS_TEXT = {
  building: 'در حال ساخت',
  moving: 'در حال جابه‌جایی',
  active: 'فعال',
  idle: 'بدون اپراتور',
  damaged: 'آسیب‌دیده؛ نیاز به تعمیر'
};
function activeUnits(S) {
  const st = militaryState(S, false),
    { crew } = staffing(S);
  return st.units.filter((u) => unitStatus(S, u, crew) === 'active');
}
export function effectiveRange(S, u, active = activeUnits(S)) {
  const d = MIL[u.kind];
  let r = d.range * (1 + 0.1 * (u.level - 1));
  if (d.mountain && terrainAt(u.x, u.z) === 'mountain') r *= d.mountain;
  const cmd = active.some(
    (c) => c.kind === 'command' && c.id !== u.id && dist(c.x, c.z, u.x, u.z) <= effectiveRangeBase(c)
  );
  return cmd ? r * 1.1 : r;
}
function effectiveRangeBase(u) {
  return MIL[u.kind].range * (1 + 0.1 * (u.level - 1));
}
export function computeShield(S) {
  const active = activeUnits(S),
    out = {};
  const range = new Map(active.map((u) => [u.id, effectiveRange(S, u, active)]));
  const radars = active.filter((u) => u.kind === 'radar');
  for (const [zone, [zx, zz]] of Object.entries(ZONE_POINTS)) {
    let sum = 0,
      deter = 0;
    const watched = radars.some((r) => dist(r.x, r.z, zx, zz) <= range.get(r.id));
    for (const u of active) {
      const d = MIL[u.kind],
        inside = dist(u.x, u.z, zx, zz) <= range.get(u.id);
      if (!inside) continue;
      if (d.shield && u.ammo > 0) {
        const cued = radars.some((r) => dist(r.x, r.z, u.x, u.z) <= range.get(r.id));
        sum += d.shield * (1 + 0.25 * (u.level - 1)) * (d.needsRadar && !cued ? 0.5 : 1);
      }
      if (d.deterrence) deter += d.deterrence;
    }
    sum = sum * (watched ? 1.25 : 1) + Math.min(1, deter);
    out[zone] = Math.min(SHIELD_CAP, Math.floor(sum + 1e-9));
  }
  return out;
}
export function refreshShield(S) {
  const st = S.military;
  if (st) st.shield = computeShield(S);
  return st?.shield;
}
export function shieldPoints(S, zone) {
  militaryState(S, false);
  return computeShield(S)[zone] || 0;
}
export function coveringUnits(S, zone) {
  const st = militaryState(S, false),
    [zx, zz] = ZONE_POINTS[zone] || [NaN, NaN],
    active = activeUnits(S);
  return active.filter((u) => dist(u.x, u.z, zx, zz) <= effectiveRange(S, u, active));
}

// ───────── Placement and commands ─────────
export function placementError(S, kind, x, z, ignoreId = null) {
  const st = militaryState(S, false);
  if (!Object.hasOwn(MIL, kind)) return 'نوع یگان معتبر نیست.';
  if (!Number.isFinite(x) || !Number.isFinite(z)) return 'مکان نامعتبر است.';
  if (x < WORLD.minX || x > WORLD.maxX || z < WORLD.minZ || z > WORLD.maxZ)
    return 'این نقطه خارج از نقشه است.';
  if (terrainAt(x, z) === 'sea') return 'روی دریا نمی‌شود پایگاه ساخت.';
  for (const d of DISTRICTS)
    if (d.kind !== 'rig' && dist(x, z, d.x, d.z) < clearance(d))
      return (
        'خیلی نزدیک «' +
        d.name +
        '» است؛ دست‌کم ' +
        clearance(d).toLocaleString('fa-IR') +
        ' واحد فاصله لازم است.'
      );
  for (const u of st.units) {
    if (u.id === ignoreId) continue;
    if ([u, u.move].some(p => p && dist(x, z, p.x, p.z) < MIN_GAP))
      return 'یگان‌ها باید دست‌کم ' + MIN_GAP.toLocaleString('fa-IR') + ' واحد فاصله داشته باشند.';
  }
  return '';
}
export function placeUnit(S, kind, x, z) {
  const st = militaryState(S),
    d = MIL[kind];
  if (!d) return 'نوع یگان معتبر نیست.';
  if (st.units.length >= MAX_UNITS)
    return 'ظرفیت ' + MAX_UNITS.toLocaleString('fa-IR') + ' یگان پر شده است.';
  if (d.max && st.units.filter((u) => u.kind === kind).length >= d.max)
    return 'از «' + d.name + '» بیش از ' + d.max.toLocaleString('fa-IR') + ' مورد مجاز نیست.';
  x = snapMapPoint(x);
  z = snapMapPoint(z);
  const bad = placementError(S, kind, x, z);
  if (bad) return bad;
  if (S.money < d.cost) return 'سرمایه کافی نیست.';
  S.money -= d.cost;
  const unit = {
    id: st.seq + 1,
    kind,
    x,
    z,
    level: 1,
    ready: S.day + d.days,
    move: null,
    ammo: d.ammo || 0,
    hp: 100
  };
  st.seq = unit.id;
  st.units.push(unit);
  st.sel = unit.id;
  st.tool = null;
  refreshShield(S);
  return '';
}
export function moveUnit(S, id, x, z) {
  const st = militaryState(S),
    u = st.units.find((v) => v.id === id);
  if (!u) return 'یگان پیدا نشد.';
  if (u.ready > S.day) return 'یگان هنوز ساخته نشده است.';
  if (u.move) return 'یگان در حال جابه‌جایی است.';
  x = snapMapPoint(x);
  z = snapMapPoint(z);
  const d = MIL[u.kind],
    far = dist(u.x, u.z, x, z);
  if (far < 0.5) return 'مقصد همان جای فعلی است.';
  const bad = placementError(S, u.kind, x, z, id);
  if (bad) return bad;
  const cost = moveCost(u);
  if (S.money < cost) return 'هزینهٔ جابه‌جایی ' + cost.toLocaleString('fa-IR') + ' است و سرمایه کافی نیست.';
  S.money -= cost;
  u.move = {
    x,
    z,
    arrive: S.day + Math.max(1, Math.ceil(far / d.speed))
  };
  st.tool = null;
  refreshShield(S);
  return '';
}
export function upgradeUnit(S, id) {
  const st = militaryState(S),
    u = st.units.find((v) => v.id === id);
  if (!u) return 'یگان پیدا نشد.';
  if (u.level >= 3) return 'این یگان در بالاترین سطح است.';
  if (u.ready > S.day || u.move) return 'در حال ساخت یا جابه‌جایی نمی‌شود ارتقا داد.';
  const cost = upgradeCost(u.kind, u.level);
  if (S.money < cost) return 'سرمایه کافی نیست.';
  S.money -= cost;
  u.level++;
  u.ammo = Math.min(maxAmmo(u), u.ammo + 1);
  refreshShield(S);
  return '';
}
export function sellUnit(S, id) {
  const st = militaryState(S),
    i = st.units.findIndex((v) => v.id === id);
  if (i < 0) return 'یگان پیدا نشد.';
  S.money += refundValue(st.units[i]);
  st.units.splice(i, 1);
  if (st.sel === id) st.sel = null;
  if (st.tool === 'move:' + id) st.tool = null;
  refreshShield(S);
  return '';
}
export function hireOperators(S, n) {
  const st = militaryState(S),
    k = Math.floor(Number(n));
  if (!Number.isFinite(k) || k === 0) return 'تعداد معتبر نیست.';
  if (k > 0) {
    if (st.ops + k > MAX_OPERATORS)
      return 'حداکثر ' + MAX_OPERATORS.toLocaleString('fa-IR') + ' اپراتور قابل استخدام است.';
    if (S.money < k * OPERATOR_HIRE) return 'سرمایه برای استخدام کافی نیست.';
    S.money -= k * OPERATOR_HIRE;
    st.ops += k;
  } else st.ops = Math.max(0, st.ops + k);
  refreshShield(S);
  return '';
}
export function selectUnit(S, id) {
  const st = militaryState(S);
  st.sel = st.units.some((u) => u.id === id) ? id : null;
  st.tool = null;
}
export function setTool(S, tool) {
  const st = militaryState(S);
  st.tool =
    (Object.hasOwn(MIL, tool) ||
      (typeof tool === 'string' &&
        tool.startsWith('move:') &&
        st.units.some((u) => 'move:' + u.id === tool))) &&
    st.tool !== tool
      ? tool
      : null;
}
export function setLayer(S, key) {
  const st = militaryState(S);
  if (Object.hasOwn(st.layers, key)) st.layers[key] = !st.layers[key];
}

// ───────── Daily rules ─────────
export function dailyUpkeep(S) {
  const st = militaryState(S, false);
  return (
    st.units
      .filter((u) => u.ready <= S.day)
      .reduce((n, u) => n + MIL[u.kind].upkeep * (1 + 0.2 * (u.level - 1)), 0) +
    st.ops * OPERATOR_WAGE
  );
}
// Called once per game day BEFORE the regional-crisis system so that the shield is current.
export function advanceMilitaryDay(S, log = () => {}) {
  const st = militaryState(S);
  for (const u of st.units) {
    if (u.move && u.move.arrive <= S.day) {
      u.x = u.move.x;
      u.z = u.move.z;
      u.move = null;
      log('«' + MIL[u.kind].name + '» به مقصد رسید و آمادهٔ کار است.');
    }
    if (u.ready === S.day && !u.move)
      log(
        'ساخت «' +
          MIL[u.kind].name +
          '» تمام شد' +
          (staffing(S).crew.get(u.id) ? '.' : '؛ اپراتور کافی برای آن نیست.')
      );
  }
  const { crew } = staffing(S);
  for (const u of st.units) if (crew.get(u.id) && u.ammo < maxAmmo(u)) u.ammo++;
  for (const u of st.units) if (crew.get(u.id) && u.hp < 100) u.hp = Math.min(100, u.hp + 2);
  const cost = Math.round(dailyUpkeep(S));
  S.money -= cost;
  S.militaryCostToday = cost;
  refreshShield(S);
  advanceRaid(S, log);
  advanceSea(S, log);
  return cost;
}

// ───────── Hostile raids: warned three days ahead, resolved against the zone shield ─────────
export const RAID_WARNING_DAYS = 3;
export function incomingRaid(S) {
  const r = militaryState(S, false).raid.incoming;
  return r
    ? {
        ...r,
        name: zoneName(r.zone),
        from: r.from,
        fromName: ENEMY_SITES.find((e) => e.id === r.from)?.name || '',
        daysLeft: Math.max(0, r.day - S.day)
      }
    : null;
}
function raidStrength(S) {
  return Math.min(6, 2 + Math.floor(S.day / 45) + (rand(S, 3) < 0.4 ? 1 : 0));
}
// The enemy probes the weakest-defended zone half of the time and any zone otherwise.
function pickZone(S, shield) {
  const ids = Object.keys(ZONE_POINTS);
  if (rand(S, 4) < 0.5) {
    const min = Math.min(...ids.map((id) => shield[id] || 0));
    const weak = ids.filter((id) => (shield[id] || 0) === min);
    return weak[Math.floor(rand(S, 5) * weak.length)];
  }
  return ids[Math.floor(rand(S, 6) * ids.length)];
}
function advanceRaid(S, log) {
  const st = S.military,
    r = st.raid;
  for (const e of ENEMY_SITES) {
    const o = st.enemies[e.id];
    if (o.down && S.day >= o.down) {
      o.down = 0;
      o.hp = 40;
      log('«' + e.name + '» دوباره فعال شد؛ هنوز ضعیف است.');
    } else if (!o.down && o.hp < 100) o.hp = Math.min(100, o.hp + 8);
  }
  if (r.incoming) {
    if (S.day >= r.incoming.day) resolveRaid(S, log);
    return;
  }
  if (S.day < r.next) return;
  const open = ENEMY_SITES.filter((e) => !st.enemies[e.id].down);
  if (!open.length) {
    r.next = S.day + 3;
    return;
  }
  const site = open[Math.floor(rand(S, 8) * open.length)],
    zone = pickZone(S, st.shield);
  const strength = Math.max(1, raidStrength(S) - Math.floor((100 - st.enemies[site.id].hp) / 35));
  r.incoming = { zone, from: site.id, day: S.day + RAID_WARNING_DAYS, strength };
  log(
    'هشدار نظامی: «' +
      site.name +
      '» به «' +
      zoneName(zone) +
      '» با شدت ' +
      strength.toLocaleString('fa-IR') +
      ' حمله می‌کند، تا ' +
      RAID_WARNING_DAYS.toLocaleString('fa-IR') +
      ' روز دیگر. پدافند بگذار یا آن پایگاه را بزن.'
  );
}
function resolveRaid(S, log) {
  const st = S.military,
    r = st.raid,
    { zone, strength } = r.incoming,
    name = zoneName(zone);
  refreshShield(S);
  const points = st.shield[zone] || 0,
    net = Math.max(0, strength - points);
  for (const u of coveringUnits(S, zone)) if (MIL[u.kind].shield && u.ammo > 0) u.ammo--;
  if (points > 0) st.stats.intercepts++;
  if (net === 0) {
    const reward = 250 * strength;
    S.money += reward;
    st.stats.earned += reward;
    st.stats.defended++;
    log('پدافند حمله به «' + name + '» را کامل دفع کرد؛ پاداش دفاع ' + reward.toLocaleString('fa-IR') + '.');
  } else {
    const loss = 350 * net;
    S.money -= loss;
    st.stats.lost += loss;
    st.stats.hits++;
    S.sat = Math.max(0, (Number(S.sat) || 0) - 2 * net);
    st.damaged[zone] = S.day + 4;
    log(
      'حمله به «' +
        name +
        '» ' +
        (points ? 'فقط تا حدی مهار شد' : 'بدون پدافند انجام شد') +
        ': هزینهٔ بازسازی ' +
        loss.toLocaleString('fa-IR') +
        ' و رضایت ' +
        (2 * net).toLocaleString('fa-IR') +
        ' واحد کم شد.'
    );
    // Installations near the target take damage; wrecks are removed.
    const [zx, zz] = ZONE_POINTS[zone];
    for (const u of [...st.units])
      if (dist(u.x, u.z, zx, zz) <= SPLASH) {
        u.hp -= 10 * net;
        if (u.hp <= 0) {
          st.units.splice(st.units.indexOf(u), 1);
          if (st.sel === u.id) st.sel = null;
          if (st.tool === 'move:' + u.id) st.tool = null;
          log('«' + MIL[u.kind].name + '» در حمله نابود شد.');
        } else if (u.hp < DAMAGED_BELOW)
          log('«' + MIL[u.kind].name + '» به‌شدت آسیب دید و از کار افتاد؛ تعمیر لازم است.');
      }
  }
  r.incoming = null;
  r.next = S.day + 10 + Math.floor(rand(S, 7) * 5);
  refreshShield(S);
}
export function zoneDamaged(S, zone) {
  return damageDays(S, zone) > 0;
}
export function defenseSummary(S) {
  militaryState(S, false);
  const shield = computeShield(S);
  return ZONES.map((d) => ({
    zone: d.id,
    name: d.name,
    points: shield[d.id] || 0,
    covering: coveringUnits(S, d.id).length
  }));
}
// First valid site near a district (spiral search) so a building can be placed without precise aiming.
export const snapMapPoint = value => Math.round(value * 10) / 10;
export function suggestSpot(S, kind, districtId, ignoreId = null) {
  const d = DISTRICTS.find((v) => v.id === districtId);
  if (!d || !Object.hasOwn(MIL, kind)) return null;
  const moving = militaryState(S, false).units.find(u => u.id === ignoreId);
  for (let r = clearance(d); r <= clearance(d) + 14; r += 1.5)
    for (let k = 0; k < 24; k++) {
      const a = (k * Math.PI) / 12,
        x = Math.round((d.x + Math.cos(a) * r) * 10) / 10,
        z = Math.round((d.z + Math.sin(a) * r) * 10) / 10;
      if ((!moving || dist(x, z, moving.x, moving.z) >= 0.5) && !placementError(S, kind, x, z, ignoreId)) return { x, z };
    }
  return null;
}

// Small read-only snapshot used by the map to decide when geometry must be rebuilt (never changes for cash or ammo ticks).
export function militarySignature(S) {
  const st = S.military;
  if (!st) return null;
  militaryState(S);
  const { crew } = staffing(S);
  return [
    S.mapLayer === 'defense',
    st.sel,
    st.tool,
    st.layers.coverage,
    st.raid.incoming && [st.raid.incoming.zone, st.raid.incoming.day, st.raid.incoming.from],
    Object.entries(st.enemies).map(([k, o]) => [k, Math.round(o.hp / 10), o.down > S.day]),
    st.blockade.until > S.day,
    st.convoy.ship && S.day,
    Object.entries(st.damaged)
      .filter(([, d]) => d > S.day)
      .map(([k]) => k),
    st.units.map((u) => [
      u.id,
      u.kind,
      u.x,
      u.z,
      u.level,
      unitStatus(S, u, crew),
      u.move && [u.move.x, u.move.z]
    ])
  ];
}

// ───────── Repair and counter-strikes ─────────
export function repairCost(unit) {
  return Math.round((MIL[unit.kind].cost * 0.3 * (100 - unit.hp)) / 100);
}
export function repairUnit(S, id) {
  const st = militaryState(S),
    u = st.units.find((v) => v.id === id);
  if (!u) return 'یگان پیدا نشد.';
  if (u.hp >= 100) return 'این یگان سالم است.';
  if (u.ready > S.day || u.move) return 'در حال ساخت یا جابه‌جایی نمی‌شود تعمیر کرد.';
  const cost = repairCost(u);
  if (S.money < cost) return 'هزینهٔ تعمیر ' + cost.toLocaleString('fa-IR') + ' است و سرمایه کافی نیست.';
  S.money -= cost;
  u.hp = 100;
  refreshShield(S);
  return '';
}
export function enemyList(S) {
  const st = militaryState(S, false),
    active = activeUnits(S);
  return ENEMY_SITES.map((e) => {
    const o = st.enemies[e.id],
      shooters = active.filter(
        (u) => MIL[u.kind].strike && u.ammo > 0 && dist(u.x, u.z, e.x, e.z) <= effectiveRange(S, u, active)
      );
    const strikers = active.filter((u) => MIL[u.kind].strike),
      nearest = strikers.length ? Math.min(...strikers.map((u) => dist(u.x, u.z, e.x, e.z))) : null;
    return {
      ...e,
      hp: o.hp,
      down: o.down,
      daysDown: Math.max(0, o.down - S.day),
      shooters: shooters.length,
      nearest,
      origin: st.raid.incoming?.from === e.id
    };
  });
}
// Strike an enemy site with every armed strike unit in range. Returns {error} or {message}.
export function strikeSite(S, id) {
  const st = militaryState(S),
    site = ENEMY_SITES.find((e) => e.id === id);
  if (!site) return { error: 'هدف معتبر نیست.' };
  const o = st.enemies[id];
  if (o.down) return { error: 'این پایگاه از کار افتاده است و تا بازسازی هدف نیست.' };
  const active = activeUnits(S),
    shooters = active.filter(
      (u) =>
        MIL[u.kind].strike && u.ammo > 0 && dist(u.x, u.z, site.x, site.z) <= effectiveRange(S, u, active)
    );
  if (!shooters.length) {
    const strikers = active.filter((u) => MIL[u.kind].strike);
    if (!strikers.length)
      return { error: 'یگان ضربهٔ فعال نداری؛ پایگاه پهپادی یا شهر موشکی بساز و اپراتور بده.' };
    const near = Math.min(...strikers.map((u) => dist(u.x, u.z, site.x, site.z)));
    return {
      error:
        'هیچ یگان ضربهٔ مسلح در برد نیست؛ نزدیک‌ترین ' +
        Math.round(near).toLocaleString('fa-IR') +
        ' واحد فاصله دارد. یگان را جلو ببر یا ارتقا بده.'
    };
  }
  let dmg = 0;
  for (const u of shooters) {
    dmg += MIL[u.kind].strike * (1 + 0.25 * (u.level - 1));
    u.ammo--;
  }
  dmg = Math.round(dmg);
  o.hp = Math.max(0, o.hp - dmg);
  st.stats.strikes++;
  let message =
    '«' +
    site.name +
    '» ' +
    dmg.toLocaleString('fa-IR') +
    ' آسیب دید؛ ' +
    o.hp.toLocaleString('fa-IR') +
    ' از ۱۰۰ مانده.';
  if (o.hp === 0) {
    const loot = 600;
    S.money += loot;
    st.stats.loot += loot;
    o.down = S.day + ENEMY_DOWN_DAYS;
    message +=
      ' پایگاه از کار افتاد؛ غنیمت ' +
      loot.toLocaleString('fa-IR') +
      ' و ' +
      ENEMY_DOWN_DAYS.toLocaleString('fa-IR') +
      ' روز بدون حمله از آن‌جا.';
    if (st.raid.incoming?.from === id) {
      st.raid.incoming = null;
      st.raid.next = S.day + 12;
      message += ' حملهٔ در راه خنثی شد.';
    }
  }
  if (id === 's' && st.blockade.until > S.day && fleetBroken(st)) {
    st.blockade.until = 0;
    st.blockade.next = S.day + 14;
    message += ' محاصرهٔ بندر شکسته شد.';
  }
  syncBlockade(S);
  refreshShield(S);
  return { message };
}

// ───────── Sea trade: merchant ships, blockade and breaking it ─────────
export function blockadeActive(S) {
  const until = S.military?.blockade?.until;
  return Number.isFinite(until) ? until > S.day : S.military?.blockadeOn === true;
}
function fleetBroken(st) {
  const o = st.enemies.s;
  return o.down > 0 || o.hp <= BLOCKADE_FLEET_HP;
}
function syncBlockade(S) {
  const st = S.military;
  if (st) st.blockadeOn = st.blockade.until > S.day;
}
// Is the middle of the lane covered by an active defense or strike unit? (an escort / covering fire)
export function laneCovered(S) {
  const active = activeUnits(S);
  return active.some(
    (u) =>
      (MIL[u.kind].shield || MIL[u.kind].strike) &&
      u.ammo > 0 &&
      dist(u.x, u.z, LANE_COVER[0], LANE_COVER[1]) <= effectiveRange(S, u, active)
  );
}
function advanceSea(S, log) {
  const st = S.military,
    b = st.blockade;
  if (b.until && b.until <= S.day) {
    b.until = 0;
    b.next = S.day + 14;
    log('ناوگان دشمن محاصره را رها کرد.');
  } else if (b.until > S.day && fleetBroken(st)) {
    b.until = 0;
    b.next = S.day + 14;
    log('ناوگان دشمن عقب نشست؛ محاصرهٔ بندر شکسته شد.');
  } else if (!b.until && S.day >= b.next && S.day >= 18 && !fleetBroken(st)) {
    b.until = S.day + BLOCKADE_MAX_DAYS;
    log(
      'محاصرهٔ اقتصادی: ناوگان دشمن مسیر بندر را بست؛ ظرفیت تجارت دریایی به ' +
        Math.round(BLOCKADE_FACTOR * 100).toLocaleString('fa-IR') +
        '٪ رسید. با ضربه به ناوگان جنوب محاصره را بشکن.'
    );
  }
  syncBlockade(S);
  const ship = st.convoy.ship;
  if (ship && S.day >= ship.arrive) {
    st.convoy.ship = null;
    if (b.until > S.day && !laneCovered(S)) {
      st.convoy.lost++;
      log('کشتی تجاری در محاصره سرنگون شد و محموله از دست رفت. مسیر را با پدافند یا یگان ضربه پوشش بده.');
    } else {
      S.money += CONVOY_PAY;
      st.convoy.delivered++;
      st.convoy.income += CONVOY_PAY;
      log(
        'کشتی تجاری سالم رسید' +
          (b.until > S.day ? ' (با پوشش مسیر)' : '') +
          '؛ درآمد ' +
          CONVOY_PAY.toLocaleString('fa-IR') +
          '.'
      );
    }
  }
}
export function sendConvoy(S) {
  const st = militaryState(S);
  if (st.convoy.ship) return 'یک کشتی تجاری هم‌اکنون در راه است.';
  if (S.money < CONVOY_COST)
    return 'هزینهٔ ارسال ' + CONVOY_COST.toLocaleString('fa-IR') + ' است و سرمایه کافی نیست.';
  S.money -= CONVOY_COST;
  st.convoy.ship = { start: S.day, arrive: S.day + CONVOY_DAYS };
  return '';
}
export function convoyPosition(S) {
  const ship = militaryState(S, false).convoy.ship;
  if (!ship) return null;
  const t = Math.min(1, Math.max(0, (S.day - ship.start) / Math.max(1, ship.arrive - ship.start)));
  return {
    x: LANE[0][0] + (LANE[1][0] - LANE[0][0]) * t,
    z: LANE[0][1] + (LANE[1][1] - LANE[0][1]) * t,
    t,
    daysLeft: Math.max(0, ship.arrive - S.day)
  };
}
export function seaStatus(S) {
  const st = militaryState(S, false);
  return {
    blockade: st.blockade.until > S.day,
    daysLeft: Math.max(0, st.blockade.until - S.day),
    fleetHp: st.enemies.s.hp,
    fleetDown: st.enemies.s.down > 0,
    convoy: convoyPosition(S),
    covered: laneCovered(S),
    stats: st.convoy,
    factor: st.blockade.until > S.day ? BLOCKADE_FACTOR : 1
  };
}
