// مالی: درآمد پایدار، وام و بازپرداخت.
import { fa } from '../../core/format.js';
export function installFinance(game) {
  const { S, log, pay } = game;
  Object.assign(game.actions, {
    loan(x) {
      const a = +x.m, d = S.debt || 0;
      if (d + a > 40000) {
        log('سقف اعتبار پر است.');
        return;
      }
      S.debt = d + a;
      S.money += a * .98;
      log('وام ' + fa(a) + ' دریافت شد (کارمزد ۲٪).');
    },
    bailout() {
      if (S.bailoutUsed) {
        log('بازسازی اضطراری قبلاً در این ذخیره استفاده شده است.');
        return;
      }
      if (S.money >= 0) {
        log('بازسازی اضطراری فقط هنگام منفی بودن سرمایه قابل استفاده است.');
        return;
      }
      const grant = 20000;
      S.money += grant;
      S.debt = (S.debt || 0) + grant;
      S.financialGraceDays = 10;
      S.bailoutUsed = true;
      log('بازسازی اضطراری فعال شد: ۲۰٬۰۰۰ واحد نقدینگی با ثبت بدهی، ۱۰ روز تنفس بهره و فرصت اصلاح جریان نقدی. واحدهای زیان‌ده و هزینه‌های غیرضروری را فوراً مدیریت کنید.');
    },
    pi(x) {
      const it = PI.find(q => q[0] === x.k);
      if (it && !(S.pi || {})[x.k] && pay(it[2])) {
        S.pi = S.pi || {};
        S.pi[x.k] = 1;
        log('منبع درآمد پایدار فعال شد: ' + it[1]);
      }
    },
    repay(x) {
      const d = S.debt || 0;
      const a = Math.min(+x.m || d, d);
      if (a > 0 && pay(a)) {
        S.debt = d - a;
        log('بازپرداخت ' + fa(a) + ' انجام شد.');
      }
    },
  });
  const PI = [['rent', 'اجاره‌ی انبار و زمین', 1500, 25], ['eng', 'خدمات مهندسی به شرکت‌های دیگر', 3500, 60], ['inv', 'سرمایه‌گذاری در اوراق', 9000, 150]];
  const BASE = 30;
  function pinc() {
    return BASE + PI.reduce((a, x) => a + ((S.pi || {})[x[0]] ? x[3] : 0), 0);
  }
  function passive() {
    return `<div class="card"><h2>درآمد پایدار</h2><div class="muted" style="font-size:12px">این درآمدها حتی وقتی واحدها خراب یا متوقف‌اند هر روز می‌رسند.</div><div class="eq"><span>یارانه‌ی توسعه‌ی دولتی (همیشگی)</span><b>+${fa(BASE)}</b></div>${PI.map(([k, n, c, v]) => `<div class="eq"><span>${n}</span>${(S.pi || {})[k] ? `<span class="tag run">فعال +${fa(v)}</span>` : `<button data-a="pi" data-k="${k}">خرید (${fa(c)}) · +${fa(v)} در روز</button>`}</div>`).join('')}<div class="row">جمع: <b class="ok">+${fa(pinc())}</b> در روز</div></div>`;
  }
  function bank() {
    const d = S.debt || 0, lim = 40000, grace = S.financialGraceDays || 0;
    return passive() + `<div id="company-finance" class="card"><h2>بانک و وام</h2><div class="row">بدهی: <b class="${d ? 'wn' : ''}">${fa(d)}</b> · سقف اعتبار عادی: <b>${fa(lim)}</b> · بهره: <b>۰٫۴٪ در روز</b> (${grace ? `تنفس بهره: ${fa(grace)} روز` : `${fa(d * .004)} امروز`})</div><div class="muted" style="font-size:12px">وام عادی کارمزد ۲٪ دارد و بهره روزانه از درآمد کم می‌شود. اگر سرمایه منفی شد، بازسازی اضطراری فقط یک‌بار در هر ذخیره قابل استفاده است.</div><div class="row">${[3000, 8000, 20000].map(a => `<button data-a="loan" data-m="${a}" ${d + a > lim ? 'disabled' : ''}>وام ${fa(a)}</button>`).join('')}</div><div class="row"><button data-a="repay" data-m="1000" ${!d ? 'disabled' : ''}>بازپرداخت ۱٬۰۰۰</button><button data-a="repay" data-m="0" ${!d ? 'disabled' : ''}>تسویه کامل</button><button data-a="bailout" ${S.money >= 0 || S.bailoutUsed ? 'disabled' : ''}>بازسازی اضطراری +۲۰٬۰۰۰</button></div><div class="muted" style="font-size:12px">بازسازی اضطراری ۲۰٬۰۰۰ واحد نقدینگی به سرمایه اضافه می‌کند، همین مقدار به بدهی می‌افزاید و ۱۰ روز بهره را متوقف می‌کند. فقط یک‌بار قابل استفاده است؛ هزینه‌های عملیاتی همچنان ادامه دارند.</div></div>`;
  }
  Object.assign(game, { bank, pinc });
}
