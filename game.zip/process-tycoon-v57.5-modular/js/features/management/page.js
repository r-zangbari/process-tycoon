// صفحه‌ی «مدیریت محصولات» و بخش‌های آن (انبار، تجارت، مالی، گزارش‌ها ...).
import { auditSystemLinks } from '../../engine/integration-audit.js';
import { renderDevelopment } from '../development/view/development.js';
import { projectEstimate } from '../industry/view/player-help.js';
import { D, IMP, IN, OUT, PR } from '../../data/catalog.js';
import { renderLegacyCenter } from '../legacy/view/legacy-center.js';
import { maintenanceFleet } from '../maintenance/view/auto-maintenance.js';
import { renderProductMarket } from '../products/view/product-market.js';
import { fa } from '../../core/format.js';
import { CITIES } from '../../data/world-map.js';
export function installManagementPage(game) {
  const { S, cap, feedCost, save } = game;
  function integrationCard() {
    const { links, issues } = auditSystemLinks(S),
      names = { ok: 'متصل', warn: 'نیازمند اقدام', info: 'اطلاع' };
    return `<section class="card wide integration-panel" id="integration-audit"><div class="integration-head"><div><span class="hmi-kicker">SYSTEM LINKS / GAMEPLAY AUDIT</span><h2>پایش ارتباط بخش‌های بازی</h2><p class="muted">بررسی زنده ارتباط خوراک، سکو، صنعت، شهر، اقتصاد، تجارت و HSE؛ وضعیت به‌صورت خودکار همراه روزهای بازی به‌روز می‌شود.</p></div><span class="tag ${issues ? 'trip' : 'run'}">${issues ? `${fa(issues)} گلوگاه` : 'بدون گلوگاه بحرانی'}</span></div><div class="integration-grid">${links.map((x) => `<div class="integration-item ${x.status}"><div class="integration-item-head"><b>${x.label}</b><span>${names[x.status]}</span></div><p>${x.detail}</p>${x.next ? `<small>اقدام پیشنهادی: ${x.next}</small>` : ''}</div>`).join('')}</div><small class="muted">نکته: این پایش مبتنی بر قوانین واقعی بازی است؛ مقادیر عملکردی در مدل ساده‌شده محاسبه می‌شوند، نه بر پایه داده‌های صنعتی واقعی.</small></section>`;
  }
  function developmentCard() {
    return renderDevelopment(S, (t) => projectEstimate(S, D[t], PR, IMP, feedCost(t)).total);
  }
  const sections = {
    inventory: [
      'انبار و فروش · خرید محصولات',
      () => renderProductMarket(S, { D, PR, cap, IN, OUT, importMultiplier: IMP })
    ],
    trade: ['تجارت', () => game.contractCard() + game.tradeCard()],
    development: ['توسعه کشور', developmentCard],
    finance: ['مالی', () => game.bank()],
    research: ['تحقیق و زیرساخت', () => game.techCard() + game.infraCard()],
    fields: ['میادین', () => game.offshoreCard()],
    maintenance: ['نگهداری خودکار', () => maintenanceFleet(S, D)],
    overview: [
      'گزارش‌ها',
      () =>
        integrationCard() +
        game.advCard() +
        game.missionCard() +
        game.statsCard() +
        game.rivalCard() +
        game.esgCard()
    ],
    legacy: ['شهر من و افتخارات', () => renderLegacyCenter(S, { CITIES, PR, IN })]
  };
  function manageNavigation(section) {
    const buttons = Object.entries(sections)
      .map(
        ([key, [label]]) =>
          `<button data-a="manage-section" data-k="${key}" aria-pressed="${section === key}">${label}</button>`
      )
      .join('');
    return `<nav class="card wide manage-navigation" aria-label="بخش‌های مدیریت محصولات">${buttons}</nav>`;
  }
  function viewManage() {
    const section = Object.hasOwn(sections, S.manageSection) ? S.manageSection : 'inventory';
    const crisis = section !== 'inventory' || S.cr ? game.crisisCard() : '';
    return manageNavigation(section) + crisis + sections[section][1]();
  }
  game.clickHandlers.push((e, b, x, i, a) => {
    if (a === 'manage-section') {
      if (!Object.hasOwn(sections, x.k)) return true;
      S.manageSection = x.k;
      game.draw();
      save();
      return true;
    }
    return false;
  });
  Object.assign(game, { viewManage });
}
