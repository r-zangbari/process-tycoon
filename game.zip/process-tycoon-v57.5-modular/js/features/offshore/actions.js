// اکشن‌های فراساحل (پروژه، خط لوله، تعمیر، بازیافت).
import { OFFSHORE, isolateOffshore, offshoreStages, recoveryReady, resumeOffshorePipeline, startOffshoreExtension, startOffshoreMaintenance } from './model/offshore.js';
import { fa } from '../../core/format.js';
export function installOffshoreActions(game) {
  const { S, log, pay, recordSOE } = game;
  Object.assign(game.actions, {
    'alert-go'(x) {
      S.tab = 'm';
      S.manageSection = 'fields';
      S.flt = 'all';
    },
    'alert-dismiss'(x) {
      S.alertAck = S.alertAck || {};
      S.alertAck[x.id] = true;
    },
    'offshore-open'() {
      S.tab = 'm';
      S.cityView = null;
      S.offshoreView = false;
      S.offshoreSelected = null;
      requestAnimationFrame(() => document.getElementById('offshore-management')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
    },
    'offshore-map'(x) {
      S.tab = 'c';
      S.cityView = null;
      S.citySelected = null;
      S.offshoreSelected = null;
      S.sel = null;
      S.offshoreView = true;
      if (x?.p === 'oil' || x?.p === 'gas')
        S.offshoreMapSelected = x.p;
      requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: 'auto' }));
    },
    'offshore-country'() {
      S.tab = 'c';
      S.cityView = null;
      S.offshoreView = false;
      S.offshoreSelected = null;
    },
    'offshore-deselect'() {
      S.offshoreSelected = null;
    },
    'offshore-country-select'(x) {
      if (x?.p !== 'oil' && x?.p !== 'gas')
        return;
      S.offshoreSelected = x.p;
      S.citySelected = null;
      S.sel = null;
      if (window.matchMedia('(max-width: 700px)').matches)
        requestAnimationFrame(() => document.getElementById('map-build-dock')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }));
    },
    'offshore-start'(x) {
      const key = x.p === 'gas' ? 'gas' : 'oil', o = S.offshore[key];
      if (o.stage >= 5 || o.project)
        return;
      const next = o.stage + 1, step = offshoreStages(key)[next];
      if (!step || !pay(step.cost))
        return;
      o.project = { target: next, days: step.days };
      log(`پروژه ${OFFSHORE[key].name} آغاز شد: ${step.name}؛ ${fa(step.days)} روز.`);
    },
    'offshore-pipeline'(x) {
      const key = x.p === 'gas' ? 'gas' : 'oil', o = S.offshore[key], def = OFFSHORE[key];
      if (o.stage !== 5 || o.pipeProject || o.pipelineLevel >= 3)
        return;
      const next = o.pipelineLevel + 1, project = def.pipelineProjects[next];
      if (!project || !pay(project.cost))
        return;
      o.pipeProject = { target: next, days: project.days };
      log(`${o.pipelineLevel === 0 ? 'ساخت' : 'ارتقای'} خط لوله زیردریایی ${def.name} آغاز شد؛ ${fa(project.days)} روز تا بهره‌برداری.`);
    },
    'offshore-toggle'(x) {
      const key = x.p === 'gas' ? 'gas' : 'oil', o = S.offshore[key];
      if (o.stage !== 5)
        return;
      if (o.maintenance || o.incident || o.pipelineIsolated || (!o.online && (o.health < 30 || (o.pipelineLevel > 0 && o.pipeHealth < 30)))) {
        log('راه‌اندازی سکو قبل از رفع رخداد، پایان تعمیرات و بازگشایی ایمن خط با سلامت کافی مجاز نیست.');
        return;
      }
      if (o.online === false && o.reserveRemaining <= 0) {
        log('ابتدا پروژهٔ اتصال بخش تازهٔ میدان را تکمیل کن تا ذخیرهٔ قابل برداشت فراهم شود.');
        return;
      }
      o.online = !o.online;
      log(`${o.online ? 'بازگشت به سرویس' : 'توقف کنترل‌شده برداشت'} سکوی ${OFFSHORE[key].name} ثبت شد.`);
    },
    'offshore-target'(x) {
      const key = x.p === 'gas' ? 'gas' : 'oil', o = S.offshore[key], v = Number(x.q);
      if (o.stage !== 5 || ![50, 75, 100].includes(v) || o.productionTarget === v)
        return;
      o.productionTarget = v;
      log(`هدف تولید میدان ${OFFSHORE[key].name} به ${fa(v)}٪ ظرفیت قابل دسترس تغییر کرد.`);
    },
    'offshore-isolate'(x) {
      const key = x.p === 'gas' ? 'gas' : 'oil';
      if (isolateOffshore(S, key, log))
        recordSOE(`فرمان ESD و ایزولاسیون خط ${OFFSHORE[key].name} توسط اپراتور اجرا شد.`, 'HIGH');
    },
    'offshore-pipe-resume'(x) {
      resumeOffshorePipeline(S, x.p === 'gas' ? 'gas' : 'oil', log);
    },
    'offshore-maintenance'(x) {
      const key = x.p === 'gas' ? 'gas' : 'oil', kind = x.k === 'pipeline' ? 'pipeline' : 'rig';
      startOffshoreMaintenance(S, key, kind, log, pay);
    },
    'offshore-recovery'(x) {
      const key = x.p === 'gas' ? 'gas' : 'oil', def = OFFSHORE[key], o = S.offshore[key];
      if (!recoveryReady(o) || o.recoveryLevel >= 2 || o.recoveryProject || o.incident || o.maintenance) {
        log('ابتدا باید میدان و خط لوله در سرویس باشند و حداقل ۱۰٪ از ذخیره برداشت شده باشد.');
        return;
      }
      const next = o.recoveryLevel + 1, project = def.recoveryProjects[next];
      if (!project || !pay(project.cost))
        return;
      o.recoveryProject = { target: next, days: project.days };
      log(`پروژه «${def.recoveryName}» سطح ${fa(next)} شروع شد؛ زمان ${fa(project.days)} روز.`);
    },
    'offshore-recovery-toggle'(x) {
      const key = x.p === 'gas' ? 'gas' : 'oil', o = S.offshore[key];
      if (o.stage !== 5 || o.recoveryLevel < 1)
        return;
      o.recoveryEnabled = !o.recoveryEnabled;
      log(`${o.recoveryEnabled ? 'فعال‌سازی' : 'توقف'} سامانه بازیافت کمکی میدان ${OFFSHORE[key].name} ثبت شد.`);
    },
    'offshore-extension'(x) {
      if (!startOffshoreExtension(S, x.p, log, pay))
        log('توسعهٔ بخش تازه فعلاً ممکن نیست؛ ذخیره، سلامت عملیات و نقد را بررسی کن.');
    },
    'offshore-import'(x) {
      game.performMarketTrade(x.p === 'gas' ? 'sourgas' : 'crude', 'buy', 500);
    },
  });
}
