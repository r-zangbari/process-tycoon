import { remainingTradePort } from '../products/model/trade-conditions.js';
// کارت میادین فراساحل و حباب هشدار.
import { offshoreTransferAlerts, renderAlertBubbles } from './view/offshore-alert.js';
import { OFFSHORE, nextOffshoreExtension, offshoreStages, recoveryAvailable, recoveryReady, reservoirMetrics, seaCondition } from './model/offshore.js';
import { cl, f1, fa } from '../../core/format.js';
export function installOffshorePage(game) {
  const { S, cap } = game;
  function syncAlerts() {
    const el = document.getElementById('alert-layer');
    if (!el)
      return;
    const html = renderAlertBubbles(offshoreTransferAlerts(S).filter(a => !(S.alertAck || {})[a.id]));
    if (el._h !== html) {
      el._h = html;
      el.innerHTML = html;
    }
  }
  function offshoreCard() {
    const cards = Object.entries(OFFSHORE).map(([key, def]) => {
      const o = S.offshore[key], stage = o.stage, steps = offshoreStages(key), next = steps[stage + 1];
      const project = o.project, pipeProject = o.pipeProject, metrics = reservoirMetrics(o);
      const pipeNext = def.pipelineProjects[o.pipelineLevel + 1];
      const recoveryNext = def.recoveryProjects[o.recoveryLevel + 1], recoveryWorking = !!o.recoveryProject;
      const recoveryUnlocked = recoveryReady(o), boostActive = recoveryAvailable(o, key, S);
      const incident = o.incident, maintenance = o.maintenance, sea = seaCondition(S.day);
      const alarm = incident?.kind === 'pipeline-leak' ? 'نشتی خط زیردریایی' : incident?.kind === 'rig-failure' ? 'خرابی اضطراری سکو' : null;
      const remaining = Math.max(0, o.reserveRemaining || 0), start = Math.max(1, o.reserveInitial || 1);
      const extension = nextOffshoreExtension(S, key);
      const hasReserve = stage >= 3, confirmedText = hasReserve ? `${fa(remaining)} / ${fa(start)} واحد` : 'تا تکمیل ارزیابی ذخیره مشخص نیست';
      const reserveWidth = hasReserve ? Math.round(remaining / start * 100) : 0;
      const pipelineStatus = o.pipelineLevel === 0 ? 'احداث نشده' : `سطح ${fa(o.pipelineLevel)} از ۳`;
      const projectUi = project ? `<div class="note offshore-project"><b>${steps[project.target].name}</b> · ${fa(project.days)} روز مانده<div class="offshore-progress"><i style="width:${cl((1 - project.days / steps[project.target].days) * 100, 0, 100)}%"></i></div></div>` : '';
      const pipelineUi = pipeProject ? `<div class="note offshore-project"><b>${o.pipelineLevel === 0 ? 'ساخت خط لوله' : 'ارتقای خط لوله'} → سطح ${fa(pipeProject.target)}</b> · ${fa(pipeProject.days)} روز مانده<div class="offshore-progress"><i style="width:${cl((1 - pipeProject.days / def.pipelineProjects[pipeProject.target].days) * 100, 0, 100)}%"></i></div></div>` : '';
      return `<article class="offshore-card"><h3>🌊 ${def.rig}</h3>
 <div class="eq"><span>توسعه میدان</span><b class="${stage === 5 ? 'ok' : 'wn'}">${stage === 5 ? (o.online ? 'سکو در سرویس' : 'سکو متوقف') : stage === 0 ? 'آغاز نشده' : steps[stage].name}</b></div>
 <div class="eq"><span>ذخیره قابل برداشت</span><b>${confirmedText}</b></div>
 ${hasReserve ? `<div class="offshore-reserve-bar" role="progressbar" aria-valuenow="${reserveWidth}" aria-valuemin="0" aria-valuemax="100" aria-label="سهم باقی‌مانده ذخیره"><i style="width:${reserveWidth}%"></i></div><div class="eq"><span>شاخص فشار مخزن</span><b class="${metrics.pressurePct < 35 ? 'bd' : metrics.pressurePct < 65 ? 'wn' : 'ok'}">${fa(metrics.pressurePct)}٪</b></div>` : ''}
 ${stage === 5 ? `<div class="offshore-integrity-top"><span class="offshore-status ${alarm ? 'alarm' : o.pipelineIsolated ? 'isolated' : 'normal'}">${alarm ? '🚨 ' + alarm : maintenance ? '🛠 تعمیرات در جریان' : o.pipelineIsolated ? '⛔ خط ایزوله است' : '✓ آماده بهره‌برداری'}</span><small>شرایط دریا: ${sea}</small></div>
 <div class="offshore-health-grid"><div><small>سلامت سکوی دریایی</small><b class="${o.health < 30 ? 'bd' : o.health < 55 ? 'wn' : 'ok'}">${f1(o.health)}٪</b><div class="offshore-health-bar"><i style="width:${o.health}%" class="${o.health < 30 ? 'bad' : o.health < 55 ? 'warn' : ''}"></i></div></div><div><small>سلامت خط لوله</small><b class="${o.pipeHealth < 30 ? 'bd' : o.pipeHealth < 55 ? 'wn' : 'ok'}">${f1(o.pipeHealth)}٪</b><div class="offshore-health-bar"><i style="width:${o.pipeHealth}%" class="${o.pipeHealth < 30 ? 'bad' : o.pipeHealth < 55 ? 'warn' : ''}"></i></div></div></div>` : ''}
 <div class="eq"><span>موجودی مخزن خشکی</span><b>${fa(S.tanks[def.product] || 0)} / ${fa(cap(def.product))}</b></div>
 ${stage < 5 ? `<div class="offshore-stage">${project ? 'مرحله در دست اجرا' : `مرحله بعدی: ${next?.name || '—'}`}<br>${next ? `هزینه: ${fa(next.cost)} · زمان: ${fa(next.days)} روز` : ''}</div>${projectUi}<div class="offshore-actions"><button class="p" data-a="offshore-start" data-p="${key}" ${project ? 'disabled' : ''}>${project ? 'در حال اجرا' : `شروع مرحله بعد (${fa(next.cost)})`}</button></div>` :
        `<div class="offshore-divider"><b>بهره‌برداری و افت طبیعی تولید</b><small>تولید اسمی اولیه: ${fa(def.rate)} واحد / روز</small></div>
 <div class="eq"><span>تولید از چاه امروز</span><b class="ok">${f1(o.producedToday || 0)} واحد</b></div>
 <div class="eq"><span>هدف بهره‌برداری</span><b>${fa(o.productionTarget)}٪</b></div>
 <div class="offshore-target-actions" role="group" aria-label="تنظیم هدف تولید ${def.name}">${[50, 75, 100].map(q => `<button data-a="offshore-target" data-p="${key}" data-q="${q}" aria-pressed="${o.productionTarget === q}" class="${o.productionTarget === q ? 'selected' : ''}">${fa(q)}٪</button>`).join('')}</div>
 <div class="offshore-actions"><button data-a="offshore-toggle" data-p="${key}" ${maintenance || incident || o.pipelineIsolated || (!o.online && (remaining <= 0 || o.health < 30 || (o.pipelineLevel > 0 && o.pipeHealth < 30))) ? 'disabled' : ''}>${o.online ? '⏸ توقف کنترل‌شده سکو' : '▶ راه‌اندازی مجدد سکو'}</button></div>
 ${alarm ? `<div class="offshore-incident" role="alert"><b>⚠ ${alarm}</b><small>${incident.kind === 'pipeline-leak' ? 'جریان به‌صورت حفاظتی قطع شده است؛ ابتدا فرمان ایزولاسیون را اجرا و سپس تعمیر کنید. تا زمان ایزولاسیون، جریمه و افت HSE ادامه دارد.' : 'سکو خاموش شده است؛ برای بازگشت به سرویس باید تعمیر اضطراری انجام شود.'}</small></div>` : ''}
 ${maintenance ? `<div class="note offshore-project"><b>🛠 ${maintenance.emergency ? 'تعمیر اضطراری' : 'سرویس دوره‌ای'} ${maintenance.kind === 'rig' ? 'سکو' : 'خط لوله'}</b> · ${fa(maintenance.days)} روز مانده</div>` : ''}
 <div class="offshore-divider"><b>تعمیرات و واکنش اضطراری (HSE)</b><small>شروع سرویس باعث توقف کنترل‌شده می‌شود</small></div>
 <div class="offshore-actions"><button class="offshore-esd" data-a="offshore-isolate" data-p="${key}" ${o.pipelineLevel === 0 || o.pipelineIsolated ? 'disabled' : ''}>⛔ ایزولاسیون اضطراری خط (ESD)</button>
 ${o.pipelineIsolated ? `<button data-a="offshore-pipe-resume" data-p="${key}" ${incident || maintenance || o.pipeHealth < 30 ? 'disabled' : ''}>🔓 بازگشایی خط پس از بازرسی</button>` : ''}</div>
 <div class="offshore-actions"><button data-a="offshore-maintenance" data-p="${key}" data-k="rig" ${maintenance || (incident && incident.kind !== 'rig-failure') ? 'disabled' : ''}>${incident?.kind === 'rig-failure' ? 'تعمیر اضطراری سکو (۳٬۲۰۰ · ۵ روز)' : 'سرویس سکو (۱٬۲۵۰ · ۳ روز)'}</button>
 ${o.pipelineLevel > 0 ? `<button data-a="offshore-maintenance" data-p="${key}" data-k="pipeline" ${maintenance || (incident && incident.kind !== 'pipeline-leak') || (incident?.kind === 'pipeline-leak' && !o.pipelineIsolated) ? 'disabled' : ''}>${incident?.kind === 'pipeline-leak' ? 'رفع نشتی خط (۴٬۲۰۰ · ۶ روز)' : 'سرویس خط (۱٬۴۵۰ · ۴ روز)'}</button>` : ''}</div>
 <div class="offshore-divider"><b>خط لوله زیردریایی → پایانه خشکی</b><small class="${o.pipelineLevel ? 'ok' : 'wn'}">${pipelineStatus}</small></div>
 <div class="eq"><span>ظرفیت انتقال خط در روز</span><b>${fa(def.pipelineCapacity[o.pipelineLevel])} واحد</b></div>
 <div class="eq"><span>خوراک تحویلی امروز به خشکی</span><b class="${o.deliveredToday ? 'ok' : 'wn'}">${f1(o.deliveredToday || 0)} واحد</b></div>
 <div class="eq"><span>بافر / مخزن موقت روی سکو</span><b>${f1(o.buffer || 0)} / ${fa(def.bufferCapacity)}</b></div>
 <div class="eq"><span>کاهش تولید به‌علت محدودیت</span><b class="${o.shutInToday > 1 ? 'wn' : 'ok'}">${f1(o.shutInToday || 0)} واحد</b></div>
 <div class="eq"><span>هزینه روزانه سکو، انتقال، بازیافت و جریمه</span><b>${fa(o.operatingCostToday || 0)}</b></div>
 ${o.fineToday > 0 ? `<div class="eq"><span>جریمه روزانه HSE بابت نشتی باز</span><b class="bd">${fa(o.fineToday)}</b></div>` : ''}
 ${pipelineUi}
 <div class="offshore-actions">${o.pipelineLevel < 3 ? `<button class="p" data-a="offshore-pipeline" data-p="${key}" ${pipeProject ? 'disabled' : ''}>${pipeProject ? 'پروژه انتقال در حال اجرا' : `${o.pipelineLevel === 0 ? 'احداث خط لوله' : 'ارتقای خط به سطح ' + fa(o.pipelineLevel + 1)} (${fa(pipeNext.cost)} · ${fa(pipeNext.days)} روز)`}</button>` : '<span class="tag run">ظرفیت خط لوله تکمیل شده</span>'}</div>
 ${o.pipelineLevel === 0 ? '<p class="offshore-warning">تا زمان نصب خط لوله، خوراک به مخازن خشکی نمی‌رسد. با پر شدن بافر سکو، برداشت از مخزن متوقف می‌شود.</p>' : ''}
 <div class="offshore-divider"><b>افزایش برداشت با فناوری کمکی</b><small>سطح ${fa(o.recoveryLevel)} از ۲</small></div>
 <div class="eq"><span>${def.recoveryName}</span><b>${o.recoveryLevel === 0 ? 'نصب نشده' : o.recoveryEnabled ? (boostActive ? 'فعال' : 'فاقد یوتیلیتی کافی / آماده‌به‌کار') : 'غیرفعال'}</b></div>
 <div class="eq"><span>مصرف یوتیلیتی امروز</span><b>${fa(o.utilityUsedToday || 0)} ${def.utility === 'water' ? 'آب' : 'برق'}</b></div>
 ${recoveryWorking ? `<div class="note offshore-project"><b>پروژه ارتقای بازیافت سطح ${fa(o.recoveryProject.target)}</b> · ${fa(o.recoveryProject.days)} روز باقی‌مانده</div>` : ''}
 <div class="offshore-actions">${o.recoveryLevel < 2 ? `<button data-a="offshore-recovery" data-p="${key}" ${recoveryWorking || !recoveryUnlocked || maintenance || incident ? 'disabled' : ''}>${recoveryWorking ? 'پروژه بازیافت در حال اجرا' : recoveryUnlocked ? `نصب / ارتقا: ${def.recoveryName} (${fa(recoveryNext.cost)} · ${fa(recoveryNext.days)} روز)` : 'پس از ۱۰٪ برداشت و احداث خط لوله قابل بازگشایی'}</button>` : '<span class="tag run">طرح تقویت سطح ۲ تکمیل شد</span>'}
 ${o.recoveryLevel > 0 ? `<button data-a="offshore-recovery-toggle" data-p="${key}">${o.recoveryEnabled ? 'توقف فناوری کمکی' : 'فعال‌سازی فناوری کمکی'}</button>` : ''}</div>
 <p class="muted offshore-compact-note">فناوری کمکی تولید روزانه را در افت فشار بهبود می‌دهد، اما ذخیره نفت و گاز را افزایش نمی‌دهد. هر سطح برای نفت ${fa(def.utilityPerLevel)} واحد آب و برای گاز ${fa(def.utilityPerLevel)} واحد برق در روز مصرف می‌کند؛ در نبود یوتیلیتی، اثر کمکی خودکار حذف می‌شود.</p>
 ${remaining <= 0 ? '<p class="offshore-warning">ذخیرهٔ بخش فعال پایان یافته است. بافر قابل انتقال است؛ پس از اتصال بخش تازه، فرمان راه‌اندازی بده.</p>' : ''}
 <div class="offshore-divider"><b>توسعهٔ بخش تازهٔ میدان</b><small>${fa(o.extensionLevel || 0)} از ۲ بخش تکمیل شد</small></div>
 ${o.extensionProject ? `<p class="note">اتصال بخش تازه · ${fa(o.extensionProject.days)} روز مانده</p>` : extension ? `<p>از ۱۰٪ ذخیرهٔ باقی‌مانده با استفاده از سکوی فعلی قابل سفارش است.</p><button data-a="offshore-extension" data-p="${key}" ${remaining > start * .1 || !o.pipelineLevel || maintenance || incident || S.money < extension.cost ? 'disabled' : ''}>اتصال بخش جدید · ${fa(extension.cost)} · ${fa(extension.days)} روز · ذخیره ${fa(extension.reserve)}</button>` : '<p>بخش‌های قابل توسعهٔ میدان مصرف شده‌اند. برای ادامهٔ تأمین از میدان دیگر یا واردات استفاده کن.</p>'}`}
 <div class="offshore-actions offshore-import-actions"><button data-a="offshore-import" data-p="${key}" ${(remainingTradePort(S)) <= 0 || (S.tanks[def.product] || 0) >= cap(def.product) ? 'disabled' : ''}>واردات ${def.name} · تا ۵۰۰ واحد</button></div>
 </article>`;
    });
    return `<section class="card wide" id="offshore-management"><div class="offshore-entry-head"><h2>اکتشاف، ذخایر، قابلیت اطمینان و انتقال فراساحلی</h2><button data-a="offshore-map" class="p">🌊 ورود به نقشه مستقل میادین</button></div><p class="muted offshore-help">در آغاز بازی برای نفت خام و گاز ترش به واردات وابسته هستید. پس از تأیید ذخیره و نصب سکو، خوراک ابتدا وارد بافر دریایی می‌شود و فقط از طریق خط لوله زیردریایی به مخزن خشکی و سپس واحدهای فرایندی می‌رسد. مخزن برداشت‌پذیر محدود است و افت فشار، دبی چاه را به‌تدریج کاهش می‌دهد. سلامت سکو و خطوط انتقال باید پایش شود؛ پس از ۱۰٪ برداشت، فناوری‌های تقویت تولید قابل نصب هستند.</p><div class="offshore-grid">${cards.join('')}</div><p class="muted offshore-model-note">مدل مخزن و فشار، ساده‌شده و مخصوص گیم‌پلی است (نه شبیه‌ساز مهندسی مخزن). ذخیره در مرحله تأیید مشخص می‌شود؛ تولید واقعی با ظرفیت مخزن موقت، خط لوله و مخزن خشکی محدود است. تولید متوقف‌شده از ذخیره کسر نمی‌شود. تعمیر سکو/خط، جریان مربوط را ایزوله می‌کند و پس از تکمیل، راه‌اندازی مجدد دستی است. نشتی خط قبل از تعمیر به ESD و ایزولاسیون اپراتوری نیاز دارد. فناوری کمکی ذخیره قابل برداشت را بیشتر نمی‌کند.</p></section>`;
  }
  Object.assign(game, { offshoreCard, syncAlerts });
}
