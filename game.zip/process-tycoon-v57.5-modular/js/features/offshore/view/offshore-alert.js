// Floating warning bubble: shown on every tab while an offshore platform cannot send product to the onshore tanks because of a failure.
import { OFFSHORE } from '../model/offshore.js';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export function offshoreTransferAlerts(S) {
  const out = [];
  for (const [key, def] of Object.entries(OFFSHORE)) {
    const o = S.offshore?.[key];
    if (!o || o.stage !== 5 || o.project)
      continue;
    const kind = o.incident?.kind, leak = kind === 'pipeline-leak', rig = kind === 'rig-failure', dead = o.pipelineLevel > 0 && o.pipeHealth <= 0;
    if (!leak && !rig && !dead)
      continue;
    const title = `${def.rig}: ارسال ${def.name} به مخازن متوقف است`;
    const detail = leak ? (o.pipelineIsolated ? 'خط زیردریایی به‌دلیل نشتی ایزوله شده است؛ پس از تعمیر، خط را دوباره باز کن.' : 'نشتی خط زیردریایی ثبت شد؛ جریان قطع شده و برای تعمیر باید خط ایزوله شود.') : rig ? 'سکو از کار افتاده است؛ تولید متوقف است و محصول تازه‌ای به مخازن نمی‌رسد. تعمیر اضطراری لازم است.' : 'سلامت خط زیردریایی به صفر رسیده است؛ انتقال تا تعمیر خط ممکن نیست.';
    out.push({ id: `${key}:${kind || 'pipe-health'}:${o.incident?.day || 0}`, key, title, detail });
  }
  return out;
}
export function renderAlertBubbles(alerts) {
  return alerts.map(a => `<div class="alert-bubble" data-alert="${esc(a.id)}"><span class="alert-icon" aria-hidden="true">⚠</span><div><b>${esc(a.title)}</b><p>${esc(a.detail)}</p><div class="alert-actions"><button data-a="alert-go" data-k="${esc(a.key)}">رفتن به میدان‌ها</button><button data-a="alert-dismiss" data-id="${esc(a.id)}">متوجه شدم</button></div></div></div>`).join('');
}
