// اکشن‌های «شهر من و افتخارات».
import { legacyAction, legacyState } from './model/legacy-development.js';
import { IN, PR } from '../../data/catalog.js';
import { CITIES } from '../../data/world-map.js';
export function installLegacyActions(game) {
  const { S, log, save } = game;
  game.clickHandlers.push((e, b, x, i, a) => {
    if (a.startsWith('legacy-')) {
      handleLegacyAction(a, x);
      return true;
    }
    return false;
  });
  function handleLegacyAction(action, x) {
    if (action === 'legacy-open') {
      S.tab = 'm';
      S.manageSection = 'legacy';
      if (x.section)
        S.legacySection = x.section;
      game.draw();
      save();
      game.scrollMarketTo(document.querySelector('.legacy-center'));
      return;
    }
    if (action === 'legacy-section') {
      S.legacySection = x.key;
      game.draw();
      save();
      return;
    }
    if (action === 'legacy-filter') {
      S.legacyFilter = x.key;
      game.draw();
      save();
      return;
    }
    if (action === 'legacy-campus') {
      S.tab = 'site';
      game.draw();
      save();
      return;
    }
    if (action === 'legacy-choose') {
      const i = Math.max(0, Math.min(CITIES.length - 1, Number(S.legacyCity) || 0));
      S.tab = 'c';
      game.actions['city-enter']({ i });
      S.countryHub = null;
      S.offshoreView = false;
      S.cityCell = null;
      S.cityDesignOpen = true;
      S.legacyItem = x.key;
      {
        const l = legacyState(S);
        l.notice = 'یک قطعه روی نقشه انتخاب کن؛ سپس ساخت را تأیید کن.';
        S.legacy = l;
      }
      game.draw();
      save();
      game.scrollMarketTo(document.querySelector('.atlas-stage'));
      return;
    }
    const i = Number(S.cityView), city = S.cityView != null ? CITIES[i] : null, cell = S.cityCell;
    const data = { key: x.key, city: city?.name, cell };
    if (action === 'legacy-sponsor')
      data.amount = document.getElementById('legacy-sponsor-amount')?.value;
    if (action === 'legacy-district') {
      data.key = document.getElementById('legacy-district-style')?.value;
      data.name = document.getElementById('legacy-district-name')?.value;
    }
    if (action === 'legacy-sign') {
      data.name = document.getElementById('legacy-sign-name')?.value;
      data.logo = document.getElementById('legacy-sign-logo')?.value;
    }
    const result = legacyAction(S, action.slice(7), data, { CITIES, PR, IN });
    if (!result.ok) {
      const l = legacyState(S);
      l.notice = result.reason;
      S.legacy = l;
    }
    else
      log(result.message);
    game.draw();
    save();
  }
}
