import { PR as PRODUCT_CATALOG } from '../../../data/catalog.js';
import { cleanUnitName } from '../../../engine/unit-names.js';
import { expectedProductNeed } from '../../products/model/product-automation.js';
export const STYLES = {
  garden: { name: 'باغ‌شهر', cost: 450, wall: '#b8cfaa', roof: '#577e62', ground: '#b6ce96' }, traditional: { name: 'سنتی', cost: 400, wall: '#d8b58b', roof: '#ae7658', ground: '#d3c49c' }, workers: { name: 'محله کارگری', cost: 350, wall: '#c3c7ba', roof: '#7c8d8a', ground: '#b5c0aa' }, modern: { name: 'مرکز مدرن', cost: 1000, wall: '#bdd8dd', roof: '#3d7684', ground: '#b3cfcd', award: 'profit' }, coastal: {
    name: 'گردشگاه ساحلی', cost: 850, wall: '#e8d8b0', roof: '#4d9aa5', ground: '#d0ddc0', award: 'export'
  }
};
const decor = (name, kind, cost, style) => ({ name, kind, cost, style, days: 0 });
export const DECORATIONS = {
  tree: decor('درخت سایه‌دار', 'tree', 180, 'garden'), flowers: decor('باغچه گل', 'flowers', 130, 'garden'), bench: decor('نیمکت محله', 'bench', 100, 'garden'), lamp: decor('چراغ خیابان', 'lamp', 220, 'garden'), fountain: decor('آب‌نمای کوچک', 'fountain', 650, 'garden'), arch: decor('طاق ورودی', 'arch', 600, 'traditional'), palm: decor('نخل زینتی', 'palm', 260, 'traditional'), mosaic: decor('کف‌سازی نقش‌دار', 'path', 280, 'traditional'), teahouse: decor('کوشک چای', 'pavilion', 750, 'traditional'), lantern: decor('فانوس میدان', 'lamp', 240, 'traditional'), sculpture: decor('اثر هنری شهری', 'statue', 800, 'modern'), bikes: decor('جایگاه دوچرخه', 'bike', 350, 'modern'), planter: decor('گلدان شهری', 'flowers', 300, 'modern'), solar: decor('چراغ خورشیدی', 'solar', 520, 'modern'), walk: decor('مسیر پیاده‌روی', 'path', 420, 'modern'), waterTrophy: { ...decor('آب‌نمای پایداری', 'fountain', 0, 'special'), award: 'water', unique: true }, exportTrophy: { ...decor('تندیس اولین صادرات', 'statue', 0, 'special'), award: 'export', unique: true }, century: { ...decor('یادمان روز صدم', 'monument', 0, 'special'), award: 'century', unique: true }, builder: { ...decor('تندیس سازندگی', 'arch', 0, 'special'), order: 'materials', unique: true }
};
export const LANDMARKS = {
  centralpark: {
    name: 'پارک مرکزی', kind: 'park', cost: 6000, days: 3, description: 'فضای سبز شاخص با اثر محدود بر جذابیت محله.'
  }, stadium: {
    name: 'مجموعه ورزشی', kind: 'stadium', cost: 12000, days: 5, description: 'پروژه بزرگ محله برای تفریح شهروندان.'
  }, museum: {
    name: 'موزه صنعت', kind: 'museum', cost: 18000, days: 6, description: 'نمایش دستاوردهای صنعت و کشور.'
  }, university: {
    name: 'دانشگاه', kind: 'university', cost: 30000, days: 8, description: 'بنای آموزشی شاخص؛ کنترلر و فناوری رایگان نمی‌دهد.'
  }, promenade: {
    name: 'گردشگاه بندر', kind: 'promenade', cost: 9000, days: 4, coastal: true, description: 'پروژه گردشگری ویژه بندر جنوبی.'
  }
};
export const ACHIEVEMENTS = {
  first: {
    name: 'اولین راه‌اندازی', goal: 1, description: 'یک واحد به بهره‌برداری برسد.', reward: 600, account: 'govBudget'
  }, water: {
    name: 'آب پایدار', goal: 5, description: 'پنج روز تأمین کامل آب با مصرف واقعی کشور؛ روزها لازم نیست پشت سر هم باشند.', reward: 1000, account: 'govBudget', unlock: 'آب‌نمای پایداری'
  }, profit: {
    name: 'جریان نقد رو به رشد', goal: 5, description: 'پنج روز افزایش نقد پایان روز با حداقل یک واحد فعال.', reward: 1200, account: 'money', unlock: 'سبک مدرن'
  }, export: {
    name: 'اولین صادرات صنعتی', goal: 1, description: 'فروش واقعی صادراتیِ محصول صنعتی یا تکمیل قرارداد صادراتی.', reward: 800, account: 'money', unlock: 'سبک ساحلی و تندیس صادرات'
  }, neighborhood: {
    name: 'محله رنگ می‌گیرد', goal: 5, description: 'پنج قطعه تزئینی فعال در شهرها بساز.', reward: 1500, account: 'govBudget'
  }, architecture: {
    name: 'افتتاح باشکوه', goal: 1, description: 'یک بنای شاخص تکمیل کن.', reward: 2000, account: 'govBudget'
  }, century: {
    name: 'صد روز سازندگی', goal: 100, description: 'به روز صدم بازی برس.', reward: 2500, account: 'govBudget', unlock: 'یادمان روز صدم'
  }, diverse: {
    name: 'صنعت متنوع', goal: 5, description: 'پنج نوع واحد صنعتی را هم‌زمان در سرویس داشته باش.', reward: 2500, account: 'money'
  }
};
export const ORDERS = {
  materials: {
    name: 'مصالح میدان شهر', product: 'cement', quantity: 20, price: 1.35, bonus: 250, unlock: 'تندیس سازندگی'
  }, fuel: { name: 'سوخت ناوگان خدمات', product: 'fuel', quantity: 25, price: 1.3, bonus: 200 }, steel: { name: 'فولاد مجموعه ورزشی', product: 'steel', quantity: 15, price: 1.3, bonus: 350 }
};
export const PALETTES = {
  teal: { name: 'فیروزه‌ای', cost: 0, steel: '#b5c9c6', dark: '#3e6c72', cream: '#d7cfab', accent: '#d9a768' }, navy: {
    name: 'آبی دریایی', cost: 900, steel: '#97b8cc', dark: '#294e70', cream: '#cdd8df', accent: '#d4b477'
  }, copper: { name: 'مسی', cost: 1100, steel: '#cdb19b', dark: '#725247', cream: '#e3ceb2', accent: '#d77d4b' }, sage: {
    name: 'سبز صنعتی', cost: 1000, steel: '#b8c8a0', dark: '#47735a', cream: '#dce2c7', accent: '#c5a75a'
  }
};
const num = (v, f = 0) => Number.isFinite(Number(v)) ? Number(v) : f, cl = (v, a, b) => Math.max(a, Math.min(b, num(v)));
export function legacyState(S) {
  const l = S.legacy || {}, raw = l.industry || {}, owned = Array.isArray(raw.owned) ? raw.owned.filter(k => Object.hasOwn(PALETTES, k)) : [];
  return {
    cities: l.cities || {}, awards: l.awards || {}, orders: l.orders || {}, counts: l.counts || { water: 0, profit: 0 }, industry: {
      palette: 'teal', garden: 0, office: 0, sign: false, name: 'محوطه صنعت', logo: 'gear', ...raw, owned: [...new Set(['teal', ...owned])]
    }, lastDay: l.lastDay, notice: l.notice || ''
  };
}
export function cityDesign(S, name) {
  const c = legacyState(S).cities[name] || {};
  return { districts: c.districts || {}, placements: c.placements || {} };
}
export const districtIndex = cell => Math.floor(Math.floor(cell / 9) / 3) * 3 + Math.floor((cell % 9) / 3);
export function districtDesign(S, name, cell) {
  const d = cityDesign(S, name).districts[districtIndex(cell)] || {};
  return {
    name: cleanUnitName(d.name) || 'محله ' + (districtIndex(cell) + 1), style: Object.hasOwn(STYLES, d.style) ? d.style : 'garden'
  };
}
export function placementDefinition(id) {
  return Object.hasOwn(DECORATIONS, id) ? DECORATIONS[id] : Object.hasOwn(LANDMARKS, id) ? LANDMARKS[id] : null;
}
export function appearanceBonus(S) {
  let count = 0, big = 0;
  for (const c of Object.values(legacyState(S).cities))
    for (const p of Object.values(c.placements || {})) {
      if (p.days > 0)
        continue;
      if (LANDMARKS[p.item])
        big += cl(p.level, 1, 3);
      else if (DECORATIONS[p.item])
        count++;
    }
  return Math.min(3, count * .08 + big * .4);
}
export function industryAppearance(S) {
  const a = legacyState(S).industry;
  return {
    ...a, garden: Math.floor(cl(a.garden, 0, 3)), office: Math.floor(cl(a.office, 0, 3)), palette: Object.hasOwn(PALETTES, a.palette) ? a.palette : 'teal', name: cleanUnitName(a.name) || 'محوطه صنعت', logo: ['gear', 'leaf', 'drop'].includes(a.logo) ? a.logo : 'gear'
  };
}
export function progressValues(S) {
  const l = legacyState(S);
  let decorCount = 0, landmarks = 0;
  for (const c of Object.values(l.cities))
    for (const p of Object.values(c.placements || {})) {
      if (p.days > 0)
        continue;
      if (LANDMARKS[p.item])
        landmarks++;
      else if (DECORATIONS[p.item])
        decorCount++;
    }
  const sold = Object.entries(S.marketDay || {}).some(([key, m]) => PRODUCT_CATALOG[key]?.[3] && m.sold > 0) || (S.productTrades || []).some(t => t.side === 'sell' && t.total > 0 && t.quantity > 0 && PRODUCT_CATALOG[t.product]?.[3]) || (S.tradeHistory || []).some(t => t.status === 'تحویل کامل' && (t.delivered || 0) > 0);
  return {
    first: (S.u || []).some(u => u.st === 'run') ? 1 : 0, water: l.counts.water || 0, profit: l.counts.profit || 0, export: sold ? 1 : 0, neighborhood: decorCount, architecture: landmarks, century: S.day || 1, diverse: new Set((S.u || []).filter(u => u.st === 'run').map(u => u.t)).size
  };
}
export function discoverAchievements(S) {
  const l = legacyState(S), v = progressValues(S);
  for (const [k, d] of Object.entries(ACHIEVEMENTS))
    if (v[k] >= d.goal && !Object.hasOwn(l.awards, k))
      l.awards[k] = { day: S.day, claimed: false };
  S.legacy = l;
  return l;
}
export function advanceLegacyDay(S) {
  const l = legacyState(S);
  if (l.lastDay === S.day)
    return;
  l.lastDay = S.day;
  for (const c of Object.values(l.cities))
    for (const p of Object.values(c.placements || {}))
      if (p.days > 0)
        p.days--;
  l.counts = { water: Math.max(0, num(l.counts.water)), profit: Math.max(0, num(l.counts.profit)) };
  if ((S.dem?.water || 0) > 0 && (S.fr?.water ?? 0) >= .98)
    l.counts.water++;
  if ((S.u || []).some(u => u.st === 'run') && S.cashDay?.day === S.day && S.cashDay.closing > S.cashDay.opening)
    l.counts.profit++;
  S.legacy = l;
  discoverAchievements(S);
}
const fail = (reason) => ({ ok: false, reason });
export function legacyAction(S, action, x, { CITIES = [], PR = {}, IN = [] } = {}) {
  let l = legacyState(S);
  const city = CITIES.find(c => c.name === x.city), cell = Number(x.cell), validCell = x.cell != null && x.cell !== '' && Number.isInteger(cell) && cell >= 0 && cell < 81;
  const finish = (message) => {
    l.notice = message;
    S.legacy = l;
    discoverAchievements(S);
    return { ok: true, message };
  };
  if (action === 'sponsor') {
    const amount = Math.floor(Number(x.amount));
    if (!Number.isFinite(amount) || amount <= 0 || S.money < amount)
      return fail('مبلغ مثبت و در حد نقد شرکت وارد کن.');
    S.money -= amount;
    S.govBudget = (S.govBudget || 0) + amount;
    return finish('کمک شرکت به بودجه عمومی منتقل شد؛ پول تازه و درآمد عملیاتی ایجاد نشد.');
  }
  if (action === 'claim') {
    const a = l.awards[x.key], d = Object.hasOwn(ACHIEVEMENTS, x.key) ? ACHIEVEMENTS[x.key] : null;
    if (!d || !a || a.claimed)
      return fail('پاداش آماده نیست یا قبلاً دریافت شده است.');
    a.claimed = true;
    S[d.account] = (S[d.account] || 0) + d.reward;
    return finish('پاداش «' + d.name + '» به ' + (d.account === 'money' ? 'نقد شرکت' : 'بودجه عمومی') + ' افزوده شد.');
  }
  if (action === 'order') {
    const d = Object.hasOwn(ORDERS, x.key) ? ORDERS[x.key] : null;
    if (!d || l.orders[x.key])
      return fail('این سفارش قبلاً تحویل شده است.');
    const need = expectedProductNeed(S, d.product, IN);
    if ((S.tanks?.[d.product] || 0) - d.quantity < need)
      return fail('موجودی کافی پس از حفظ نیاز برآوردی یک روز وجود ندارد.');
    if (!PR[d.product])
      return fail('کالا نامعتبر است.');
    const payment = d.quantity * PR[d.product][2] * d.price + d.bonus;
    S.tanks[d.product] -= d.quantity;
    S.money += payment;
    l.orders[x.key] = { day: S.day, payment };
    return finish('سفارش محلی تحویل شد؛ ' + Math.round(payment) + ' به نقد شرکت رسید. سفارش یک‌بارمصرف است.');
  }
  if (action === 'palette') {
    const p = Object.hasOwn(PALETTES, x.key) ? PALETTES[x.key] : null;
    if (!p)
      return fail('رنگ نامعتبر است.');
    if (!l.industry.owned.includes(x.key)) {
      if (S.money < p.cost)
        return fail('نقد شرکت کافی نیست.');
      S.money -= p.cost;
      l.industry.owned = [...l.industry.owned, x.key];
    }
    l.industry.palette = x.key;
    return finish('رنگ محوطه صنعت تغییر کرد؛ اثر عملیاتی ندارد.');
  }
  if (action === 'industry') {
    if (!['garden', 'office', 'sign'].includes(x.key))
      return fail('گزینه نامعتبر است.');
    const level = x.key === 'sign' ? (l.industry.sign ? 1 : 0) : Math.floor(cl(l.industry[x.key], 0, 3));
    if (level >= (x.key === 'sign' ? 1 : 3))
      return fail('این ارتقا تکمیل شده است.');
    const cost = x.key === 'sign' ? 450 : (x.key === 'office' ? 2000 : 1200) * (level + 1);
    if (S.money < cost)
      return fail('نقد شرکت کافی نیست.');
    S.money -= cost;
    l.industry[x.key] = x.key === 'sign' ? true : level + 1;
    return finish('ظاهر سایت ارتقا یافت؛ هزینه نگهداری روزانه ندارد.');
  }
  if (action === 'sign') {
    if (!l.industry.sign)
      return fail('ابتدا تابلوی اختصاصی را بساز.');
    l.industry.name = cleanUnitName(x.name) || 'محوطه صنعت';
    if (['gear', 'leaf', 'drop'].includes(x.logo))
      l.industry.logo = x.logo;
    return finish('نام و نشان تابلو ذخیره شد.');
  }
  if (!city || !validCell)
    return fail('ابتدا شهر و یک قطعه معتبر را انتخاب کن.');
  const c = cityDesign(S, city.name), p = c.placements[cell];
  if (action === 'district') {
    const style = Object.hasOwn(STYLES, x.key) ? STYLES[x.key] : null;
    if (!style || style.award && !l.awards[style.award])
      return fail('این سبک هنوز باز نشده است.');
    const index = districtIndex(cell), old = c.districts[index] || {};
    const cost = (old.style || 'garden') === x.key ? 0 : style.cost;
    if ((S.govBudget || 0) < cost)
      return fail('بودجه عمومی کافی نیست.');
    S.govBudget -= cost;
    c.districts[index] = { style: x.key, name: cleanUnitName(x.name) || old.name || 'محله ' + (index + 1) };
    l.cities[city.name] = c;
    return finish('نام و سبک محله ذخیره شد؛ ظاهر همه ۹ قطعه محله هماهنگ می‌شود.');
  }
  if (action === 'remove') {
    if (!p)
      return fail('این قطعه آیتمی ندارد.');
    delete c.placements[cell];
    l.cities[city.name] = c;
    return finish('آیتم جمع شد؛ هزینه برنمی‌گردد و می‌توان دوباره جای‌گذاری کرد.');
  }
  if (action === 'upgrade') {
    const d = p && LANDMARKS[p.item];
    if (!d || p.days > 0 || p.level >= 3)
      return fail('بنای تکمیل‌شده قابل ارتقا انتخاب کن.');
    const cost = d.cost * .6 * p.level;
    if ((S.govBudget || 0) < cost)
      return fail('بودجه عمومی کافی نیست.');
    S.govBudget -= cost;
    p.level++;
    p.days = d.days;
    l.cities[city.name] = c;
    return finish('ارتقای بنای شاخص شروع شد؛ اثر آن پس از تکمیل بازمی‌گردد.');
  }
  if (action === 'place') {
    const d = placementDefinition(x.key);
    if (!d || p)
      return fail('ابتدا قطعه بدون آیتم یا گزینه جمع‌کردن را انتخاب کن.');
    if (d.award && !l.awards[d.award] || d.order && !l.orders[d.order])
      return fail('پاداش لازم هنوز باز نشده است.');
    if (d.coastal && city.kind !== 'port')
      return fail('گردشگاه بندر فقط در شهر بندری ساخته می‌شود.');
    if (LANDMARKS[x.key] && S.cityMaps?.[city.name]?.[cell])
      return fail('بنای شاخص به قطعه بدون ساختمان نیاز دارد.');
    if (d.unique && Object.values(l.cities).some(c => Object.values(c.placements || {}).some(p => p.item === x.key)))
      return fail('این یادبود در کشور فقط یک نمونه دارد.');
    if ((S.govBudget || 0) < d.cost)
      return fail('بودجه عمومی کافی نیست.');
    S.govBudget -= d.cost;
    c.placements[cell] = { item: x.key, level: 1, days: d.days || 0 };
    l.cities[city.name] = c;
    return finish(d.days ? 'پروژه آغاز شد؛ تکمیل پس از ' + d.days + ' روز بازی.' : 'آیتم روی نقشه قرار گرفت؛ هزینه روزانه ندارد.');
  }
  return fail('اقدام نامعتبر است.');
}
