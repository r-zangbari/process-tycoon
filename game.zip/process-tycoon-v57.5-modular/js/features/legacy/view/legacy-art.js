import { placementDefinition, STYLES, PALETTES, industryAppearance } from '../model/legacy-development.js';
export function ornamentArt(item, level = 1, pending = false) {
  const d = placementDefinition(item);
  if (!d)
    return '';
  const color = d.style === 'traditional' ? '#c58b61' : d.style === 'modern' ? '#5b9db2' : '#60936c', k = d.kind;
  let art = '';
  if (pending)
    return '<path d="M-38 7L0-15 38 7 0 29Z" fill="#d7c09a" stroke="#a6895c"/><path d="M-25 4H25M-20 14H20M0 0V-58H45M30-58V-8" stroke="#c48d45" stroke-width="5" fill="none"/>';
  if (['tree', 'palm'].includes(k))
    art = `<path d="M0 10V-40" stroke="#95714f" stroke-width="7"/>${k === 'palm' ? '<path d="M0-38Q-30-63-37-30Q-14-44 0-38Q20-62 39-32Q17-44 0-38Q-6-70-20-57Q-9-45 0-38" fill="#51976e"/>' : '<ellipse cy="-40" rx="26" ry="27" fill="#679f70"/><ellipse cx="-13" cy="-46" rx="17" ry="18" fill="#8aba7e"/>'}`;
  else if (k === 'flowers')
    art = '<path d="M-32-3L0-17 32-3 0 13Z" fill="#aac28b" stroke="#668663"/>' + [-22, -10, 0, 12, 23].map((x, i) => `<circle cx="${x}" cy="${-9 + i % 2 * 6}" r="6" fill="${i % 2 ? '#dc9e87' : '#e2cd77'}"/>`).join('');
  else if (k === 'bench')
    art = '<path d="M-28-13H27V-2H-28ZM-28-33H27V-18H-28Z" fill="#bc9368" stroke="#82644b"/><path d="M-23-2V12M22-2V12M-24-19V-4M22-19V-4" stroke="#526f6e" stroke-width="4"/>';
  else if (['lamp', 'solar'].includes(k))
    art = `<path d="M0 12V-59H24" fill="none" stroke="#52736e" stroke-width="5"/><circle cx="22" cy="-55" r="10" fill="#f1d58f" stroke="#bba96d"/>${k === 'solar' ? '<path d="M-19-59L3-70 24-59 1-48Z" fill="#4d7e9e" stroke="#a9cccb"/>' : ''}`;
  else if (k === 'fountain')
    art = '<ellipse cy="6" rx="36" ry="18" fill="#99b9b8" stroke="#507c85" stroke-width="3"/><ellipse cy="1" rx="30" ry="12" fill="#71b0c0"/><path d="M0 1V-45M0-35Q-24-48-26-10M0-35Q24-48 26-10" fill="none" stroke="#afdce0" stroke-width="4"/><ellipse cy="-12" rx="14" ry="5" fill="#e1d9bf"/>';
  else if (k === 'path')
    art = '<path d="M-40 3L0-20 40 3 0 26Z" fill="#d6c9a3" stroke="#9d9b7e"/>' + [-20, 0, 20].map(x => `<path d="M${x - 10} 1L${x} -5 ${x + 10} 1 ${x} 7Z" fill="${color}"/>`).join('');
  else if (k === 'arch')
    art = '<path d="M-30 12V-46Q0-73 30-46V12H18V-38Q0-53-18-38V12Z" fill="#cfaf87" stroke="#a77d57" stroke-width="2"/>';
  else if (k === 'pavilion')
    art = '<path d="M-27 10V-27H27V10M-10-24V11M11-24V11" fill="#e6cda9" stroke="#ab8c62" stroke-width="4"/><path d="M-38-28L0-55 38-28Z" fill="#a97659"/><circle cy="-28" r="5" fill="#d8b876"/>';
  else if (k === 'bike')
    art = '<circle cx="-24" cy="-4" r="15" fill="none" stroke="#5d7e85" stroke-width="3"/><circle cx="25" cy="-4" r="15" fill="none" stroke="#5d7e85" stroke-width="3"/><path d="M-24-4L-9-29 9-4H-24M9-4L20-28 25-4M-13-29H-1M15-32H25" fill="none" stroke="#8eb896" stroke-width="4"/>';
  else if (['statue', 'monument'].includes(k))
    art = `<path d="M-25 12H25V-2H-25Z" fill="#9faeaa"/><path d="M-11-2L-5-49 8-65 15-6Z" fill="${color}" stroke="#557c76" stroke-width="2"/><circle cx="-2" cy="-69" r="9" fill="#d2ba87"/>`;
  else if (k === 'park')
    art = '<ellipse cy="4" rx="43" ry="23" fill="#97bd7b"/><path d="M-38 8L30-15M-30-14L30 13" stroke="#d8d1ab" stroke-width="7"/><path d="M-23-4V-30M26 7V-21" stroke="#94714c" stroke-width="4"/><circle cx="-23" cy="-32" r="14" fill="#4b8d62"/><circle cx="26" cy="-24" r="13" fill="#639e68"/>';
  else if (k === 'stadium')
    art = '<ellipse cy="-6" rx="45" ry="28" fill="#c4d5d1" stroke="#668781" stroke-width="3"/><ellipse cy="-10" rx="33" ry="18" fill="#74a77c"/><path d="M-12-23V3M-31-11H31M12-23V3" stroke="#dce4be" fill="none"/>';
  else if (k === 'promenade')
    art = '<path d="M-43 8L0-18 43 8 0 32Z" fill="#83b9c2"/><path d="M-39-2L0-26 39-2 0 22Z" fill="#d9c6a5"/><path d="M-28-11V-34M26 3V-20" stroke="#5b7b6b" stroke-width="4"/><circle cx="-28" cy="-36" r="9" fill="#eed18c"/>';
  else
    art = `<path d="M-36 12V-29H36V12Z" fill="#d8d1b6" stroke="#6b8a7a" stroke-width="2"/><path d="M-43-30L0-56 43-30Z" fill="${k === 'museum' ? '#be9666' : '#6f9b9e'}"/><path d="M-24-23V10M-8-23V10M8-23V10M24-23V10" stroke="#f2eedb" stroke-width="7"/>`;
  return `<g>${art}${level > 1 ? `<text x="35" y="18" text-anchor="middle" fill="#385d4a" font-size="15">${'★'.repeat(level)}</text>` : ''}</g>`;
}
export const itemPreview = (id, level = 1) => `<svg viewBox="-65 -95 130 135" role="img" aria-label="${placementDefinition(id)?.name || 'آیتم'}">${ornamentArt(id, level)}</svg>`;
export function styleArt(svg, style) {
  const p = STYLES[style] || STYLES.garden;
  return `<g style="color:${p.roof}">${svg.replaceAll('#d7a476', p.wall).replaceAll('#bc8660', p.wall).replaceAll('#895f54', p.roof).replaceAll('#a6614f', p.roof).replaceAll('#8dbcc0', p.wall).replaceAll('#4f8791', p.roof).replaceAll('#e2e1cd', p.wall).replaceAll('#d6c7a6', p.wall).replaceAll('#d9c7a8', p.wall).replaceAll('#b8c9c3', p.wall).replaceAll('#8b6b56', p.roof)}</g>`;
}
export function campusPaletteArt(svg, S) {
  const p = PALETTES[industryAppearance(S).palette];
  return svg.replaceAll('#b7cbca', p.steel).replaceAll('#b5ccce', p.steel).replaceAll('#7caeac', p.steel).replaceAll('#dfb36b', p.accent).replaceAll('#d8a65b', p.accent).replaceAll('#536d70', p.dark);
}
