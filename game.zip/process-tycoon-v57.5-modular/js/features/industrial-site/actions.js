// اکشن‌های نقشه صنعت (انتخاب واحد، صفحه‌بندی).
import { cl } from '../../core/format.js';
export function installIndustrialSiteActions(game) {
  const { S, save } = game;
  Object.assign(game.actions, {
    'site-page'(x) {
      game.ui.mapSheetOpen = false;
      const pages = Math.max(1, Math.ceil(S.u.length / 12));
      S.siteMapPage = cl((Number(S.siteMapPage) || 0) + Number(x.d || 0), 0, pages - 1);
    },
  });
  game.clickHandlers.push((e, b, x, i, a) => {
    if (a === 'campus-show') {
      game.ui.mapSheetOpen = true;
      game.draw();
      return true;
    }
    if (a === 'campus-select') {
      if (S.u[i]) {
        S.siteSelectedUnit = i;
        game.ui.mapSheetOpen = true;
      }
      game.draw();
      save();
      return true;
    }
    if (a === 'campus-locate') {
      S.siteMapPage = Math.floor(i / 12);
      game.draw();
      save();
      return true;
    }
    if (a === 'campus-manage') {
      S.tab = 'i';
      S.industrySection = ['build', 'ready'].includes(S.u[i]?.st) ? 'projects' : 'operations';
      S.expandedUnit = i;
      game.draw();
      save();
      document.getElementById('u' + i)?.scrollIntoView({ block: 'center' });
      return true;
    }
    return false;
  });
}
