// صفحه‌ی «نقشه صنعت».
import { renderIndustrySite } from './view/industry-view.js';
import { D } from '../../data/catalog.js';
import { fa } from '../../core/format.js';
export function installIndustrialSitePage(game) {
  const { S } = game;
  function viewIndustrialSite() {
    return renderIndustrySite(S, D, fa, game.ui.mapSheetOpen);
  }
  Object.assign(game, { viewIndustrialSite });
}
