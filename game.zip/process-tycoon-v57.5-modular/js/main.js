// امپراتوری فرایند — نقطه‌ی ورود. همه‌ی منطق در js/app و js/features است.
import { createGame } from './app/create-game.js';
createGame();
