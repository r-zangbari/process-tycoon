// داده‌های ثابت نقشه‌ی کشور: مناطق، شهرها، میادین دریایی و پیش‌فرض چیدمان شهر.
export const REGIONS = [['شمال غرب', 0, 0], ['شمال مرکزی', 1, 0], ['شمال شرق', 2, 0], ['غرب', 0, 1], ['مرکز', 1, 1], ['شرق', 2, 1], ['جنوب غرب', 0, 2], ['جنوب مرکزی', 1, 2], ['جنوب شرق', 2, 2]];
// v51.4: National background is north-up with a SOUTHERN coastline. Geographic
// markers are visual only; persistent city keys remain their original names.
export const CITIES = [
  { name: 'مرکز شمالی', x: 322, y: 112, region: 1, kind: 'city' },
  { name: 'پایتخت', x: 396, y: 248, region: 4, kind: 'capital' },
  { name: 'مرکز شرقی', x: 638, y: 214, region: 5, kind: 'city' },
  { name: 'بندر جنوبی', x: 452, y: 354, region: 7, kind: 'port' },
  { name: 'مرکز انرژی', x: 604, y: 300, region: 5, kind: 'industrial' }
];
export const CITY_PLOT_STORAGE = 'process-tycoon-city-plot-layout-v1';
export const CITY_PLOT_DEFAULTS = [[410.4, 59.6], [537.3, 82.6], [334.8, 97.9], [601.2, 136.9], [279.0, 137.6], [533.7, 160.6], [657.9, 175.1], [363.6, 175.9], [212.4, 179.7], [285.3, 198.8], [596.7, 209.5], [735.3, 210.3], [163.8, 260.7], [587.7, 260.7], [729.0, 260.7], [268.2, 261.5], [647.1, 296.7], [222.3, 297.4], [527.4, 306.6], [357.3, 312.7], [602.1, 337.2], [293.4, 338.0], [536.4, 380.0], [406.8, 421.3]];
export const clampCityCoord = (v, max) => Math.round(Math.min(max, Math.max(0, Number(v) || 0)) * 10) / 10;
