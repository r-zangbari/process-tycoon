// کنترل‌های select/input سراسری.
import { PR } from '../data/catalog.js';
export function installFormControls(game) {
  const { S, save } = game;
  document.addEventListener('change', e => {
    if (e.target.id === 'legacy-item') {
      S.legacyItem = e.target.value;
      game.draw();
      save();
    }
    if (e.target.id === 'legacy-city') {
      S.legacyCity = Number(e.target.value);
      game.draw();
      save();
    }
    if (e.target.id === 'project-type') {
      S.projectType = Number(e.target.value);
      game.draw();
      save();
    }
    if (e.target.id === 'market-cash-unit') {
      S.marketCashUnit = Number(e.target.value);
      game.draw();
      save();
    }
    if (e.target.id === 'market-product' && Object.hasOwn(PR, e.target.value)) {
      S.marketProduct = e.target.value;
      game.draw();
      save();
    }
    if (e.target.id === 'market-quantity') {
      const value = Number(e.target.value);
      S.marketQuantity = Number.isFinite(value) && value > 0 ? value : 0;
      game.draw();
      save();
    }
  });
  document.addEventListener('input', e => {
    if (e.target.id === 'market-quantity') {
      const v = Number(e.target.value);
      S.marketQuantity = Number.isFinite(v) && v > 0 ? v : 0;
      game.draw();
    }
  });
}
