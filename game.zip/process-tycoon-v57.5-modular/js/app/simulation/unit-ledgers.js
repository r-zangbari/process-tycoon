import { D, OPN, PR } from '../../data/catalog.js';
import { analyzeUnit } from '../../features/maintenance/model/unit-diagnostics.js';

export function settleUnitLedgers(S, log) {
  S.u.forEach((u, i) => {
    if (u.st === 'run' && u.out) {
      let rv = 0;
      for (const p in u.out) rv += u.out[p] * ((S.rp || {})[p] || 0);
      const x = rv - u.cst;
      u.pl = u.pl == null ? x : 0.8 * u.pl + 0.2 * x;
      const ledger = u.dayEconomics;
      if (ledger?.day === S.day) {
        ledger.revenue = rv;
        ledger.totalCost = u.cst;
        ledger.profit = x;
        ledger.smoothedProfit = u.pl;
        ledger.port = {
          capacity: S.port,
          used: S.portUsedToday,
          remaining: S.portRemainingToday,
          feedUsed: S.feedPortUsedToday
        };
        ledger.market = structuredClone(S.marketDay || {});
        ledger.products.forEach((p) => {
          p.unitValue = (S.rp || {})[p.product] || 0;
          p.value = p.accepted * p.unitValue;
          p.valuation = S.hold?.[p.product] && PR[p.product][3] ? 'inventory' : 'allocated';
        });
      }
      if (
        x < 0 &&
        (u.lastDailyProfit == null || u.lastDailyProfit >= 0) &&
        (!u.lastLossAlertDay || S.day - u.lastLossAlertDay >= 5)
      ) {
        const report = analyzeUnit(S, i, { D, PR, OPN });
        log(
          'هشدار زیان «' +
            D[u.t].n +
            '»: ' +
            (report.primary?.title || 'درآمد کمتر از هزینه') +
            '؛ تحلیل و راه رفع در مشاور بحران.'
        );
        u.lastLossAlertDay = S.day;
      }
      u.lastDailyProfit = x;
    } else if (u.st !== 'run') u.pl = null;
  });
}
