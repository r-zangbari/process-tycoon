// رویدادهای اقتصادی روزانه: رویداد تصادفی، اقتصاد منطقه‌ای و اقتصاد پویای ملی.
import { GH, GW, TY } from '../../data/catalog.js';
import { CITIES, REGIONS } from '../../data/world-map.js';
import { cl, fa } from '../../core/format.js';
export function installEconomyEvents(game) {
  const { S, log, r } = game;
  const EV = () => {
    const x = r();
    if (x < .3 && !S.offers.length) {
      S.offers.push({ t: 'exp', txt: 'پیشنهاد قرارداد صادراتی: ۲۰ روز درآمد ×۱٫۳', d: 12 });
      log('پیشنهاد قرارداد صادراتی رسید.');
    }
    else if (x < .55 && !S.offers.length) {
      S.offers.push({ t: 'strike', txt: 'نیروها تهدید به اعتصاب کرده‌اند. با پرداخت ۱۵۰۰ مذاکره می‌کنید؟', d: 8 });
      log('تهدید به اعتصاب!');
    }
    else if (x < .8) {
      S.fx.sanc = 15;
      log('تحریم جدید برای ۱۵ روز: قیمت صادرات ×۰٫۷، واردات خارجی ×۱٫۲۵ و ظرفیت قابل استفاده پایانه ۶۵٪.');
    }
    else {
      S.fx.spike = 12;
      log('جهش قیمت جهانی: ۱۲ روز ×۱٫۴.');
    }
  };
  function regionCells(rx, ry) {
    const cells = [];
    for (let y = Math.floor(ry * GH / 3); y < Math.floor((ry + 1) * GH / 3); y++)
      for (let x = Math.floor(rx * GW / 3); x < Math.floor((rx + 1) * GW / 3); x++)
        cells.push(y * GW + x);
    return cells;
  }
  function regionMetrics(index) {
    const [name, rx, ry] = REGIONS[index], cells = regionCells(rx, ry), built = cells.filter(i => S.grid[i]), available = cells.filter(i => !S.grid[i] && buildable(i)).length;
    let connected = 0, total = 0;
    built.forEach(i => {
      const b = S.grid[i], need = Object.keys(TY[b.t]?.need || {});
      if (!need.length)
        return;
      need.forEach(k => {
        total++;
        if (b.c?.[k])
          connected++;
      });
    });
    const coverage = total ? connected / total * 100 : 100, state = S.regions?.[index] || {}, level = state.investment || 0, infra = state.infrastructure || {}, infraTotal = ['power', 'gas', 'water', 'roads'].reduce((a, k) => a + cl(Number(infra[k]) || 0, 0, 3), 0), infraAvg = infraTotal / 4, density = built.length / cells.length * 100;
    return {
      name, cells, built: built.length, available, coverage, level, density, infra, infraAvg, index: cl(coverage * .48 + Math.min(100, density * 3) * .12 + level * 5.5 + infraAvg * 5.5, 0, 100), satisfaction: state.satisfaction ?? 70
    };
  }
  function updateRegionalEconomy() {
    if (S.day % 30 !== 0)
      return;
    S.regions = S.regions || {};
    let totalDelta = 0;
    REGIONS.forEach((_, i) => {
      const m = regionMetrics(i), state = S.regions[i] || (S.regions[i] = { investment: 0, satisfaction: 70 });
      const serviceShortage = 1 - (S.fr?.power ?? 1) * .25 - (S.fr?.gas ?? 1) * .25 - (S.fr?.water ?? 1) * .25 - (S.fr?.fuel ?? 1) * .25;
      const infraAvg = ['power', 'gas', 'water', 'roads'].reduce((a, k) => a + cl(Number(state.infrastructure?.[k]) || 0, 0, 3), 0) / 4;
      const city = CITIES.find(c => c.region === i), cityLevel = city ? (Number(S.cities?.[city.name]?.level) || 0) : 0;
      const delta = cl((m.coverage - 75) * .018 + (state.investment || 0) * .12 + infraAvg * .24 + cityLevel * .08 - serviceShortage * 2.2, -2.5, 1.8);
      state.satisfaction = cl((state.satisfaction ?? 70) + delta, 0, 100);
      totalDelta += delta;
    });
    S.sat = cl((S.sat || 70) + totalDelta / REGIONS.length * .18, 0, 100);
  }
  function updateDynamicEconomy() {
    const e = S.economy || (S.economy = { inflation: 100, unemployment: 8, employment: 0, stability: 75, shock: null, relief: 0 });
    if (!Number.isFinite(e.inflation))
      e.inflation = 100;
    if (!Number.isFinite(e.unemployment))
      e.unemployment = 8;
    if (!Number.isFinite(e.stability))
      e.stability = 75;
    if (e.shock && e.shock.days > 0 && --e.shock.days === 0) {
      log('بحران اقتصادی «' + e.shock.name + '» پایان یافت.');
      e.shock = null;
    }
    if (S.day % 30 !== 0)
      return;
    const needs = ['power', 'gas', 'water', 'fuel'].filter(k => (S.dem?.[k] || 0) > 0);
    const shortage = needs.length ? needs.reduce((a, k) => a + cl(1 - (S.fr?.[k] ?? 1), 0, 1), 0) / needs.length : 0;
    const running = S.u.filter(u => u.st === 'run').length, total = Math.max(1, S.u.length);
    const employment = cl(35 + running / total * 45 + (S.eng || 0) * 2 + (S.nationalProjects?.petrochem || 0), 0, 95);
    e.employment = Math.round(employment * 10) / 10;
    e.unemployment = cl(100 - employment, 3, 35);
    const fiscalPressure = cl(((S.govRate || 1) - 1) * .65, -.4, .5);
    const shockPressure = e.shock?.type === 'supply' ? .45 : e.shock?.type === 'demand' ? .15 : 0;
    const inflationDelta = cl(0.12 + shortage * 1.8 + fiscalPressure + shockPressure - (e.stability / 100) * .22, -.35, 2.4);
    e.inflation = cl(e.inflation + inflationDelta, 75, 220);
    const satDelta = (.35 - shortage * 5 - (e.inflation > 125 ? .55 : 0) - (e.unemployment > 20 ? .45 : 0) + (e.relief > 0 ? .8 : 0));
    S.sat = cl((S.sat || 70) + satDelta, 0, 100);
    e.stability = cl(e.stability + (.2 - shortage * 3 - (e.inflation > 140 ? .7 : 0) + (S.sat > 70 ? .15 : 0)), 0, 100);
    if (e.relief > 0)
      e.relief--;
    if (!e.shock && r() < .12) {
      const type = r() < .55 ? 'supply' : 'demand';
      e.shock = { type, name: type === 'supply' ? 'اختلال زنجیره تأمین' : 'رکود تقاضا', days: 18 };
      log('بحران اقتصادی: ' + e.shock.name + '؛ فشار بر قیمت‌ها و فعالیت اقتصادی برای ۱۸ روز.');
    }
    if (e.inflation > 150)
      log('هشدار اقتصاد ملی: تورم بالا هزینه‌های عملیاتی و فشار معیشتی را افزایش داده است.');
    if (shortage > .25)
      log('هشدار اقتصاد ملی: کمبود خدمات انرژی/آب به ' + fa(Math.round(shortage * 100)) + '٪ رسیده و رضایت عمومی تحت فشار است.');
  }
  const buildable = i => Number.isInteger(i) && i >= 0 && i < S.grid.length;
  Object.assign(game, { EV, buildable, regionMetrics, updateDynamicEconomy, updateRegionalEconomy });
}
