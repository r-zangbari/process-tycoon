// ترتیب ثبت وقایع و تسویهٔ هر روز بازی در این فایل مشخص است.
import { normalizeState } from '../../core/game-state.js';
import { D, GH, GW, IMP, IN, MK, OPN, OPT, OUT, PR, TECHN, setImportMultiplier } from '../../data/catalog.js';
import { advanceStoryCrisis, settleDevelopment } from '../../features/development/model/development.js';
import { advanceOffshoreProjects, simulateOffshoreDay } from '../../features/offshore/model/offshore.js';
import { advancePartOrders, runAutoMaintenance } from '../../features/maintenance/model/auto-maintenance.js';
import { simulateWaterDay } from '../../features/water/model/water-supply.js';
import {
  automationSettings,
  runProductAutomation
} from '../../features/products/model/product-automation.js';
import { reviewSafetyDay } from '../../features/safety/model/safety.js';
import { advanceMilitaryDay } from '../../features/military/model/military.js';
import { closeCashDay } from '../../features/products/model/cash-clarity.js';
import { advanceLegacyDay } from '../../features/legacy/model/legacy-development.js';
import { cl, fa } from '../../core/format.js';
import { settleExportContracts } from './export-contracts.js';
import { operateUnits } from './operate-units.js';
import { settleUnitLedgers } from './unit-ledgers.js';

export function installDailyTick(game) {
  const { S, cap, country, log, r, recordSOE } = game;
  function tick() {
    normalizeState(S, { setImportMultiplier, D, PR, MK, GW, GH });
    const openingCash = S.money;
    S.day++;
    advanceStoryCrisis(S, r, log);
    // Resolve timed changes before calculating capacity, stock and daily income.
    advanceMilitaryDay(S, log);
    // Advance field development, pipelines, integrity work and assisted-recovery projects.
    advanceOffshoreProjects(S, log);
    advancePartOrders(S, D, log);
    const contractPort = settleExportContracts(S, log);
    runAutoMaintenance(S, {
      D,
      PR,
      OPN,
      IN,
      OPT,
      importMultiplier: () => IMP,
      availableOperators: game.opsAvail,
      remainingPort: () => contractPort,
      log,
      recordSOE,
      random: r
    });
    let availablePortForFeed = contractPort;
    S.feedPortUsedToday = 0;
    S.pd = {};
    S.prodLoss = {};
    S.cs = {};
    S.imp = {};
    S.ic = {};
    S.imc = 0;
    S.mkt = cl(S.mkt + (r() - 0.5) * 0.12, 0.6, 1.8);
    const inflationCost = cl(1 + ((S.economy?.inflation ?? 100) - 100) * 0.002, 0.9, 1.3),
      supplyShock = S.economy?.shock?.type === 'supply' ? 1.18 : 1;
    let net = -(S.ops * (S.sal || 12) + (S.eng || 0) * 40) * inflationCost + (S.tradeRevenueToday || 0);
    S.portRemainingToday = contractPort;
    S.portUsedToday = S.portCapacityToday - contractPort;
    S.marketDay = {};
    simulateWaterDay(S, { cap });
    runProductAutomation(S, { PR, cap, IN, OUT, importMultiplier: IMP });
    availablePortForFeed = S.portRemainingToday;
    let importCashBudget = Math.max(0, S.money - automationSettings(S).reserve);
    // Wellhead output fills a separate offshore buffer; pipelines carry feed to onshore tanks.
    S.offshoreOperatingCostToday = simulateOffshoreDay(S, cap, log, r, recordSOE);
    net -= S.offshoreOperatingCostToday;
    const running = game.opsNeed(),
      avail = game.opsAvail(),
      rt = running ? Math.min(1, avail / running) : 1,
      opF = (running && rt < 1 ? 0.4 + 0.6 * rt : 1) * (S.gridIncident?.days > 0 ? S.gridIncident.factor : 1),
      nz = Math.pow(0.85, S.tr) * (1 + (1 - rt) * 1.5) * ((S.tech || {}).apc ? 0.7 : 1);
    const fm =
      (S.fx.sanc ? 0.7 : 1) *
      (S.fx.spike ? 1.4 : 1) *
      (S.fx.exp ? 1.3 : 1) *
      (S.esg >= 70 ? 1.1 : S.esg < 40 ? 0.9 : 1) *
      (S.fx.rival ? 0.9 : 1);
    {
      const em = game.emission() * Math.pow(0.7, S.ab || 0);
      S.esg = S.esg + (cl(100 - em * 4, 0, 100) - S.esg) * 0.05;
      if (S.esg < 30 && S.day % 5 === 0) {
        S.money -= 500;
        log('جریمه‌ی زیست‌محیطی ۵۰۰ به‌خاطر نمره‌ی ESG پایین.');
      }
    }
    S.rv = S.rv.map(
      (w) => w * (1 + (0.004 + (r() - 0.4) * 0.012) * [0.6, 1, 1.4][S.diff == null ? 1 : S.diff])
    );
    if (r() < 0.01 && !S.fx.rival) {
      S.fx.rival = 10;
      log('رقیب قیمت‌شکنی کرد: قیمت صادرات ۱۰ روز ۱۰٪ کمتر.');
    }
    S.mor = cl(
      S.mor +
        (0.25 -
          (1 - rt) * 2.5 -
          (S.sat < 50 ? 0.5 : 0) -
          (S.safe < 60 ? 0.5 : 0) -
          (S.fx.strike ? 0.5 : 0) +
          (S.mor < 80 ? 0.15 : 0)),
      0,
      100
    );
    if (S.walk) {
      if (--S.walk.d <= 0) {
        S.walk = null;
        S.mor = Math.max(S.mor, 50);
        log('اپراتورها به کار برگشتند.');
      }
    } else if (S.mor < 35 && running && r() < (35 - S.mor) / 60 + 0.03) {
      S.walk = { d: 4 + Math.floor(r() * 4), f: 0.4 + r() * 0.5, c: 0 };
      log('اپراتورها به‌خاطر نارضایتی دست از کار کشیدند! (چند روز)');
    }
    const operations = operateUnits(game, {
      running,
      avail,
      rt,
      opF,
      nz,
      inflationCost,
      supplyShock,
      availablePortForFeed,
      importCashBudget,
      net
    });
    net = operations.net;
    availablePortForFeed = operations.availablePortForFeed;
    const intr = S.financialGraceDays > 0 ? 0 : (S.debt || 0) * 0.004;
    if (S.financialGraceDays > 0) S.financialGraceDays--;
    const nationalIncome = country(fm, availablePortForFeed);
    const govBase = Math.max(
      0,
      (S.inc?.tax || 0) +
        (S.inc?.ex || 0) * 0.08 +
        (S.inc?.ct || 0) * 0.08 +
        (S.tradeRevenueToday || 0) * 0.08
    );
    const govTransfer = govBase * cl(Number(S.govRate) || 1, 0.5, 1.5);
    S.govIncomeToday = govTransfer;
    S.govBudget = Math.max(0, (S.govBudget || 0) + govTransfer);
    net += nationalIncome - govTransfer - intr + game.pinc() - (S.adv ? 15 : 0);
    S.money += net;
    game.updateDynamicEconomy();
    game.updateRegionalEconomy();
    if (S.money < 0 && S.day % 15 === 0)
      log('سرمایه منفی است؛ از بخش «بانک و وام» وام بگیرید یا خرابی‌ها را سریع تعمیر کنید.');
    ['sanc', 'spike', 'exp', 'strike', 'rival'].forEach((k) => {
      if (S.fx[k] && --S.fx[k] <= 0) delete S.fx[k];
    });
    S.offers = S.offers.filter(
      (o) =>
        --o.d > 0 ||
        (o.t === 'strike' && ((S.fx.strike = 8), log('مهلت مذاکره تمام شد؛ اعتصاب شروع شد.'), false))
    );
    if (r() < 0.03) game.EV();
    if (S.rd && --S.rd.d <= 0) {
      (S.tech = S.tech || {})[S.rd.k] = 1;
      log('تحقیق «' + TECHN[S.rd.k] + '» کامل شد!');
      S.rd = null;
    }
    S.co = (S.co || []).filter(
      (c) => --c.x > 0 && !(r() < 0.04 && (log('رقیب پیشنهاد قرارداد ' + PR[c.p][0] + ' را از شما گرفت.'), 1))
    );
    if (r() < 0.05 && S.co.length < 2) {
      const ps = ['methanol', 'ethylene', 'sulfur'],
        p = ps[Math.floor(r() * 3)],
        q = [8, 15, 25][Math.floor(r() * 3)];
      S.co.push({ p, q, d: 30, pr: 1.25, pen: 1.5, x: 10 });
      log('پیشنهاد قرارداد بلندمدت ' + PR[p][0] + ' رسید.');
    }
    if (S.personnel?.injuryDays > 0 && --S.personnel.injuryDays === 0) {
      recordSOE('اپراتور آسیب‌دیده پس از دوره درمان به کار بازگشت.', 'INFO');
      log('اپراتور آسیب‌دیده پس از تکمیل دوره درمان به کار بازگشت.');
    }
    if (S.gridIncident?.days > 0 && --S.gridIncident.days <= 0) {
      S.gridIncident = null;
      recordSOE('تأمین برق شبکه به حالت عادی بازگشت.', 'INFO');
      log('اختلال برق شبکه برطرف شد.');
    }
    if (S.cr && --S.cr.d <= 0) game.resolveCr(null);
    if (!S.cr && r() < 0.025) {
      const ru = S.u.map((u, i) => i).filter((i) => S.u[i].st === 'run');
      if (ru.length) {
        const ui = ru[Math.floor(r() * ru.length)],
          types = ['feed', 'cooling', 'rotating', 'instrument', 'grid', 'leak', 'flood'];
        let k = types[Math.floor(r() * types.length)];
        if (D[S.u[ui].t].nuc && r() < 0.25) k = 'core';
        const unit = S.u[ui],
          def = D[unit.t];
        if (k === 'feed') unit.feedIncident = { days: 4, factor: 0.68 };
        if (k === 'cooling') unit.coolingIncident = { days: 4, offset: 0.72 };
        if (k === 'instrument') {
          const vi = Math.floor(r() * def.v.length);
          unit.instrumentIncident = { days: 4, k: vi, bias: 0.65 };
        }
        if (k === 'rotating') {
          const pi = unit.eq.findIndex((e, j) =>
            /پمپ|pump|کمپرسور|compressor/i.test(String(def.e[j]?.[0] || ''))
          );
          if (pi >= 0) {
            unit.incidentEquipment = pi;
            unit.eq[pi].h = Math.max(0, unit.eq[pi].h - 22);
          }
        }
        if (k === 'grid') S.gridIncident = { days: 3, factor: 0.68 };
        S.cr = { k, i: ui, d: 3 };
        recordSOE('شروع رخداد: ' + game.CR[k].t, 'HIGH', ui);
        log('رخداد عملیاتی: ' + game.CR[k].t + ' در «' + def.n + '».');
      }
    }
    if (S.day % 60 === 0) {
      if (S.safe >= 70) {
        S.money += 2000;
        log('ممیزی ایمنی: عالی؛ جایزه ۲٬۰۰۰.');
      } else {
        S.money -= 1500;
        log('ممیزی ایمنی: جریمه ۱٬۵۰۰ به‌خاطر نمره‌ی ایمنی پایین.');
      }
    }
    settleUnitLedgers(S, log);
    game.MS.forEach(([k, , , nd, rw, f]) => {
      const m = (S.ms[k] = S.ms[k] || { p: 0, done: 0 });
      if (!m.done && f() && ++m.p >= nd) {
        m.done = 1;
        S.money += rw;
        log('مأموریت انجام شد: ' + game.MS.find((q) => q[0] === k)[1] + ' (جایزه ' + fa(rw) + ')');
      }
    });
    reviewSafetyDay(S, { D, availableOperators: game.opsAvail(), requiredOperators: game.opsNeed() });
    settleDevelopment(S, log);
    closeCashDay(S, openingCash);
    advanceLegacyDay(S);
    S.mh.push(Math.round(S.money));
    if (S.mh.length > 80) S.mh.shift();
    if (!S.won && S.money >= 250000 && new Set(S.u.filter((u) => u.st === 'run').map((u) => u.t)).size >= 5) {
      S.won = true;
      log('تبریک! امپراتوری فرایند شما شکل گرفت. می‌توانید ادامه دهید.');
    }
    if (S.diagnosticPauseDay && S.day >= S.diagnosticPauseDay) {
      S.paused = true;
      delete S.diagnosticPauseDay;
      log('یک روز داده عملیاتی ثبت شد؛ زمان برای بررسی مشاور متوقف شد.');
    }
    if (S.money < -5000) log('هشدار: بدهی سنگین است؛ واحدهای سودده را حفظ کنید.');
  }
  Object.assign(game, { tick });
}
