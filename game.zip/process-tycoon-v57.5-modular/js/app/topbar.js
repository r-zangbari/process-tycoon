// دکمه‌های نوار بالا: پشتیبان‌گیری، بازیابی، سختی، صدا، توقف، سرعت، شروع دوباره.
import { D, GH, GW, MK, PR, setImportMultiplier } from '../data/catalog.js';
import { createFreshState, normalizeState } from '../core/game-state.js';
import { exportSnapshot, importSnapshot, prepareSnapshot } from '../core/save-store.js';
import { GAME_VERSION } from '../core/version.js';
import { $ } from '../core/format.js';
export function installTopbar(game) {
  const { S, replaceState, save } = game;
  function restore(candidate) {
    candidate.paused = true;
    delete candidate.diagnosticPauseDay;
    candidate.cityView = null;
    candidate.offshoreView = false;
    candidate.offshoreSelected = null;
    if (!save(candidate)) throw Error('ذخیرهٔ فعلی عوض نشد. وضعیت ذخیره را در بالای صفحه بررسی کن.');
    replaceState(candidate);
    game.draw();
  }

  $('#exportSave').onclick = () => {
    const payload = exportSnapshot(S);
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }), url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `process-tycoon-save-day-${S.day}-v${GAME_VERSION}.json`;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
  };
  $('#importSaveBtn').onclick = () => $('#importSaveInput').click();
  $('#importSaveInput').onchange = async (event) => {
    const input = event.target, file = input.files?.[0];
    if (!file)
      return;
    try {
      const candidate = importSnapshot(await file.text());
      if (game.canPlay && window.confirm('وضعیت کنونی بازی با فایل پشتیبان جایگزین شود؟'))
        restore(candidate);
    }
    catch (error) {
      window.alert('بازیابی انجام نشد: ' + (error?.message || 'خطای خواندن فایل'));
    }
    finally {
      input.value = '';
    }
  };
  $('#restorePrevious').onclick = () => {
    if (!game.canPlay) return;
    try {
      const candidate = game.readPreviousSave();
      if (!candidate) throw Error('ذخیرهٔ قبلی قابل خواندن نیست.');
      if (window.confirm('ذخیرهٔ سالم قبلی بازیابی شود؟'))
        restore(candidate);
    } catch (error) {
      window.alert('بازیابی انجام نشد. ' + error.message);
    }
  };
  $('#diff').onclick = () => {
    S.diff = ((S.diff == null ? 1 : S.diff) + 1) % 3;
    normalizeState(S, { setImportMultiplier, D, PR, MK, GW, GH });
    game.draw();
    save();
  };
  $('#snd').onclick = () => {
    S.mute = !S.mute;
    game.draw();
    save();
  };
  game.togglePause = () => {
    S.paused = !S.paused;
    if (S.paused) delete S.diagnosticPauseDay;
    game.clock.resetElapsed();
  };
  $('#pause').onclick = () => {
    if (!game.canPlay) return;
    game.togglePause();
    game.draw();
    save();
  };
  $('#spd').onclick = () => {
    S.spd = S.spd === 4 ? 1 : S.spd * 2;
    game.clock.resetElapsed();
    game.draw();
    save();
  };
  let rc = 0;
  $('#reset').onclick = () => {
    if (!game.canPlay) return;
    const b = $('#reset');
    if (!rc) {
      b.textContent = 'تأیید شروع دوباره؟';
      rc = setTimeout(() => {
        rc = 0;
        b.textContent = 'شروع دوباره';
      }, 3000);
      return;
    }
    clearTimeout(rc);
    rc = 0;
    b.textContent = 'شروع دوباره';
    const diff = S.diff ?? 1;
    const candidate = prepareSnapshot({ ...createFreshState(), diff, money: [8000, 5000, 3500][diff] });
    try {
      restore(candidate);
    } catch (error) {
      window.alert('شروع دوباره انجام نشد. ' + error.message);
    }
  };
}
