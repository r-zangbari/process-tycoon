// نگه‌داشتن بازرسم هنگام تعامل کاربر (اسکرول، درگ).
export function installInteractionHold(game) {
  const hd = e => {
    if (e.type === 'pointermove' && !e.buttons)
      return;
    if (e.target && e.target.closest && e.target.closest('.sk2,#mapbox,#country-three,#industry-three'))
      game.ui.hold = Date.now();
  };
  ['pointerdown', 'pointermove', 'pointerup', 'touchstart', 'touchmove', 'wheel'].forEach(t => document.addEventListener(t, hd, { capture: true, passive: true }));
  document.addEventListener('scroll', e => {
    if (e.target.classList && (e.target.classList.contains('sk2') || e.target.classList.contains('mimic-scroll')))
      game.ui.hold = Date.now();
  }, true);
  // Keep the live simulation from replacing the Mimic DOM during touch/drag and
  // momentum scrolling. Scroll position is also restored by the AP setter.
  const markMimicInteraction = e => {
    if (e.target?.closest?.('.mimic-scroll'))
      game.ui.hold = Date.now();
  };
  ['pointerdown', 'pointermove', 'touchstart', 'touchmove', 'wheel'].forEach(type => document.addEventListener(type, markMimicInteraction, { capture: true, passive: true }));
}
