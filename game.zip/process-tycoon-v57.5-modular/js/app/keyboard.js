// میان‌برهای کیبورد (Escape).
import { setTool } from '../features/military/model/military.js';
export function installKeyboard(game) {
  const { S } = game;
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape')
      return;
    if (S.tab === 'c' && S.military?.tool) {
      setTool(S, null);
      game.ui.countryNotice = '';
      game.draw();
      return;
    }
    if (game.ui.countryExpanded) {
      game.ui.countryExpanded = false;
      game.draw();
    }
  });
}
