// هسته‌ی بازی: ساخت state (S)، سرویس‌های پایه (ذخیره، لاگ، اقتصاد، تجهیزات، صدا) و شیء مشترک game.
// هر نمونه‌ی بازی با createGameContext() از نو ساخته می‌شود.
import { createSaveStore } from '../core/save-store.js';
import { D, IMP, IN, INF, MK, OUT, PR, PROB, SF, TECHN, TY, setImportMultiplier } from '../data/catalog.js';
import { createEconomy } from '../engine/economy.js';
import { createEquipmentTools } from '../engine/equipment.js';
import { createGameAudio } from '../features/audio/model/game-audio.js';
import { createIndustryActions } from '../features/industry/model/industry.js';
import { createProcessModel } from '../engine/process.js';
import { createPIDController } from '../features/control-room/model/pid-controller.js';
import { cl, fa } from '../core/format.js';
import { CITIES } from '../data/world-map.js';
export function createGameContext() {
  // v = [نام، واحد، هدف، نیم‌پهنای باند مجاز]   e = [نام تجهیز، دارای استندبای؟]
  // تولید روزانه‌ی هر واحد در حالت ایده‌آل، هم‌ترتیب با D
  // خوراک روزانه‌ی هر واحد (از مخزن خودتان برداشت می‌شود؛ کسری با قیمت واردات خریده می‌شود)
  const r = Math.random;
  const store = createSaveStore();
  const initial = store.read(), S = initial.state;
  function applyLoadedPreferences() {
    setImportMultiplier([1.2, 1.4, 1.7][S.diff] || 1.4);
    if (S.tab === 'offshore') {
      S.tab = 'c';
      S.offshoreView = true;
      S.cityView = null;
    }
  }
  applyLoadedPreferences();
  const economy = createEconomy({
    getState: () => S, PR, IN, OUT, IMP: () => IMP, fa, log: t => log(t)
  });
  const { cap, feedTxt, feedCost, prodTxt, pay } = economy;
  const equipment = createEquipmentTools({ D });
  const { level: lvl, partCost, isOut, anyOut } = equipment;
  const maintenanceCost = (u, d) => {
    const wear = (u.eq || []).reduce((a, e) => a + (100 - e.h) + (e.reserve ? 100 - e.reserve.h : 0), 0);
    return wear > 0 ? d.cost * .012 + wear * d.cost / 6500 : 0;
  };
  function showSaveStatus(result, day = S.day) {
    const el = document.getElementById('saveStatus');
    if (el) {
      const status = {
        saved: 'ذخیره شد · روز ' + fa(day),
        previous: 'ذخیرهٔ سالم قبلی بازیابی شد · روز ' + fa(day),
        damaged: 'ذخیرهٔ محلی ناخواناست؛ پشتیبان فایل را بازیابی کن',
        unavailable: 'ذخیره ناموفق؛ پشتیبان فایل بگیر'
      };
      el.textContent = status[result] || 'ذخیره خودکار';
      el.className = ['saved', 'previous'].includes(result) ? 'ok' : ['unavailable', 'damaged'].includes(result) ? 'bd' : '';
    }
    const previous = document.getElementById('restorePrevious');
    if (previous) previous.hidden = !store.hasPrevious();
  }
  const save = (state = S) => {
    if (!game.canPlay) return false;
    const result = store.write(state);
    if (result === 'conflict') {
      game.onSaveConflict?.();
      return false;
    }
    if (result === 'saved') game.onSaveWritten?.();
    showSaveStatus(result, state.day);
    return result === 'saved';
  };
  const gameAudio = createGameAudio({
    getState: () => S
  });
  const snd = t => gameAudio.message(t);
  const log = t => {
    snd(t);
    S.log.unshift('روز ' + fa(S.day) + ': ' + t);
    S.log.length = Math.min(S.log.length, 40);
  };
  const recordSOE = (message, severity = 'INFO', unitIndex = null) => {
    S.soe = Array.isArray(S.soe) ? S.soe : [];
    S.soe.unshift({ day: S.day, message, severity, unit: unitIndex == null ? '' : D[S.u[unitIndex]?.t]?.n || '' });
    S.soe.length = Math.min(S.soe.length, 60);
  };
  const A = createIndustryActions({
    S, D, INF, TECHN, PR, IMP: () => IMP, PROB, feedCost, partCost, pay, log, r, fa, anyOut
  });
  const processModel = createProcessModel({ S, TY, SF, PR, MK, cl, r, log });
  const pidController = createPIDController({ cl });
  const country = (fm, remainingPort) => processModel.country(fm, remainingPort, CITIES);
  const replaceState = next => {
    for (const key of Object.keys(S))
      delete S[key];
    Object.assign(S, next);
    applyLoadedPreferences();
    game.clock?.resetElapsed();
    return S;
  };
  function reloadSnapshot() {
    const snapshot = store.read();
    replaceState(snapshot.state);
    return snapshot.source;
  }
  const game = {
    S, replaceState, reloadSnapshot, showSaveStatus, initialSaveSource: initial.source,
    readPreviousSave: store.previous, saveChanged: store.changed, canPlay: false,
    r, log, recordSOE, cap, anyOut, pidController, lvl, country, partCost, prodTxt, feedTxt, feedCost, maintenanceCost, pay, save, A, processModel, gameAudio, ui: {
      mapSheetOpen: false, countryExpanded: false, countryNotice: '', cityMoveCell: null, cityBuildingDrag: null, cityClickSuppressUntil: 0, hmiSelectionCommit: false, renderedScreen: null, hold: 0
    }, actions: {}, clickHandlers: []
  };
  return game;
}
