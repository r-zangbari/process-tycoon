// کلیدهای ذخیرهٔ بازی با نام صفحه‌های داخلی نگاشت می‌شوند.
const screens = {
  i: (game) => game.viewIndustry(),
  site: (game) => game.viewIndustrialSite(),
  hmi: (game) => game.viewHMI(),
  m: (game) => game.viewManage(),
  c: (game) => game.viewCountry()
};

export function renderScreen(game) {
  const tab = game.S.tab;
  return (Object.hasOwn(screens, tab) ? screens[tab] : screens.i)(game);
}
