// مسیریاب مرکزی کلیک: دکمه‌های data-a را به handler هر بخش می‌رساند.
import { applyProcessDisturbance } from '../features/control-room/model/process-dynamics.js';
import { D } from '../data/catalog.js';
import { cl, f1 } from '../core/format.js';
export function installClickRouter(game) {
  const { A, S, log, save } = game;
  document.addEventListener('click', e => {
    if (e.target.closest('[data-go],[data-top]'))
      return;
    const g = e.target.closest('[data-go]');
    if (g) {
      const i = +g.dataset.go;
      S.flash = { i, t: Date.now() };
      game.draw();
      const el = document.getElementById('u' + i);
      if (el)
        el.scrollIntoView({
          behavior: matchMedia('(prefers-reduced-motion:reduce)').matches ? 'auto' : 'smooth', block: 'center'
        });
      return;
    }
    const tp = e.target.closest('[data-top]');
    if (tp) {
      const el = document.getElementById('sky');
      if (el)
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }
    if (e.target.closest('[data-c]'))
      return;
    const b = e.target.closest('button');
    if (!b || b.disabled || !b.dataset.a)
      return;
    const x = b.dataset, i = +x.i, a = x.a;
    for (const handle of game.clickHandlers)
      if (handle(e, b, x, i, a))
        return;
    if (game.actions[a]) {
      game.actions[a](x);
      game.draw();
      save();
      return;
    }
    if (a === 'disturb') {
      const key = `${i}:${+x.k}`, cfg = S.pid[key] || (S.pid[key] = { mode: 'manual', mv: 50 });
      const amount = applyProcessDisturbance(cfg, D[S.u[i].t].v[+x.k][3]);
      log(`اختلال آزمایشی به متغیر ${D[S.u[i].t].v[+x.k][0]} اعمال شد؛ پاسخ فرایند قابل مشاهده است.`);
    }
    else if (a === 'buy') {
      const before = S.u.length;
      A.buy(+x.t, document.getElementById('project-name-' + x.t)?.value);
      if (S.u.length > before) {
        S.industrySection = 'projects';
        S.expandedUnit = S.u.length - 1;
      }
    }
    else if (a === 'fix')
      A.fix(i, x.n === '1');
    else if (a === 'adj') {
      const key = `${i}:${+x.k}`, cfg = S.pid[key] || (S.pid[key] = { mode: 'manual', mv: 50, integral: 0, previousError: 0, output: 0 });
      if (cfg.mode !== 'auto') {
        cfg.mv = cl((Number(cfg.mv) || 50) + (+x.s) * 5, 0, 100);
        log(`خروجی دستی محرک ${D[S.u[i].t].v[+x.k][0]} به ${f1(cfg.mv)}٪ تغییر کرد.`);
      }
    }
    else if (a === 'up')
      A.up(i, +x.j);
    else if (a === 'part')
      A.part(i, +x.j, x.f === '1', x.role);
    else if (a === 'repair')
      A.repair(i, +x.j, x.role);
    else if (a === 'auto')
      A.auto(i, +x.k);
    else if (a === 'offer')
      A.offer(+x.o, x.y === '1');
    else
      A[a](i);
    game.draw();
    save();
  });
}
