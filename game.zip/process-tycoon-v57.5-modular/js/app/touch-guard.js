// محافظ لمس: جلوگیری از بازرسم هنگام لمس.
import { installTouchSafety } from '../ui-kit/touch-safety.js';
export function installTouchGuard(game) {
  const touchSafety = installTouchSafety(document, {
    onActivity: () => {
      game.ui.hold = Date.now();
    }
  });
  Object.assign(game, { touchSafety });
}
