import { createProcessClock } from '../engine/game-engine.js';
import { installSaveSession } from './save-session.js';

export function installStartup(game) {
  const { S, save } = game;
  let lastClockPaintDay = S.day;
  const clock = createProcessClock({
    tick: game.tick, getState: () => S, draw: () => {
      if (S.day !== lastClockPaintDay && !game.touchSafety.busy() && Date.now() - game.ui.hold > 900 && !document.activeElement?.matches?.('input,select,textarea')) {
        lastClockPaintDay = S.day;
        game.draw();
      }
    },
    save,
    onSuspend: () => {
      const pause = document.getElementById('pause');
      if (pause) pause.textContent = 'ادامه';
      const mapPause = document.querySelector('[data-a="country-pause"]');
      if (mapPause) mapPause.textContent = 'ادامهٔ زمان';
    }
  });
  game.clock = clock;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && game.canPlay) clock.suspend();
  });
  installSaveSession(game, clock);
}
