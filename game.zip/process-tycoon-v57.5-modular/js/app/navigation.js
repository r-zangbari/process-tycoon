// ناوبری بین تب‌ها.
export function installNavigation(game) {
  const { S } = game;
  Object.assign(game.actions, {
    tab(x) {
      game.ui.mapSheetOpen = false;
      game.ui.countryExpanded = false;
      game.ui.defenseSite = null;
      if (x.t === 'offshore') {
        S.tab = 'c';
        S.offshoreView = true;
        S.cityView = null;
        return;
      }
      S.tab = x.t;
      S.offshoreView = false;
      S.offshoreSelected = null;
    },
  });
}
