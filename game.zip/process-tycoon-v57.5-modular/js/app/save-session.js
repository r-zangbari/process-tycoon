import { STORAGE_KEY } from '../core/game-state.js';

// Hold the browser lock for the lifetime of the playable tab. Older builds and
// non-secure browser contexts are also checked for a changed save before writing.
export function installSaveSession(game, clock, host = globalThis.window) {
  const panel = document.getElementById('saveSession');
  const message = document.getElementById('saveSessionMessage');
  const reload = document.getElementById('saveSessionReload');
  let session = null;
  let conflicts = false;

  function show(mode) {
    const playable = mode === 'active';
    game.canPlay = playable;
    document.querySelectorAll('body > header, #tabs, #app').forEach(element => {
      element.inert = !playable;
    });
    if (!playable) clock.stop();
    if (panel) panel.hidden = playable;
    if (message) {
      message.textContent = {
        conflict: 'نسخهٔ تازه‌تری از ذخیره پیدا شد. برای ادامه همان ذخیره را باز کن.',
        waiting: 'بازی در تب دیگری باز است یا هنوز آماده می‌شود. پس از بستن تب فعال، آخرین ذخیره در این تب باز می‌شود.',
        error: 'باز کردن بازی انجام نشد. صفحه را دوباره بارگذاری کن.'
      }[mode] || '';
    }
    if (reload) reload.hidden = mode !== 'conflict' && mode !== 'error';
  }

  function pauseOnOpen() {
    if (!host) return;
    game.S.paused = true;
    delete game.S.diagnosticPauseDay;
    clock.resetElapsed();
  }

  function activate(current, refresh) {
    if (session !== current) return;
    const source = refresh ? game.reloadSnapshot() : game.initialSaveSource;
    game.showSaveStatus(source);
    pauseOnOpen();
    show('active');
    if (source === 'legacy') game.save();
    if (!game.canPlay) return;
    clock.start();
    game.draw();
  }

  function open(refresh = false) {
    if (session || conflicts) return;
    const current = { abort: new AbortController(), release: null, wrote: false };
    session = current;
    const locks = host?.navigator?.locks;
    if (!locks?.request) {
      activate(current, refresh);
      return;
    }
    show('waiting');
    locks.request(STORAGE_KEY, { signal: current.abort.signal }, () => {
      if (session !== current) return;
      const untilRelease = new Promise(resolve => { current.release = resolve; });
      activate(current, true);
      return untilRelease;
    }).catch(error => {
      if (session !== current || error.name === 'AbortError') return;
      if (!current.release) {
        activate(current, true);
        return;
      }
      leave();
      show('error');
      console.error(error);
    });
  }

  function leave() {
    const current = session;
    session = null;
    game.canPlay = false;
    clock.stop();
    if (current?.release) current.release();
    else current?.abort.abort();
  }

  game.onSaveConflict = () => {
    conflicts = true;
    game.S.paused = true;
    leave();
    show('conflict');
  };
  game.onSaveWritten = () => {
    if (session) session.wrote = true;
  };
  if (reload) reload.onclick = () => host.location.reload();
  host?.addEventListener?.('storage', event => {
    if (!game.canPlay || (event.key !== STORAGE_KEY && event.key !== null) || !game.saveChanged()) return;
    // A closing tab's last write can reach this renderer after its lock is granted.
    if (session?.release && !session.wrote) {
      game.showSaveStatus(game.reloadSnapshot());
      pauseOnOpen();
      game.draw();
    } else {
      game.onSaveConflict();
    }
  });
  host?.addEventListener?.('pagehide', () => {
    if (game.canPlay) clock.suspend();
    leave();
  });
  host?.addEventListener?.('pageshow', () => open(true));
  open();
}
