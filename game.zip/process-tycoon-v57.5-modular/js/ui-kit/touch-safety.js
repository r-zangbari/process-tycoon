// One tap, one action. Native scrolling and multi-touch must never issue commands.
const actionable = 'button,a,summary,[data-map-kind],[data-city-cell],[data-city-building],[data-city],[data-c],[data-offshore-select],[data-offshore-country],[data-mimic-eq],[data-mimic-valve],[data-mimic-pump],[data-go],[data-hmi]';
export function createTapTracker({ now = Date.now, threshold = 8 } = {}) {
  const pointers = new Map();
  let gesture = null, finished = null;
  return {
    down(e) {
      if (e.button != null && e.button !== 0)
        return;
      finished = null;
      pointers.set(e.pointerId, true);
      if (gesture) {
        gesture.cancelled = true;
        return;
      }
      gesture = {
        id: e.pointerId, x: e.clientX, y: e.clientY, target: e.target?.closest?.(actionable) || e.target, time: now(), motion: false, cancelled: pointers.size > 1
      };
    },
    move(e) {
      if (gesture && pointers.has(e.pointerId)) {
        const distance = Math.hypot(e.clientX - gesture.x, e.clientY - gesture.y);
        if (distance > 2)
          gesture.motion = true;
        if (distance > threshold)
          gesture.cancelled = true;
      }
    },
    scrolled() {
      if (gesture?.motion)
        gesture.cancelled = true;
    },
    cancel() {
      if (gesture)
        gesture.cancelled = true;
    },
    up(e) {
      if (!pointers.has(e.pointerId))
        return;
      this.move(e);
      if (e.type === 'pointercancel')
        this.cancel();
      pointers.delete(e.pointerId);
      if (!pointers.size) {
        finished = gesture;
        gesture = null;
      }
    },
    accepts(e) {
      if (e.detail === 0 && !e.pointerType)
        return true;
      const g = finished;
      finished = null;
      return !!g && !g.cancelled && now() - g.time < 1200 && (e.target?.closest?.(actionable) || e.target) === g.target;
    },
    busy() {
      return pointers.size > 0;
    },
    clear() {
      pointers.clear();
      gesture = null;
      finished = null;
    }
  };
}
export function installTouchSafety(doc, { onActivity = () => { } } = {}) {
  const tracker = createTapTracker();
  doc.addEventListener('pointerdown', e => {
    tracker.down(e);
    onActivity();
  }, true);
  doc.addEventListener('pointermove', e => {
    tracker.move(e);
    if (tracker.busy())
      onActivity();
  }, true);
  for (const type of ['pointerup', 'pointercancel'])
    doc.addEventListener(type, e => {
      tracker.up(e);
      onActivity();
    }, true);
  doc.addEventListener('scroll', () => {
    tracker.scrolled();
    onActivity();
  }, true);
  doc.addEventListener('wheel', () => {
    tracker.cancel();
    onActivity();
  }, { capture: true, passive: true });
  doc.addEventListener('click', e => {
    if (!tracker.accepts(e)) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }, true);
  doc.addEventListener('visibilitychange', () => {
    if (doc.hidden)
      tracker.clear();
  });
  doc.defaultView?.addEventListener?.('blur', () => tracker.clear());
  return tracker;
}
