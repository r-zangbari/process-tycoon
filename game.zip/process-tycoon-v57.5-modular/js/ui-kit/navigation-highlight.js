let active = null, timer = null;
export function clearNavigationHighlight() {
  if (timer != null)
    clearTimeout(timer);
  active?.classList?.remove?.('diagnostic-focus');
  active = null;
  timer = null;
}
export function highlightNavigationTarget(el) {
  clearNavigationHighlight();
  if (!el || el.id === 'app')
    return;
  active = el;
  el.classList?.add?.('diagnostic-focus');
  timer = setTimeout(clearNavigationHighlight, 2200);
  timer?.unref?.();
}
