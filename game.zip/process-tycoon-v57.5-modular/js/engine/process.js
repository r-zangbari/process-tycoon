import { CITIES } from '../data/world-map.js';
import { DISTRICTS } from '../features/country/model/country-planning.js';
import { regionalDisruption } from '../features/country/model/region-disruption.js';
import { settleDistrictProduction } from '../features/country/model/district-production.js';
import { appearanceBonus } from '../features/legacy/model/legacy-development.js';
import { collectUrbanWastewater } from '../features/water/model/water-supply.js';
import { productRule } from '../features/products/model/product-automation.js';
import { effectiveTradePort } from '../features/products/model/trade-conditions.js';
// Country-level utility demand, delivery, taxation and export settlement.
import { summarizeUrbanDevelopment } from '../features/country/model/urban-economy.js';
const cityRegions = Object.fromEntries(DISTRICTS.filter(d => d.city != null).map(d => [CITIES[d.city].name, d.id]));
export function createProcessModel(ctx) {
  let { S } = ctx;
  const { TY, SF, PR, MK, cl, r, log } = ctx;
  function country(fm, remainingPort = S.port, cities = []) {
    const dem = { power: 0, gas: 0, fuel: 0, water: 0 },
      del = {},
      fr = {};
    let dom = 0,
      tax = 0,
      eco = 0,
      ex = 0,
      pop = 0,
      sat = [];
    S.grid.forEach((b) => {
      if (!b) return;
      const t = TY[b.t];
      for (const p in t.need) if (b.c[p]) dem[p] += t.need[p] * b.l;
    });
    const urban = summarizeUrbanDevelopment(S.cityMaps, cities);
    for (const p in urban.demand) dem[p] += urban.demand[p];
    {
      const sf = SF[Math.floor(((S.day - 1) % 360) / 90)];
      dem.gas *= sf.g;
      dem.power *= sf.p;
    }
    for (const p in dem) {
      const level = Math.max(0, Math.min(4, Number(S.network?.[p]) || 0));
      const loss = Math.max(0.02, 0.1 - level * 0.02);
      const withdrawal = Math.min(S.tanks[p], dem[p] / (1 - loss));
      del[p] = withdrawal * (1 - loss);
      S.tanks[p] -= withdrawal;
      fr[p] = dem[p] ? Math.min(1, del[p] / dem[p]) : 1;
      dom += del[p] * PR[p][2];
    }
    const districts = settleDistrictProduction(S, fr, TY, MK);
    tax += districts.tax;
    eco += districts.eco;
    pop += districts.pop;
    sat.push(...districts.sat);
    pop += urban.population;
    const urbanTax = cities.reduce((total, city) => {
      return total + (urban.places[city.name]?.tax || 0) * regionalDisruption(S, cityRegions[city.name]).factor;
    }, 0);
    tax += urbanTax * (0.4 + (0.6 * (fr.power + fr.gas + fr.water + fr.fuel)) / 4);
    S.foodIndex = Math.min(
      1,
      ((S.pd.veg || 0) + (S.pd.meat || 0) + (S.pd.food || 0)) / Math.max(20, pop * 0.5)
    );
    tax *= 1 + 0.12 * S.foodIndex;
    S.urbanToday = {
      population: urban.population,
      tax: urbanTax,
      demand: urban.demand,
      developed: urban.developed
    };
    for (const k in MK) S.pm[k] = cl((S.pm[k] || 1) + (r() - 0.5) * 0.08, 0.6, 1.6);
    let ctInc = 0,
      cp = Math.max(0, Math.min(Number(S.port) || 0, Number(remainingPort) || 0));
    const sv = {};
    for (const p in del) sv[p] = del[p] * PR[p][2];
    for (const p in S.ic) sv[p] = (sv[p] || 0) + S.ic[p] * PR[p][2];
    S.ct = (S.ct || []).filter((c) => {
      const dl = Math.min(S.tanks[c.p], c.q, cp),
        bs = PR[c.p][2];
      S.tanks[c.p] -= dl;
      cp -= dl;
      ctInc += dl * bs * c.pr - (c.q - dl) * bs * c.pen;
      sv[c.p] = (sv[c.p] || 0) + dl * bs * c.pr;
      if (dl < c.q && S.day % 5 === 0) log('کسری تحویل قرارداد ' + PR[c.p][0] + '؛ جریمه می‌شوید.');
      if (--c.d <= 0) {
        log('قرارداد ' + PR[c.p][0] + ' به پایان رسید.');
        return false;
      }
      return true;
    });
    const le = Math.min(S.tanks.power, S.line || 0);
    S.tanks.power -= le;
    ex += le * 6 * fm;
    sv.power = (sv.power || 0) + le * 6 * fm;
    // Spot market: price strategy changes both realized price and market demand.
    const marketBase = {
      methanol: 70,
      ethylene: 85,
      sulfur: 35,
      crude: 120,
      naphtha: 55,
      ammonia: 55,
      urea: 65,
      propane: 45,
      butane: 45,
      fueloil: 60,
      steel: 35,
      cement: 65
    };
    const marketDay = {};
    for (const p in PR)
      if (PR[p][3]) {
        S.pm[p] = cl((S.pm[p] || 1) + (r() - 0.5) * 0.1, 0.5, 1.8);
        const strategy = cl(Number(S.salePrice?.[p]) || 1, 0.7, 1.5),
          baseDemand = marketBase[p] || 40;
        const demandFactor = cl(1.25 - (strategy - 1) * 0.78, 0.35, 1.45),
          shockFactor = S.economy?.shock?.type === 'demand' ? 0.72 : 1,
          demand = baseDemand * demandFactor * shockFactor;
        const unitPrice = PR[p][2] * S.pm[p] * strategy * fm * (S.mkt || 1);
        let sold = 0,
          revenue = 0;
        if (
          productRule(S, p, PR).sellMode === 'legacy' &&
          !S.hold[p] &&
          cp > 0 &&
          unitPrice >= productRule(S, p, PR).minSell &&
          !(S.autoMarketDay?.day === S.day && S.autoMarketDay.bought?.[p] > 0)
        ) {
          sold = Math.min(
            Math.max(
              0,
              S.tanks[p] -
                (S.marketAutomation?.rules?.[p]
                  ? Math.max(
                      (150 * (1 + 0.5 * (S.tl?.[p] || 0)) * productRule(S, p, PR).reserve) / 100,
                      (S.cs?.[p] || 0) + (dem[p] || 0)
                    )
                  : 0)
            ),
            cp,
            Math.max(0, demand - (S.autoMarketDay?.day === S.day ? S.autoMarketDay.sold?.[p] || 0 : 0))
          );
          S.tanks[p] -= sold;
          cp -= sold;
          revenue = sold * unitPrice;
          ex += revenue;
          sv[p] = (sv[p] || 0) + revenue;
        }
        marketDay[p] = { demand, sold, revenue, unitPrice, strategy };
      }
    S.marketDay = marketDay;
    S.portRemainingToday = cp;
    S.portUsedToday = Math.max(0, (S.portCapacityToday ?? effectiveTradePort(S)) - cp);
    S.rp = {};
    for (const p in PR) {
      const pd = S.pd[p] || 0;
      S.rp[p] = pd > 0 ? (PR[p][3] && S.hold[p] ? PR[p][2] : Math.min(PR[p][2] * 1.8, (sv[p] || 0) / pd)) : 0;
    }
    const beauty = appearanceBonus(S);
    if (sat.length)
      S.sat = 0.9 * S.sat + 0.1 * Math.min(100, (100 * sat.reduce((x, y) => x + y, 0)) / sat.length + beauty);
    else if (beauty > 0 && urban.population > 0)
      S.sat = 0.9 * S.sat + 0.1 * Math.min(100, 25 * (fr.power + fr.gas + fr.water + fr.fuel) + beauty);
    let pen = 0;
    if (S.day > 30 && S.sat < 35) {
      pen = 25;
      if (S.day % 10 === 0) log('نارضایتی شهروندان بالاست؛ اعتراض‌ها هزینه دارد.');
    }
    if (fr.power < 0.7 && dem.power && S.day % 7 === 0) log('خاموشی در شهر: برق کافی نیست.');
    collectUrbanWastewater(S, {
      urbanDemand: urban.demand.water || 0,
      housingDemand: S.grid.reduce(
        (n, b) => n + (b?.t === 'h' && b.c?.water ? (TY.h?.need?.water || 0) * b.l : 0),
        0
      ),
      deliveryRatio: fr.water
    });
    S.dem = dem;
    S.fr = fr;
    S.pop = pop;
    S.inc = { dom, tax, eco, ex, pen, ct: ctInc };
    return dom + tax + eco + ex - pen + ctInc;
  }
  return {
    country,
    setState(next) {
      S = next;
    }
  };
}
