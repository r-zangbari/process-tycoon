// Count only time spent actively playing and stop on a long scheduling gap.
const DAY_MS = 1500;
const INTERVAL_MS = 500;
const MAX_GAP_MS = 4000;

export function createProcessClock({
  tick, getState, draw, save, onSuspend = () => draw(),
  now = () => performance.now(), schedule = setInterval, cancel = clearInterval
}) {
  let acc = 0, last = 0, timer = null;

  function resetElapsed(time = now()) {
    acc = 0;
    last = time;
  }

  function suspend() {
    const state = getState();
    resetElapsed();
    if (state.paused) return;
    state.paused = true;
    save();
    onSuspend();
  }

  function update() {
    const state = getState(), time = now();
    const elapsed = time - last;
    last = time;
    if (state.paused) {
      acc = 0;
      draw();
      return;
    }
    if (elapsed > MAX_GAP_MS || elapsed < 0) {
      suspend();
      return;
    }
    acc += elapsed * state.spd;
    let advanced = false;
    while (acc >= DAY_MS && !state.paused) {
      acc -= DAY_MS;
      tick();
      advanced = true;
    }
    if (state.paused) acc = 0;
    if (advanced) save();
    draw();
  }

  return {
    start() {
      if (timer !== null) return;
      resetElapsed();
      timer = schedule(update, INTERVAL_MS);
    },
    stop() {
      if (timer === null) return;
      cancel(timer);
      timer = null;
      resetElapsed();
    },
    resetElapsed,
    suspend
  };
}
