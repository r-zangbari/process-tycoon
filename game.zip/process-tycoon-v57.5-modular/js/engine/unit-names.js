export const escapeText = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export function cleanUnitName(value) {
  return Array.from(String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim()).slice(0, 32).join('');
}
export function unitName(u, D, index = 0) {
  return cleanUnitName(u?.name) || `${D[u?.t]?.n || 'واحد'} ${Number(index) + 1}`;
}
export const unitTitle = (u, D, index = 0) => escapeText(unitName(u, D, index));
