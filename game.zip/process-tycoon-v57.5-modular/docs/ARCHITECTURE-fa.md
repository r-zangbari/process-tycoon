# نقشهٔ کد امپراتوری فرایند

## پیدا کردن فایل مناسب

| بخش | صفحه و نمای قابل ویرایش | منطق و ورودی‌ها | ظاهر |
|---|---|---|---|
| صنعت | `js/features/industry/page.js` و `view/project-grid.js` | `actions.js`، `model/industry.js`، مشخصات واحدها در `js/data/catalog.js` | `css/pages/industry.css` |
| نقشهٔ صنعت | `js/features/industrial-site/page.js` و `view/industry-view.js` | `actions.js`؛ صحنهٔ مشترک نقشه در پوشهٔ کشور | `css/pages/industrial-site.css` |
| اتاق کنترل | `js/features/control-room/page.js` و `view/process-mimic.js` | `actions.js`، `events.js`، `model/` | `css/pages/control-room.css` |
| محصولات | `js/features/management/page.js` و `js/features/products/view/product-market.js` | `js/features/products/market.js` و `js/features/products/model/` | `css/pages/products.css` و `management.css` |
| کشور | `js/features/country/page.js` و `view/country-view.js` | `actions.js`، `model/country-planning.js`، `model/atlas-terrain.js` | `css/pages/country.css` و `country-late.css` |
| شهر و قطب‌ها | `js/features/country/view/city-inspector.js` و `hub-inspector.js` | `country/city-editor.js`، `country/model/urban-economy.js` و `district-production.js` | `css/pages/city.css` و `country.css` |
| دفاع و تجارت دریایی | `js/features/military/view/tactical-panel.js` | `military/actions.js` و `military/model/military.js`؛ ظرفیت تجارت در `products/model/trade-conditions.js` | `css/pages/military.css` |
| آب و فراساحل | `js/features/water/view/water-supply.js` و `js/features/offshore/page.js` | `water/model/water-supply.js` و `offshore/model/offshore.js` | `css/pages/country.css` و `offshore.css` |
| صفحهٔ آنلاین | `online.html` و `js/features/online/online-client.js` | `server/index.mjs` و `server/online-world.mjs` | `css/online.css` |
| راهنمای بازی | `GUIDE-fa.html` و متن قابل ویرایش در `docs/guides-src/GUIDE-fa.md` | — | شیوه‌نامهٔ داخل `GUIDE-fa.html` |

مسیرهای کوتاه جدول از پوشهٔ همان بخش شروع می‌شوند. وقتی نام ویژگی دوم هم در مسیر آمده، آن را از `js/features/` پیدا کن. همهٔ صفحه‌های بازی از `index.html` باز می‌شوند و وضعیت بازی و ذخیرهٔ مشترک دارند. `online.html` ورودی جداگانهٔ بخش سرور است.

## جریان اجرا

1. `js/main.js` برنامه را از `js/app/create-game.js` راه‌اندازی می‌کند. نصب بخش‌ها و ترتیب ثبت رویدادهای مرورگر در یک جا مشخص است.
2. `js/app/context.js` وضعیت ذخیره‌شده و سرویس‌های مشترک را آماده می‌کند. اطلاعات پایدار در `game.S` و حالت موقت رابط در `game.ui` قرار دارد.
3. `js/app/screens.js` واگذاری پنج تب به صفحه‌ها را انجام می‌دهد. زیرصفحه‌های مدیریت محصولات و عنوان هر کدام در `js/features/management/page.js` تعریف می‌شوند.
4. دکمه‌های دارای `data-a` از `js/app/click-router.js` به اکشن‌های بخش مربوط می‌رسند. اکشن عادی در `actions.js` ثبت می‌شود و پس از اجرا، رندر و ذخیره انجام می‌شوند.
5. `js/app/draw.js` صفحهٔ فعال را رسم می‌کند. هنگام به‌روزرسانی همان نقشه، `js/ui-kit/map-refresh.js` میزبان صحنه، اسکرول و وضعیت پنل‌ها را حفظ می‌کند.

## ذخیره، ساعت و پیشنهاد پروژه

- `js/core/save-store.js` اعتبارسنجی ذخیره، انتقال از کلید قدیمی، تشخیص تغییر ذخیره و نگهداری نسخهٔ قبلی را انجام می‌دهد. نسخهٔ فایل پشتیبان در `js/core/version.js` تنظیم می‌شود.
- `js/app/save-session.js` کنترل تب‌ها و بازخوانی ذخیره هنگام انتقال کنترل را مدیریت می‌کند. `js/app/startup.js` توقف ساعت را به پنهان‌شدن صفحه وصل می‌کند. منطق زمان و جلوگیری از جهش روزها در `js/engine/game-engine.js` است.
- `js/features/industry/model/project-progress.js` پیشنهاد و دکمهٔ مناسب مرحلهٔ ساخت را تعیین می‌کند. تشخیص واحد در حال بهره‌برداری در `js/features/maintenance/model/unit-diagnostics.js` انجام می‌شود.

## ترتیب شبیه‌سازی روزانه

- `js/app/simulation/daily-tick.js` ترتیب آغاز روز، تعمیرات، آب و خوراک، صنعت، کشور، رخدادها و تسویه را تعیین می‌کند.
- `export-contracts.js` در همین پوشه پیش‌پرداخت، تحویل، جریمه و سهم ظرفیت بندر را تسویه می‌کند.
- `operate-units.js` وضعیت تجهیز، متغیرهای عملیاتی، خوراک و محصول هر واحد را پیش می‌برد.
- `unit-ledgers.js` پس از تسویه کشور، ارزش محصول، هزینه و سود واحد را گزارش می‌کند.
- `js/engine/process.js` گزارش کشوری، برداشت خدمات از مخزن‌های مشترک، اقتصاد و تجارت را به هم وصل می‌کند.
- `js/features/country/model/district-production.js` ترتیب مزرعه و گلخانه، دامداری و کارخانهٔ فراوری را اجرا می‌کند. محصول مصرف‌شده در مرحلهٔ بعد از فروش مرحلهٔ قبل کم می‌شود.

ترتیب مراحل روز مهم است. پس از تغییر آن، اثر را بر موجودی، اعتبار قرارداد و صورت نقد با آزمون‌های یک روز کامل بررسی کن.

## دو نمونهٔ ویرایش

**تغییر مصرف آب گلخانه**  
در `js/data/catalog.js` بخش `TY`، مقدار `need.water` برای کلید `g` را تغییر بده. هزینه و مقدار خروجی در همان جدول است. برای تغییر نحوهٔ مصرف خوراک دام یا ترتیب فراوری، `district-production.js` را باز کن. برای آزمون پیوند این مقادیر با خدمات و مالیات از `npm run test:country` استفاده کن.

**تغییر کارت قطعهٔ کشاورزی**  
در `js/features/country/view/hub-inspector.js` تابع `renderHubInspector` را باز کن. همان فایل ساخت، اتصال و ارتقای قطعهٔ منتخب را نمایش می‌دهد. برای تغییر ظاهر عمومی پنل به `css/pages/country.css` برو. اگر فرمان تازه‌ای می‌افزایی، داده‌های دکمه را در اکشن مربوط به کشور اعتبارسنجی کن.

## نقشه، اختلال منطقه‌ای و تجارت

- مرز و ارتفاع اطلس در `js/features/country/model/atlas-terrain.js` تعریف شده است. نمایش سه‌بعدی، رسم ایزومتریک و اعتبارسنجی موقعیت از همین داده استفاده می‌کنند.
- در `js/features/country/view/country-scene.js` کیفیت رندر گوشی و بازیابی گرافیک تنظیم می‌شود. پیش‌نمایش ساخت و جابه‌جایی موقت است و فرمان قطعی در `js/features/military/actions.js` ثبت می‌شود.
- `js/features/country/model/region-disruption.js` زمان و ضریب اثر یک منطقه را ارائه می‌دهد. `js/features/products/model/trade-conditions.js` مرجع ظرفیت مؤثر و ظرفیت آزاد بندر است. مرحلهٔ دفاع روزانه پیش از تسویهٔ تجارت و تولید اجرا می‌شود.

## ظاهر و اعتبارسنجی

`css/style.css` ترتیب بارگیری فایل‌ها را نشان می‌دهد. رنگ‌ها و متغیرهای پایه در `css/base/tokens.css` و قواعد مختص هر بخش در `css/pages/` قرار دارند. قواعد لمسی و اولویت‌های انتهایی در `css/base/touch-and-overrides.css` جمع شده‌اند. جایگاه فایل‌ها در شیوه‌نامه روی اولویت قوانین اثر دارد.

آزمون‌های فعال در سطح اول `tests/` هستند. پوشهٔ `tests/legacy-visual/` سابقهٔ بررسی طرح‌های قدیمی را نگه می‌دارد. با `npm test` مسیر روزانه، پرداخت‌ها، ذخیره، کشاورزی، دفاع، نقشه، رابط و سرور آنلاین بررسی می‌شوند.
