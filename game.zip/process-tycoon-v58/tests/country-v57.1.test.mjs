import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState,normalizeState} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,TY,setImportMultiplier} from '../js/data/catalog.js';
import {districtLots} from '../js/systems/country-planning.js';
import {changeFarm,dispatchVoyage,changeDrill,strategyState} from '../js/systems/strategy.js';
import {renderCountry} from '../js/ui/country-view.js';
import {renderVectorMap} from '../js/ui/map-vector.js';
import {sceneSignature} from '../js/ui/map-design.js';

function fresh(){
 const s=createFreshState();
 s.tab='c';s.money=10000;
 normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});
 return s;
}
function country(s,expanded){
 return renderCountry({S:s,TY,PR,CITIES:[],fa:String,offshoreCard:()=>'',countryEconomyCard:()=>'',REGIONS:[],expanded});
}

test('old specialized projects migrate onto unoccupied lots inside the existing agricultural hub',()=>{
 const s=fresh();
 s.grid[0]={t:'f',l:2,c:{water:1}};
 s.strategy={plots:[{kind:'barn',level:2,ready:8,active:false},{kind:'cold',level:1,ready:1}]};
 normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});
 const before=structuredClone(s.strategy);
 const lots=districtLots(s,'north');
 assert.equal(lots.find(l=>l.id===0).type,'f');
 assert.deepEqual(lots.filter(l=>l.agriSlot!=null).map(l=>[l.id,l.type,l.level,l.pending]),[[3,'barn',2,true],[6,'cold',1,false]]);
 assert.deepEqual(s.strategy,before);
 s.countryHub='north';s.sel=9;
 assert.match(country(s,false),/ساخت مزرعه/);
 assert.match(country(s,false),/data-a="farm-build" data-k="greenhouse"/);
 assert.equal(changeFarm(s,2,'build','greenhouse',9),'');
 assert.match(changeFarm(s,3,'build','greenhouse',9),/آزاد نیست/);
 assert.equal(districtLots(s,'north').filter(l=>l.id===9).length,1);
 assert.match(renderVectorMap(s,[]),/data-map-id="9" aria-label="گلخانه/);
});

test('migration preserves specialized projects when all original north lots are occupied',()=>{
 const s=fresh();
 for(let id=0;id<s.grid.length;id+=3)s.grid[id]={t:'f',l:1,c:{}};
 s.strategy={plots:[{kind:'cold',level:2,ready:2}]};
 normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});
 const extension=s.strategy.plots[0].cell;
 assert.equal(extension,s.grid.length);
 assert.equal(districtLots(s,'north').find(l=>l.id===extension).type,'cold');
 s.grid[0]=null;
 assert.equal(strategyState(s).plots[0].cell,extension);
});

test('expanded country markup retains the same host and existing map overlays',()=>{
 const s=fresh();
 const normal=country(s,false),full=country(s,true);
 assert.match(full,/country-atlas atlas-expanded/);
 for(const html of [normal,full]){
  assert.equal((html.match(/id="country-three"/g)||[]).length,1);
  assert.match(html,/data-view="atlas"/);
  assert.match(html,/data-k="sea"/);
  assert.match(html,/data-k="readiness"/);
  assert.doesNotMatch(html,/<dialog/);
 }
 assert.match(full,/خروج از تمام‌صفحه/);
 s.mapLayer='sea';
 assert.equal(dispatchVoyage(s,'island','fodder',6),'');
 const sea=renderVectorMap(s,[]);
 assert.match(sea,/data-map-kind="route"/);
 assert.match(sea,/data-map-kind="ship"/);
 const before=sceneSignature(s,[]);s.day++;
 assert.notEqual(sceneSignature(s,[]),before);
 s.mapLayer='readiness';changeDrill(s,'start');
 const drill=renderVectorMap(s,[]);
 assert.match(drill,/data-map-kind="team"/);
 assert.match(drill,/data-map-kind="alarm"/);
});
