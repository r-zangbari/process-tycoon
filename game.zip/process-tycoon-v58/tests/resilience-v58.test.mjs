import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState,normalizeState} from '../js/core/game-state.js';
import {D,GW,GH,PR,TY,SF,MK,setImportMultiplier} from '../js/data/catalog.js';
import {advanceResilienceDay,baseCrew,protectionPoints,resilienceState,resilienceAction,resilienceFactor,routeClosedUntil,staffedStations} from '../js/systems/resilience.js';
import {dispatchVoyage,protectVoyage,settleStrategy,changeFarm} from '../js/systems/strategy.js';
import {simulateWaterDay} from '../js/systems/water-supply.js';
import {effectiveTradePort} from '../js/systems/trade-conditions.js';
import {createProcessModel} from '../js/systems/process.js';
import {createStarterCityGrid} from '../js/systems/urban-economy.js';
import {renderVectorMap} from '../js/ui/map-vector.js';

const supply={power:1,water:1,fuel:1};
function fresh(){
 const s=createFreshState();
 normalizeState(s,{D,GW,GH,PR,TY,SF,MK,setImportMultiplier});
 s.money=10000;s.paused=true;s.tab='c';s.fr={...supply};
 s.port=100;s.portRemainingToday=100;
 return s;
}

test('regional warning damages the real port once and two-day repair restores berth capacity',()=>{
 const s=fresh();
 assert.equal(resilienceAction(s,'warn','port'),'');
 assert.equal(resilienceAction(s,'warn','north'),'سناریو فعال است یا هنوز دورهٔ بازیابی تمام نشده.');
 assert.match(renderVectorMap({...s,mapLayer:'readiness'},[]),/data-map-kind="crisis-alarm"/);
 s.day=4;
 assert.equal(advanceResilienceDay(s),0);
 assert.equal(resilienceFactor(s,'port'),.7);
 assert.equal(effectiveTradePort(s),70);
 assert.equal(routeClosedUntil(s,'island'),6);
 s.fx.sanc=1;
 assert.equal(effectiveTradePort(s),45.5);
 assert.equal(advanceResilienceDay(s),0);
 assert.equal(resilienceFactor(s,'port'),.7);
 const cash=s.money;assert.equal(resilienceAction(s,'repair','port'),'');
 assert.equal(s.money,cash-240);
 assert.notEqual(resilienceAction(s,'repair','port'),'');
 s.day=5;advanceResilienceDay(s);assert.equal(resilienceFactor(s,'port'),.75);
 s.day=6;advanceResilienceDay(s);assert.equal(resilienceFactor(s,'port'),1);
 assert.equal(resilienceFactor(s,'industry'),1);
 s.day=7;advanceResilienceDay(s);assert.equal(routeClosedUntil(s,'island'),null);
});

test('district projects use available trained operators and sufficient power and reward only the first successful defense',()=>{
 const s=fresh();s.tr=1;s.ops=2;
 assert.equal(resilienceAction(s,'build','industry','reserve'),'');
 assert.equal(resilienceAction(s,'build','industry','station'),'');
 assert.notEqual(resilienceAction(s,'crew','industry'),'');
 s.day=3;
 assert.equal(resilienceAction(s,'crew','industry'),'');
 assert.deepEqual(staffedStations(s,baseCrew(s)),['industry']);
 assert.equal(protectionPoints(s,'industry'),3);
 s.fr.power=.2;assert.equal(protectionPoints(s,'industry'),1);
 s.fr.power=1;
 assert.equal(resilienceAction(s,'warn','industry'),'');
 s.day=6;
 assert.equal(advanceResilienceDay(s),700);
 assert.equal(advanceResilienceDay(s),0);
 assert.equal(settleStrategy(s,supply),700);
 assert.equal(s.resilience.last.damage,0);
 assert.deepEqual(s.resilience.protected,['industry']);
 s.day=14;
 assert.equal(resilienceAction(s,'warn-auto'),'');
 assert.notEqual(s.resilience.warning.zone,'industry');
});

test('a fictional closure delays unaccompanied ships on its route only and active sanctions still apply to all',()=>{
 const s=fresh();
 for(const route of ['island','island','bay'])assert.equal(dispatchVoyage(s,route,'fodder',6),'');
 const cash=s.money;
 assert.equal(protectVoyage(s,2),'');assert.notEqual(protectVoyage(s,2),'');assert.equal(s.money,cash-24);
 s.resilience=resilienceState(s);s.resilience.closure={route:'island',until:4};
 s.day=2;settleStrategy(s,supply);
 assert.deepEqual(s.strategy.ships.map(v=>v.due),[5,4,6]);
 assert.equal(s.strategy.ships[0].routeDelay,true);
 s.fx.sanc=2;s.day=4;settleStrategy(s,supply);
 assert.deepEqual(s.strategy.ships.map(v=>v.due),[6,5,7]);
 assert.equal(s.strategy.ships[1].routeDelay,false);
});

test('water loss affects coastal delivery and production with balanced physical stocks',()=>{
 const s=fresh();s.tanks.power=100;s.tanks.rawwater=0;
 s.waterSupply={sources:{desal:{enabled:true,level:1,connected:true}},coastal:{built:true,stock:60}};
 s.resilience=resilienceState(s);s.resilience.districts['water-desal'].damage=50;
 const report=simulateWaterDay(s,{cap:()=>200});
 assert.equal(report.coastalDelivered,22.5);
 assert.equal(report.sources.desal.quantity,50);
 assert.equal(s.tanks.rawwater,72.5);
 assert.match(report.sources.desal.status,/افت ظرفیت ساحلی/);
});

test('regional damage scales production and applies capital tax loss only to the selected city',()=>{
 const s=fresh();s.grid.fill(null);
 s.grid[0]={t:'f',l:1,c:{water:1,fuel:1}};
 s.grid[2]={t:'k',l:1,c:{power:1,gas:1,fuel:1}};
 assert.equal(changeFarm(s,0,'build','field',3),'');
 const cities=[{name:'پایتخت'},{name:'شهر دوم'}];
 s.cityMaps=Object.fromEntries(cities.map(({name})=>{
  const grid=createStarterCityGrid();grid[0]={type:'shop',level:1};return [name,grid];
 }));
 s.day=4;for(const p of ['water','fuel','gas','power'])s.tanks[p]=500;
 const other=structuredClone(s);
 s.resilience=resilienceState(s);
 s.resilience.districts.north.damage=30;s.resilience.districts.energy.damage=20;s.resilience.districts.capital.damage=50;
 const run=S=>createProcessModel({S,TY,SF,PR,MK,cl:(x,a,b)=>Math.min(b,Math.max(a,x)),r:()=>.5,log(){}}).country(1,0,cities);
 run(other);run(s);
 assert.equal(s.pd.crop,7);assert.equal(s.pd.goods,12);
 assert.ok(Math.abs(s.strategy.stock.fodder-4.2)<1e-8);
 assert.equal(s.inc.tax,other.inc.tax*.75);
 assert.equal(s.pop,other.pop);
});
