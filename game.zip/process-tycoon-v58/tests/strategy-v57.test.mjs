import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState} from '../js/core/game-state.js';
import {PR,MK,SF,TY} from '../js/data/catalog.js';
import {createProcessModel} from '../js/systems/process.js';
import {changeFarm,changeDrill,dispatchVoyage,farmDemand,loadScheduledVoyages,settleStrategy,strategyState} from '../js/systems/strategy.js';
import {closeCashDay} from '../js/systems/cash-clarity.js';

const utilities={water:1,fuel:1,power:1};
function fresh(){
 const s=createFreshState();
 s.cs={};s.ic={};s.port=40;s.portRemainingToday=40;s.money=10000;
 return s;
}

test('agricultural construction is paid once and the utility-limited chain has real material inputs',()=>{
 const s=fresh(),capital=s.money;
 assert.equal(changeFarm(s,0,'build','field'),'');
 assert.match(changeFarm(s,0,'build','greenhouse'),/اجازه/);
 assert.equal(s.money,capital-450);
 assert.deepEqual(farmDemand(s),{});
 changeFarm(s,1,'build','barn');changeFarm(s,2,'build','dairy');changeFarm(s,3,'build','cold');
 s.day=4;
 assert.deepEqual(farmDemand(s),{water:8,fuel:1,power:6});
 assert.equal(settleStrategy(s,{...utilities,power:.5}),0);
 assert.deepEqual(s.strategy.stock,{produce:0,fodder:4,milk:0,dairy:2});
 assert.equal(s.strategy.today.rows[1].rate,.5);
 const before=structuredClone(s);
 settleStrategy(s,utilities);
 assert.deepEqual(s,before);
});

test('agriculture shares real utility demand, withdrawals and shortages with the rest of the country',()=>{
 const s=fresh();s.grid.fill(null);
 for(const p of Object.keys(PR))s.tanks[p]=0;
 s.tanks.water=2;s.tanks.fuel=10;
 changeFarm(s,0,'build','field');s.day=3;
 createProcessModel({S:s,TY,SF,PR,MK,cl:(x,a,b)=>Math.min(b,Math.max(a,x)),r:()=>.5,log(){}}).country(1,s.port);
 assert.equal(s.dem.water,4);
 assert.ok(Math.abs(s.fr.water-.45)<1e-10);
 assert.ok(Math.abs(s.strategy.stock.fodder-2.7)<1e-10);
 assert.equal(s.tanks.water,0);
});

test('voyages reserve cargo and use shared port slots, then credit exports only on arrival',()=>{
 const s=fresh();s.strategy=strategyState(s);s.strategy.stock.produce=12;s.portRemainingToday=4;
 assert.equal(dispatchVoyage(s,'island','produce',6),'');
 assert.equal(s.strategy.ships[0].queued,true);
 assert.equal(s.strategy.stock.produce,6);
 assert.equal(s.portRemainingToday,4);
 s.day=2;assert.equal(loadScheduledVoyages(s,5),5);
 assert.equal(loadScheduledVoyages(s,40),34);
 assert.equal(loadScheduledVoyages(s,40),40);
 assert.equal(settleStrategy(s,utilities),0);
 s.day=5;
 assert.equal(settleStrategy(s,utilities),72);
 assert.equal(s.strategy.ships.length,0);
 assert.equal(s.strategy.history.length,1);
 const before=s.money;s.money+=s.strategy.today.income;
 const cash=closeCashDay(s,before);
 assert.equal(cash.strategy,72);
 assert.equal(cash.other,0);
});

test('paid imports wait for real storage and resume without charging twice',()=>{
 const s=fresh();s.strategy=strategyState(s);
 s.fx={sanc:2};s.strategy.stock.fodder=17;
 const initial=s.money;
 assert.equal(dispatchVoyage(s,'island','fodder',6),'');
 assert.equal(s.money,initial-60);assert.equal(s.portRemainingToday,34);
 s.day=4;settleStrategy(s,utilities);assert.equal(s.strategy.ships[0].delayed,true);
 s.day=5;settleStrategy(s,utilities);assert.equal(s.strategy.ships[0].qty,5);assert.equal(s.strategy.stock.fodder,18);
 s.fx={};s.day=6;s.strategy.stock.fodder=10;settleStrategy(s,utilities);
 assert.equal(s.strategy.stock.fodder,15);assert.equal(s.strategy.ships.length,0);assert.equal(s.money,initial-60);
});

test('a readiness drill needs a trained team in the right district and sufficient power',()=>{
 const s=fresh();
 changeDrill(s,'start');assert.equal(s.strategy.drill.target,'port');
 assert.match(changeDrill(s,'move','port',false),/آموزش/);
 s.tr=1;assert.equal(changeDrill(s,'move','port',true),'');
 s.day=2;settleStrategy(s,utilities);assert.equal(s.strategy.drill.team,'capital');
 s.day=3;settleStrategy(s,utilities);assert.equal(s.strategy.drill.team,'port');
 s.day=4;assert.equal(settleStrategy(s,utilities),550);
 assert.equal(s.strategy.drill.wins,1);
 assert.equal(settleStrategy(s,utilities),550);
 s.day=5;assert.equal(settleStrategy(s,utilities),0);assert.equal(s.strategy.drill.wins,1);
});
