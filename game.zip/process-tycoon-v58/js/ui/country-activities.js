import {RESILIENCE_ZONES,PROTECTION,CONVOY_COST,baseCrew,staffedStations,resilienceState,resilienceFactor,repairCost,protectionPoints,routeClosedUntil} from '../systems/resilience.js';
import {effectiveTradePort} from '../systems/trade-conditions.js';
import {FARMS,GOODS,ROUTES,DRILL_ZONES,strategyState,farmStorage,voyageQuote} from '../systems/strategy.js';

const n=x=>(Number.isFinite(x)?x:0).toLocaleString('fa-IR',{maximumFractionDigits:1});
const btn=(act,label,attrs='',disabled=false)=>`<button type="button" data-a="${act}" ${attrs} ${disabled?'disabled':''}>${label}</button>`;
const resource={power:'برق',water:'آب',fuel:'سوخت'};
export function renderFarmStock(S,s){const cap=farmStorage(S,s),loss=s.today?.day===S.day?Object.entries(s.today.lost||{}).filter(([,x])=>x>.005):[];return `<dl class="strategy-stock">${Object.entries(GOODS).map(([p,name])=>`<div><dt>${name}</dt><dd>${n(s.stock[p])} / ${n(cap[p])}</dd></div>`).join('')}</dl>${loss.length?`<p>مازاد ذخیره‌نشدهٔ امروز · ${loss.map(([p,x])=>GOODS[p]+' '+n(x)).join('، ')}</p>`:''}`}
export function renderFarmLot(S,s,lot){
 const i=lot.agriSlot,b=s.plots[i];
 if(!b)return `<div class="strategy-build">${Object.entries(FARMS).map(([kind,f])=>btn('farm-build',`${f.name}<small>${n(f.cost)} سرمایه · ${n(f.days)} روز</small>`,`data-k="${kind}"`,S.money<f.cost||!s.plots.includes(null))).join('')}</div>${renderFarmStock(S,s)}`;
 const f=FARMS[b.kind],row=s.today?.day===S.day?s.today.rows?.[i]:null,building=b.ready>S.day;
 const inputs=[...Object.entries(f.need).map(([p,x])=>resource[p]+' '+n(x*b.level)),...Object.entries(f.input||{}).map(([p,x])=>GOODS[p]+' '+n(x*b.level))];
 return `<h2>${f.name} · سطح ${n(b.level)}</h2><p>${building?'پایان ساخت در روز '+n(b.ready):b.active?'در مدار':'متوقف'}</p>
 ${inputs.length?`<p>نیاز روزانه · ${inputs.join('، ')}</p>`:''}
 ${row?`<p>بهره‌برداری امروز ${n(row.rate*100)}٪ · تأمین خدمات ${n(row.util*100)}٪</p>${row.district<1?`<p>ظرفیت قطب پس از آسیب ${n(row.district*100)}٪</p>`:''}<p>${Object.entries(row.out).map(([p,x])=>GOODS[p]+' ذخیره‌شده '+n(x)).join('، ')}</p>`:''}
 ${btn('farm-upgrade','ارتقا · '+n(f.cost*(b.level+1)),'',building||b.level>=3||S.money<f.cost*(b.level+1))}
 ${btn('farm-toggle',b.active?'توقف':'فعال‌کردن','',building)}${renderFarmStock(S,s)}`;
}
export function renderSeaPanel(S,s,sel){
 const v=sel.kind==='ship'?s.ships.find(v=>String(v.id)===String(sel.id)):null;
 if(v)return `<h3>کشتی ${n(v.id)} · ${ROUTES[v.route].name}</h3><p>${v.buy?'واردات':'صادرات'} ${GOODS[v.product]} · ${n(v.qty)} واحد</p><p>${v.queued?'رزرو شده · در انتظار ظرفیت پایانه':v.waiting?'در انتظار فضای سیلو':v.delayed?(v.routeDelay?'اختلال مسیر':'تأخیر تجاری')+' · موعد '+n(v.due):'موعد تحویل روز '+n(v.due)}</p>
 ${v.protected?'<p>همراهی حفاظتی فعال</p>':v.waiting?'':btn('country-convoy','همراهی حفاظتی · '+n(CONVOY_COST),`data-i="${v.id}"`,S.money<CONVOY_COST)}
 <p>همراهی فقط تأخیرِ بسته‌بودن این مسیر را رفع می‌کند.</p>`;
 const route=Object.hasOwn(ROUTES,sel.id)?sel.id:'island',closed=routeClosedUntil(S,route);
 return `<div class="row">${Object.entries(ROUTES).map(([id,r])=>btn('country-route',r.name,`data-k="${id}" aria-pressed="${route===id}"`)).join('')}</div><h3>${ROUTES[route].name}</h3><p>کشتی فعال ${n(s.ships.length)} از ۴ · ظرفیت آزاد پایانه ${n(Math.min(S.portRemainingToday??S.port,effectiveTradePort(S)))} · مسیر ${n(ROUTES[route].days)} روز</p>
 ${closed?`<p class="resilience-warning">مسیر تا پایان روز ${n(closed)} مختل است. مسیر دیگر را انتخاب کن یا برای کشتی همراهی حفاظتی بگیر.</p>`:''}
 ${s.ships.length?`<div class="row">${s.ships.map(v=>btn('country-ship','کشتی '+n(v.id),`data-i="${v.id}"`)).join('')}</div>`:''}
 <div class="strategy-build">${['produce','dairy','fodder'].map(product=>{
  const qty=6,q=voyageQuote(S,route,product,qty);
  return btn('country-voyage',`${q.buy?'واردات':'صادرات'} ${GOODS[product]}<small>${n(qty)} واحد · ${n(q.total)} سرمایه${q.queued?' · رزرو نوبت':''}</small>`,`data-k="${product}" data-p="${route}"`,!q.allowed);
 }).join('')}</div>${renderFarmStock(S,s)}${s.history.length?`<h4>آخرین تحویل</h4><p>${GOODS[s.history[0].product]} · ${ROUTES[s.history[0].route]?.name||'—'} · روز ${n(s.history[0].day)}</p>`:''}`;
}
function protectionPanel(S,zone){
 const data=resilienceState(S),w=data.warning,last=data.last,crew=baseCrew(S);
 const active=staffedStations(S,crew);
 const id=zone||w?.zone||'industry',row=data.districts[id],place=RESILIENCE_ZONES[id];
 const repairing=row.repair>S.day,closed=id==='port'?data.closure:null;
 const busy=!!w||!!last&&S.day<last.day+8;
 const projects=Object.entries(PROTECTION).map(([key,d])=>{
  const p=row.projects[key],building=p?.ready>S.day,cost=d.cost*((p?.level||0)+1);
  const summary=building?'آماده در روز '+n(p.ready):p?'سطح '+n(p.level)+' از ۲':'ساخته نشده';
  return `<div class="resilience-project"><b>${d.name}</b><span>${summary}</span>
   ${btn('country-resilience',(p?'ارتقا':'ساخت')+' · '+n(cost),`data-i="${id}" data-t="build" data-k="${key}"`,building||p?.level>=2||S.money<cost)}</div>`;
 }).join('');
 const ready=row.projects.station?.ready<=S.day,canAssign=ready&&S.tr>=1&&crew>active.length;
 return `<section class="resilience-panel"><h3>دفاع و بازسازی کشور</h3>
  ${w?`<p class="resilience-warning"><b>هشدار ${RESILIENCE_ZONES[w.zone].name}</b> · روز ${n(w.due)} · شدت ${n(w.strength)} · پوشش فعلی ${n(protectionPoints(S,w.zone))}${w.route?' · مسیر '+ROUTES[w.route].name:''}</p>`:''}
  ${!w&&last?`<p>آخرین نتیجه · ${RESILIENCE_ZONES[last.zone].name} · ${last.damage?'افت ظرفیت '+n(last.damage)+'٪':'تداوم خدمت'}${last.reward?' · پاداش '+n(last.reward):''}</p>`:''}
  <p>نشان‌های تداوم خدمت ${n(data.protected.length)} از ${n(Object.keys(RESILIENCE_ZONES).length)}</p>
  <h4>${place.name}</h4><p>${place.impact} · ظرفیت فعلی ${n(resilienceFactor(S,id)*100)}٪ · پوشش ${n(protectionPoints(S,id))}</p>
  ${repairing?`<p>پایان بازسازی در روز ${n(row.repair)}</p>`:''}
  ${closed&&closed.until>=S.day?`<p>مسیر ${ROUTES[closed.route].name} تا پایان روز ${n(closed.until)} مختل است.</p>`:''}
  ${projects}
  <p>نیروی پایگاه‌ها ${n(active.length)} از ${n(crew)} اپراتور حاضر · ${active.includes(id)?'پایگاه دارای اپراتور':row.crew?'اپراتور امروز در دسترس نیست':'پایگاه بدون اپراتور'}</p>
  <div class="row">${btn('country-resilience',row.crew?'آزادکردن اپراتور':'اختصاص اپراتور',`data-i="${id}" data-t="crew"`,!row.crew&&!canAssign)}
  ${row.damage?btn('country-resilience',repairing?'در حال بازسازی':'بازسازی دو روزه · '+n(repairCost(row.damage)),`data-i="${id}" data-t="repair"`,repairing||S.money<repairCost(row.damage)):''}
  ${btn('country-resilience','آغاز سناریوی بحران در این منطقه',`data-i="${id}" data-t="warn"`,busy)}
  ${btn('country-resilience','سناریوی خودکار', 'data-t="warn-auto"',busy)}</div>
  <small>ذخیرهٔ پشتیبان بدون اپراتور پوشش می‌دهد. پایگاه و تیم واکنش به آموزش و دست‌کم ۵۰٪ تأمین برق نیاز دارند.</small></section>`;
}
export function renderDrillPanel(S,s,sel){
 const d=s.drill,zone=sel.kind==='district'&&Object.hasOwn(DRILL_ZONES,sel.id)?sel.id:null;
 return `<div class="row resilience-regions">${Object.entries(DRILL_ZONES).map(([id,label])=>btn('country-zone',label,`data-k="${id}" aria-pressed="${zone===id}"`)).join('')}</div>
 ${zone?btn('country-team','اعزام تیم به '+DRILL_ZONES[zone],`data-k="${zone}"`,d.team===zone||!!d.moving||S.tr<1):''}
 ${sel.kind==='team'?'<p class="strategy-order">برای اعزام، حلقهٔ منطقهٔ مقصد را روی نقشه انتخاب کن.</p>':''}`+protectionPanel(S,zone)+`<details><summary>مانور آموزشی و اعزام تیم</summary><h3>مانور آمادگی کشور</h3><p>${d.target?'هشدار تمرینی در '+DRILL_ZONES[d.target]+' · ارزیابی روز '+n(d.due):d.result==='covered'?'ارزیابی قبل · خدمات منطقه برقرار ماند.':d.result==='gap'?'ارزیابی قبل · پوشش کامل نبود.':'با شروع مانور، یک منطقه روی نقشه هشدار می‌گیرد.'}</p>
 ${!d.target&&d.lastTarget?`<p>منطقهٔ ارزیابی قبل · ${DRILL_ZONES[d.lastTarget]}</p>`:''}
 <p>تیم واکنش · ${d.moving?'در مسیر '+DRILL_ZONES[d.moving]+' تا روز '+n(d.arrival):DRILL_ZONES[d.team]}</p>
 <p>یک سطح آموزش اپراتورها و دست‌کم ۵۰٪ تأمین برق برای موفقیت لازم است.</p>
 ${btn('country-drill','شروع مانور','',!!d.target)}

 <p>دفاع موفق ${n(d.wins)} · پاداش نخستین موفقیت ۵۵۰</p></details>`;
}

// The same activities are projected onto either renderer of the country atlas.
export const MARINE_NODES={
 island:{map:[855,515],world:[37,34]},
 bay:{map:[98,493],world:[-36,30]}
};
export function countryActivity(S){
 const layer=S.mapLayer;
 if(layer!=='sea'&&layer!=='readiness')return null;
 const state=strategyState(S),selection=S.atlasActivity||{};
 if(layer==='sea')return {layer,selection,closed:Object.keys(ROUTES).filter(id=>routeClosedUntil(S,id)!=null),ships:state.ships.map(v=>({...v,progress:shipProgress(S.day,v)}))};
 const d=state.drill;
 const response=resilienceState(S),w=response.warning;
 const zones=Object.entries(response.districts).map(([id,r])=>({id,damage:r.damage,coverage:protectionPoints(S,id),protected:response.protected.includes(id),
  projects:Object.entries(r.projects).map(([key,p])=>({key,level:p.level,building:p.ready>S.day})),repairing:r.repair>S.day}));
 return {layer,selection,drill:d,warning:w,crisisProgress:w?Math.min(.96,Math.max(0,1-(w.due-S.day)/3)):0,zones,teamProgress:d.moving?Math.max(0,1-(d.arrival-S.day)/2):0,
  warningProgress:d.target?Math.min(.96,Math.max(0,1-(d.due-S.day)/3)):0};
}
function shipProgress(day,ship){
 const progress=ship.queued?0:ship.waiting?1:Math.min(.96,Math.max(.035,(day-ship.start-(ship.delayDays||0))/ROUTES[ship.route].days));
 return ship.buy?1-progress:progress;
}
export const quadraticPoint=(a,b,c,t)=>a.map((v,i)=>(1-t)**2*v+2*t*(1-t)*b[i]+t**2*c[i]);
