import {countryActivity,MARINE_NODES,quadraticPoint} from './country-activities.js';
import {FARMS,ROUTES} from '../systems/strategy.js';
import {mapTone,campusNetwork,cityServiceMap} from './map-operations.js';
import {cityDesign,districtDesign,STYLES,industryAppearance,PALETTES,placementDefinition,districtIndex} from '../systems/legacy-development.js';
import {ornamentArt,styleArt,campusPaletteArt} from './legacy-art.js';
import {unitName} from '../systems/unit-names.js';
import {DISTRICTS,countryViewKey} from '../systems/country-planning.js';
import {D} from '../data/catalog.js';
import {industryPage} from './industry-view.js';
import {renderNationalHub,renderCityBuilding,renderProcessFacility,renderOffshoreRig,renderFarmBuilding} from './strategy-graphics.js';
import {atlasRoutes,layoutLots,sceneSignature} from './map-design.js';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),num=n=>Math.round(n).toLocaleString('fa-IR');
const tree=(x,y,s=1)=>`<g transform="translate(${x} ${y}) scale(${s})"><ellipse cy="6" rx="11" ry="4" fill="#284f4233"/><path d="M0 2v-19" stroke="#8d785a" stroke-width="4"/><path d="M-12-7L0-34 12-7Z" fill="#487b61"/><path d="M0-34L12-7H0Z" fill="#365f52"/></g>`;
const farm=()=>`<g><path d="M-51 6L-8-18 49 9 5 32Z" fill="#8ca961" stroke="#d9ce96"/>${[0,1,2,3,4].map(i=>`<path d="M${-43+i*9} ${9-i*5}l48 23" stroke="${i%2?'#b2bd6e':'#6f9255'}" stroke-width="5"/>`).join('')}<path d="M-8-15l16-10 19 11v25l-16 8-19-9z" fill="#d69d77"/><path d="M-13-16L4-34 30-17 11-7Z" fill="#9f624f"/></g>`;
const art=(kind,level=1)=>FARMS[kind]?renderFarmBuilding(kind,level):kind==='farm'||kind==='f'?farm():kind==='factory'||kind==='k'?renderNationalHub('industrial',level):['h','home','park','shop','service'].includes(kind)?renderCityBuilding(kind==='h'?'home':kind,level):renderNationalHub(kind,level);
const target=(kind,id,label,content)=>`<g class="map-target" role="button" tabindex="0" data-map-kind="${kind}" data-map-id="${id}" aria-label="${esc(label)}"><title>${esc(label)}</title>${content}</g>`;
const tag=(text,x,y,selected=false,detail=false)=>`<g class="vector-label ${selected?'selected':''} ${detail?'map-label-detail':''}" transform="translate(${x} ${y})"><rect x="-${Math.max(44,text.length*3.3+12)}" y="-13" width="${Math.max(88,text.length*6.6+24)}" height="26" rx="8"/><text text-anchor="middle" dominant-baseline="central">${esc(text)}</text></g>`;
const pts=[[180,125],[410,205],[658,130],[195,315],[665,326],[458,417],[240,525],[710,518],[80,225],[365,92],[775,235],[812,415],[442,329]];
const districtPoint=id=>pts[DISTRICTS.findIndex(d=>d.id===id)];
function activityArt(S){
 const a=countryActivity(S);if(!a)return '';
 const mark=(kind,id,title,point,body)=>target(kind,id,title,`<g transform="translate(${point.join(' ')})">${body}</g>`);
 if(a.layer==='sea'){
  const p=districtPoint('port'),bend=[p[0],567];
  const routes=Object.entries(MARINE_NODES).map(([id,node])=>{
   const q=node.map,selected=a.selection.id===id;
   const path=`M${p}Q${bend} ${q}`;
   return target('route',id,ROUTES[id].name,`<path d="${path}" fill="none" stroke="transparent" stroke-width="30" pointer-events="stroke"/><path d="${path}" class="atlas-voyage-path ${a.closed.includes(id)?'interrupted':''} ${selected?'selected':''}"/><circle cx="${q[0]}" cy="${q[1]}" r="13" fill="#5297aa" stroke="#c6e3d6" stroke-width="3"/>${S.mapLabels===false?'':tag(ROUTES[id].name,Math.min(820,q[0]),q[1]+27,selected)}`);
  }).join('');
  return routes+a.ships.map((v,i)=>{
   const [x,y]=quadraticPoint(p,bend,MARINE_NODES[v.route].map,v.progress);
   return mark('ship',String(v.id),'کشتی '+num(v.id),[x+i*9,y-i*8],'<path d="M-20 1H21L13 11H-13Z" fill="#f1d79d" stroke="#174656" stroke-width="2"/><rect x="-8" y="-8" width="17" height="9" fill="#dbecdc"/>'+(v.protected?'<circle cx="19" cy="-8" r="6" fill="#69c4a3" stroke="#ecf7e3" stroke-width="2"/>':''));
  }).join('');
 }
 const d=a.drill,p=districtPoint(d.team),q=d.moving?districtPoint(d.moving):p;
 const team=p.map((v,i)=>v+(q[i]-v)*a.teamProgress);
 const zones=a.zones.map(z=>{
  const [x,y]=districtPoint(z.id),alert=d.target===z.id||a.warning?.zone===z.id;
  const covered=z.coverage>0||!d.moving&&d.team===z.id;
  const label=DISTRICTS.find(d=>d.id===z.id).name;
  const projects=z.projects.map(({key,level,building},i)=>`<g transform="translate(${26+i*18} 20)"><rect width="14" height="11" rx="2" fill="${building?'#eab77b':key==='station'?'#4a96a4':'#9ac591'}" stroke="#e7e9be"/><text x="7" y="8" text-anchor="middle" fill="#17382f" font-size="8">${num(level)}</text></g>`).join('');
  return mark('zone',z.id,'پوشش '+label,[x,y],`<circle r="46" class="atlas-defense-ring ${alert?'alert':z.damage?'damaged':covered?'covered':''}"/>${projects}
   ${z.protected?'<circle cx="-36" cy="17" r="6" fill="#d8d377" stroke="#ecf7e3"/>':''}
   ${z.repairing?'<path d="M-32-22h16m-8-8v16" stroke="#f4dc9a" stroke-width="4"/>':''}`);
 }).join('');
 const w=a.warning;
 const alarm=w?mark('crisis-alarm',w.zone,'هشدار بحران',quadraticPoint([780,548],[750,420],districtPoint(w.zone),a.crisisProgress),`<path d="M0-16L16 12H-16Z" fill="#b75e44" stroke="#f9db9d" stroke-width="3"/><path d="M0-7V2M0 5v2" stroke="#fff2d1" stroke-width="3"/>`):'';
 const warning=d.target?mark('alarm',d.target,'هشدار مانور',quadraticPoint([840,528],[680,440],districtPoint(d.target),a.warningProgress),'<path d="M0-13L13 0 0 13-13 0Z" fill="#c16b42" stroke="#ffe1aa" stroke-width="3"/>'):'';
 return zones+(d.moving?`<path d="M${p}L${q}" class="atlas-voyage-path"/>`:'')+mark('team','team','تیم واکنش',[team[0]+38,team[1]-37],'<path d="M0-18L16-10V4Q13 13 0 19Q-13 13-16 4V-10Z" fill="#176b61" stroke="#dcf4c3" stroke-width="3"/><path d="M-7 0H7M0-7V7" stroke="#f7f2d8" stroke-width="3"/>')+warning+alarm;
}
function atlas(S){
 const routes=atlasRoutes(S).map(({a,b,id,color,road,active,selected})=>{
  const p=pts[DISTRICTS.findIndex(d=>d.id===a)],q=pts[DISTRICTS.findIndex(d=>d.id===b)];
  const d=`M${p}Q${(p[0]+q[0])/2} ${(p[1]+q[1])/2-18} ${q}`;
  const line=`<path class="vector-route ${road?'':'service-route'}" d="${d}" stroke="${color}" stroke-width="${selected?12:road?9:7}" ${road||active?'':'stroke-dasharray="8 7"'}/>`;
  return id?target('network',id,'جزئیات مسیر',`<path d="${d}" fill="none" stroke="transparent" stroke-width="27" pointer-events="stroke"/>${line}`):line;
 }).join('');
 return `<defs><linearGradient id="map-ocean" x2="0" y2="1"><stop stop-color="#346f7e"/><stop offset="1" stop-color="#204d61"/></linearGradient><linearGradient id="map-land" x2="1" y2="1"><stop stop-color="#c9d3ab"/><stop offset="1" stop-color="#92ad86"/></linearGradient></defs><rect width="900" height="600" fill="url(#map-ocean)"/><path d="M20 80L176 27 450 55 690 27 855 120 861 345Q813 421 702 415L555 455 388 454Q264 417 190 401L38 330Z" fill="#172e3b" transform="translate(0 13)" opacity=".35"/><path d="M20 80L176 27 450 55 690 27 855 120 861 345Q813 421 702 415L555 455 388 454Q264 417 190 401L38 330Z" fill="url(#map-land)" stroke="#e8d7a9" stroke-width="7"/><path d="M319 60Q269 135 306 199T289 345Q292 399 352 443" stroke="#d5d6ab" stroke-width="20" fill="none"/><path d="M319 60Q269 135 306 199T289 345Q292 399 352 443" stroke="#76a8a6" stroke-width="12" fill="none"/><g fill="#889b85" stroke="#788d7b"><path d="M55 100L103 25 164 104Z"/><path d="M104 117L169 38 234 115Z"/><path d="M139 75L169 38 198 74 173 63Z" fill="#eef0db" stroke="none"/></g>${Array.from({length:23},(_,i)=>tree(75+(i*53)%705,82+(i*41)%290,.65+(i%3)*.2)).join('')}${routes}<path d="M100 487q70-19 128 2M380 555q74-20 139-4M697 460q70-16 143-4" stroke="#bad4cf" stroke-width="2" opacity=".25" fill="none"/>${DISTRICTS.map((d,i)=>{const [x,y]=pts[i],selected=d.id===(S.atlasSelected||'capital'),rig=d.kind==='rig',built=S.offshore?.[d.id]?.stage===5,lv=d.city!=null?1+(S.cities?.[d.city===1?'پایتخت':'مرکز شرقی']?.level||0):1;return target('district',d.id,d.name,`<g transform="translate(${x} ${y})"><ellipse cy="20" rx="66" ry="24" fill="${rig?'#8dbdb222':'#506f4b22'}" ${selected?'stroke="#f4cf7f" stroke-width="4"':''}/><g transform="scale(${rig?.48:.8})">${d.water?`<ellipse cy="5" rx="32" ry="16" fill="#5c98a7"/><rect x="-32" y="-35" width="64" height="40" fill="#82b4be"/><ellipse cy="-35" rx="32" ry="16" fill="#d4e9dd"/><path d="M-45 20H-15V-8M34 8H58" stroke="#3e7f91" stroke-width="8" fill="none"/>`:rig?renderOffshoreRig(d.id,built,S.offshore?.[d.id]?.health):art(d.kind,lv)}</g>${(d.id==='capital'&&S.development?.offers?.water?.status==='complete')||(d.water==='desal'&&S.waterSupply?.coastal?.built)?'<g transform="translate(43 10)"><ellipse cy="6" rx="16" ry="7" fill="#205b65"/><path d="M-16 6V-16H16V6Z" fill="#2b97a8"/><ellipse cy="-16" rx="16" ry="7" fill="#d9f3ea"/></g>':''}${S.mapLabels===false?'':tag(d.name,0,rig?72:62,selected,!selected&&!'capital north east port'.split(' ').includes(d.id))}</g>`)}).join('')}${activityArt(S)}<text x="824" y="568" class="vector-water-title" text-anchor="end">دریای جنوبی</text><g transform="translate(839 82)" class="map-compass"><path d="M0-22L8 8 0 3-8 8Z" fill="#f1dcaa"/><text text-anchor="middle" y="-29">شمال</text></g>`;
}
function lotMap(S,CITIES){
 const {city,cols,rows,lots,spacing}=layoutLots(S,CITIES),scale=Math.min(8,550/((cols+rows)*spacing*.55)),project=(x,z)=>[450+(x-z)*scale*.85,300+(x+z)*scale*.42],extent=Math.max(cols,rows)*spacing/2+2;
 const services=city&&S.mapLayer==='services'?cityServiceMap(S,CITIES[S.cityView].name):null;
 const corners=[[-extent,-extent],[extent,-extent],[extent,extent],[-extent,extent]].map(([x,z])=>project(x,z).join(',')).join(' ');
 return `<rect width="900" height="600" fill="#adc0b0"/><polygon points="${corners}" fill="#5b7e6b" transform="translate(0 12)"/><polygon points="${corners}" fill="#8da68a" stroke="#ddd5b2" stroke-width="5"/>${Array.from({length:cols+1},(_,i)=>{const x=(i-cols/2)*spacing,a=project(x,-rows*spacing/2),b=project(x,rows*spacing/2);return `<path d="M${a}L${b}" stroke="#64796f" stroke-width="${scale*1.15}"/>`}).join('')}${Array.from({length:rows+1},(_,i)=>{const z=(i-rows/2)*spacing,a=project(-cols*spacing/2,z),b=project(cols*spacing/2,z);return `<path d="M${a}L${b}" stroke="#64796f" stroke-width="${scale*1.15}"/>`}).join('')}${[...lots].sort((a,b)=>(a.x+a.z)-(b.x+b.z)).map(l=>{const [x,y]=project(l.x,l.z),w=spacing*scale*.77,h=w*.5,cityName=city?CITIES[S.cityView].name:'',district=city?districtDesign(S,cityName,l.id):null,placement=city?cityDesign(S,cityName).placements[l.id]:null;return target(city?'city-lot':'lot',l.id,`${placement?placementDefinition(placement.item)?.name||'آیتم':FARMS[l.type]?.name||(l.type?'ساختمان':'زمین')} ${num(l.id+1)}`,`<g transform="translate(${x} ${y})"><path d="M0 ${-h}L${w} 0 0 ${h} ${-w} 0Z" fill="${l.selected?'#ddc48c':l.pending?'#c7a77b':services?.has(l.id)?mapTone(services.get(l.id)?'ok':'bad'):city?STYLES[district.style].ground:l.type?'#c2c8a8':'#aebc96'}" stroke="${l.selected?'#fff3bc':'#d6dbb9'}" stroke-width="${l.selected?3:1}"/>${l.type?`<g transform="translate(0 -6) scale(${Math.min(.65,w/60)})">${l.pending?'<path d="M-21 7L0-9 21 7 0 20Z" fill="#bc9e6f" stroke="#f2daa2" stroke-dasharray="4 2"/><path d="M-15 7V-10M10 7V-10M-15-10H15" fill="none" stroke="#ad8247" stroke-width="2"/>':city?styleArt(art(l.type,l.level),district.style):art(l.type,l.level)}</g>`:`<path d="M-5 0h10M0-5v10" stroke="#6c8b75" stroke-width="1.4"/>`}${placement?`<g transform="translate(${l.type?w*.52:0} ${l.type?6:-5}) scale(${Math.min(l.type?.36:.65,w/66)})">${ornamentArt(placement.item,placement.level,placement.days>0)}</g>`:''}${city&&S.mapLabels!==false&&[10,13,16,37,40,43,64,67,70].includes(l.id)&&cityDesign(S,cityName).districts[districtIndex(l.id)]?`<text text-anchor="middle" y="${h+16}" font-size="12" fill="#325c49" stroke="#f0eed5" stroke-width="3" paint-order="stroke">${esc(district.name)}</text>`:''}${S.mapLabels===false?'':`<text y="${h-3}" class="lot-number ${l.selected?'':'map-label-detail'}" text-anchor="middle">${num(l.id+1)}</text>`}</g>`)}).join('')}`;
}
function campusLinks(S,units){
 const pos=units.findIndex(({i})=>i===S.siteSelectedUnit);
 if(pos<0)return '';
 const data=campusNetwork(S,S.siteSelectedUnit),x=115+(pos%6)*133,start=pos<6?252:380;
 const flow=(offset,y,tone)=>`<path d="M${x+offset} ${start} V${y} H${x+offset+(offset<0?-30:30)}" fill="none" stroke="${mapTone(tone)}" stroke-width="7" stroke-linecap="round" ${data.running?'':'stroke-dasharray="6 5"'}/>`;
 return (data.feeds.length?flow(-11,280,data.inputTone):'')+(data.outputs.length?flow(11,330,data.outputTone):'');
}
function campus(S){const {units}=industryPage(S),appearance=industryAppearance(S),palette=PALETTES[appearance.palette];return `<rect width="900" height="600" fill="#b6c8b9"/><path d="M50 70H850V544H50Z" fill="#a6b59b" stroke="#e4debb" stroke-width="7"/><path d="M50 305H850M450 70V544" stroke="#58716b" stroke-width="38"/><path d="M50 305H850M450 70V544" stroke="#c4ccab" stroke-width="2" stroke-dasharray="12 14"/><path d="M60 280H840M60 330H840" stroke="#d4b67a" stroke-width="5"/>${campusLinks(S,units)}${Array.from({length:12},(_,j)=>{const x=115+(j%6)*133,y=j<6?216:465,e=units[j];return `<g transform="translate(${x} ${y})"><path d="M-55-108H55V34H-55Z" fill="${e&&e.i===S.siteSelectedUnit?'#ead49e':e?'#d4d9bd':'#a1b197'}" stroke="${e&&e.i===S.siteSelectedUnit?'#fff2b8':'#e6e3c7'}" stroke-width="2"/>${e?target('unit',e.i,unitName(e.u,D,e.i),`<rect x="-55" y="-108" width="110" height="175" fill="transparent" pointer-events="all"/><g transform="scale(.66)">${campusPaletteArt(renderProcessFacility(e.u.t,e.u.st),S)}${e.u.st==='build'?'<path d="M-42 12V-92H44M-27 -92v104M25 -92v25" fill="none" stroke="#f9c261" stroke-width="4" stroke-dasharray="8 4"/>':''}</g>${S.mapLabels===false?'':tag(num(e.i+1)+' · '+(unitName(e.u,D,e.i).length>15?unitName(e.u,D,e.i).slice(0,14)+'…':unitName(e.u,D,e.i)),0,54,e.i===S.siteSelectedUnit,e.i!==S.siteSelectedUnit)}`):'<text class="lot-number" text-anchor="middle" y="-25">زمین توسعه</text>'}</g>`}).join('')}${Array.from({length:15+appearance.garden*5},(_,i)=>tree(55+(i*55)%790,572-Math.floor(i/15)*28,.65)).join('')}${appearance.office?`<g transform="translate(785 95) scale(${.6+appearance.office*.12})">${renderCityBuilding('service',appearance.office)}</g>`:''}${appearance.sign?`<g transform="translate(450 530)"><rect x="-135" y="-25" width="270" height="40" rx="8" fill="${palette.dark}" stroke="${palette.accent}" stroke-width="3"/><text text-anchor="middle" y="0" font-size="17" fill="#fff">${esc(appearance.name)} · ${appearance.logo==='leaf'?'❧':appearance.logo==='drop'?'◉':'⚙'}</text></g>`:''}`}
function marine(S,port){return `<rect width="900" height="600" fill="#347e8c"/>${port?`<path d="M0 0H900V120L675 200 400 150 0 220Z" fill="#adbf99" stroke="#e2d4a7" stroke-width="7"/><g transform="translate(450 290) scale(2.7)">${renderNationalHub('port',1)}</g><path d="M180 415l250 60 150-60" fill="#edf0cf" stroke="#23566a" stroke-width="4"/><path d="M180 415l40 31 210 46 150-60v-17l-150 60Z" fill="#c78b67"/>${tag('پایانه مشترک · '+num(S.port)+' واحد در روز',450,545)}`:['oil','gas'].map((id,i)=>{const x=i?660:245,o=S.offshore?.[id]||{};return target('district',id,id==='oil'?'میدان نفت':'میدان گاز',`<g transform="translate(${x} 255) scale(1.4)">${renderOffshoreRig(id,o.stage===5,o.health)}</g>${tag(id==='oil'?'میدان نفت دریایی':'میدان گاز دریایی',x,490)}<path d="M${x} 430L450 580" stroke="${o.pipelineLevel?'#dfba76':'#a3bab3'}" stroke-width="6" stroke-dasharray="12 9"/>`)}).join('')}`}
export function renderVectorMap(S,CITIES){const key=S.tab==='site'?'industry':countryViewKey(S);return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 600" style="background:${['atlas','offshore','hub:port'].includes(key)?'#347e8c':'#adc0b0'}" class="vector-world ${S.mapTime==='night'?'night':''}" aria-label="نمای ایزومتریک تعاملی" role="group">${key==='industry'?campus(S):key==='atlas'?atlas(S):key==='offshore'||key==='hub:port'?marine(S,key==='hub:port'):lotMap(S,CITIES)}</svg>`}
export function createVectorScene(host,key,onSelect){
 let node=host,callback=onSelect,signature='',zoom=1,pan={x:0,y:0},enabled=false,down=null,lastState;
 const view=()=>{const svg=node.querySelector('svg');svg?.classList.toggle('map-near',zoom>1.2);svg?.setAttribute('viewBox',`${450-450/zoom+pan.x} ${300-300/zoom+pan.y} ${900/zoom} ${600/zoom}`)};
 const choose=e=>{const g=e.target.closest?.('[data-map-kind]');if(!g)return;if(e.type==='keydown'&&!['Enter',' '].includes(e.key))return;if(e.type==='keydown')e.preventDefault();callback({kind:g.dataset.mapKind,id:['lot','city-lot','unit'].includes(g.dataset.mapKind)?Number(g.dataset.mapId):g.dataset.mapId})};
 const fingers=new Map();
 const distance=()=>{const [a,b]=[...fingers.values()];return Math.hypot(a.x-b.x,a.y-b.y)};
 const setZoom=factor=>{zoom=Math.max(.65,Math.min(4,zoom*factor));view()};
 const pointerDown=e=>{
  fingers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(down&&!down.released){down.moved=true;return}
  down={x:e.clientX,y:e.clientY,px:pan.x,py:pan.y,moved:false};
  if(enabled)e.target.setPointerCapture?.(e.pointerId);
 };
 const pointerMove=e=>{
  if(!down)return;
  const before=fingers.size===2?distance():0;
  if(fingers.has(e.pointerId))fingers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(fingers.size>1){
   down.moved=true;const after=distance();
   if(enabled&&before>0&&after>0)setZoom(after/before);
   return;
  }
  if(Math.hypot(e.clientX-down.x,e.clientY-down.y)>7)down.moved=true;
  if(!enabled||!down.moved)return;
  pan.x=Math.max(-450,Math.min(450,down.px-(e.clientX-down.x)*900/node.clientWidth/zoom));
  pan.y=Math.max(-300,Math.min(300,down.py-(e.clientY-down.y)*600/node.clientHeight/zoom));
  view();
 };
 const pointerUp=e=>{
  fingers.delete(e.pointerId);
  if(!down)return;
  if(fingers.size){const [p]=fingers.values();Object.assign(down,{x:p.x,y:p.y,px:pan.x,py:pan.y,moved:true});return}
  if(Math.hypot(e.clientX-down.x,e.clientY-down.y)>7)down.moved=true;
  down.released=true;
 };
 const click=e=>{const valid=down&&!down.moved;down=null;if(e.detail===0||valid)choose(e)};
 const wheel=e=>{if(!enabled)return;e.preventDefault();setZoom(e.deltaY<0?1.15:.87)};
 const bind=n=>{n.addEventListener('pointerdown',pointerDown);n.addEventListener('pointermove',pointerMove);n.addEventListener('pointerup',pointerUp);n.addEventListener('click',click);n.addEventListener('pointercancel',cancel);n.addEventListener('keydown',choose);n.addEventListener('wheel',wheel,{passive:false})};
 const cancel=()=>{down=null;fingers.clear()};
 const unbind=n=>{n.removeEventListener('pointerdown',pointerDown);n.removeEventListener('pointermove',pointerMove);n.removeEventListener('pointerup',pointerUp);n.removeEventListener('click',click);n.removeEventListener('pointercancel',cancel);n.removeEventListener('keydown',choose);n.removeEventListener('wheel',wheel)};
 bind(node);
 return {key,attach(n,f){callback=f;if(node!==n){unbind(node);cancel();node=n;signature='';bind(node)}node.dataset.renderer='vector';node.style.touchAction=enabled?'none':'pan-y';const button=document.querySelector('[data-a="atlas-camera"][data-k="toggle"]');if(button){button.setAttribute('aria-pressed',String(enabled));button.textContent=enabled?'پایان کنترل دوربین':'کنترل دوربین'}},update(S,CITIES){lastState=S;const next=sceneSignature(S,CITIES);if(next!==signature){const focus=node.querySelector(':focus')?.dataset;signature=next;node.innerHTML=renderVectorMap(S,CITIES);view();if(focus?.mapId!=null)node.querySelector(`[data-map-kind="${focus.mapKind}"][data-map-id="${focus.mapId}"]`)?.focus({preventScroll:true})}const note=document.querySelector('.map-renderer-note');if(note)note.textContent='نمای ایزومتریک سبک';},cameraAction(command){if(command==='toggle'){enabled=!enabled;node.style.touchAction=enabled?'none':'pan-y';const b=document.querySelector('[data-a="atlas-camera"][data-k="toggle"]');if(b){b.setAttribute('aria-pressed',String(enabled));b.textContent=enabled?'پایان کنترل دوربین':'کنترل دوربین'}}else if(command==='reset'){zoom=1;pan={x:0,y:0}}else if(command==='focus'){const id=lastState?.atlasSelected||'capital',i=DISTRICTS.findIndex(d=>d.id===id);if(key==='atlas'&&i>=0){zoom=1.7;pan={x:pts[i][0]-450,y:pts[i][1]-300}}else{const id=key.startsWith('industry:')?lastState?.siteSelectedUnit:lastState?.cityView!=null?lastState?.cityCell:lastState?.sel,g=node.querySelector(`[data-map-id="${id}"]`);if(g){const box=g.getBBox();zoom=2;pan={x:box.x+box.width/2-450,y:box.y+box.height/2-300}}}}else zoom=Math.max(.65,Math.min(4,zoom*(command==='in'?1.2:1/1.2)));view()},dispose(){unbind(node);node.innerHTML=''}};
}
