// Version 50 — vector/isometric visual layer only. No production or economic side effects.
const prism=(x,y,w=34,h=24,roof='#d5ddd8',front='#90a6a5',side='#627b7e')=>`<g><polygon points="${x},${y} ${x+w/2},${y-9} ${x+w},${y} ${x+w/2},${y+9}" fill="${roof}" stroke="#455f65" stroke-width=".8"/><polygon points="${x},${y} ${x+w/2},${y+9} ${x+w/2},${y+h+9} ${x},${y+h}" fill="${front}" stroke="#455f65" stroke-width=".7"/><polygon points="${x+w},${y} ${x+w/2},${y+9} ${x+w/2},${y+h+9} ${x+w},${y+h}" fill="${side}" stroke="#455f65" stroke-width=".7"/></g>`;
const column=(x,y,height=52,r=8)=>`<g><ellipse cx="${x}" cy="${y+1}" rx="${r+2}" ry="${r/2+2}" fill="#4a6d74" opacity=".22"/><rect x="${x-r}" y="${y-height}" width="${r*2}" height="${height}" rx="2" fill="#b7cbca" stroke="#516f76" stroke-width="1"/><rect x="${x+r*.3}" y="${y-height}" width="${r*.55}" height="${height}" fill="#789a9d" opacity=".7"/><ellipse cx="${x}" cy="${y-height}" rx="${r}" ry="${r*.48}" fill="#e9f0e9" stroke="#58747b"/><ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.48}" fill="#8ea9a7" stroke="#58747b"/>${[.24,.5,.76].map(t=>`<path d="M${x-r-2} ${y-height*t}h${2*r+4}" stroke="#5d8289" stroke-width="2"/>`).join('')}<path d="M${x+r+1} ${y-height+5}V${y+2}" stroke="#d8a65b" stroke-width="2" stroke-dasharray="3 4"/></g>`;
const bullet=(x,y,w=35)=>`<g><ellipse cx="${x}" cy="${y+6}" rx="${w/2+4}" ry="8" fill="#2a5157" opacity=".15"/><path d="M${x-w/2+6} ${y-14}h${w-12}q9 5 0 16h${-w+12}q-9-5 0-16" fill="#b5ccce" stroke="#53757c" stroke-width="1.2"/><path d="M${x-w/2+6} ${y-11}h${w-12}" stroke="#eef5ed" stroke-width="3"/><path d="M${x-10} ${y+1}v9m20-9v9" stroke="#536b71" stroke-width="3"/></g>`;
const tanks=(x,y)=>`${column(x,y,28,11)}${column(x+22,y-2,23,9)}`;
const rack=(x,y)=>`<g stroke-linecap="round"><path d="M${x-26} ${y}l20 10h26m-48-14 20 10h28" fill="none" stroke="#536d70" stroke-width="5"/><path d="M${x-26} ${y-1}l20 10h26" fill="none" stroke="#dfb36b" stroke-width="2"/><path d="M${x-24} ${y}v10m18 0v8m18-8v8" stroke="#5d777b" stroke-width="2"/></g>`;
const flare=(x,y)=>`<g><path d="M${x-6} ${y}l6-69 6 69m-10-43h8m-9 24h10m-11-5 12 8" stroke="#536d72" stroke-width="2.5" fill="none"/><path d="M${x} ${y-68}q-7-10 1-15q7 6 1 15z" fill="#f0a84b" stroke="#f9d38b" stroke-width="1.2"/></g>`;
const exchanger=(x,y)=>`<g><rect x="${x-20}" y="${y-13}" width="40" height="17" rx="8" fill="#7caeac" stroke="#426970" stroke-width="1"/><path d="M${x-13} ${y+4}v6m26-6v6M${x-21} ${y-5}h-8m50 0h8" stroke="#54757b" stroke-width="3"/><path d="M${x-12} ${y-12}h22" stroke="#d6ece4" stroke-width="2.5"/></g>`;
const solarPanel=(x,y,s=1)=>`<g transform="translate(${x} ${y}) scale(${s})"><polygon points="0,-12 24,-24 44,-12 20,0" fill="#265971" stroke="#91c4c1" stroke-width="1.4"/><path d="M6 -15l20 12M13 -20l20 12M10 -17l23-12" stroke="#75b2c5" stroke-width="1"/><path d="M12 -2v9m26-16v9" stroke="#576b70" stroke-width="2"/></g>`;
const gasCylinder=(x,y,r=11)=>`<g><ellipse cx="${x}" cy="${y+1}" rx="${r}" ry="${r*.48}" fill="#6f9699"/><rect x="${x-r}" y="${y-35}" width="${r*2}" height="35" fill="#8faeb1" stroke="#426c74"/><ellipse cx="${x}" cy="${y-35}" rx="${r}" ry="${r*.48}" fill="#d8e3df" stroke="#426c74"/><path d="M${x} ${y-40}v-8m-6 6h12" stroke="#586e78" stroke-width="2"/></g>`;
const coolingTower=(x,y)=>`<g><path d="M${x-20} ${y}Q${x-8} ${y-23} ${x-18} ${y-62}Q${x} ${y-69} ${x+18} ${y-62}Q${x+8} ${y-23} ${x+20} ${y}Z" fill="#a7babe" stroke="#5c727b" stroke-width="1.3"/><ellipse cx="${x}" cy="${y-62}" rx="18" ry="5" fill="#657d83" stroke="#e3e9e1" stroke-width="2"/><path d="M${x-11} ${y-71}q-8-9 2-15m9 13q-5-9 2-14" fill="none" stroke="#e7f0ef" stroke-width="4" opacity=".45"/></g>`;
const roundDome=(x,y)=>`<g><rect x="${x-27}" y="${y-12}" width="54" height="14" fill="#9aafb2" stroke="#4f6970"/><path d="M${x-27} ${y-12}a27 28 0 0 1 54 0Z" fill="#d6e1dc" stroke="#607c84" stroke-width="1.5"/><path d="M${x-18} ${y-31}q18-19 36 0" fill="none" stroke="#f7fbf5" stroke-width="2"/></g>`;
const crane=(x,y)=>`<g stroke="#c99b58" stroke-width="2.6" fill="none"><path d="M${x} ${y}v-74l50 9-50 6m25-10v39"/><path d="M${x-5} ${y-51}l10-10m-10-3 10-11M${x} ${y-61}h50" stroke-width="1.5"/><path d="M${x+50} ${y-61}v36" stroke="#66787c" stroke-width="1.2"/></g>`;

// One integrated site model per process unit. Equipment-shaped silhouettes remain decorative,
// while the entire unit continues to be one selectable facility connected to the DCS.
// v51.1 — Original isometric game artwork, loaded from bundled local WebP files.
// SVG model remains a single accessible selection target; images are decorative.
export const facilityImagePath=(type)=>`./assets/isometric/unit-${String(Math.max(0,Math.min(15,Number(type)||0))).padStart(2,'0')}.webp`;
export const offshoreImagePath=(kind)=>`./assets/isometric/offshore-${kind==='gas'?'gas':'oil'}.webp`;
export function renderProcessFacility(type,status='off'){
 const t=Math.max(0,Math.min(15,Number(type)||0));
 const running=status==='run',fault=status==='trip'||status==='broken',building=status==='build';
 const theme=running?'#36c18b':fault?'#ed6f64':building?'#e2b965':'#86a9b4';
 const label=running?'در سرویس':fault?(status==='broken'?'خرابی':'تریپ'):building?'در ساخت':status==='ready'?'آماده':'متوقف';
 return `<g class="facility-art facility-${t} ${running?'operating':''} ${building?'construction':''}">
  <ellipse cy="40" rx="68" ry="19" fill="#1c3b3c" opacity=".22" pointer-events="none"/>
  <g class="facility-scene">${t===13?solarPanel(-50,-5,1.6)+solarPanel(0,20,1.6):t===1?tanks(-25,4)+prism(2,0,40,20):prism(-48,0,58,28)+column(-12,-8,66,9)+column(18,-2,85,10)+rack(0,30)}${t===0||t===3?flare(50,0):""}</g>
  <path d="M-55 42Q0 68 55 42" stroke="${theme}" stroke-width="4" opacity=".95" fill="none" pointer-events="none"/>
  <circle cx="61" cy="-114" r="10" fill="${theme}" stroke="#fff5db" stroke-width="3" pointer-events="none"/>
  <circle cx="61" cy="-114" r="3.3" fill="#fff" pointer-events="none"/>
  <title>${label}</title>
 </g>`;
}

const cityBlock=(y,h,roof,front,side)=>`<polygon points="-19,${y} 0,${y-10} 19,${y} 0,${y+10}" fill="${roof}" stroke="#40584f" stroke-width="1"/><polygon points="-19,${y} 0,${y+10} 0,${y+h+10} -19,${y+h}" fill="${front}" stroke="#506d63"/><polygon points="19,${y} 0,${y+10} 0,${y+h+10} 19,${y+h}" fill="${side}" stroke="#48665a"/>`;
// User-supplied 3-stage city imagery. Keep one SVG group so click selection uses the existing tile hit area.
const CITY_ART_RATIO={"service-2":0.77209,"park-3":0.87674,"service-3":0.86744,"park-2":0.8814,"home-2":0.71395,"service-1":0.59767,"shop-1":0.56512,"shop-3":0.93023,"home-1":0.57907,"park-1":0.9093,"home-3":0.93953,"shop-2":0.85116};
export function renderCityBuildingArt(type,level=1){return renderCityBuilding(type,level)}
export function renderCityBuilding(type,level=1){
 const n=Math.max(1,Math.min(3,Number(level)||1)),height=16+(n-1)*14;
 const ground='<ellipse cy="24" rx="26" ry="11" fill="#284d37" opacity=".28"/>';
 if(type==='park')return `<g class="city-iso-building park">${ground}<polygon points="-25,3 0,-10 25,3 0,17" fill="#67986c" stroke="#e2dab5"/><path d="M-19 3L0 12 19 3M0-6v19" stroke="#c8b892" stroke-width="3"/><path d="M-17-2l-1-18m30 17 3-16" stroke="#7d6344" stroke-width="3"/><circle cx="-19" cy="-23" r="10" fill="#3b8658"/><circle cx="-10" cy="-19" r="8" fill="#5aab70"/><circle cx="15" cy="-23" r="11" fill="#438553"/><circle cx="20" cy="-16" r="7" fill="#79b46d"/>${n>=2?'<circle cx="4" cy="-36" r="9" fill="#4d9a59"/>':''}${n>=3?'<path d="M-6 6h13M-5 9h11" stroke="#e1d7bd" stroke-width="2"/>':''}</g>`;
 const style={home:['#d7a476','#bc8660','#895f54'],shop:['#8dbcc0','#7caaaf','#4f8791'],service:['#e2e1cd','#b8c9ba','#819d9a']}[type]||['#d8b18b','#a88e74','#7d6961'];
 const building=cityBlock(-11-height,height+19,...style);
 const windows=Array.from({length:n+1},(_,i)=>`<g><polygon points="-15,${9-i*12} -8,${12-i*12} -8,${18-i*12} -15,${15-i*12}" fill="#c9e3da" stroke="#486a6d" stroke-width=".8"/><polygon points="9,${12-i*12} 16,${9-i*12} 16,${15-i*12} 9,${18-i*12}" fill="#7ba8ad" stroke="#345e68" stroke-width=".8"/></g>`).join('');
 const roof=type==='home'?`<path d="M-21 ${-11-height} L0 ${-25-height} L21 ${-11-height}" fill="none" stroke="#a6614f" stroke-width="3.5"/><rect x="5" y="${-33-height}" width="5" height="12" fill="#926b5f"/>`:type==='shop'?`<polygon points="-20,${-11-height} 0,${-22-height} 20,${-11-height} 0,${-1-height}" fill="#a1cdd0" stroke="#d4e4d8"/>`:`<path d="M0 ${-22-height}v-9M-5 ${-26-height}h10" stroke="#e47259" stroke-width="4"/>`;
 const front=type==='shop'?'<path d="M-18 9l18 9 18-9" stroke="#dfd9b3" stroke-width="3" fill="none"/><path d="M-12 16v12m24-12v12" stroke="#4f756d" stroke-width="2"/>':type==='service'?'<path d="M-7 -2v14M-13 5H-1" stroke="#c64e56" stroke-width="3"/>':'<rect x="-4" y="14" width="8" height="16" rx="1" fill="#6f5849"/>';
 return `<g class="city-iso-building ${type}">${ground}${building}${roof}${windows}${front}${n===3?'<path d="M-20 29L0 40L20 29" stroke="#eedebe" fill="none" stroke-width="1.5"/>':''}</g>`;
}

export function renderFarmBuilding(kind,level=1){
 const h=13+level*4;
 const base='<path d="M-37 7L0-12 38 7 0 25Z" fill="#92a375" stroke="#d8d6a1"/>';
 const shapes={
  field:()=>Array.from({length:6},(_,i)=>`<path d="M${-27+i*6} ${7-i*3}l29 14" stroke="${i%2?'#c3bf76':'#637d49'}" stroke-width="4"/>`).join(''),
  greenhouse:()=>prism(-27,-18,52,19,'#bdd9d2','#8caea1','#64928f')+'<path d="M-21-19l25 7 14-6m-17 7v16" fill="none" stroke="#d8e9df" stroke-width="2"/>',
  barn:()=>prism(-25,-20,51,25,'#b96f56','#b3a289','#837a67')+'<path d="M-19 2l10 4v13l-10-4Z" fill="#624e49"/>',
  dairy:()=>prism(-29,-22,42,h,'#a8c4bd','#889f9d','#617d81')+column(21,12,h,6),
  silo:()=>column(-12,10,h+12,9)+column(9,12,h+10,9),
  cold:()=>prism(-29,-16,56,24,'#add1d5','#92a8ba','#668297')+'<path d="M-17-2l9 4m-5-8v13" stroke="#e7f4ee" stroke-width="2"/>'
 };
 return base+shapes[kind]();
}

export function renderNationalHub(kind='city',level=1){
 const capital=kind==='capital',industrial=kind==='industrial',port=kind==='port';
 const body=industrial?`${prism(-43,-9,42,24)}${column(-20,-6,47,6)}${column(8,-4,56,6)}${prism(7,2,38,23,'#b5cbca')}`:port?`${prism(-38,2,45,27,'#e2cda5','#a7b8aa','#6e837f')}${crane(16,-7)}<path d="M-50 31h100l-12 10h-76z" fill="#b7a382"/>`: `${prism(-39,2,42,22,'#e3c79d','#b7a285','#796b5d')}${prism(5,-7,36,30,'#c8d8d0','#9fbaab','#729b95')}${capital?`${prism(-10,-21,24,36,'#d5ccad','#b0a68b','#786e62')}<path d="M1 -55v-12" stroke="#d5b76c" stroke-width="3"/>`:''}`;
 return `<g><ellipse cy="28" rx="61" ry="24" fill="#1e3b3a" opacity=".22"/><polygon points="0,-18 60,13 0,44 -60,13" fill="#aca788" stroke="#f7e2ac" stroke-width="1.4"/><path d="M-45 15L0 37L45 15" stroke="#ded2a7" stroke-width="4" fill="none"/>${body}${level>1?`<circle cx="49" cy="-10" r="7" fill="#d5c08c"/>`:''}</g>`;
}

function renderOffshoreRigVector(kind='oil',built=false,health=100){
 const isOil=kind==='oil',color=health<30?'#ef7973':health<55?'#e7b758':'#55c8ab';
 const jacket=`<g stroke="#395666" stroke-width="6" fill="none"><path d="M-50 17l-14 102m50-103-8 103M20 17l8 102M53 17l14 102M-64 118h131M-61 80h118M-56 52h109"/><path d="M-59 80l39 38m30-38-28 38m48-66 33 28m-32 38 27-38m-100-28 37 28" stroke="#5b7881" stroke-width="3"/></g>`;
 const deck=`<polygon points="-76,-1 10,-35 84,-1 -5,35" fill="#e0d6b9" stroke="#d8e7db" stroke-width="3"/><polygon points="-76,-1 -5,35 -5,45 -76,10" fill="#677e84"/><polygon points="84,-1 -5,35 -5,45 84,9" fill="#4a646c"/><path d="M-74 -2L10 -35 83 -2" fill="none" stroke="#f5c873" stroke-width="2.5"/><path d="M-67 -9v-9m133 8v-10" stroke="#d8b86a" stroke-width="3"/>`;
 const fac=isOil?`${column(11,-9,60,12)}${bullet(-26,-10,37)}${crane(44,-7)}${rack(-9,3)}`:`${gasCylinder(-19,-6,11)}${gasCylinder(8,-14,11)}${column(31,-10,72,11)}${flare(56,-9)}${rack(-19,9)}`;
 const heli=`<g><ellipse cx="-65" cy="-14" rx="30" ry="17" fill="#f0ca75" stroke="#456a76" stroke-width="4"/><text x="-65" y="-10" text-anchor="middle" font-size="14" fill="#425761" font-weight="bold">H</text></g>`;
 const construction='<path d="M-55 -20L60 20M-55 20L60-20" stroke="#f5dc96" stroke-width="4" stroke-dasharray="10 6"/><text text-anchor="middle" y="8" font-size="14" font-weight="bold" fill="#f8e9ce">طرح توسعه</text>';
 return `<g class="offshore-platform-svg"><ellipse cx="0" cy="126" rx="83" ry="15" fill="#0b4052" opacity=".3"/>${built?`${jacket}${deck}${heli}${fac}<circle cx="73" cy="-44" r="8" fill="${color}" stroke="#fff6d7" stroke-width="3"/>`:`<g opacity=".75"><path d="M-55 25l60-28 59 28-60 29z" fill="#5a8791" stroke="#e0e5d7" stroke-width="3" stroke-dasharray="7 6"/>${construction}</g>`}</g>`;
}

// Completed marine facilities use the original painted artwork. The survey/construction
// stage retains the original prospect schematic: no productive rig is shown before unlock.
export function renderOffshoreRig(kind='oil',built=false,health=100){
 return renderOffshoreRigVector(kind,built,health);
}
