import {NETWORKS,networkKey,countryNetwork} from './ui/map-operations.js';
import {advanceResilienceDay,baseCrew,resilienceAction,resilienceFactor,staffedStations} from './systems/resilience.js';
import {FARMS,ROUTES,DRILL_ZONES,strategyState,changeFarm,dispatchVoyage,protectVoyage,changeDrill,loadScheduledVoyages} from './systems/strategy.js';
import {DISTRICTS} from './systems/country-planning.js';
import {acceptDevelopment,settleDevelopment,advanceStoryCrisis,prepareStoryCrisis,storyFactor} from './systems/development.js';
import {renderDevelopment} from './ui/development.js';
import {installTouchSafety} from './ui/touch-safety.js';
import {offshoreTransferAlerts,renderAlertBubbles} from './ui/offshore-alert.js';
import {legacyAction,legacyState,discoverAchievements,advanceLegacyDay,cityDesign,LANDMARKS} from './systems/legacy-development.js';
import {renderLegacyCenter} from './ui/legacy-center.js';
import {waterNetwork,waterAction,simulateWaterDay} from './systems/water-supply.js';
import {cleanUnitName,unitTitle,unitName} from './systems/unit-names.js';
import {stepOperatingDrift} from './systems/operating-drift.js';
import {clearNavigationHighlight,highlightNavigationTarget} from './ui/navigation-highlight.js';
import {closeCashDay} from './systems/cash-clarity.js';
import {createGameAudio} from './systems/game-audio.js';
import {mountAudioControls} from './ui/audio-controls.js';
import {renderControlRoom} from './ui/control-room.js';
import {runProductAutomation,productRule,saveProductRule,automationSettings,emergencyImportAllowance,recordEmergencyImport} from './systems/product-automation.js';
import {effectiveTradePort,importTradeFactor} from './systems/trade-conditions.js';
import {changeSafety,reviewSafetyDay} from './systems/safety.js';
import {renderSafetyReport} from './ui/safety-report.js';
import {renderProductMarket} from './ui/product-market.js';
import {executeProductTrade} from './systems/product-market.js';
import {hasEquipmentFaults,recoveryBlock,renderReserveRepairs} from './systems/unit-recovery.js';
import {runAutoMaintenance,advancePartOrders,purchaseMaintenance,normalizeMaintenance,maintenanceLicenseCost} from './systems/auto-maintenance.js';
import {maintenancePanel,maintenanceFleet} from './ui/auto-maintenance.js';
import {analyzeUnit,recommendations} from './systems/unit-diagnostics.js';
import {renderAdvisorReport,renderRecommendation,quickButton} from './ui/crisis-advisor.js';
import {refreshMapMarkup,refreshAdvisorMarkup,refreshScreenMarkup} from './ui/map-refresh.js';
import {renderIndustrySite} from './ui/industry-view.js';
import {renderCountry} from './ui/country-view.js';
import {mountCountryScene,countryCamera} from './ui/country-scene.js';
import {districtLots} from './systems/country-planning.js';
import {rememberCityMove,undoCityMove} from './systems/city-move-history.js';
// Process Tycoon v51 — integration audit, linked urban economy, shipping and contract accounting, versioned guide
// DCS selector stability fix; modular state, economy, equipment and simulation clock.
'use strict';

import {nextAction,projectEstimate,unitExplanation} from './ui/player-help.js';
import { D, PROB, PR, IMP, setImportMultiplier, IN, ALT, OPT, INF, OUT, TY, GW, GH, CELL, MK, OPN, EM, RIV, IC, INFN, SEAS, SF, TECH, TECHN, GOAL, L5 } from './data/catalog.js';
import {createFreshState,normalizeState,loadState,saveState} from './core/game-state.js';
import {createEconomy} from './systems/economy.js';
import {createEquipmentTools} from './systems/equipment.js';
import {createProcessClock} from './systems/game-engine.js';
import {createProcessModel} from './systems/process.js';
import {createIndustryActions} from './systems/industry.js';
import {renderProjectSections,renderProjectNavigation,projectStage} from './ui/project-grid.js';
import {renderProcessMimic} from './ui/process-mimic.js';
import {createPIDController} from './systems/pid-controller.js';
import {describeFinalElement,actuatorPosition} from './systems/control-elements.js';
import {advanceProcessVariable,applyProcessDisturbance,calculateProcessCoupling,calculateProductQuality} from './systems/process-dynamics.js';
import {stepUnitProcessModel} from './systems/process-unit-model.js';
import {OFFSHORE,offshoreStages,reservoirMetrics,advanceOffshoreProjects,simulateOffshoreDay,seaCondition,recoveryReady,recoveryAvailable,nextOffshoreExtension,startOffshoreExtension,startOffshoreMaintenance,isolateOffshore,resumeOffshorePipeline} from './systems/offshore.js';
import {renderProcessFacility,renderCityBuildingArt,renderNationalHub,renderOffshoreRig,facilityImagePath} from './ui/strategy-graphics.js';
import {createStarterCityGrid,cityDevelopmentMetrics,summarizeUrbanDevelopment} from './systems/urban-economy.js';
import {auditSystemLinks} from './systems/integration-audit.js';
// v = [نام، واحد، هدف، نیم‌پهنای باند مجاز]   e = [نام تجهیز، دارای استندبای؟]
// تولید روزانه‌ی هر واحد در حالت ایده‌آل، هم‌ترتیب با D
// خوراک روزانه‌ی هر واحد (از مخزن خودتان برداشت می‌شود؛ کسری با قیمت واردات خریده می‌شود)
const r=Math.random,cl=(x,a,b)=>Math.min(b,Math.max(a,x));
const tripDeviationSafe=(vars,values)=>(vars||[]).reduce((m,v,k)=>{const measured=Number(values?.[k]);return Math.max(m,Math.abs((Number.isFinite(measured)?measured:v[2])-v[2])/Math.max(Number(v[3])||.001,.001))},0);
const fa=n=>Number.isFinite(n)?Math.round(n).toLocaleString('fa-IR'):'۰',f1=n=>!Number.isFinite(n)?'۰':n.toFixed(1).replace('.','٫').replace(/\d/g,c=>'۰۱۲۳۴۵۶۷۸۹'[c]),$=s=>document.querySelector(s);
let S;
S=loadState();
normalizeState(S,{setImportMultiplier,D,PR,MK,GW,GH});
if(S.tab==='offshore'){
 S.tab='c';
 S.offshoreView=true;
 S.cityView=null;
}

const economy=createEconomy({getState:()=>S,PR,IN,OUT,IMP:()=>IMP,fa,log:t=>log(t)});
const {cap,feedTxt,feedCost,prodTxt,pay}=economy;
const equipment=createEquipmentTools({D});
const {level:lvl,partCost,isOut,anyOut}=equipment;
const maintenanceCost=(u,d)=>{const wear=(u.eq||[]).reduce((a,e)=>a+(100-e.h)+(e.reserve?100-e.reserve.h:0),0);return wear>0?d.cost*.012+wear*d.cost/6500:0};
const save=()=>{const ok=saveState(S);const el=document.getElementById('saveStatus');if(el){el.textContent=ok?'ذخیره شد · روز '+fa(S.day):'ذخیره ناموفق؛ پشتیبان بگیر';el.className=ok?'ok':'bd';el.title=ok?'پیشرفت در همین مرورگر ذخیره شد.':'حافظه مرورگر در دسترس نیست یا پر شده است؛ از پشتیبان ذخیره استفاده کن.'}return ok};
const gameAudio=createGameAudio({getState:()=>S});
const snd=t=>gameAudio.message(t);
const log=t=>{snd(t);S.log.unshift('روز '+fa(S.day)+': '+t);S.log.length=Math.min(S.log.length,40)};
const recordSOE=(message,severity='INFO',unitIndex=null)=>{S.soe=Array.isArray(S.soe)?S.soe:[];S.soe.unshift({day:S.day,message,severity,unit:unitIndex==null?'':D[S.u[unitIndex]?.t]?.n||''});S.soe.length=Math.min(S.soe.length,60);};

const A=createIndustryActions({S,D,INF,TECHN,PR,IMP:()=>IMP,PROB,feedCost,partCost,pay,log,r,fa,anyOut});
const EV=()=>{const x=r();
 if(x<.3&&!S.offers.length){S.offers.push({t:'exp',txt:'پیشنهاد قرارداد صادراتی: ۲۰ روز درآمد ×۱٫۳',d:12});log('پیشنهاد قرارداد صادراتی رسید.')}
 else if(x<.55&&!S.offers.length){S.offers.push({t:'strike',txt:'نیروها تهدید به اعتصاب کرده‌اند. با پرداخت ۱۵۰۰ مذاکره می‌کنید؟',d:8});log('تهدید به اعتصاب!')}
 else if(x<.8){S.fx.sanc=15;log('تحریم جدید برای ۱۵ روز: قیمت صادرات ×۰٫۷، واردات خارجی ×۱٫۲۵ و ظرفیت قابل استفاده پایانه ۶۵٪.')}
 else{S.fx.spike=12;log('جهش قیمت جهانی: ۱۲ روز ×۱٫۴.')}};
const processModel=createProcessModel({S,TY,SF,PR,MK,cl,r,log});
const REGIONS=[['شمال غرب',0,0],['شمال مرکزی',1,0],['شمال شرق',2,0],['غرب',0,1],['مرکز',1,1],['شرق',2,1],['جنوب غرب',0,2],['جنوب مرکزی',1,2],['جنوب شرق',2,2]];
// v51.4: National background is north-up with a SOUTHERN coastline. Geographic
// markers are visual only; persistent city keys remain their original names.
const CITIES=[
 {name:'مرکز شمالی',x:322,y:112,region:1,kind:'city'},
 {name:'پایتخت',x:396,y:248,region:4,kind:'capital'},
 {name:'مرکز شرقی',x:638,y:214,region:5,kind:'city'},
 {name:'بندر جنوبی',x:452,y:354,region:7,kind:'port'},
 {name:'مرکز انرژی',x:604,y:300,region:5,kind:'industrial'}
];
const MARINE_FIELDS={oil:{x:175,y:462,shoreX:308,shoreY:388},gas:{x:623,y:441,shoreX:585,shoreY:321}};
// Image-coordinated region marks avoid sea, coast and the mountainous north-west.
const REGION_DISPLAY_ANCHORS=[[109,124],[360,93],[638,88],[122,250],[380,218],[650,226],[153,337],[359,342],[650,305]];

function regionCells(rx,ry){const cells=[];for(let y=Math.floor(ry*GH/3);y<Math.floor((ry+1)*GH/3);y++)for(let x=Math.floor(rx*GW/3);x<Math.floor((rx+1)*GW/3);x++)cells.push(y*GW+x);return cells}
function regionMetrics(index){const [name,rx,ry]=REGIONS[index],cells=regionCells(rx,ry),built=cells.filter(i=>S.grid[i]),available=cells.filter(i=>!S.grid[i]&&buildable(i)).length;let connected=0,total=0;built.forEach(i=>{const b=S.grid[i],need=Object.keys(TY[b.t]?.need||{});if(!need.length)return;need.forEach(k=>{total++;if(b.c?.[k])connected++})});const coverage=total?connected/total*100:100,state=S.regions?.[index]||{},level=state.investment||0,infra=state.infrastructure||{},infraTotal=['power','gas','water','roads'].reduce((a,k)=>a+cl(Number(infra[k])||0,0,3),0),infraAvg=infraTotal/4,density=built.length/cells.length*100;return {name,cells,built:built.length,available,coverage,level,density,infra,infraAvg,index:cl(coverage*.48+Math.min(100,density*3)*.12+level*5.5+infraAvg*5.5,0,100),satisfaction:state.satisfaction??70}}
function updateRegionalEconomy(){if(S.day%30!==0)return;S.regions=S.regions||{};let totalDelta=0;REGIONS.forEach((_,i)=>{const m=regionMetrics(i),state=S.regions[i]||(S.regions[i]={investment:0,satisfaction:70});const serviceShortage=1-(S.fr?.power??1)*.25-(S.fr?.gas??1)*.25-(S.fr?.water??1)*.25-(S.fr?.fuel??1)*.25;const infraAvg=['power','gas','water','roads'].reduce((a,k)=>a+cl(Number(state.infrastructure?.[k])||0,0,3),0)/4;const city=CITIES.find(c=>c.region===i),cityLevel=city?(Number(S.cities?.[city.name]?.level)||0):0;const delta=cl((m.coverage-75)*.018+(state.investment||0)*.12+infraAvg*.24+cityLevel*.08-serviceShortage*2.2,-2.5,1.8);state.satisfaction=cl((state.satisfaction??70)+delta,0,100);totalDelta+=delta});S.sat=cl((S.sat||70)+totalDelta/REGIONS.length*.18,0,100)}
const pidController=createPIDController({cl});
const country=(fm,remainingPort)=>processModel.country(fm,remainingPort,CITIES);
function updateDynamicEconomy(){
 const e=S.economy||(S.economy={inflation:100,unemployment:8,employment:0,stability:75,shock:null,relief:0});
 if(!Number.isFinite(e.inflation))e.inflation=100;if(!Number.isFinite(e.unemployment))e.unemployment=8;if(!Number.isFinite(e.stability))e.stability=75;
 if(e.shock&&e.shock.days>0&&--e.shock.days===0){log('بحران اقتصادی «'+e.shock.name+'» پایان یافت.');e.shock=null;}
 if(S.day%30!==0)return;
 const needs=['power','gas','water','fuel'].filter(k=>(S.dem?.[k]||0)>0);
 const shortage=needs.length?needs.reduce((a,k)=>a+cl(1-(S.fr?.[k]??1),0,1),0)/needs.length:0;
 const running=S.u.filter(u=>u.st==='run').length,total=Math.max(1,S.u.length);
 const employment=cl(35+running/total*45+(S.eng||0)*2+(S.nationalProjects?.petrochem||0),0,95);
 e.employment=Math.round(employment*10)/10;e.unemployment=cl(100-employment,3,35);
 const fiscalPressure=cl(((S.govRate||1)-1)*.65,-.4,.5);
 const shockPressure=e.shock?.type==='supply'?.45:e.shock?.type==='demand'?.15:0;
 const inflationDelta=cl(0.12+shortage*1.8+fiscalPressure+shockPressure-(e.stability/100)*.22,-.35,2.4);
 e.inflation=cl(e.inflation+inflationDelta,75,220);
 const satDelta=(.35-shortage*5-(e.inflation>125?.55:0)-(e.unemployment>20?.45:0)+(e.relief>0?.8:0));
 S.sat=cl((S.sat||70)+satDelta,0,100);e.stability=cl(e.stability+(.2-shortage*3-(e.inflation>140?.7:0)+(S.sat>70?.15:0)),0,100);
 if(e.relief>0)e.relief--;
 if(!e.shock&&r()<.12){const type=r()<.55?'supply':'demand';e.shock={type,name:type==='supply'?'اختلال زنجیره تأمین':'رکود تقاضا',days:18};log('بحران اقتصادی: '+e.shock.name+'؛ فشار بر قیمت‌ها و فعالیت اقتصادی برای ۱۸ روز.');}
 if(e.inflation>150)log('هشدار اقتصاد ملی: تورم بالا هزینه‌های عملیاتی و فشار معیشتی را افزایش داده است.');
 if(shortage>.25)log('هشدار اقتصاد ملی: کمبود خدمات انرژی/آب به '+fa(Math.round(shortage*100))+'٪ رسیده و رضایت عمومی تحت فشار است.');
}
function tick(){
 normalizeState(S,{setImportMultiplier,D,PR,MK,GW,GH});const openingCash=S.money;S.day++;
 advanceStoryCrisis(S,r,log);
 advanceResilienceDay(S,log);
 // Advance field development, pipelines, integrity work and assisted-recovery projects.
 advanceOffshoreProjects(S,log);
 advancePartOrders(S,D,log);
 // Export contracts draw down stored inventory and share the daily port limit.
 S.portCapacityToday=effectiveTradePort(S);let contractPort=loadScheduledVoyages(S,S.portCapacityToday,log),contractIncome=0;
 (S.tradeContracts||[]).slice().forEach(c=>{
  const available=Math.max(0,S.tanks[c.p]||0),deliver=Math.min(available,c.remaining,contractPort);
  if(deliver>0){S.tanks[c.p]-=deliver;c.remaining-=deliver;c.delivered=(c.delivered||0)+deliver;contractPort-=deliver;const gross=deliver*c.unitPrice;const applied=Number.isFinite(c.advanceBalance)?Math.min(gross,Math.max(0,c.advanceBalance)):0;if(Number.isFinite(c.advanceBalance))c.advanceBalance-=applied;contractIncome+=gross-applied;}
  c.days--;
  if(c.remaining<=.001){S.tradeHistory.unshift({p:c.p,qty:c.qty,delivered:c.delivered,status:'تحویل کامل',day:S.day});S.tradeContracts=S.tradeContracts.filter(q=>q!==c);log(`قرارداد صادرات ${PR[c.p][0]} با تحویل کامل تسویه شد.`)}
  else if(c.days<=0){const penalty=c.remaining*c.unitPrice*.18,refund=Number.isFinite(c.advanceBalance)?Math.max(0,c.advanceBalance):0;S.money-=penalty+refund;S.tradeHistory.unshift({p:c.p,qty:c.qty,delivered:c.delivered,status:'نقض قرارداد',day:S.day,penalty,refund});S.tradeContracts=S.tradeContracts.filter(q=>q!==c);log(`مهلت قرارداد ${PR[c.p][0]} تمام شد؛ ${fa(c.delivered)} تحویل، بازپرداخت پیش‌دریافت ${fa(refund)} و جریمه ${fa(penalty)} اعمال شد.`)}
 });
 S.tradeRevenueToday=contractIncome;
 runAutoMaintenance(S,{D,PR,OPN,IN,OPT,importMultiplier:()=>IMP,availableOperators:opsAvail,remainingPort:()=>contractPort,log,recordSOE,random:r});
 let availablePortForFeed=contractPort;S.feedPortUsedToday=0;
 S.pd={};S.prodLoss={};S.cs={};S.imp={};S.ic={};S.imc=0;S.mkt=cl(S.mkt+(r()-.5)*.12,.6,1.8);const inflationCost=cl(1+((S.economy?.inflation??100)-100)*.002,.9,1.3),supplyShock=S.economy?.shock?.type==='supply'?1.18:1;let net=-(S.ops*(S.sal||12)+(S.eng||0)*40)*inflationCost+(S.tradeRevenueToday||0);S.portRemainingToday=contractPort;S.portUsedToday=S.portCapacityToday-contractPort;S.marketDay={};simulateWaterDay(S,{cap});runProductAutomation(S,{PR,cap,IN,OUT,importMultiplier:IMP});availablePortForFeed=S.portRemainingToday;let importCashBudget=Math.max(0,S.money-automationSettings(S).reserve);
 // Wellhead output fills a separate offshore buffer; pipelines carry feed to onshore tanks.
 S.offshoreOperatingCostToday=simulateOffshoreDay(S,cap,log,r,recordSOE);
 net-=S.offshoreOperatingCostToday;
 const districtDamage=resilienceFactor(S,'industry');
 const running=opsNeed(),avail=opsAvail(),rt=running?Math.min(1,avail/running):1,opF=(running&&rt<1?.4+.6*rt:1)*(S.gridIncident?.days>0?S.gridIncident.factor:1),nz=Math.pow(.85,S.tr)*(1+(1-rt)*1.5)*((S.tech||{}).apc?.7:1);
 const fm=(S.fx.sanc?.7:1)*(S.fx.spike?1.4:1)*(S.fx.exp?1.3:1)*(S.esg>=70?1.1:S.esg<40?.9:1)*(S.fx.rival?.9:1);
 {const em=emission()*Math.pow(.7,S.ab||0);S.esg=S.esg+(cl(100-em*4,0,100)-S.esg)*.05;if(S.esg<30&&S.day%5===0){S.money-=500;log('جریمه‌ی زیست‌محیطی ۵۰۰ به‌خاطر نمره‌ی ESG پایین.')}}
 S.rv=S.rv.map(w=>w*(1+(.004+(r()-.4)*.012)*[.6,1,1.4][S.diff==null?1:S.diff]));if(r()<.01&&!S.fx.rival){S.fx.rival=10;log('رقیب قیمت‌شکنی کرد: قیمت صادرات ۱۰ روز ۱۰٪ کمتر.')}
 S.mor=cl(S.mor+(.25-(1-rt)*2.5-(S.sat<50?.5:0)-(S.safe<60?.5:0)-(S.fx.strike?.5:0)+(S.mor<80?.15:0)),0,100);
 if(S.walk){if(--S.walk.d<=0){S.walk=null;S.mor=Math.max(S.mor,50);log('اپراتورها به کار برگشتند.')}}
 else if(S.mor<35&&running&&r()<(35-S.mor)/60+.03){S.walk={d:4+Math.floor(r()*4),f:.4+r()*.5,c:0};log('اپراتورها به‌خاطر نارضایتی دست از کار کشیدند! (چند روز)')}
 S.u.forEach((u,ui)=>{const d=D[u.t];
  if(u.tb>0)u.tb--;
  if(u.st==='tar'){if(--u.tar<=0){u.eq.forEach(e=>{e.h=100});u.tb=60;u.v=d.v.map(x=>x[2]+(r()<.5?-1:1)*x[3]*1.2);u.st='run';log('تعمیرات اساسی «'+d.n+'» تمام شد؛ واحد دوباره در مدار است.')}return}
  u.load=cl(Number(u.load)||100,50,140);u.feedGrade=cl(Number(u.feedGrade)||90,70,100);u.overloadTicks=u.overloadTicks||0;
  const preStress=tripDeviationSafe(d.v,u.v);
  u.eq.forEach((e,j)=>{const nm=d.e[j][0],sb=d.e[j][1];
   // Random breakdowns are disabled above 30% health. Severe process excursions
   // accelerate wear and make low-health equipment more failure-prone.
   const isPumpEquipment=/پمپ|pump/i.test(String(nm));const mainInService=!isPumpEquipment||e.running!==false;const failureRisk=mainInService&&e.h<30?(0.0015+(30-e.h)*.00035+Math.max(0,preStress-1.5)*.002)/e.l:0;
   if(u.st==='run'&&!e.f&&failureRisk>0&&r()<failureRisk*(u.tb>0?.5:1)*((S.tech||{}).pred?.6:1)*Math.pow(.88,S.eng||0)*[.7,1,1.4][S.diff==null?1:S.diff]){e.f={st:0,eta:0,dl:sb?8:0};
    if(sb){recordSOE('خرابی تجهیز '+nm+'؛ بررسی ورود رزرو.','HIGH',ui);if(/پمپ|pump/i.test(nm)&&e.reserve&&!e.reserve.f&&e.reserve.h>=30){u.processState=u.processState||{};u.processState.pumpStandby=true;e.running=false;e.reserve.running=true;}log(nm+' اصلی خراب شد؛ تجهیز رزرو در صورت آماده‌بودن وارد مدار شد. تا ۸ روز قطعه را تهیه و تعمیر کنید وگرنه رزرو هم از دسترس خارج می‌شود!')}
    else{recordSOE('خرابی تجهیز '+nm+' و خروج واحد از سرویس.','HIGH',ui);log(nm+' خراب شد و واحد «'+d.n+'» از سرویس خارج شد.');changeSafety(S,-.75,'خرابی تجهیز بحرانی؛ خروج خودکار واحد از سرویس',{routine:true,key:ui+':equipment',unit:ui})}}
   if(e.f){if(u.st==='run'&&sb&&e.f.dl>0&&--e.f.dl===0){log('استندبای '+nm+' هم از کار افتاد! «'+d.n+'» از سرویس خارج شد.');changeSafety(S,-1.25,'اتمام مهلت بهره‌برداری رزرو بدون تکمیل تعمیر',{routine:true,key:ui+':reserve',unit:ui})}}});
  if(u.st==='run'&&anyOut(u)){u.st='broken';u.tripReason='equipment'}
  if(u.st!=='run')return;
  let w=0;
  const couplingOffsets=calculateProcessCoupling(d.v,u.v);
  if(u.coolingIncident?.days>0){const tk=d.v.findIndex(x=>/دما|temperature|temp/i.test(x[0]));if(tk>=0)couplingOffsets[tk]+=(u.coolingIncident.offset||.7)*d.v[tk][3];}
  if(u.instrumentIncident?.days>0&&Number.isInteger(u.instrumentIncident.k)){const ik=u.instrumentIncident.k;couplingOffsets[ik]+=(u.instrumentIncident.bias||.6)*d.v[ik][3];}
  const requestedLoadRatio=(u.load||100)/100;
  const flowVariableIndex=d.v.findIndex(x=>/دبی|جریان|flow/i.test(x[0]));
  if(flowVariableIndex>=0)couplingOffsets[flowVariableIndex]+=(requestedLoadRatio-1)*d.v[flowVariableIndex][3]*.65;
  const levelK=d.v.findIndex(x=>/سطح|لول|level/i.test(x[0]));const flowK=d.v.findIndex(x=>/دبی|جریان|flow/i.test(x[0]));
  d.v.forEach((x,k)=>{const key=`${ui}:${k}`;const pidConfig=S.pid?.[key]||(S.pid[key]={mode:'manual',mv:50,integral:0,previousError:0,output:0});if(!Number.isFinite(pidConfig.mv))pidConfig.mv=50;const pvBefore=u.v[k];const finalElement=describeFinalElement(x[0]);pidConfig.actuatorTag=finalElement.tag;pidConfig.actuatorLabel=finalElement.label;pidConfig.actuatorType=finalElement.type;pidConfig.actuatorDirection=finalElement.direction;
   if(pidConfig.mode==='auto'&&u.au?.[k]){const requestedSp=Number.isFinite(pidConfig.sp)?pidConfig.sp:x[2];if(!Number.isFinite(pidConfig.rampedSp))pidConfig.rampedSp=pvBefore;const rampStep=Math.max(x[3]*.12,.0001);pidConfig.rampedSp+=cl(requestedSp-pidConfig.rampedSp,-rampStep,rampStep);const result=pidController.step({pv:pvBefore,sp:pidConfig.rampedSp,span:x[3],config:pidConfig});pidConfig.mv=actuatorPosition(result.output,finalElement.direction)}
   if(pidConfig.mode==='auto'&&!u.au?.[k]){pidConfig.mode='manual';pidConfig.integral=0;pidConfig.previousError=0;}
   stepOperatingDrift(pidConfig,{span:x[3],variableName:x[0],automatic:pidConfig.mode==='auto'&&!!u.au?.[k],random:r});const mv=cl(pidConfig.mv,0,100);const isCoupled=k===levelK||k===flowK;
   if(!isCoupled){const noise=(r()-.5)*x[3]*.04*nz;const dynamic=advanceProcessVariable({pv:pvBefore,nominal:x[2],span:x[3],mv,variableName:x[0],state:pidConfig,disturbance:pidConfig.disturbance||0,interactionOffset:(couplingOffsets[k]||0)+(pidConfig.naturalBias||0),noise});u.v[k]=dynamic.pv;pidConfig.disturbance=dynamic.state.disturbance;pidConfig.processTarget=dynamic.state.target;pidConfig.actuatorEffect=dynamic.state.actuatorEffect}
   const controlReference=pidConfig.mode==='auto'&&Number.isFinite(pidConfig.sp)?pidConfig.sp:x[2];w=Math.max(w,Math.abs(u.v[k]-controlReference)/Math.max(x[3],.001));u.h[k].push(+u.v[k].toFixed(2));if(u.h[k].length>40)u.h[k].shift();pidConfig.mvHistory=pidConfig.mvHistory||[];pidConfig.mvHistory.push(+mv.toFixed(1));if(pidConfig.mvHistory.length>40)pidConfig.mvHistory.shift()});
  u.processState=u.processState||{};
  if(typeof u.processState.valveOpen!=='boolean')u.processState.valveOpen=typeof S.mimicValve==='boolean'?S.mimicValve:true;
  if(typeof u.processState.pumpStandby!=='boolean')u.processState.pumpStandby=!!S.mimicPump;
  const unitProcess=stepUnitProcessModel({unit:u,definition:d,unitIndex:ui,pid:S.pid||{},valveOpen:u.processState.valveOpen,pumpStandby:u.processState.pumpStandby});
  if(unitProcess){w=0;d.v.forEach((x,k)=>{const cfg=S.pid?.[`${ui}:${k}`]||{};const controlReference=cfg.mode==='auto'&&Number.isFinite(cfg.sp)?cfg.sp:x[2];w=Math.max(w,Math.abs(u.v[k]-controlReference)/Math.max(x[3],.0001));if(u.h[k]?.length)u.h[k][u.h[k].length-1]=+u.v[k].toFixed(2)});u.processState=u.processState||{};u.processState.lastFlowFactor=unitProcess.flowFactor;u.processState.lastPumpReady=unitProcess.pumpReady;u.processState.pumpRunning=unitProcess.pumpRunning;u.processState.pressureEffect=unitProcess.pressureEffect;u.processState.temperatureEffect=unitProcess.temperatureEffect;u.processState.flowCouplingEffect=unitProcess.flowCouplingEffect;}
  // Safety limits are independent of operator SP: SP error is a control issue,
  // while a sustained excursion beyond the engineering safety envelope trips the unit.
  let tripDeviation=0;
  d.v.forEach((x,k)=>{tripDeviation=Math.max(tripDeviation,Math.abs(u.v[k]-x[2])/Math.max(x[3],.0001));});
  const equipmentCapacities=u.eq.map((e,j)=>{const name=String(d.e[j]?.[0]||'');const critical=/پمپ|pump|کمپرسور|compressor|کوره|furnace|توربین|turbine|فن|blower/i.test(name);return 100+Math.max(0,(e.l||1)-1)*(critical?18:12)});
  const ratedCapacity=equipmentCapacities.length?Math.min(...equipmentCapacities):100;u.ratedCapacity=ratedCapacity;const loadRatio=(u.load||100)/ratedCapacity;
  u.capacityUse=Math.round(loadRatio*100);
  const overload= Math.max(0,loadRatio-1);
  u.overloadTicks=overload>.25?(u.overloadTicks||0)+1:Math.max(0,(u.overloadTicks||0)-1);
  const baseQuality=calculateProductQuality({variables:d.v,values:u.v,pid:S.pid||{},unitIndex:ui,equipment:u.eq});const feedQualityBonus=(u.feedGrade-90)*.22;const quality=cl(baseQuality+feedQualityBonus-Math.max(0,(u.load||100)-100)*.22,25,100);u.quality=quality;const qualityFactor=.65+.35*(quality/100),feedQualityFactor=.72+.28*(u.feedGrade/100),L=lvl(u);
  // Wear and failure risk follow the equipment actually in service. A standby
  // pump is not charged operating wear while it is available but idle.
  u.eq.forEach((e,j)=>{
   const isPump=/پمپ|pump/i.test(String(d.e[j]?.[0]||''));
   const stressWear=(w>1?.18:0)+(w>1.7?.45:0)+(tripDeviationSafe(d.v,u.v)>2?.35:0)+overload*.9;
   const activeWear=(.08+stressWear)/e.l;
   const mainActive=!isPump||e.running!==false;
   if(mainActive)e.h=Math.max(0,e.h-activeWear);
   if(e.reserve){
    const reserveActive=isPump&&e.reserve.running===true;
    if(reserveActive)e.reserve.h=Math.max(0,e.reserve.h-activeWear);
   }
  });
  // Closing XV-101 is an operator isolation command, not an instantaneous
  // catastrophic process deviation. Give the operator a short response window;
  // sustained low flow still trips the unit as a protective action.
  u.processState=u.processState||{};
  const flowIndexForTrip=d.v.findIndex(x=>/دبی|جریان|flow/i.test(x[0]));
  const nominalFlowForTrip=flowIndexForTrip>=0?d.v[flowIndexForTrip][2]:0;
  const isolatedByValve=u.processState.valveOpen===false;
  if(isolatedByValve&&flowIndexForTrip>=0&&u.v[flowIndexForTrip]<nominalFlowForTrip*.2){
   u.processState.lowFlowTicks=(u.processState.lowFlowTicks||0)+1;
   tripDeviation=d.v.reduce((peak,x,k)=>k===flowIndexForTrip?peak:Math.max(peak,Math.abs(u.v[k]-x[2])/Math.max(x[3],.0001)),0);
   if(u.processState.lowFlowTicks<4)log('هشدار: شیر XV-101 بسته است و دبی پایین‌تر از حد عملیاتی قرار دارد.');
  }else u.processState.lowFlowTicks=0;
  if(tripDeviation>3.1||(u.processState.lowFlowTicks||0)>=4||(u.overloadTicks||0)>=5){u.st='trip';u.tripReason=(u.processState.lowFlowTicks||0)>=4?'low-flow':(u.overloadTicks||0)>=5?'overload':'process';recordSOE('تریپ حفاظتی واحد به‌دلیل عبور از محدوده عملیاتی ثبت شد.','HIGH',ui);Object.entries(S.pid||{}).filter(([key])=>key.startsWith(`${ui}:`)).forEach(([,cfg])=>{cfg.integral=0;cfg.previousError=0;cfg.output=0;cfg.disturbance=0;});S.esg=Math.max(0,S.esg-3);changeSafety(S,u.tripReason==='low-flow'&&u.processState?.valveOpen===false?0:d.nuc?-1.5:-.5,u.tripReason==='low-flow'&&u.processState?.valveOpen===false?'توقف حفاظتی پس از ایزوله‌کردن شیر؛ جریمه ایمنی ندارد':'عملکرد حفاظت فرایند؛ علت '+({"low-flow":'دبی پایین',overload:'اضافه‌بار',process:'انحراف متغیر'})[u.tripReason],{routine:true,key:ui+':'+u.tripReason,unit:ui});log('تریپ حفاظتی «'+d.n+'»: دبی پایین پایدار، اضافه‌بار ممتد تجهیزات یا عبور متغیر از محدوده ایمنی.')}
  else{u.dayEconomics={day:S.day,feeds:[],products:[],costs:{base:d.rev*.25*inflationCost,wages:OPN[u.t]*(S.sal||12)*inflationCost,feedImported:0,feedInternal:0,energy:0},factors:{story:storyFactor(S,'industry'),districtDamage,operator:opF,availableOperators:avail,requiredOperators:running,strike:S.fx.strike?.5:1,quality,qualityFactor,capacityUse:u.capacityUse,grid:S.gridIncident?.days>0?S.gridIncident.factor:1,feedIncident:u.feedIncident?.days>0?u.feedIncident.factor:1,avgHealth:0}};net-=d.rev*.25*inflationCost;const loadFactor=(u.load||100)/100;const k0=storyFactor(S,'industry')*districtDamage*opF*(S.fx.strike?.5:1)*loadFactor*(u.feedIncident?.days>0?u.feedIncident.factor:1);let ff=1,impc=0,qf=1;
   for(const p in IN[u.t]){const feedPremium=1+Math.max(0,u.feedGrade-90)*.006;const n=IN[u.t][p]*k0*((S.tech||{}).heat?.85:1),tk=Math.min(S.tanks[p],n);S.tanks[p]-=tk;let got=tk;const al=(ALT[u.t]||{})[p];
    if(al&&got<n){const ta=Math.min(S.tanks[al],(n-got)/.85);S.tanks[al]-=ta;got+=ta*.85;S.ic[al]=(S.ic[al]||0)+ta;S.cs[al]=(S.cs[al]||0)+ta}
    const feedCashBefore=importCashBudget,feedPortBefore=availablePortForFeed;const pc=PR[p][2]*IMP*(p==='power'?1:feedPremium)*inflationCost*supplyShock*importTradeFactor(S,p),shipsByPort=!['power','gas','water','rawwater','steam'].includes(p),buy=pc>0?Math.min(emergencyImportAllowance(S,p,Math.max(0,n-got),pc,PR),Math.max(0,importCashBudget)/pc,shipsByPort?availablePortForFeed:Infinity):0;recordEmergencyImport(S,p,buy,pc);importCashBudget=Math.max(0,importCashBudget-buy*pc);if(shipsByPort){availablePortForFeed=Math.max(0,availablePortForFeed-buy);S.feedPortUsedToday+=buy;}u.dayEconomics.costs.feedImported+=buy*pc;u.dayEconomics.costs.feedInternal+=tk*PR[p][2]*.5;u.dayEconomics.feeds.push({product:p,required:n,local:tk,alternative:Math.max(0,got-tk),imported:buy,delivered:got+buy,missing:Math.max(0,n-got-buy),importCost:buy*pc,internalCost:tk*PR[p][2]*.5,optional:!!(OPT[u.t]||{})[p],policyLimited:buy<Math.max(0,n-got)-.001&&(!productRule(S,p,PR).emergency||(productRule(S,p,PR).maxBuy>0&&pc>productRule(S,p,PR).maxBuy)||!!S.emergencyTradeStatus?.[p]),cashLimited:n-got-buy>.001&&feedCashBefore<Math.max(0,n-got)*pc-.001,portLimited:shipsByPort&&n-got-buy>.001&&feedPortBefore<Math.max(0,n-got)-.001});impc+=tk*PR[p][2]*.5+buy*pc;net-=buy*pc;S.imc+=buy*pc;S.cs[p]=(S.cs[p]||0)+n;S.imp[p]=(S.imp[p]||0)+buy;S.ic[p]=(S.ic[p]||0)+tk;
    if(n>0){const fr=(got+buy)/n;if((OPT[u.t]||{})[p])qf=Math.min(qf,fr);else ff=Math.min(ff,fr)}}
   u.qf=qf;
   // Unit-specific utility demand: higher load raises energy intensity non-linearly; worn equipment wastes more energy.
   const avgHealth=u.eq.length?u.eq.reduce((a,e)=>a+e.h,0)/u.eq.length:100;const energyIntensity=(EM[u.t]||1)*Math.pow(loadFactor,1.35)*(1+(100-avgHealth)/180);u.energyUse=energyIntensity;u.energyCost=energyIntensity*PR.power[2]*IMP*.28*inflationCost;net-=u.energyCost;
   u.dayEconomics.factors.avgHealth=avgHealth;u.dayEconomics.costs.energy=u.energyCost;u.dayEconomics.factors.feed=ff;u.feedGradeCostFactor=1+Math.max(0,u.feedGrade-90)*.006;u.fs=ff;
   if(u.feedIncident?.days>0&&--u.feedIncident.days<=0){u.feedIncident=null;recordSOE('کیفیت/دبی خوراک به وضعیت عادی بازگشت.','INFO',ui);log('اختلال خوراک در «'+d.n+'» برطرف شد.')}
   if(u.coolingIncident?.days>0&&--u.coolingIncident.days<=0){u.coolingIncident=null;recordSOE('سیستم خنک‌کاری به وضعیت عادی بازگشت.','INFO',ui);log('اختلال خنک‌کاری «'+d.n+'» برطرف شد.')}
   if(u.instrumentIncident?.days>0&&--u.instrumentIncident.days<=0){u.instrumentIncident=null;recordSOE('سیگنال ابزار دقیق به وضعیت عادی بازگشت.','INFO',ui);log('اختلال ابزار دقیق «'+d.n+'» برطرف شد.')}if(ff<.5&&S.day%6===0)log('کمبود خوراک «'+d.n+'»؛ تولید کاهش یافت.');
   const k=k0*qualityFactor*feedQualityFactor*ff*(.6+.4*qf)*(1+.35*(L-1))*((S.tech||{}).cat?1.15:1);u.out={};u.cst=d.rev*.25*inflationCost+OPN[u.t]*(S.sal||12)*inflationCost+impc+(u.energyCost||0);for(const p in OUT[u.t]){const requested=OUT[u.t][p]*k,free=Math.max(0,cap(p)-S.tanks[p]),accepted=Math.min(requested,free),lost=Math.max(0,requested-accepted);u.dayEconomics.products.push({product:p,requested,accepted,spilled:lost,unitValue:0,value:0});u.out[p]=accepted;S.pd[p]=(S.pd[p]||0)+accepted;S.tanks[p]+=accepted;if(lost>0.0001)S.prodLoss[p]=(S.prodLoss[p]||0)+lost}}});
 if(Object.values(S.prodLoss).some(v=>v>0.01)&&S.day%3===0){const top=Object.entries(S.prodLoss).sort((a,b)=>b[1]-a[1])[0];log('محدودیت ظرفیت ذخیره‌سازی: تولید '+PR[top[0]][0]+' به میزان '+f1(top[1])+' واحد به‌دلیل پر بودن مخزن قابل ذخیره نبود. ظرفیت مخزن را افزایش دهید یا موجودی را تخلیه کنید.')}
 const intr=S.financialGraceDays>0?0:(S.debt||0)*.004;if(S.financialGraceDays>0)S.financialGraceDays--;const nationalIncome=country(fm,availablePortForFeed);const govBase=Math.max(0,(S.inc?.tax||0)+(S.inc?.ex||0)*.08+(S.inc?.ct||0)*.08+(S.tradeRevenueToday||0)*.08);const govTransfer=govBase*cl(Number(S.govRate)||1,.5,1.5);S.govIncomeToday=govTransfer;S.govBudget=Math.max(0,(S.govBudget||0)+govTransfer);net+=nationalIncome-govTransfer-intr+pinc()-(S.adv?15:0);S.money+=net;updateDynamicEconomy();updateRegionalEconomy();if(S.money<0&&S.day%15===0)log('سرمایه منفی است؛ از بخش «بانک و وام» وام بگیرید یا خرابی‌ها را سریع تعمیر کنید.');
 ['sanc','spike','exp','strike','rival'].forEach(k=>{if(S.fx[k]&&--S.fx[k]<=0)delete S.fx[k]});
 S.offers=S.offers.filter(o=>--o.d>0||(o.t==='strike'&&(S.fx.strike=8,log('مهلت مذاکره تمام شد؛ اعتصاب شروع شد.'),false)));
 if(r()<.03)EV();
 if(S.rd&&--S.rd.d<=0){(S.tech=S.tech||{})[S.rd.k]=1;log('تحقیق «'+TECHN[S.rd.k]+'» کامل شد!');S.rd=null}
 S.co=(S.co||[]).filter(c=>--c.x>0&&!(r()<.04&&(log('رقیب پیشنهاد قرارداد '+PR[c.p][0]+' را از شما گرفت.'),1)));
 if(r()<.05&&S.co.length<2){const ps=['methanol','ethylene','sulfur'],p=ps[Math.floor(r()*3)],q=[8,15,25][Math.floor(r()*3)];S.co.push({p,q,d:30,pr:1.25,pen:1.5,x:10});log('پیشنهاد قرارداد بلندمدت '+PR[p][0]+' رسید.')}
 if(S.personnel?.injuryDays>0&&--S.personnel.injuryDays===0){recordSOE('اپراتور آسیب‌دیده پس از دوره درمان به کار بازگشت.','INFO');log('اپراتور آسیب‌دیده پس از تکمیل دوره درمان به کار بازگشت.')}
 if(S.gridIncident?.days>0&&--S.gridIncident.days<=0){S.gridIncident=null;recordSOE('تأمین برق شبکه به حالت عادی بازگشت.','INFO');log('اختلال برق شبکه برطرف شد.')}
 if(S.cr&&--S.cr.d<=0)resolveCr(null);
 if(!S.cr&&r()<.025){const ru=S.u.map((u,i)=>i).filter(i=>S.u[i].st==='run');if(ru.length){const ui=ru[Math.floor(r()*ru.length)],types=['feed','cooling','rotating','instrument','grid','leak','flood'];let k=types[Math.floor(r()*types.length)];if(D[S.u[ui].t].nuc&&r()<.25)k='core';const unit=S.u[ui],def=D[unit.t];if(k==='feed')unit.feedIncident={days:4,factor:.68};if(k==='cooling')unit.coolingIncident={days:4,offset:.72};if(k==='instrument'){const vi=Math.floor(r()*def.v.length);unit.instrumentIncident={days:4,k:vi,bias:.65};}if(k==='rotating'){const pi=unit.eq.findIndex((e,j)=>/پمپ|pump|کمپرسور|compressor/i.test(String(def.e[j]?.[0]||'')));if(pi>=0){unit.incidentEquipment=pi;unit.eq[pi].h=Math.max(0,unit.eq[pi].h-22);}}if(k==='grid')S.gridIncident={days:3,factor:.68};S.cr={k,i:ui,d:3};recordSOE('شروع رخداد: '+CR[k].t,'HIGH',ui);log('رخداد عملیاتی: '+CR[k].t+' در «'+def.n+'».')}}
 if(S.day%60===0){if(S.safe>=70){S.money+=2000;log('ممیزی ایمنی: عالی؛ جایزه ۲٬۰۰۰.')}else{S.money-=1500;log('ممیزی ایمنی: جریمه ۱٬۵۰۰ به‌خاطر نمره‌ی ایمنی پایین.')}}
 S.u.forEach((u,i)=>{if(u.st==='run'&&u.out){let rv=0;for(const p in u.out)rv+=u.out[p]*((S.rp||{})[p]||0);const x=rv-u.cst,previous=u.pl;u.pl=u.pl==null?x:.8*u.pl+.2*x;
  const ledger=u.dayEconomics;if(ledger?.day===S.day){ledger.revenue=rv;ledger.totalCost=u.cst;ledger.profit=x;ledger.smoothedProfit=u.pl;ledger.port={capacity:S.port,used:S.portUsedToday,remaining:S.portRemainingToday,feedUsed:S.feedPortUsedToday};ledger.market=structuredClone(S.marketDay||{});ledger.products.forEach(p=>{p.unitValue=(S.rp||{})[p.product]||0;p.value=p.accepted*p.unitValue;p.valuation=S.hold?.[p.product]&&PR[p.product][3]?'inventory':'allocated'})}
  if(x<0&&(u.lastDailyProfit==null||u.lastDailyProfit>=0)&&(!u.lastLossAlertDay||S.day-u.lastLossAlertDay>=5)){const report=analyzeUnit(S,i,{D,PR,OPN});log('هشدار زیان «'+D[u.t].n+'»: '+(report.primary?.title||'درآمد کمتر از هزینه')+'؛ تحلیل و راه رفع در مشاور بحران.');u.lastLossAlertDay=S.day}u.lastDailyProfit=x;
 }else if(u.st!=='run')u.pl=null});
 MS.forEach(([k,,,nd,rw,f])=>{const m=S.ms[k]=S.ms[k]||{p:0,done:0};if(!m.done&&f()&&++m.p>=nd){m.done=1;S.money+=rw;log('مأموریت انجام شد: '+MS.find(q=>q[0]===k)[1]+' (جایزه '+fa(rw)+')')}});
 reviewSafetyDay(S,{D,availableOperators:opsAvail(),requiredOperators:opsNeed()});
 settleDevelopment(S,log);closeCashDay(S,openingCash);advanceLegacyDay(S);
 S.mh.push(Math.round(S.money));if(S.mh.length>80)S.mh.shift();
 if(!S.won&&S.money>=250000&&new Set(S.u.filter(u=>u.st==='run').map(u=>u.t)).size>=5){S.won=true;log('تبریک! امپراتوری فرایند شما شکل گرفت. می‌توانید ادامه دهید.')}
 if(S.diagnosticPauseDay&&S.day>=S.diagnosticPauseDay){S.paused=true;delete S.diagnosticPauseDay;log('یک روز داده عملیاتی ثبت شد؛ زمان برای بررسی مشاور متوقف شد.')}
 if(S.money<-5000)log('هشدار: بدهی سنگین است؛ واحدهای سودده را حفظ کنید.')}
// ---- نمودارها
function chart(h,c,b,col){const W=120,H=40,y=v=>H-cl((v-(c-3*b))/(6*b),0,1)*H;
 const pts=h.map((v,i)=>((i/Math.max(1,39))*W).toFixed(1)+','+y(v).toFixed(1)).join(' ');
 return `<svg class="ch" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="روند"><rect class="z" x="0" y="${H/3}" width="${W}" height="${H/3}"/>${h.length>1?`<polyline points="${pts}" stroke="${col}"/>`:''}</svg>`}
function moneyChart(){const h=S.mh,mn=Math.min(...h),mx=Math.max(...h,mn+1),W=120,H=40;
 const pts=h.map((v,i)=>((i/Math.max(1,h.length-1))*W).toFixed(1)+','+(H-(v-mn)/(mx-mn)*H).toFixed(1)).join(' ');
 return `<svg class="ch" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="روند سرمایه"><polyline points="${pts}" stroke="var(--brand)"/></svg>`}
const col=w=>w<=1?'var(--ok)':w<=1.7?'var(--warn)':'var(--bad)';
function eqRow(u,i,e,j,d){const nm=d.e[j][0],sb=d.e[j][1],f=e.f;let st='';
 if(f){const lbl=f.st===0?'نیازمند قطعه':f.st===1?'قطعه در راه ('+fa(f.eta)+' روز)':'قطعه رسیده';
  st=`<div class="note">${nm}${sb?' (اصلی)':''}: ${lbl}.${sb&&f.dl>0?' مهلت استندبای: '+fa(f.dl)+' روز':sb?' استندبای هم خراب است':''}<div class="row">${f.st===0?`<button data-a="part" data-i="${i}" data-j="${j}" data-f="0">خرید قطعه (${fa(partCost(d,j))})</button><button data-a="part" data-i="${i}" data-j="${j}" data-f="1">ارسال فوری (${fa(partCost(d,j)*2)})</button>`:''}${f.st===2?`<button class="p" data-a="repair" data-i="${i}" data-j="${j}">تعمیر (${fa(d.cost*.04)})</button>`:''}</div></div>`}
 return `<div class="eq"><span>${nm}${sb?' <span class="tag">استندبای</span>':''} · سطح ${fa(e.l)}</span><span><span class="hp"><i style="width:${e.h}%;background:${e.h>60?'var(--ok)':e.h>30?'var(--warn)':'var(--bad)'}"></i></span> <button data-a="up" data-i="${i}" data-j="${j}">ارتقا (${fa(d.cost*.3*e.l)})</button></span></div>${st}`}
function unit(u,i){if(!['build','ready'].includes(u.st)&&S.expandedUnit!==i)return `<article class="card compact-unit" id="u${i}"><div class="row"><h3>${fa(i+1)}. ${unitTitle(u,D,i)}</h3><span class="tag ${u.st}">${({run:'در سرویس',trip:'تریپ',broken:hasEquipmentFaults(u)?'خارج از سرویس · خرابی':'در انتظار راه‌اندازی',off:'متوقف',tar:'تعمیرات'})[u.st]||u.st}</span></div><p>${unitExplanation(u)}</p><div class="row"><span>میانگین سود واحد: ${u.pl==null?'—':fa(u.pl)}</span>${u.pl<0?quickButton({target:'advisor',index:i,title:'علت زیان و راه رفع'}):''}<span>خوراک: ${u.fs==null?'—':fa(u.fs*100)+'٪'}</span></div><div class="row"><button data-hmi="${i}">اتاق کنترل</button><button data-a="unit-expand" data-i="${i}">جزئیات و تعمیرات</button></div>${maintenancePanel(S,u,i,D,{compact:true})}</article>`;const d=D[u.t],T={build:'در حال ساخت',ready:'آماده‌ی راه‌اندازی',run:'در حال کار',trip:'تریپ',broken:hasEquipmentFaults(u)?'خارج از سرویس · خرابی':'در انتظار راه‌اندازی',tar:'تعمیرات اساسی',off:'متوقف (عمدی)'}[u.st];
 let h=`<div class="card${S.flash&&S.flash.i===i&&Date.now()-S.flash.t<1800?' flash':''}" id="u${i}"><div class="row unit-card-head"><h2>${fa(i+1)}. ${unitTitle(u,D,i)}</h2><span class="tag ${u.st}">${T}</span><button data-top="1" aria-label="بازگشت به فهرست">↑ فهرست</button><button class="unit-hmi-entry" data-hmi="${i}" ${['build','ready'].includes(u.st)?'disabled title="پس از راه‌اندازی در دسترس است"':''}>ورود به اتاق کنترل</button></div><div class="muted" style="font-size:12px">نوع واحد: ${d.n} · محصول: ${prodTxt(u.t)}</div><div class="muted" style="font-size:12px">زیرساخت لازم: سطح ${fa(INF[u.t])} · اپراتور لازم: ${fa(OPN[u.t])} · میانگین سود روزانه (تخمینی): <b class="${u.pl<0?'bd':'ok'}">${u.pl==null?'—':fa(u.pl)}</b> · خوراک: ${feedTxt(u.t)}${u.fs!=null&&u.st==='run'?' · تأمین '+fa(u.fs*100)+'٪':''}${u.quality!=null&&u.st==='run'?' · کیفیت محصول '+fa(u.quality)+'٪':''}</div>`;
 h+=`<details class="unit-identity"><summary>نام واحد و مشخصات</summary><label>نام اختصاصی<input id="unit-name-${i}" maxlength="32" value="${unitTitle(u,D,i)}"></label><button data-a="unit-rename" data-i="${i}">ذخیره نام</button></details><p class="note">${unitExplanation(u)}</p>`;if(u.st==='broken'&&!hasEquipmentFaults(u))h+=`<button class="p" data-a="restart" data-i="${i}">بازگشت به سرویس پس از بررسی · ${fa(d.cost*.04)}</button><p>${recoveryBlock(S,u,i,D)||'تجهیزات سالم‌اند؛ راه‌اندازی را تأیید کن.'}</p>`;
 if(u.st==='build'||u.st==='ready'){h+=projectStage(u,d,fa);
  if(u.prob)h+=`<div class="note">${u.prob}<div class="row"><button data-a="fix" data-i="${i}" data-n="1">رفع فوری (${fa(d.cost*.08)})</button><button data-a="fix" data-i="${i}" data-n="0">ادامه با ریسک</button></div></div>`;
  h+=`<details class="project-equipment"><summary>فهرست تجهیزات و پیشرفت نصب</summary>`+d.e.map((x,j)=>`<div class="eq"><span>${x[0]}${x[1]?' <span class="tag">استندبای</span>':''}</span><span>${j<u.eq.length?'نصب‌شده ✓':''}</span></div>`).join('')+'</details>';
  if(u.st==='build'&&!u.prob)h+=`<div class="row"><button class="p" data-a="install" data-i="${i}">نصب ${d.e[u.eq.length][0]} (${fa(d.cost*.2)} + مصالح)</button></div>`;
  if(u.su)h+=stepUI(u,i);else if(u.st==='ready')h+=`<div class="row"><button class="p" data-a="start" data-i="${i}">راه‌اندازی واحد (خوراک اولیه ${fa(feedCost(u.t))})</button></div>`}
 else{
  h+=d.v.map((x,k)=>{const v=u.v[k],w=Math.abs(v-x[2])/x[3];
   return `<div class="var"><div class="l"><span>${x[0]}</span><b style="color:${col(w)}">${f1(v)} ${x[1]}</b></div>${chart(u.h[k],x[2],x[3],col(w))}<div class="row">${u.st==='run'&&S.pid?.[`${i}:${k}`]?.mode!=='auto'?`<button data-a="adj" data-i="${i}" data-k="${k}" data-s="-1">کاهش</button><button data-a="adj" data-i="${i}" data-k="${k}" data-s="1">افزایش</button>`:''}${u.au[k]?`<span class="tag run">${S.pid?.[`${i}:${k}`]?.mode==='auto'?'PID خودکار':'کنترلر نصب‌شده'}</span>`:`<button data-a="auto" data-i="${i}" data-k="${k}">کنترلر خودکار (${fa(d.cost*.15)})</button>`}<span class="muted">هدف: ${f1(x[2])}</span></div></div>`}).join('');
  h+=`<div class="note"><b>بار عملیاتی و ظرفیت نامی</b><div class="row"><span>بار خوراک: <b>${fa(u.load||100)}٪</b></span><span>ظرفیت نامی واحد: <b>${fa(u.ratedCapacity||100)}٪</b></span><span>بهره‌برداری ظرفیت: <b class="${(u.capacityUse||100)>115?'bd':(u.capacityUse||100)>100?'wn':'ok'}">${fa(u.capacityUse||100)}٪</b></span><span>کیفیت: <b>${fa(u.quality??100)}٪</b></span></div><div class="row"><button data-a="load" data-i="${i}" data-d="-10" ${(+u.load||100)<=50?'disabled':''}>کاهش بار ۱۰٪</button><button data-a="load" data-i="${i}" data-d="10" ${(+u.load||100)>=140?'disabled':''}>افزایش بار ۱۰٪</button><button data-a="load" data-i="${i}" data-d="0">بار نامی ۱۰۰٪</button></div><div class="row"><span>کیفیت خوراک ورودی: <b>${fa(u.feedGrade||90)}٪</b></span><button data-a="feed-grade" data-i="${i}" data-d="-5" ${(+u.feedGrade||90)<=70?'disabled':''}>خوراک اقتصادی‌تر −۵٪</button><button data-a="feed-grade" data-i="${i}" data-d="5" ${(+u.feedGrade||90)>=100?'disabled':''}>خوراک باکیفیت‌تر +۵٪</button></div><div class="row muted"><span>مصرف انرژی تخمینی: ${f1(u.energyUse||0)} واحد/روز</span><span>هزینه انرژی: ${fa(u.energyCost||0)} در روز</span></div><small class="muted">خوراک باکیفیت‌تر هزینه بیشتری دارد اما کیفیت محصول را بهبود می‌دهد؛ بار بالاتر، مصرف انرژی و استهلاک را افزایش می‌دهد.</small></div>`;
  h+=u.eq.map((e,j)=>eqRow(u,i,e,j,d)).join('')+renderReserveRepairs(u,d,i,fa);
  h+=`<div class="row"><button data-a="pm" data-i="${i}" ${maintenanceCost(u,d)<=0?'disabled':''}>سرویس دوره‌ای (${fa(maintenanceCost(u,d))})</button><button data-a="tar" data-i="${i}" ${["run","trip","off"].includes(u.st)?"":"disabled"}>تعمیرات اساسی (${fa(d.cost*.15)})</button>${u.st==="off"?`<button class="p" data-a="resume" data-i="${i}">بازگشت به سرویس (${fa(d.cost*.02)})</button>`:`<button data-a="stop" data-i="${i}" ${u.st==="run"?"":"disabled"}>خروج عمدی از سرویس</button>`}${u.st==='trip'?`<button class="p" data-a="restart" data-i="${i}">راه‌اندازی مجدد (${fa(d.cost*.04)})</button>`:''}</div>`}
 return h+maintenancePanel(S,u,i,D)+(u.pl<0?quickButton({target:'advisor',index:i,title:'تحلیل زیان در مشاور'}):'')+(!['build','ready'].includes(u.st)?`<button data-a="unit-collapse">بستن جزئیات</button>`:'')+'</div>'}
function personnelCard(){
 const p=S.personnel||{injured:0,fatalities:0,injuryDays:0};
 return `<div class="card wide"><h2>ایمنی نیروی انسانی و HSE</h2><div class="row"><span>آسیب‌دیدگی تجمعی: <b class="${p.injured?'wn':'ok'}">${fa(p.injured||0)}</b></span><span>تلفات جانی: <b class="${p.fatalities?'bd':'ok'}">${fa(p.fatalities||0)}</b></span><span>اپراتور خارج از شیفت: <b>${fa(p.injuryDays>0?1:0)}</b></span><span>نیروی ازدست‌رفته دائمی: <b>${fa(p.fatalities||0)}</b></span><span>شاخص ایمنی: <b class="${S.safe<50?'bd':S.safe<80?'wn':'ok'}">${fa(S.safe)}٪</b></span></div><small class="muted">تصمیم پرخطر یا تأخیر در واکنش می‌تواند به آسیب یا فوت نیروی انسانی منجر شود. هزینه درمان، غرامت، پیگیری قانونی و جریمه از سرمایه کسر می‌شود؛ اقدام ایمن و تخلیه به‌موقع ریسک را کاهش می‌دهد.</small>${renderSafetyReport(S,D)}</div>`
}
function applyPersonnelConsequence(eventKey,unitIndex){
 const risk={feed:[.08,.005],cooling:[.28,.035],rotating:[.34,.045],instrument:[.16,.012],grid:[.22,.025],leak:[.62,.19],flood:[.27,.025],core:[.48,.14]}[eventKey]||[.15,.01];
 const p=S.personnel=S.personnel||{injured:0,fatalities:0,injuryDays:0};
 const safetyFactor=cl(1-(S.tr||0)*.12+(70-S.safe)*.004,.45,1.35);
 const fatal=Math.random()<risk[1]*safetyFactor;
 const injured=!fatal&&Math.random()<risk[0]*safetyFactor;
 changeSafety(S,-(fatal?22:injured?12:2),fatal?'حادثه منجر به فوت؛ پیامد ایمنی شدید':injured?'آسیب اپراتور در رخداد عملیاتی':'تشدید رخداد یا بی‌اقدامی؛ نزدیک‌به‌حادثه بدون آسیب انسانی',{unit:unitIndex,target:'controls'});
 if(fatal){p.fatalities=(p.fatalities||0)+1;const fine=120000;S.money-=fine;log(`حادث منجر به فوت یک اپراتور شد؛ غرامت و جریمه قانونی ${fa(fine)} از سرمایه کسر شد.`);recordSOE('حادثه انسانی: فوت اپراتور؛ توقف و بررسی HSE الزامی است.','HIGH',unitIndex);}
 else if(injured){p.injured=(p.injured||0)+1;p.injuryDays=Math.max(p.injuryDays||0,6+Math.floor(r()*5));const fine=18000;S.money-=fine;log(`یک اپراتور آسیب دید و ${fa(fine)} هزینه درمان، غرامت و جریمه از سرمایه کسر شد؛ نیروی انسانی تا پایان درمان در دسترس نیست.`);recordSOE('حادثه انسانی: آسیب‌دیدگی اپراتور و خروج موقت از شیفت.','HIGH',unitIndex);}
 else{log('حادثه بدون آسیب انسانی مهار شد؛ با این حال تخطی از رویه ایمنی ثبت شد.');recordSOE('نزدیک‌به‌حادثه (Near Miss): اقدام پرخطر بدون آسیب انسانی.','MED',unitIndex);}
}
const CR={
 feed:{t:'اختلال خوراک ورودی',m:n=>`دبی یا کیفیت خوراک ورودی «${n}» دچار نوسان شده است.`,o:[['تأمین خوراک جایگزین (۸۰۰)',800,'safe'],['کاهش بار ۲۰٪ و پایش (رایگان)',0,'reduce'],['ادامه بدون اقدام (پرخطر)',0,'risk']]},
 cooling:{t:'افت ظرفیت خنک‌کاری',m:n=>`دمای فرایند «${n}» به‌علت افت عملکرد سیستم خنک‌کاری در حال افزایش است.`,o:[['راه‌اندازی خنک‌کاری اضطراری (۱۲۰۰)',1200,'safe'],['کاهش بار ۲۵٪ (رایگان)',0,'reduce'],['توقف اضطراری واحد (۳۰۰)',300,'trip']]},
 rotating:{t:'لرزش/اختلال تجهیز دوار',m:n=>`افزایش لرزش در تجهیز دوار «${n}» گزارش شده است.`,o:[['انتقال بار به تجهیز رزرو (۳۰۰)',300,'switch'],['کاهش بار و پایش (رایگان)',0,'reduce'],['ادامه کار بدون اقدام (پرخطر)',0,'risk']]},
 instrument:{t:'اختلال ابزار دقیق',m:n=>`سیگنال یکی از ترانسمیترهای «${n}» مشکوک به انحراف یا Drift است.`,o:[['انتقال حلقه مربوطه به MAN و بررسی (۲۵۰)',250,'manual'],['کاهش بار ۱۵٪ و پایش (رایگان)',0,'reduce'],['ادامه در AUTO (پرخطر)',0,'risk']]},
 grid:{t:'افت/قطع برق شبکه',m:n=>`تأمین برق «${n}» دچار افت شده است.`,o:[['راه‌اندازی ژنراتور اضطراری (۵۰۰)',500,'safe'],['کاهش بار واحدها (رایگان)',0,'reduceall'],['خاموشی کنترل‌شده همه واحدها (۱۰۰)',100,'tripall']]},
 leak:{t:'نشتی گاز',m:n=>`نشتی گاز در «${n}» گزارش شد.`,o:[['ESD و ایزوله کردن (۳۰۰)',300,'trip'],['تخلیه و اعلام وضعیت اضطراری (۸۰۰)',800,'evac'],['ادامه با پایش (پرخطر)',0,'risk']]},
 flood:{t:'آب‌گرفتگی محوطه',m:n=>`آب‌گرفتگی در محوطه‌ی «${n}» شناسایی شده است.`,o:[['پمپ تخلیه و حفاظت تجهیزات (۶۰۰)',600,'safe'],['توقف و محافظت از تجهیزات (۲۰۰)',200,'trip'],['نادیده گرفتن (پرخطر)',0,'risk']]},
 core:{t:'اختلال خنک‌کاری راکتور',m:n=>`اختلال در سیستم خنک‌کاری «${n}».`,o:[['خنک‌سازی اضطراری (۲٬۰۰۰)',2000,'safe'],['کاهش توان و پایش (رایگان)',0,'reduce'],['SCRAM و خاموشی (۵۰۰)',500,'trip']]}};
function resolveCr(oi){const c=S.cr;if(!c)return;const u=S.u[c.i],def=CR[c.k],o=oi==null?null:def.o[oi],act=o?o[2]:'bad';if(o&&!pay(o[1]))return;S.cr=null;
 const clearEffects=x=>{if(!x)return;x.feedIncident=null;x.coolingIncident=null;x.instrumentIncident=null;if(c.k==='grid')S.gridIncident=null;};
 const trip=x=>{if(x?.st==='run'){x.st='trip';clearEffects(x)}};
 if(act==='safe'){if(c.k==='feed'&&u)u.feedIncident=null;if(c.k==='cooling'&&u)u.coolingIncident=null;if(c.k==='grid')S.gridIncident=null;log('اقدام اضطراری موفق بود؛ اختلال مهار شد و واحدها در سرویس باقی ماندند.');recordSOE('رخداد با اقدام اضطراری مهار شد.','INFO',c.i)}
 else if(act==='reduce'){if(u){u.load=cl((u.load||100)-20,50,140);if(c.k==='feed')u.feedIncident={days:2,factor:.85};if(c.k==='cooling')u.coolingIncident={days:2,offset:.3};if(c.k==='instrument')u.instrumentIncident={days:2,k:u.instrumentIncident?.k??0,bias:.25};}log('بار واحد کاهش یافت؛ رخداد با محدودیت تولید تحت پایش قرار گرفت.');recordSOE('بار عملیاتی برای کنترل رخداد کاهش یافت.','MED',c.i)}
 else if(act==='reduceall'){S.u.forEach(x=>{if(x.st==='run')x.load=cl((x.load||100)-20,50,140)});S.gridIncident={days:1,factor:.9};log('بار تمام واحدهای در سرویس ۲۰٪ کاهش یافت.');recordSOE('بار کل سایت برای مدیریت افت برق کاهش یافت.','MED')}
 else if(act==='switch'){if(u){const j=u.incidentEquipment??u.eq.findIndex((e,k)=>e.reserve&&/پمپ|pump/i.test(String(D[u.t].e[k]?.[0]||'')));const e=u.eq[j];if(e?.reserve&&!e.reserve.f&&e.reserve.h>=30){e.running=false;e.reserve.running=true;u.processState=u.processState||{};u.processState.pumpStandby=true;u.processState.pumpRunning=true;u.eq[j].h=Math.max(0,u.eq[j].h-2);log('تجهیز رزرو وارد سرویس شد؛ تجهیز دارای لرزش از مدار خارج شد.');recordSOE('انتقال سرویس به تجهیز رزرو انجام شد.','INFO',c.i)}else{u.load=cl((u.load||100)-20,50,140);log('تجهیز رزرو آماده نبود؛ بار واحد کاهش یافت.');recordSOE('رزرو در دسترس نبود؛ بار واحد کاهش یافت.','MED',c.i)}}}
 else if(act==='manual'){if(u?.instrumentIncident){const key=`${c.i}:${u.instrumentIncident.k}`,cfg=S.pid[key];if(cfg){cfg.mode='manual';cfg.integral=0;cfg.previousError=0;}u.instrumentIncident=null;}log('حلقه مرتبط به MAN منتقل شد؛ بررسی ابزار دقیق لازم است.');recordSOE('حلقه کنترلی مشکوک از AUTO خارج شد.','INFO',c.i)}
 else if(act==='trip'||act==='evac'){trip(u);if(act==='evac')changeSafety(S,5,'تخلیه ایمن در واکنش به نشتی',{unit:c.i,target:'controls'});log('واحد به‌صورت ایمن از سرویس خارج شد؛ پس از رفع علت راه‌اندازی مجدد کنید.');recordSOE('واحد به فرمان اپراتور ESD/Shutdown شد.','HIGH',c.i)}
 else if(act==='tripall'){S.u.forEach(trip);log('خاموشی کنترل‌شده انجام شد؛ واحدها را پس از پایدارشدن شبکه دوباره راه‌اندازی کنید.');recordSOE('خاموشی کنترل‌شده سایت انجام شد.','HIGH')}
 else{applyPersonnelConsequence(c.k,c.i);if(u){u.load=cl((u.load||100)-10,50,140);if(c.k==='rotating'){const j=u.incidentEquipment,e=u.eq[j];if(e){e.h=Math.max(0,e.h-18);if(e.h<30){e.f={st:0,eta:0,dl:0};u.st='broken';}}}else if(c.k==='cooling'||c.k==='core'){u.st='trip';S.money-=c.k==='core'?15000:2500;}else if(c.k==='leak'){u.st='broken';if(u.eq[0]&&!u.eq[0].f)u.eq[0].f={st:0,eta:0,dl:0};S.money-=2000;}else if(c.k==='flood')u.eq.forEach(e=>e.h=Math.max(0,e.h-25));else if(c.k==='instrument'){u.st='trip';}else if(c.k==='feed')u.feedIncident={days:4,factor:.5};}if(c.k==='grid'){S.u.forEach(trip);S.gridIncident={days:3,factor:.4};}log('عدم اقدام مناسب باعث تشدید رخداد، خسارت اقتصادی و افت شاخص ایمنی شد.');recordSOE('رخداد تشدید شد؛ خسارت عملیاتی ثبت گردید.','HIGH',c.i)}}
function crisisCard(){const c=S.cr;if(!c)return walkCard()+personnelCard();const def=CR[c.k],u=S.u[c.i];return walkCard()+personnelCard()+`<div class="card wide" style="border-color:var(--bad)"><h2 class="bd">بحران: ${def.t}</h2><div class="note"><b>${def.m(D[u.t].n)}</b> ${fa(c.d)} روز فرصت تصمیم دارید؛ در غیر این صورت بدترین نتیجه رخ می‌دهد.<div class="row">${def.o.map((o,k)=>`<button class="p" data-a="cr" data-o="${k}">${o[0]}</button>`).join('')}</div></div></div>`}
function contractCard(){const ct=S.ct||[],co=S.co||[];return `<div class="card"><h2>قراردادها</h2><div class="muted" style="font-size:12px">قیمت قرارداد ثابت و ۲۵٪ بالاتر از پایه است، ولی کسری تحویل جریمه‌ی ۱٫۵ برابر قیمت دارد.</div>${ct.map(c=>`<div class="eq"><span>${PR[c.p][0]}: ${fa(c.q)} در روز</span><span class="tag run">${fa(c.d)} روز</span></div>`).join('')||'<div class="muted">قرارداد فعالی ندارید.</div>'}${co.map((c,k)=>`<div class="note">پیشنهاد: ${PR[c.p][0]} ${fa(c.q)} در روز، ${fa(c.d)} روز، قیمت ×${f1(c.pr)}<div class="row"><button class="p" data-a="ctok" data-o="${k}">امضا</button><button data-a="ctno" data-o="${k}">رد</button></div></div>`).join('')}</div>`}
const opsNeed=()=>S.u.reduce((a,u)=>a+(u.st==='run'?OPN[u.t]:0),0),opsAvail=()=>{const available=baseCrew(S);return available-staffedStations(S,available).length;};
function walkCard(){const w=S.walk;if(!w)return'';return `<div class="card wide" style="border-color:var(--bad)"><h2 class="bd">اپراتورها دست از کار کشیده‌اند</h2><div class="note"><b>در دسترس: ${fa(opsAvail())} از ${fa(S.ops)} اپراتور · ${fa(w.d)} روز مانده</b> تولید و ایمنی واحدها زیر فشار است.<div class="row"><button class="p" data-a="neg">مذاکره و افزایش ۱۵٪ حقوق (۲٬۰۰۰)</button><button data-a="contr" ${w.c?'disabled':''}>پیمانکار موقت (۸۰۰)</button></div></div></div>`}
const emission=()=>S.u.reduce((a,u)=>a+(u.st==='run'?EM[u.t]:0),0);
const netWorth=()=>S.money-(S.debt||0)+S.u.reduce((a,u)=>a+(u.st==='build'?0:D[u.t].cost*.8),0)+S.grid.reduce((a,b)=>a+(b?TY[b.t].cost*b.l*.5:0),0);
const MS=[
 ['m1','تأمین کامل برق کشور','۱۰ روز با تأمین ≥ ۹۸٪ برق',10,5000,()=>S.dem.power>0&&(S.fr.power??1)>=.98],
 ['m2','گاز زمستان','۲۰ روز زمستانی با تأمین ≥ ۹۰٪ گاز',20,8000,()=>Math.floor(((S.day-1)%360)/90)===3&&S.dem.gas>0&&(S.fr.gas??1)>=.9],
 ['m3','استقلال خوراک','۱۵ روز بدون واردات خوراک',15,6000,()=>S.imc===0&&S.u.some(u=>u.st==='run')],
 ['m4','کشور سبز','۱۵ روز با ESG ≥ ۸۰٪',15,7000,()=>S.esg>=80],
 ['m5','شهر بزرگ','جمعیت ≥ ۱۶۰٬۰۰۰ نفر',1,5000,()=>S.pop>=160000],
 ['m6','صادرکننده‌ی بزرگ','درآمد صادراتی ≥ ۱٬۰۰۰ در روز',1,10000,()=>(S.inc.ex||0)>=1000]];
function missionCard(){const o=S.ms||{};return `<div class="card"><h2>مأموریت‌ها</h2>${MS.map(([k,n,d,nd,rw])=>{const m=o[k]||{p:0,done:0};return `<div class="eq"><span><b>${n}</b> <span class="muted">${d}</span></span><span>${m.done?'<span class="tag run">انجام شد</span>':fa(m.p)+'/'+fa(nd)+' · جایزه '+fa(rw)}</span></div>`}).join('')}</div>`}
function rivalCard(){const rows=[['شما',netWorth(),1],...(S.rv||[]).map((w,i)=>[RIV[i],w,0])].sort((a,b)=>b[1]-a[1]);return `<div class="card"><h2>رقبا و رتبه‌بندی</h2><div class="muted" style="font-size:12px">ارزش خالص = سرمایه + دارایی‌ها − بدهی. رقبا گاهی قرارداد را قاپ می‌زنند یا قیمت‌شکنی می‌کنند.</div>${rows.map((x,i)=>`<div class="eq"><span>${fa(i+1)}. ${x[2]?'<b>'+x[0]+'</b>':x[0]}</span><b>${fa(x[1])}</b></div>`).join('')}</div>`}
function esgCard(){const n=S.ab||0,em=emission()*Math.pow(.7,n);return `<div class="card"><h2>محیط‌زیست (ESG)</h2><div class="row">نمره: <b class="${S.esg<40?'bd':S.esg<70?'wn':'ok'}">${fa(S.esg)}٪</b> · شاخص انتشار: <b>${f1(em)}</b></div><div class="muted" style="font-size:12px">بالای ۷۰٪ قیمت صادرات ۱۰٪ بیشتر، زیر ۴۰٪ ده درصد کمتر و زیر ۳۰٪ جریمه. تریپ نمره را کم می‌کند. هر سطح کنترل انتشار، انتشار را ۳۰٪ کم می‌کند.</div><div class="row">کنترل انتشار: <b>${fa(n)}/۳</b> <button data-a="ab" ${n>=3?'disabled':''}>ارتقا (${fa(4000*(n+1))})</button></div></div>`}
function skyline(){if(!S.u.length)return'';
 const cs={run:'var(--ok)',trip:'var(--bad)',broken:'var(--bad)',off:'var(--warn)',tar:'var(--warn)'},sn={build:'در حال ساخت',ready:'آماده',run:'در حال کار',trip:'تریپ',broken:'خراب',off:'متوقف',tar:'تعمیرات'};
 const cnt=k=>S.u.filter(u=>u.st===k).length;
 return `<div class="card wide" id="sky"><div class="row"><h2>نمای افق صنعتی</h2><span class="muted">${fa(S.u.length)} پروژه · ${fa(cnt('run'))} در حال کار · برای رفتن به هر واحد روی آن بزنید</span></div><div class="row">${[['all','همه'],['run','در حال کار'],['bad','خراب / تریپ'],['off','متوقف / در ساخت'],['loss','ضررده']].map(([v,n])=>`<button data-a="flt" data-v="${v}" aria-pressed="${(S.flt||'all')===v}">${n}</button>`).join('')}<span class="muted">مرتب‌سازی:</span><button data-a="srt" data-v="num" aria-pressed="${(S.srt||'num')==='num'}">شماره</button><button data-a="srt" data-v="pl" aria-pressed="${S.srt==='pl'}">بیشترین ضرر</button></div><div class="sk2">${visUnits().map(i=>{const u=S.u[i],d=D[u.t],c=cs[u.st]||'var(--mut)',h=14+(d.cost>30000?14:d.cost>10000?8:0);
  return `<div class="sk-card"><button class="sk" data-go="${i}" style="border-color:${c}" aria-label="رفتن به ${d.n} شماره ${i+1}"><svg viewBox="0 0 50 40" width="46" height="36" aria-hidden="true"><rect x="0" y="35" width="50" height="4" fill="var(--line)"/><rect x="6" y="${35-h}" width="34" height="${h}" fill="var(--card)" stroke="${c}" stroke-width="2"/><rect x="12" y="${35-h-9}" width="6" height="9" fill="${c}"/>${u.st==='run'?`<circle class="smk" cx="15" cy="${35-h-13}" r="3" fill="var(--mut)"/>`:''}</svg><b>${fa(i+1)}</b><span>${d.n}</span><small style="color:${c}">${sn[u.st]||''}</small></button><button class="sk-control" data-hmi="${i}" ${['build','ready'].includes(u.st)?'disabled title="پس از راه‌اندازی در دسترس است"':''}>${['build','ready'].includes(u.st)?'پس از راه‌اندازی در دسترس':'ورود به اتاق کنترل'}</button></div>`}).join('')}${visUnits().length?'':'<div class="muted">موردی با این فیلتر نیست.</div>'}</div></div>`}
function infraCard(){const n=S.infra||0;return `<div class="card"><h2>زیرساخت ملی</h2><div class="row">سطح فعلی: <b>${fa(n)}/۴</b></div>${IC.map((c,k)=>`<div class="eq"><span>${fa(k+1)}. ${INFN[k]}</span>${k<n?'<span class="tag run">ساخته شد</span>':k===n?`<button data-a="infra">ساخت (${fa(c)})</button>`:'<span class="muted">قفل</span>'}</div>`).join('')}<div class="muted" style="font-size:12px">هر واحد برای ساخت به سطح زیرساخت مشخصی نیاز دارد. فولاد و سیمان ساخت از مخزن خودتان برداشت می‌شود و کمبودش با قیمت واردات خریده می‌شود.</div></div>`}

// Operator HMI: all displayed values are read from the live simulation state.
function viewHMI(){
 const commissioned=S.u.map((u,i)=>({u,i})).filter(x=>!['build','ready'].includes(x.u.st));
 if(!commissioned.length)return `<section class="hmi-shell wide"><div class="hmi-head"><div><span class="hmi-kicker">CONTROL ROOM / DCS</span><h2>اتاق کنترل فرایند</h2><p class="muted">نمایش زنده وضعیت واحدها، متغیرهای فرایندی و آلارم‌های عملیاتی</p></div><span class="tag">بدون واحد راه‌اندازی‌شده</span></div><div class="hmi-empty">هنوز واحدی به بهره‌برداری نرسیده است. پس از راه‌اندازی اولین پروژه، اطلاعات آن در این صفحه نمایش داده می‌شود.</div></section>`;
 let selected=commissioned.find(x=>x.i===S.hmiUnit)||commissioned[0];
 const u=selected.u,i=selected.i,d={...D[u.t],n:unitTitle(u,D,i)};if(S.hmiUnit!==i){S.mimicEq=null;S.mimicLoop=null}S.hmiUnit=i;
 const stateName={run:'در سرویس',trip:'تریپ',broken:hasEquipmentFaults(u)?'خارج از سرویس · خرابی':'در انتظار راه‌اندازی',tar:'تعمیرات اساسی',off:'توقف عمدی'}[u.st]||u.st;
 const stateClass=u.st==='run'?'ok':(['trip','broken'].includes(u.st)?'bd':'wn');
 const alarms=[];d.v.forEach((v,k)=>{const pc=S.pid?.[`${i}:${k}`];if(pc?.naturalDays>0)alarms.push(['INFO','نوسان ملایم: '+v[0],pc.naturalCause+'؛ اثر محدود و موقت. وضعیت حلقه را بررسی کن.'])});
 if(u.st==='trip')alarms.push(['HIGH','تریپ واحد','واحد از مدار خارج شده است.']);
 if(u.st==='broken')alarms.push(hasEquipmentFaults(u)?['HIGH','خرابی واحد','خرابی تجهیز اصلی یا رزرو ثبت شده؛ جزئیات تعمیر را بررسی کن.']:['INFO','در انتظار بازگشت به سرویس',unitExplanation(u)]);
 if(u.st==='off')alarms.push(['INFO','توقف عمدی','واحد با فرمان اپراتور متوقف شده است.']);
 if(u.st==='tar')alarms.push(['INFO','تعمیرات اساسی','واحد در دوره تعمیرات اساسی قرار دارد.']);
 if(S.cr?.i===i)alarms.push(['HIGH','رخداد فعال: '+CR[S.cr.k].t,`زمان پاسخ: ${fa(S.cr.d)} روز باقی‌مانده.`]);
 if(u.feedIncident?.days>0)alarms.push(['MED','اختلال خوراک',`کاهش دسترسی خوراک؛ ${fa(u.feedIncident.days)} روز باقی‌مانده.`]);
 if(u.coolingIncident?.days>0)alarms.push(['HIGH','افت خنک‌کاری',`افزایش بار حرارتی؛ ${fa(u.coolingIncident.days)} روز باقی‌مانده.`]);
 if(u.instrumentIncident?.days>0)alarms.push(['MED','Drift ابزار دقیق',`سیگنال متغیر ${d.v[u.instrumentIncident.k]?.[0]||''} نیازمند بررسی است.`]);
 if(S.gridIncident?.days>0)alarms.push(['HIGH','اختلال برق سایت',`ظرفیت برق محدود است؛ ${fa(S.gridIncident.days)} روز باقی‌مانده.`]);
 d.v.forEach((x,k)=>{const value=u.v[k],dev=Math.abs(value-x[2])/Math.max(x[3],.0001);if(dev>1.7)alarms.push(['HIGH','انحراف شدید: '+x[0],`مقدار ${f1(value)} ${x[1]}؛ هدف ${f1(x[2])} ${x[1]}.`]);else if(dev>1)alarms.push(['MED','انحراف فرایندی: '+x[0],`مقدار ${f1(value)} ${x[1]} از باند کنترل خارج شده است.`]);});
 u.eq.forEach((e,j)=>{if(e.reserve&&e.reserve.h<30)alarms.push(['MED','سلامت پایین پمپ رزرو: '+d.e[j][0],`سلامت تجهیز رزرو ${fa(e.reserve.h)}٪ است و در صورت نیاز آماده ورود به مدار نیست.`]);if(e.reserve?.f)alarms.push(['MED','خرابی رزرو: '+d.e[j][0],'قطعه و تعمیر تجهیز رزرو را در تجهیزات و نگهداری بررسی کن.']);if(e.f)alarms.push(['HIGH','خرابی تجهیز: '+d.e[j][0],e.f.st===0?'قطعه یدکی موردنیاز است.':e.f.st===1?'قطعه در مسیر تأمین است.':'قطعه رسیده و تجهیز آماده تعمیر است.']);if(e.h<30)alarms.push(['MED','سلامت پایین تجهیز: '+d.e[j][0],`سلامت تجهیز ${fa(e.h)}٪ است.`]);});
 const variableBlocks=d.v.map((x,k)=>{const value=u.v[k],dev=Math.abs(value-x[2])/Math.max(x[3],.0001),level=dev>1.7?'bd':dev>1?'wn':'ok',pidKey=`${i}:${k}`,pc=S.pid?.[pidKey]||{},sp=Number.isFinite(pc.sp)?pc.sp:x[2],pidAuto=pc.mode==='auto';return `<div class="hmi-pv"><div class="hmi-pv-top"><span>${x[0]}</span><b class="${level}">${f1(value)} <small>${x[1]}</small></b></div><div class="hmi-target">هدف طراحی ${f1(x[2])} ${x[1]} · باند ±${f1(x[3])}</div>${chart(u.h[k]||[],sp,x[3],dev>1.7?'var(--bad)':dev>1?'var(--warn)':'var(--ok)')}<div class="pid-controls"><label>مقدار هدف SP (${x[1]})<input type="number" step="any" data-pid-sp data-i="${i}" data-k="${k}" value="${sp}" ${u.st!=='run'?'disabled':''}></label>${!u.au?.[k]?`<button type="button" data-a="auto" data-i="${i}" data-k="${k}" ${u.st!=='run'?'disabled':''}>خرید و نصب کنترلر PID (${fa(d.cost*.15)})</button>`:`<button type="button" data-a="pid-toggle" data-i="${i}" data-k="${k}" ${u.st!=='run'?'disabled':''}>${pidAuto?'خودکار AUTO · تغییر به دستی MAN':'دستی MAN · فعال‌سازی خودکار AUTO'}</button>`}</div><div class="pid-readout muted">${pidAuto?`خروجی کنترلر: ${f1((pc.output||0)*100)}٪ · ${pc.actuatorTag||describeFinalElement(x[0]).tag} · ${pc.actuatorLabel||describeFinalElement(x[0]).label} · موقعیت محرک: ${f1(pc.mv??50)}٪ · Kp ${pc.kp??0.25} / Ki ${pc.ki??0.06} / Kd ${pc.kd??0.02}`:`MAN · خروجی دستی محرک: ${f1(pc.mv??50)}٪ · ${pc.actuatorTag||describeFinalElement(x[0]).tag}`}<br>هدف دینامیکی مدل: ${f1(pc.processTarget??x[2])} ${x[1]} · اثر محرک: ${f1(pc.actuatorEffect||0)} ${x[1]} · اختلال باقی‌مانده: ${f1(pc.disturbance||0)} ${x[1]}</div>${pc.naturalDays>0?`<p class="loop-drift">${pc.naturalCause} · اثر هدف ${f1(pc.naturalBias)} ${x[1]} · ${fa(pc.naturalDays)} روز باقی‌مانده. ${pidAuto?'AUTO در حال جبران است.':'با اصلاح خروجی دستی یا فعال‌کردن AUTO آن را جبران کن.'} این رخداد ملایم جای خرابی واقعی تجهیز نیست.</p>`:''}<div class="row hmi-actions"><button type="button" data-a="disturb" data-i="${i}" data-k="${k}" ${u.st!=='run'?'disabled':''}>اعمال اختلال آزمایشی</button>${u.st==='run'&&!pidAuto?`<button data-a="adj" data-i="${i}" data-k="${k}" data-s="-1">کاهش خروجی</button><button data-a="adj" data-i="${i}" data-k="${k}" data-s="1">افزایش خروجی</button>`:''}${u.au[k]&&!pidAuto?'<span class="tag run">کنترلر نصب‌شده · آماده AUTO</span>':''}</div></div>`});
 const equipment=u.eq.map((e,j)=>{const fault=e.f,partActions=fault&&fault.st===0?`<button data-a="part" data-i="${i}" data-j="${j}" data-f="0">سفارش قطعه (${fa(partCost(d,j))})</button><button data-a="part" data-i="${i}" data-j="${j}" data-f="1">ارسال فوری (${fa(partCost(d,j)*2)})</button>`:fault&&fault.st===2?`<button class="p" data-a="repair" data-i="${i}" data-j="${j}">تعمیر تجهیز (${fa(d.cost*.04)})</button>`:fault?'<span class="muted">قطعه در مسیر تأمین است</span>':'';return `<div class="hmi-eq"><div class="hmi-eq-title"><b>${d.e[j][0]}</b><span class="${fault?'bd':e.h<30?'wn':'ok'}">${fault?(fault.st===0?'خراب · قطعه لازم':fault.st===1?'قطعه در راه':'آماده تعمیر'):e.h<30?'نیازمند توجه':'آماده به کار'}</span></div><div class="bar"><i style="width:${cl(e.h,0,100)}%;background:${fault?'var(--bad)':e.h<30?'var(--warn)':'var(--ok)'}"></i></div><small class="muted">سلامت اصلی ${fa(e.h)}٪${e.reserve?' · سلامت رزرو '+fa(e.reserve.h)+'٪':''} · سطح ${fa(e.l)}</small><div class="row hmi-actions">${partActions}<button data-a="up" data-i="${i}" data-j="${j}" ${e.l>=4?'disabled':''}>ارتقای تجهیز (${fa(d.cost*.3*e.l)})</button></div></div>`}).join('');
 const alarmHtml=alarms.length?alarms.map(a=>`<div class="hmi-alarm ${a[0].toLowerCase()}"><b>${a[0]}</b><div><strong>${a[1]}</strong><small>${a[2]}</small></div></div>`).join(''):'<div class="hmi-clear">✓ هیچ آلارم فعالی برای این واحد شناسایی نشد.</div>';
 return renderControlRoom({S,D,u,d,i,commissioned,stateName,stateClass,alarms,alarmHtml,variableBlocks,equipment:equipment+renderReserveRepairs(u,d,i,fa),maintenance:maintenancePanel(S,u,i,D),commands:`<section class="hmi-panel hmi-command-panel"><div class="hmi-panel-head"><h3>فرمان‌های عملیاتی واحد</h3><span class="muted">فرمان‌ها روی همان واحد انتخاب‌شده اعمال می‌شوند</span></div><div class="row hmi-command-actions"><button data-a="pm" data-i="${i}" ${maintenanceCost(u,d)<=0?'disabled':''}>سرویس دوره‌ای (${fa(maintenanceCost(u,d))})</button><button data-a="tar" data-i="${i}" ${['run','trip','off'].includes(u.st)?'':'disabled'}>تعمیرات اساسی · ${fa(d.cost*.15)}</button>${u.st==='run'?`<button data-a="stop" data-i="${i}">شات‌داون / خروج از سرویس</button>`:''}${u.st==='off'?`<button class="p" data-a="resume" data-i="${i}">راه‌اندازی مجدد پس از توقف · ${fa(d.cost*.02)}</button>`:''}${u.st==='trip'?`<button class="p" data-a="restart" data-i="${i}">راه‌اندازی مجدد پس از تریپ · ${fa(d.cost*.04)}</button>`:''}${u.st==='broken'?(hasEquipmentFaults(u)?'<span class="tag trip">خرابی ثبت‌شده را در تجهیزات اصلی و رزرو بررسی کن</span>':`<button class="p" data-a="restart" data-i="${i}">بازگشت به سرویس پس از بررسی · ${fa(d.cost*.04)}</button><span>${recoveryBlock(S,u,i,D)||'خرابی ثبت نشده؛ منتظر تأیید راه‌اندازی است.'}</span>`):''}${u.st==='tar'?`<span class="tag tar">تعمیرات اساسی · ${fa(u.tar||0)} روز باقی‌مانده</span>`:''}</div><div class="row hmi-command-actions"><b>بار عملیاتی: ${fa(u.load||100)}٪ · ظرفیت نامی: ${fa(u.ratedCapacity||100)}٪ · بار ظرفیت: ${fa(u.capacityUse||100)}٪</b><button data-a="load" data-i="${i}" data-d="-10" ${(+u.load||100)<=50?'disabled':''}>کاهش بار ۱۰٪</button><button data-a="load" data-i="${i}" data-d="10" ${(+u.load||100)>=140?'disabled':''}>افزایش بار ۱۰٪</button><button data-a="load" data-i="${i}" data-d="0">بار نامی ۱۰۰٪</button></div><div class="row hmi-command-actions"><b>کیفیت خوراک: ${fa(u.feedGrade||90)}٪ · مصرف انرژی: ${f1(u.energyUse||0)} واحد/روز · هزینه انرژی: ${fa(u.energyCost||0)}</b><button data-a="feed-grade" data-i="${i}" data-d="-5" ${(+u.feedGrade||90)<=70?'disabled':''}>کاهش کیفیت خوراک</button><button data-a="feed-grade" data-i="${i}" data-d="5" ${(+u.feedGrade||90)>=100?'disabled':''}>افزایش کیفیت خوراک</button></div><p class="muted hmi-command-note">شات‌داون، راه‌اندازی مجدد، تعمیرات، تغییر بار و کیفیت خوراک از همین پنل قابل انجام است.</p></section>`,mimic:()=>renderProcessMimic({unit:u,definition:d,formatNumber:f1,unitIndex:i,selectedIndex:Number.isInteger(S.mimicEq)?S.mimicEq:null,selectedLoop:Number.isInteger(S.mimicLoop)?S.mimicLoop:null,loopConfigs:d.v.map((_,k)=>S.pid?.[`${i}:${k}`]),valveOpen:u.processState?.valveOpen!==false,pumpStandby:u.processState?.pumpStandby===true,processState:u.processState||null,pidLoops:d.v.map((v,k)=>({name:v[0],unit:v[1],config:S.pid?.[`${i}:${k}`]})).filter(loop=>loop.config?.mode==='auto')}),fa,f1});
}

function visUnits(){const f=S.flt||'all';let ix=S.u.map((u,i)=>i).filter(i=>{const u=S.u[i];return f==='all'||(f==='run'&&u.st==='run')||(f==='bad'&&['trip','broken'].includes(u.st))||(f==='off'&&['off','tar','build','ready'].includes(u.st))||(f==='loss'&&u.pl!=null&&u.pl<0)});if(S.srt==='pl')ix.sort((a,b)=>(S.u[a].pl??1e9)-(S.u[b].pl??1e9));return ix}
function stepUI(u,i){const s=u.su;return `<div class="note"><b>مراحل راه‌اندازی: ایمنی ← پمپ ← دما ← فشار ← خروجی (${fa(s.pos)}/۵ · خطا: ${fa(s.miss)})</b><div class="sel" style="flex-direction:column;margin-top:6px">${(S.tutorial&&!S.tutorial.dismissed?[0,1,2,3,4]:s.o).map(k=>`<button ${k<s.pos?'disabled':''} data-a="step" data-i="${i}" data-k="${k}">${k<s.pos?'✓ ':''}${L5[k]}</button>`).join('')}</div></div>`}
function techCard(){const o=S.tech||{};return `<div class="card wide"><h2>تحقیق و توسعه</h2>${S.rd?`<div class="note">در حال تحقیق: <b>${TECHN[S.rd.k]}</b> · ${fa(S.rd.d)} روز مانده</div>`:'<div class="muted" style="font-size:12px">هم‌زمان فقط یک تحقیق ممکن است.</div>'}${TECH.map(([k,n,ds,c,d])=>`<div class="eq"><span><b>${n}</b> <span class="muted">${ds}</span></span>${o[k]?'<span class="tag run">انجام شد</span>':`<button data-a="tech" data-k="${k}" ${S.rd?'disabled':''}>تحقیق (${fa(c)} · ${fa(d)} روز)</button>`}</div>`).join('')}</div>`}
function statsCard(){const T=[0,0,0,0,0],si=Math.floor(((S.day-1)%360)/90);
 const rows=D.map((d,t)=>{const us=S.u.filter(u=>u.t===t),bl=us.filter(u=>u.st==='build'||u.st==='ready').length,rn=us.filter(u=>u.st==='run').length,dn=us.length-bl,sp=dn-rn;[us.length,dn,bl,rn,sp].forEach((v,k)=>T[k]+=v);return `<tr><td>${d.n}</td><td class="muted">${GOAL[t]}</td><td><b>${fa(dn)}</b></td><td>${fa(bl)}</td><td class="ok">${fa(rn)}</td><td class="${sp?'bd':''}">${fa(sp)}</td></tr>`}).join('');
 const g={};S.grid.forEach(b=>{if(b){g[b.t]=g[b.t]||[0,0];g[b.t][0]++;g[b.t][1]+=b.l}});
 return `<div class="card wide"><h2>آمار پروژه‌ها</h2><div class="row"><span class="tag">فصل: ${SEAS[si]}</span><span class="tag">ضریب تقاضا: گاز ×${f1(SF[si].g)} · برق ×${f1(SF[si].p)}</span></div><div style="overflow-x:auto"><table><tr><th>پروژه</th><th>هدف اصلی</th><th>ساخته‌شده</th><th>در حال ساخت</th><th>در حال کار</th><th>متوقف / خراب / تعمیرات</th></tr>${rows}<tr><td><b>جمع</b></td><td></td><td><b>${fa(T[1])}</b></td><td><b>${fa(T[2])}</b></td><td><b>${fa(T[3])}</b></td><td><b>${fa(T[4])}</b></td></tr></table></div><div class="row" style="margin-top:6px">${Object.entries(TY).filter(()=>false).map(([k,t])=>`<span class="tag">${t.e} ${t.n}: ${fa((g[k]||[0])[0])} (جمع سطح ${fa((g[k]||[0,0])[1])})</span>`).join(' ')}</div></div>`}
let countryExpanded=false,countryNotice='';
function farmCommand(action,kind){
 if(S.countryHub!=='north')return;
 const lot=districtLots(S,'north').find(l=>l.id===S.sel);
 if(!lot)return;
 const slot=action==='build'&&!lot.type?strategyState(S).plots.indexOf(null):lot.agriSlot;
 if(slot==null||slot<0)return;
 countryNotice=changeFarm(S,slot,action,kind,lot.id);
 if(!countryNotice&&action==='build')log(FARMS[kind].name+' در قطب کشاورزی در حال ساخت است.');
}
function chooseActivity(kind,id){
 S.atlasActivity={kind,id};mapSheetOpen=true;countryNotice='';
}
const B={
 'country-expand'(){countryExpanded=!countryExpanded;mapSheetOpen=false;},
 'country-pause'(){$('#pause').click();},
 'country-sea'(){
  S.countryHub=null;S.cityView=null;S.offshoreView=false;S.mapLayer='sea';
  chooseActivity('route','island');
 },
 'country-route'(x){if(Object.hasOwn(ROUTES,x.k))chooseActivity('route',x.k);},
 'country-ship'(x){if(strategyState(S).ships.some(v=>v.id===Number(x.i)))chooseActivity('ship',x.i);},
 'country-convoy'(x){countryNotice=protectVoyage(S,Number(x.i))||'همراهی حفاظتی ثبت شد.';},
 'country-resilience'(x){
  const msg=resilienceAction(S,x.t,x.i,x.k);
  if(!msg&&x.t==='warn-auto')chooseActivity('district',S.resilience.warning.zone);
  countryNotice=msg||'فرمان تاب‌آوری ثبت شد.';
 },
 'country-response'(){
  S.tab='c';S.cityView=null;S.countryHub=null;S.offshoreView=false;S.mapLayer='readiness';
  chooseActivity('district',S.resilience?.warning?.zone||'industry');
  window.scrollTo(0,0);
 },
 'country-voyage'(x){countryNotice=dispatchVoyage(S,x.p,x.k,6)||'سفر تجاری ثبت شد.';},
 'country-zone'(x){if(Object.hasOwn(DRILL_ZONES,x.k))chooseActivity('district',x.k);},
 'country-drill'(){
  countryNotice=changeDrill(S,'start');
  if(!countryNotice)chooseActivity('district',S.strategy.drill.target);
 },
 'country-team'(x){countryNotice=changeDrill(S,'move',x.k,S.tr>=1)||'تیم واکنش اعزام شد.';},
 'farm-build'(x){farmCommand('build',x.k);},
 'farm-upgrade'(){farmCommand('upgrade');},
 'farm-toggle'(){farmCommand('toggle');},
 'map-industry'(){S.tab='site';mapSheetOpen=false;window.scrollTo(0,0);},
 'map-country'(){
  S.tab='c';S.atlasSelected='industry';S.countryHub=null;S.offshoreView=false;S.cityView=null;mapSheetOpen=false;window.scrollTo(0,0);
 },
 'ops-close'(){mapSheetOpen=false},
 'ops-show'(){mapSheetOpen=true},
 'ops-network'(x){if(Object.hasOwn(NETWORKS,x.k)){S.mapLayer='services';S.mapNetwork=x.k;S.mapStep=null;mapSheetOpen=false}},
 'ops-step'(x){if(countryNetwork(S).steps.some(p=>p.id===x.k)){S.mapStep=x.k;mapSheetOpen=true}},
 'ops-treatment'(){
  const i=S.u.findIndex(u=>u.t===1&&u.st==='run');
  const unit=i>=0?i:S.u.findIndex(u=>u.t===1);
  if(unit>=0){S.tab='site';S.siteMapPage=Math.floor(unit/12);S.siteSelectedUnit=unit;mapSheetOpen=true}
  else{S.tab='i';S.industrySection='catalog';S.projectType=1;mapSheetOpen=false}
 },
 'dev-open'(){S.tab='m';S.manageSection='development'},
 'dev-accept'(x){acceptDevelopment(S,x.k)},
 'dev-prepare'(){if(prepareStoryCrisis(S))log('خدمات جایگزین بحران داستانی رزرو شد.')},
 'dev-project'(x){const t=Number(x.i);if(t!==1&&t!==13)return;S.tab='i';S.industrySection='catalog';S.projectType=t},
 'dev-stock'(x){S.tab='m';S.manageSection='inventory';if(Object.hasOwn(PR,x.k||'')){S.marketProduct=x.k;S.marketFilter='all';S.marketPage=Math.floor(Object.keys(PR).indexOf(x.k)/12)}},

 'alert-go'(x){S.tab='m';S.manageSection='fields';S.flt='all'},
 'alert-dismiss'(x){S.alertAck=S.alertAck||{};S.alertAck[x.id]=true},
 load(x){const u=S.u[+x.i];if(!u||!['run','trip','off'].includes(u.st))return;const delta=Number(x.d);u.load=delta===0?100:cl((Number(u.load)||100)+delta,50,140);u.overloadTicks=0;log('بار عملیاتی «'+D[u.t].n+'» روی '+fa(u.load)+'٪ تنظیم شد.');},
 'feed-grade'(x){const u=S.u[+x.i];if(!u||!['run','trip','off'].includes(u.st))return;u.feedGrade=cl((Number(u.feedGrade)||90)+Number(x.d),70,100);log('کیفیت خوراک ورودی «'+D[u.t].n+'» روی '+fa(u.feedGrade)+'٪ تنظیم شد؛ هزینه و کیفیت محصول متناسب تغییر می‌کند.');},
 stop(x){const u=S.u[+x.i];if(u&&u.st==='run'){u.st='off';log('«'+D[u.t].n+'» به‌صورت عمدی از سرویس خارج شد؛ هزینه‌ی جاری و مصرف خوراک متوقف است.')}},
 resume(x){const u=S.u[+x.i];if(!u||u.st!=='off')return;const d=D[u.t],blocked=recoveryBlock(S,u,+x.i,D);if(blocked){log(blocked);return}if(pay(d.cost*.02)){u.v=d.v.map(y=>y[2]+(r()<.5?-1:1)*y[3]*1.2);u.st=anyOut(u)?'broken':'run';log('«'+d.n+'» '+(u.st==='run'?'دوباره وارد سرویس شد.':'هنوز تجهیز خراب دارد؛ ابتدا تعمیر کنید.'))}},
 zin(){zoomAt(1.35,GW*CELL/2,GH*CELL/2)},zout(){zoomAt(1/1.35,GW*CELL/2,GH*CELL/2)},zreset(){S.cam={x:0,y:0,k:1};camApply()},'map-3d'(){S.map3d=!S.map3d;const box=document.getElementById('mapbox');if(box)box.classList.toggle('map-3d',!!S.map3d);const toggle=box?.querySelector('[data-a=\"map-3d\"]');if(toggle){toggle.textContent=S.map3d?'۲بعدی':'۳بعدی';toggle.setAttribute('aria-pressed',String(!!S.map3d))}log(S.map3d?'نمای برجسته سه‌بعدی نقشه فعال شد.':'نمای دوبعدی نقشه فعال شد.')},
 ab(){const n=S.ab||0;if(n<3&&pay(4000*(n+1))){S.ab=n+1;log('سامانه‌ی کنترل انتشار ارتقا یافت.')}},
 eng(){if((S.eng||0)<3&&pay(3000)){S.eng=(S.eng||0)+1;log('مهندس متخصص استخدام شد.')}},
 infra(){const n=S.infra||0;if(n<4&&pay(IC[n])){S.infra=n+1;log('زیرساخت «'+INFN[n]+'» ساخته شد.')}},
 'economic-relief'(){if((S.govBudget||0)<2500){log('بودجه عمومی برای بسته حمایتی کافی نیست.');return}S.govBudget-=2500;S.sat=cl((S.sat||70)+5,0,100);S.economy=S.economy||{};S.economy.relief=3;S.economy.stability=cl((S.economy.stability??75)+3,0,100);log('بسته حمایتی عمومی اجرا شد؛ رضایت و ثبات اقتصادی موقتاً تقویت شد. هزینه: ۲٬۵۰۰ از بودجه عمومی.');},
 'gov-rate'(x){S.govRate=cl((Number(S.govRate)||1)+Number(x.d),.5,1.5);S.govRate=Math.round(S.govRate*10)/10;log('ضریب اخذ مالیات و عوارض ملی روی ×'+f1(S.govRate)+' تنظیم شد.')},
 'national-build'(x){const p=x.p,defs={refinery:['پالایشگاه ملی',12000],power:['نیروگاه ملی',16000],petrochem:['مجتمع پتروشیمی',18000],pipeline:['خطوط انتقال سراسری',9000]},d=defs[p];if(!d)return;S.nationalProjects=S.nationalProjects||{};const lv=S.nationalProjects[p]||0;if(lv>=3){log('این زیرساخت به حداکثر سطح توسعه رسیده است.');return}const cost=d[1]*(lv+1);if((S.govBudget||0)<cost){log('بودجه عمومی برای اجرای این پروژه کافی نیست.');return}S.govBudget-=cost;S.nationalProjects[p]=lv+1;log(`${d[0]} به سطح ${fa(lv+1)} توسعه یافت؛ هزینه ${fa(cost)} از بودجه عمومی پرداخت شد.`)},
 'map-deselect'(){S.sel=null;S.citySelected=null},
 'city-deselect'(){S.citySelected=null},
 'city-upgrade'(x){const city=CITIES[Number(x.i)];if(!city)return;S.cities=S.cities||{};const state=S.cities[city.name]||(S.cities[city.name]={level:0,satisfaction:70}),lv=Number(state.level)||0,cost=6000*(lv+1);if(lv>=3){log(`خدمات شهری «${city.name}» به حداکثر سطح رسیده است.`);return}if((S.govBudget||0)<cost){log('بودجه عمومی برای ارتقای خدمات این شهر کافی نیست.');return}S.govBudget-=cost;state.level=lv+1;state.satisfaction=cl((state.satisfaction??70)+4,0,100);S.regions=S.regions||{};const rs=S.regions[city.region]||(S.regions[city.region]={investment:0,satisfaction:70});rs.satisfaction=cl((rs.satisfaction??70)+2,0,100);log(`خدمات شهری «${city.name}» به سطح ${fa(lv+1)} ارتقا یافت؛ هزینه ${fa(cost)} از بودجه عمومی.`)}, 'city-enter'(x){mapSheetOpen=false;const i=Number(x.i);if(!Number.isInteger(i)||!CITIES[i])return;S.offshoreView=false;S.offshoreSelected=null;S.cityView=i;S.cityCell=null;S.cityMapPage=0;S.cityMaps=S.cityMaps||{};if(!Array.isArray(S.cityMaps[CITIES[i].name]))S.cityMaps[CITIES[i].name]=createStarterCityGrid();S.cityCam=S.cityCam||{x:0,y:0,k:1};log(`وارد نقشه مستقل شهر «${CITIES[i].name}» شدید.`)},
 'city-exit'(){cityMoveCell=null;cityBuildingDrag=null;S.cityView=null;S.cityCell=null},
 'city-map-page'(x){cityMoveCell=null;const next=Math.max(0,Math.min(3,(Number(S.cityMapPage)||0)+Number(x.d||0)));S.cityMapPage=next;S.cityCell=null},
 'city-cell'(x){mapSheetOpen=true;cityMoveCell=null;const i=Number(x.i);if(Number.isInteger(i)&&i>=0&&i<81)S.cityCell=i},
 'city-build'(x){const i=Number(S.cityView),cell=Number(S.cityCell),city=CITIES[i];if(!city||!Number.isInteger(cell)||cell<0||cell>=81)return;S.cityMaps=S.cityMaps||{};const grid=S.cityMaps[city.name]||(S.cityMaps[city.name]=Array(81).fill(null));if(grid[cell]||LANDMARKS[cityDesign(S,city.name).placements[cell]?.item])return;const defs={home:['خانه مسکونی',850],shop:['مرکز تجاری',1250],service:['مرکز خدماتی',2100],park:['پارک شهری',650]},d=defs[x.t];if(!d)return;if((S.govBudget||0)<d[1]){log('بودجه عمومی برای ساخت این مجموعه شهری کافی نیست.');return}S.govBudget-=d[1];grid[cell]={type:x.t,level:1};const st=S.cities?.[city.name]||(S.cities[city.name]={level:0,satisfaction:70});if(x.t==='service')st.satisfaction=cl((st.satisfaction??70)+1.5,0,100);if(x.t==='park')st.satisfaction=cl((st.satisfaction??70)+1,0,100);log(`${d[0]} در شهر «${city.name}» ساخته شد؛ هزینه ${fa(d[1])} از بودجه عمومی.`)},
 'city-building-undo'(){const city=CITIES[Number(S.cityView)];if(city&&undoCityMove(S,city.name)){cityMoveCell=null;cityBuildingDrag=null;log('آخرین جابه‌جایی ساختمان در این شهر بازگردانده شد.')}},
 'city-building-move'(){const city=CITIES[Number(S.cityView)];const cell=Number(S.cityCell);if(!city||!S.cityMaps?.[city.name]?.[cell])return;cityMoveCell=cityMoveCell===cell?null:cell;cityBuildingDrag=null;},
 'city-building-nudge'(x){const city=CITIES[Number(S.cityView)],cell=Number(S.cityCell);if(!city||cityMoveCell!==cell)return;const p=cityBuildingPos(city.name,cell);setCityBuildingPos(city.name,cell,p[0]+Number(x.dx||0),p[1]+Number(x.dy||0));},
 'city-building-reset-position'(){const city=CITIES[Number(S.cityView)],cell=Number(S.cityCell);if(!city||cityMoveCell!==cell)return;rememberCityMove(S,city.name,cell,cityBuildingPos(city.name,cell));if(S.cityBuildingPositions?.[city.name])delete S.cityBuildingPositions[city.name][cell];},
 'city-building-upgrade'(){const i=Number(S.cityView),cell=Number(S.cityCell),city=CITIES[i],grid=city&&S.cityMaps?.[city.name],b=grid?.[cell];if(!b||b.level>=3)return;const costs={home:500,shop:750,service:1200,park:350},cost=costs[b.type]*b.level;if((S.govBudget||0)<cost){log('بودجه عمومی برای ارتقای این ساختمان کافی نیست.');return}S.govBudget-=cost;b.level++;if(b.type==='service'||b.type==='park'){const st=S.cities?.[city.name]||(S.cities[city.name]={level:0,satisfaction:70});st.satisfaction=cl((st.satisfaction??70)+.8,0,100)}log('ساختمان شهری به سطح '+fa(b.level)+' ارتقا یافت؛ هزینه '+fa(cost)+'.')},
 'city-building-demolish'(){const i=Number(S.cityView),cell=Number(S.cityCell),city=CITIES[i],grid=city&&S.cityMaps?.[city.name],b=grid?.[cell];if(!b)return;const refund={home:250,shop:350,service:600,park:180}[b.type]*b.level;S.govBudget=(S.govBudget||0)+refund;grid[cell]=null;if(S.cityMoveHistory?.[city.name])S.cityMoveHistory[city.name]=S.cityMoveHistory[city.name].filter(m=>m.cell!==cell);if(S.cityBuildingPositions?.[city.name])delete S.cityBuildingPositions[city.name][cell];cityMoveCell=null;S.cityCell=null;log('ساختمان شهری تخریب شد؛ '+fa(refund)+' به بودجه عمومی بازگشت.')},

 'regional-invest'(x){const i=Number(x.i);if(!Number.isInteger(i)||i<0||i>=REGIONS.length)return;S.regions=S.regions||{};const state=S.regions[i]||(S.regions[i]={investment:0,satisfaction:70}),lv=state.investment||0,cost=3500*(lv+1);if(lv>=3){log('برنامه توسعه این منطقه به سقف سرمایه‌گذاری رسیده است.');return}if((S.govBudget||0)<cost){log('بودجه عمومی برای توسعه این منطقه کافی نیست.');return}S.govBudget-=cost;state.investment=lv+1;state.satisfaction=cl((state.satisfaction??70)+2,0,100);log(`زیرساخت محلی منطقه «${REGIONS[i][0]}» به سطح ${fa(lv+1)} ارتقا یافت؛ هزینه ${fa(cost)} از بودجه عمومی.`)},
 'regional-infra-toggle'(x){const i=Number(x.i);if(!Number.isInteger(i)||i<0||i>=REGIONS.length)return;S.openRegionalInfra=S.openRegionalInfra===i?null:i;},
 'regional-infra'(x){const i=Number(x.i),p=x.p;if(!Number.isInteger(i)||i<0||i>=REGIONS.length||!['power','gas','water','roads'].includes(p))return;S.regions=S.regions||{};const state=S.regions[i]||(S.regions[i]={investment:0,satisfaction:70});state.infrastructure=state.infrastructure||{};const lv=cl(Number(state.infrastructure[p])||0,0,3),base={power:1700,gas:1900,water:1600,roads:1300}[p],cost=base*(lv+1),label={power:'شبکه برق',gas:'شبکه گاز',water:'شبکه آب',roads:'راه‌های دسترسی'}[p];if(lv>=3){log(`${label} منطقه «${REGIONS[i][0]}» به حداکثر سطح رسیده است.`);return}if((S.govBudget||0)<cost){log('بودجه عمومی برای این ارتقای منطقه‌ای کافی نیست.');return}S.govBudget-=cost;state.infrastructure[p]=lv+1;state.satisfaction=cl((state.satisfaction??70)+1.2,0,100);log(`${label} منطقه «${REGIONS[i][0]}» به سطح ${fa(lv+1)} ارتقا یافت؛ هزینه ${fa(cost)} از بودجه عمومی.`)},
 network(x){const p=x.p;if(!['power','gas','water','fuel'].includes(p))return;S.network=S.network||{};const lv=Math.max(0,Math.min(4,S.network[p]||0)),cost=[1800,2800,4200,6000][lv];if(lv<4&&(S.govBudget||0)>=cost){S.govBudget-=cost;S.network[p]=lv+1;log('شبکه ملی '+({power:'برق',gas:'گاز',water:'آب',fuel:'سوخت'}[p])+' ارتقا یافت؛ تلفات انتقال به '+fa(Math.max(2,10-(lv+1)*2))+'٪ رسید.')}else if(lv<4)log('بودجه عمومی برای این سرمایه‌گذاری کافی نیست.')},
 flt(x){S.flt=x.v},
 srt(x){S.srt=x.v},
 neg(){if(S.walk&&pay(2000)){S.walk=null;S.mor=Math.min(100,S.mor+30);S.sal=Math.round((S.sal||12)*1.15*10)/10;log('مذاکره موفق شد؛ اپراتورها برگشتند و حقوق ۱۵٪ بالا رفت.')}},
 contr(){if(S.walk&&!S.walk.c&&pay(800)){S.walk.c=1;log('پیمانکار موقت جایگزین نیمی از نیروها شد.')}},
 bonus(){if(pay(1000)){S.mor=Math.min(100,S.mor+20);log('پاداش و رفاه پرداخت شد؛ روحیه‌ی اپراتورها بهتر شد.')}},
 tar(x){const u=S.u[+x.i];if(!u)return;const d=D[u.t];if((u.st==='run'||u.st==='trip'||u.st==='off')&&pay(d.cost*.15)){u.st='tar';u.tar=5;log('تعمیرات اساسی «'+d.n+'» شروع شد (۵ روز توقف).')}},
 restart(x){const ui=+x.i,u=S.u[ui];if(!u||!['trip','broken'].includes(u.st))return;const d=D[u.t],blocked=recoveryBlock(S,u,ui,D);if(blocked){log(blocked);return}const keepStandby=!!u.processState?.pumpStandby;if(pay(d.cost*.04)){u.v=d.v.map((y,k)=>{const cfg=S.pid?.[`${ui}:${k}`]||(S.pid[`${ui}:${k}`]={});cfg.integral=0;cfg.previousError=0;cfg.output=0;cfg.disturbance=0;cfg.mv=Number.isFinite(cfg.mv)?cl(cfg.mv,0,100):50;cfg.sp=Number.isFinite(cfg.sp)?cl(cfg.sp,y[2]-y[3]*3,y[2]+y[3]*3):y[2];cfg.rampedSp=y[2];return y[2]+(r()-.5)*y[3]*.04});u.st=anyOut(u)?'broken':'run';u.tripReason=null;if(u.maintenance)u.maintenance.recoveryPending=false;u.feedIncident=null;u.coolingIncident=null;u.instrumentIncident=null;u.incidentEquipment=null;u.processState={valveOpen:true,pumpStandby:false,lowFlowTicks:0};u.eq.forEach((e,j)=>{if(/پمپ|pump/i.test(String(d.e[j]?.[0]||''))){const useReserve=!!(e.reserve&&!e.reserve.f&&e.reserve.h>=30&&(e.f||keepStandby));e.running=!useReserve;if(e.reserve)e.reserve.running=useReserve;if(useReserve)u.processState.pumpStandby=true;}});log('راه‌اندازی مجدد «'+d.n+'» با بازنشانی مسیر XV-101؛ بار عملیاتی، بازشدگی دستی شیر/دور پمپ و SP تنظیم‌شده توسط اپراتور حفظ شد و حلقه‌های AUTO به‌صورت تدریجی به SP معتبر می‌رسند. '+(u.st==='run'?'واحد وارد سرویس شد.':'به‌دلیل خرابی تجهیز، واحد هنوز خارج از سرویس است.'))}},
 tech(x){if(S.rd)return;const t=TECH.find(q=>q[0]===x.k);if(!t||(S.tech||{})[t[0]])return;if(pay(t[3])){S.rd={k:t[0],d:t[4]};log('تحقیق «'+t[1]+'» شروع شد ('+fa(t[4])+' روز).')}},
 step(x){const u=S.u[+x.i];if(!u||!u.su)return;const s=u.su;if(+x.k===s.pos)s.pos++;else{s.miss++;changeSafety(S,-.5,'رعایت‌نکردن ترتیب راه‌اندازی',{routine:true,key:x.i+':startup',unit:Number(x.i),target:'unit'});log('ترتیب اشتباه! خطای ایمنی ثبت شد.')}
  if(s.pos>=5){const d=D[u.t],f=s.miss===0?.8:s.miss<3?1.6:2.4;u.v=d.v.map(y=>y[2]+(r()<.5?-1:1)*y[3]*f);u.st='run';u.su=null;S.industrySection='operations';S.expandedUnit=i;log('«'+d.n+'» راه‌اندازی شد'+(s.miss?' با '+fa(s.miss)+' خطا':' بدون خطا')+'.')}},
 cr(x){resolveCr(+x.o)},
 line(){const n=S.line||0;if(pay(3000*(n/100+1)))S.line=n+100},
 ctok(x){const c=S.co[+x.o];if(!c)return;S.co.splice(+x.o,1);(S.ct=S.ct||[]).push(c);log('قرارداد '+PR[c.p][0]+' امضا شد.')},
 ctno(x){S.co.splice(+x.o,1)},
 tab(x){mapSheetOpen=false;if(x.t==='offshore'){S.tab='c';S.offshoreView=true;S.cityView=null;return}S.tab=x.t;S.offshoreView=false;S.offshoreSelected=null},
 hselect(x){S.hmiUnit=+x.i;},
 loan(x){const a=+x.m,d=S.debt||0;if(d+a>40000){log('سقف اعتبار پر است.');return}S.debt=d+a;S.money+=a*.98;log('وام '+fa(a)+' دریافت شد (کارمزد ۲٪).')},
 bailout(){if(S.bailoutUsed){log('بازسازی اضطراری قبلاً در این ذخیره استفاده شده است.');return}if(S.money>=0){log('بازسازی اضطراری فقط هنگام منفی بودن سرمایه قابل استفاده است.');return}const grant=20000;S.money+=grant;S.debt=(S.debt||0)+grant;S.financialGraceDays=10;S.bailoutUsed=true;log('بازسازی اضطراری فعال شد: ۲۰٬۰۰۰ واحد نقدینگی با ثبت بدهی، ۱۰ روز تنفس بهره و فرصت اصلاح جریان نقدی. واحدهای زیان‌ده و هزینه‌های غیرضروری را فوراً مدیریت کنید.');},
 adv(){if(!S.adv&&pay(1000)){S.adv=1;log('مشاور بحران استخدام شد.')}},
 pi(x){const it=PI.find(q=>q[0]===x.k);if(it&&!(S.pi||{})[x.k]&&pay(it[2])){S.pi=S.pi||{};S.pi[x.k]=1;log('منبع درآمد پایدار فعال شد: '+it[1])}},
 repay(x){const d=S.debt||0;const a=Math.min(+x.m||d,d);if(a>0&&pay(a)){S.debt=d-a;log('بازپرداخت '+fa(a)+' انجام شد.')}},
 build(x){const t=TY[x.t];if(!t||!S.countryHub||!hubAllowed(S.countryHub,x.t)){log('ساخت این ساختمان فقط در قطب مربوط مجاز است.');return}if(S.sel===null||S.grid[S.sel]||!districtLots(S,S.countryHub).some(l=>l.id===S.sel&&!l.type)||!buildable(S.sel)||!pay(t.cost))return;S.grid[S.sel]={t:x.t,l:1,c:{},hub:S.countryHub};log(t.n+' ساخته شد؛ آن را به شبکه‌ها وصل کنید.')},
 conn(x){const b=S.grid[S.sel];if(b&&Object.hasOwn(TY[b.t].need,x.p)&&!b.c[x.p]&&pay(100))b.c[x.p]=1},
 cup(){const b=S.grid[S.sel];if(b&&b.l<3&&pay(TY[b.t].cost*b.l*1.2)){b.l++;log(TY[b.t].n+' به سطح '+fa(b.l)+' ارتقا یافت.')}},
 demo(){const b=S.grid[S.sel];if(b){S.money+=TY[b.t].cost*b.l*.3;S.grid[S.sel]=null}},
 tank(x){const n=(S.tl[x.p]||0)+1;if(pay(800*n))S.tl[x.p]=n},
 hold(x){S.hold[x.p]=!S.hold[x.p]},
 price(x){const p=x.p;if(!PR[p]||!PR[p][3])return;const old=Number(S.salePrice[p])||1;S.salePrice[p]=cl(Math.round((old+(+x.d)*.1)*10)/10,.7,1.5);log('استراتژی قیمت '+PR[p][0]+' به ×'+f1(S.salePrice[p])+' تغییر کرد؛ تقاضای بازار متناسب با قیمت تعدیل می‌شود.')},
 'trade-contract'(x){
  const p=x.p,qty=Math.max(100,Math.min(5000,Math.round((Number(x.q)||500)/100)*100));
  if(!PR[p]?.[3]||S.tradeContracts.length>=4)return;
  const unit=PR[p][2]*(S.pm[p]||1)*(S.salePrice[p]||1)*(S.mkt||1);
  const price=unit*1.12,advance=qty*price*.2;
  S.money+=advance; // Buyer advances 20% cash; it is offset against delivered invoices.
  const c={id:Date.now()+Math.floor(r()*10000),p,qty,remaining:qty,days:20,unitPrice:price,advance,advanceBalance:advance,delivered:0};
  S.tradeContracts.push(c);log(`قرارداد صادرات ${PR[p][0]} به میزان ${fa(qty)} واحد امضا شد؛ پیش‌دریافت ${fa(advance)} به سرمایه افزوده شد و هنگام تحویل از صورتحساب کسر می‌شود.`)
 },
 'offshore-open'(){S.tab='m';S.cityView=null;S.offshoreView=false;S.offshoreSelected=null;requestAnimationFrame(()=>document.getElementById('offshore-management')?.scrollIntoView({behavior:'smooth',block:'start'}))},
 'offshore-map'(x){
  S.tab='c';S.cityView=null;S.citySelected=null;S.offshoreSelected=null;S.sel=null;
  S.offshoreView=true;
  if(x?.p==='oil'||x?.p==='gas')S.offshoreMapSelected=x.p;
  requestAnimationFrame(()=>window.scrollTo({top:0,behavior:'auto'}));
 },
 'offshore-country'(){S.tab='c';S.cityView=null;S.offshoreView=false;S.offshoreSelected=null},
 'offshore-deselect'(){S.offshoreSelected=null},
 'offshore-country-select'(x){
  if(x?.p!=='oil'&&x?.p!=='gas')return;
  S.offshoreSelected=x.p;S.citySelected=null;S.sel=null;
  if(window.matchMedia('(max-width: 700px)').matches)requestAnimationFrame(()=>document.getElementById('map-build-dock')?.scrollIntoView({behavior:'smooth',block:'nearest'}));
 },
 'site-page'(x){mapSheetOpen=false;const pages=Math.max(1,Math.ceil(S.u.length/12));S.siteMapPage=cl((Number(S.siteMapPage)||0)+Number(x.d||0),0,pages-1)},
 'offshore-start'(x){
  const key=x.p==='gas'?'gas':'oil',o=S.offshore[key];
  if(o.stage>=5||o.project)return;
  const next=o.stage+1,step=offshoreStages(key)[next];
  if(!step||!pay(step.cost))return;
  o.project={target:next,days:step.days};
  log(`پروژه ${OFFSHORE[key].name} آغاز شد: ${step.name}؛ ${fa(step.days)} روز.`);
 },
 'offshore-pipeline'(x){
  const key=x.p==='gas'?'gas':'oil',o=S.offshore[key],def=OFFSHORE[key];
  if(o.stage!==5||o.pipeProject||o.pipelineLevel>=3)return;
  const next=o.pipelineLevel+1,project=def.pipelineProjects[next];
  if(!project||!pay(project.cost))return;
  o.pipeProject={target:next,days:project.days};
  log(`${o.pipelineLevel===0?'ساخت':'ارتقای'} خط لوله زیردریایی ${def.name} آغاز شد؛ ${fa(project.days)} روز تا بهره‌برداری.`);
 },
 'offshore-toggle'(x){
  const key=x.p==='gas'?'gas':'oil',o=S.offshore[key];
  if(o.stage!==5)return;
  if(o.maintenance||o.incident||o.pipelineIsolated||(!o.online&&(o.health<30||(o.pipelineLevel>0&&o.pipeHealth<30)))){log('راه‌اندازی سکو قبل از رفع رخداد، پایان تعمیرات و بازگشایی ایمن خط با سلامت کافی مجاز نیست.');return}
  if(o.online===false&&o.reserveRemaining<=0){log('ابتدا پروژهٔ اتصال بخش تازهٔ میدان را تکمیل کن تا ذخیرهٔ قابل برداشت فراهم شود.');return}
  o.online=!o.online;
  log(`${o.online?'بازگشت به سرویس':'توقف کنترل‌شده برداشت'} سکوی ${OFFSHORE[key].name} ثبت شد.`);
 },
 'offshore-target'(x){
  const key=x.p==='gas'?'gas':'oil',o=S.offshore[key],v=Number(x.q);
  if(o.stage!==5||![50,75,100].includes(v)||o.productionTarget===v)return;
  o.productionTarget=v;
  log(`هدف تولید میدان ${OFFSHORE[key].name} به ${fa(v)}٪ ظرفیت قابل دسترس تغییر کرد.`);
 },
 'offshore-isolate'(x){const key=x.p==='gas'?'gas':'oil';if(isolateOffshore(S,key,log))recordSOE(`فرمان ESD و ایزولاسیون خط ${OFFSHORE[key].name} توسط اپراتور اجرا شد.`,'HIGH');},
 'offshore-pipe-resume'(x){resumeOffshorePipeline(S,x.p==='gas'?'gas':'oil',log)},
 'offshore-maintenance'(x){const key=x.p==='gas'?'gas':'oil',kind=x.k==='pipeline'?'pipeline':'rig';startOffshoreMaintenance(S,key,kind,log,pay)},
 'offshore-recovery'(x){
  const key=x.p==='gas'?'gas':'oil',def=OFFSHORE[key],o=S.offshore[key];
  if(!recoveryReady(o)||o.recoveryLevel>=2||o.recoveryProject||o.incident||o.maintenance){log('ابتدا باید میدان و خط لوله در سرویس باشند و حداقل ۱۰٪ از ذخیره برداشت شده باشد.');return}
  const next=o.recoveryLevel+1,project=def.recoveryProjects[next];
  if(!project||!pay(project.cost))return;
  o.recoveryProject={target:next,days:project.days};
  log(`پروژه «${def.recoveryName}» سطح ${fa(next)} شروع شد؛ زمان ${fa(project.days)} روز.`);
 },
 'offshore-recovery-toggle'(x){
  const key=x.p==='gas'?'gas':'oil',o=S.offshore[key];if(o.stage!==5||o.recoveryLevel<1)return;
  o.recoveryEnabled=!o.recoveryEnabled;
  log(`${o.recoveryEnabled?'فعال‌سازی':'توقف'} سامانه بازیافت کمکی میدان ${OFFSHORE[key].name} ثبت شد.`);
 },
 'offshore-extension'(x){if(!startOffshoreExtension(S,x.p,log,pay))log('توسعهٔ بخش تازه فعلاً ممکن نیست؛ ذخیره، سلامت عملیات و نقد را بررسی کن.')},
 'offshore-import'(x){performMarketTrade(x.p==='gas'?'sourgas':'crude','buy',500)},
 'trade-import'(x){if(PR[x.p]?.[3])performMarketTrade(x.p,'buy',Number(x.q)||500)},
 'trade-cancel'(x){const c=S.tradeContracts.find(c=>String(c.id)===String(x.id));if(!c)return;const penalty=Math.max(0,c.remaining*c.unitPrice*.08),refund=Number.isFinite(c.advanceBalance)?Math.max(0,c.advanceBalance):0;S.money-=penalty+refund;S.tradeContracts=S.tradeContracts.filter(q=>q!==c);log(`قرارداد ${PR[c.p][0]} لغو شد؛ پیش‌دریافت مصرف‌نشده ${fa(refund)} بازپرداخت و جریمه فسخ ${fa(penalty)} اعمال شد.`)},
 port(){if(pay(1500*S.port/20))S.port+=20}};
const cstat=(b)=>{if(!b)return'var(--line)';const ks=Object.keys(TY[b.t].need),m=Math.min(...ks.map(p=>b.c[p]?S.fr[p]??1:0));return m>=.9?'var(--ok)':m>=.5?'var(--warn)':'var(--bad)'};
const PI=[['rent','اجاره‌ی انبار و زمین',1500,25],['eng','خدمات مهندسی به شرکت‌های دیگر',3500,60],['inv','سرمایه‌گذاری در اوراق',9000,150]],BASE=30;
function pinc(){return BASE+PI.reduce((a,x)=>a+((S.pi||{})[x[0]]?x[3]:0),0)}
function passive(){return `<div class="card"><h2>درآمد پایدار</h2><div class="muted" style="font-size:12px">این درآمدها حتی وقتی واحدها خراب یا متوقف‌اند هر روز می‌رسند.</div><div class="eq"><span>یارانه‌ی توسعه‌ی دولتی (همیشگی)</span><b>+${fa(BASE)}</b></div>${PI.map(([k,n,c,v])=>`<div class="eq"><span>${n}</span>${(S.pi||{})[k]?`<span class="tag run">فعال +${fa(v)}</span>`:`<button data-a="pi" data-k="${k}">خرید (${fa(c)}) · +${fa(v)} در روز</button>`}</div>`).join('')}<div class="row">جمع: <b class="ok">+${fa(pinc())}</b> در روز</div></div>`}
function syncAlerts(){const el=document.getElementById('alert-layer');if(!el)return;const html=renderAlertBubbles(offshoreTransferAlerts(S).filter(a=>!(S.alertAck||{})[a.id]));if(el._h!==html){el._h=html;el.innerHTML=html}}
function diagnosticContext(){return {D,PR,OPN}}
function advice(){return recommendations(S,diagnosticContext())}
function advCard(){
 const data=advice();
 return `<section id="crisis-advisor" class="card wide advisor"><h2>مشاور بحران و علت زیان</h2>${!S.adv?`<p>تشخیص اولیه و مسیر رسیدگی در «اقدام پیشنهادی» نمایش داده می‌شود. مشاور، ریز تسویه و راه رفع همه واحدهای زیان‌ده را یکجا بررسی می‌کند.</p><button class="p" data-a="adv">استخدام مشاور (۱٬۰۰۰ · حقوق ۱۵ در روز)</button>`:`<p>علت‌ها از داده ثبت‌شده همان واحد استخراج می‌شوند. ابتدا مسئله ایمنی و تولید، سپس فروش و هزینه را بررسی کن.</p>${data.items.length?data.items.slice(0,5).map(r=>renderRecommendation(r)).join(''):'<p class="ok">در داده‌های موجود مشکل فوری شناسایی نشد.</p>'}<h3>گزارش واحدهای زیان‌ده</h3>${data.reports.filter(r=>r.loss).map((r,i)=>renderAdvisorReport(r,S,PR,i===0||S.advisorUnit===r.index)).join('')||'<p>واحد در سرویس با نتیجه منفی ثبت نشده است.</p>'}<p class="muted">حقوق مهندسان و نیروی مازاد، هزینه مشاور، بهره وام، جرایم و انتقال به بودجه عمومی هزینه‌های مشترک شرکت‌اند و در سود هر واحد تخصیص داده نشده‌اند. تشخیص واحد، تضمین سود نقد کل شرکت نیست.</p>`}</section>`
}
function bank(){const d=S.debt||0,lim=40000,grace=S.financialGraceDays||0;return passive()+`<div id="company-finance" class="card"><h2>بانک و وام</h2><div class="row">بدهی: <b class="${d?'wn':''}">${fa(d)}</b> · سقف اعتبار عادی: <b>${fa(lim)}</b> · بهره: <b>۰٫۴٪ در روز</b> (${grace?`تنفس بهره: ${fa(grace)} روز`:`${fa(d*.004)} امروز`})</div><div class="muted" style="font-size:12px">وام عادی کارمزد ۲٪ دارد و بهره روزانه از درآمد کم می‌شود. اگر سرمایه منفی شد، بازسازی اضطراری فقط یک‌بار در هر ذخیره قابل استفاده است.</div><div class="row">${[3000,8000,20000].map(a=>`<button data-a="loan" data-m="${a}" ${d+a>lim?'disabled':''}>وام ${fa(a)}</button>`).join('')}</div><div class="row"><button data-a="repay" data-m="1000" ${!d?'disabled':''}>بازپرداخت ۱٬۰۰۰</button><button data-a="repay" data-m="0" ${!d?'disabled':''}>تسویه کامل</button><button data-a="bailout" ${S.money>=0||S.bailoutUsed?'disabled':''}>بازسازی اضطراری +۲۰٬۰۰۰</button></div><div class="muted" style="font-size:12px">بازسازی اضطراری ۲۰٬۰۰۰ واحد نقدینگی به سرمایه اضافه می‌کند، همین مقدار به بدهی می‌افزاید و ۱۰ روز بهره را متوقف می‌کند. فقط یک‌بار قابل استفاده است؛ هزینه‌های عملیاتی همچنان ادامه دارند.</div></div>`}
function tradeCard(){
 const products=Object.entries(PR).filter(([p,v])=>v[3]);
 const contracts=(S.tradeContracts||[]).map(c=>`<div class="eq"><span><b>${PR[c.p][0]}</b> · مانده ${fa(c.remaining)} / ${fa(c.qty)} · ${fa(c.days)} روز</span><span><b>${fa(c.unitPrice)}</b> / واحد <button data-a="trade-cancel" data-id="${c.id}">فسخ</button></span></div>`).join('');
 const history=(S.tradeHistory||[]).slice(0,5).map(h=>`<div class="eq"><span>${PR[h.p]?.[0]||h.p} · ${h.status} · ${fa(h.delivered)} از ${fa(h.qty)}</span><small>روز ${fa(h.day)}${h.penalty?` · جریمه ${fa(h.penalty)}`:''}</small></div>`).join('');
 return `<section class="card wide"><h2>تجارت خارجی، قرارداد و واردات</h2><p class="muted">قراردادها از موجودی مخزن تحویل می‌شوند و با ظرفیت روزانه پایانه مشترک‌اند. ۲۰٪ ارزش قرارداد در زمان امضا به‌عنوان پیش‌دریافت به سرمایه اضافه می‌شود؛ مبلغ آن هنگام تحویل از صورتحساب کسر می‌شود. بخش مصرف‌نشده پیش‌دریافت در فسخ یا نقض قرارداد بازپرداخت می‌شود؛ نقض قرارداد جریمه هم دارد.</p><div class="trade-grid">${products.map(([p,[n]])=>`<div class="card"><b>${n}</b><div class="muted">موجودی: ${fa(S.tanks[p]||0)} · ظرفیت آزاد: ${fa(Math.max(0,cap(p)-(S.tanks[p]||0)))}</div><div class="row"><button data-a="trade-contract" data-p="${p}" data-q="500" ${S.tradeContracts.length>=4?'disabled':''}>قرارداد صادرات ۵۰۰</button><button data-a="trade-contract" data-p="${p}" data-q="1500" ${S.tradeContracts.length>=4?'disabled':''}>قرارداد ۱۵۰۰</button></div><button data-a="trade-import" data-p="${p}" data-q="500" ${(S.portRemainingToday??S.port)<=0||(S.tanks[p]||0)>=cap(p)?'disabled':''}>واردات تا ۵۰۰ واحد</button></div>`).join('')}</div><h3>قراردادهای فعال (${fa(S.tradeContracts.length)}/۴)</h3>${contracts||'<div class="muted">قرارداد فعالی وجود ندارد.</div>'}<h3>سوابق تجارت</h3>${history||'<div class="muted">هنوز سابقه‌ای ثبت نشده است.</div>'}<div class="muted">ظرفیت کل پایانه: ${fa(S.port)} واحد/روز · مصرف‌شده امروز: ${fa(S.portUsedToday||0)} · باقی‌مانده: ${fa(S.portRemainingToday??S.port)}. واردات دستی، واردات خودکار خوراک (به‌جز یوتیلیتی‌های محلی)، صادرات قراردادی و فروش نقدی از یک سقف مشترک استفاده می‌کنند.</div></section>`;
}
function offshoreCard(){
 const cards=Object.entries(OFFSHORE).map(([key,def])=>{
  const o=S.offshore[key],stage=o.stage,steps=offshoreStages(key),next=steps[stage+1];
  const project=o.project,pipeProject=o.pipeProject,metrics=reservoirMetrics(o);
  const pipeNext=def.pipelineProjects[o.pipelineLevel+1];
  const recoveryNext=def.recoveryProjects[o.recoveryLevel+1],recoveryWorking=!!o.recoveryProject;
  const recoveryUnlocked=recoveryReady(o),boostActive=recoveryAvailable(o,key,S);
  const incident=o.incident,maintenance=o.maintenance,sea=seaCondition(S.day);
  const alarm=incident?.kind==='pipeline-leak'?'نشتی خط زیردریایی':incident?.kind==='rig-failure'?'خرابی اضطراری سکو':null;
  const remaining=Math.max(0,o.reserveRemaining||0),start=Math.max(1,o.reserveInitial||1);
  const extension=nextOffshoreExtension(S,key);
  const hasReserve=stage>=3,confirmedText=hasReserve?`${fa(remaining)} / ${fa(start)} واحد`:'تا تکمیل ارزیابی ذخیره مشخص نیست';
  const reserveWidth=hasReserve?Math.round(remaining/start*100):0;
  const pipelineStatus=o.pipelineLevel===0?'احداث نشده':`سطح ${fa(o.pipelineLevel)} از ۳`;
  const projectUi=project?`<div class="note offshore-project"><b>${steps[project.target].name}</b> · ${fa(project.days)} روز مانده<div class="offshore-progress"><i style="width:${cl((1-project.days/steps[project.target].days)*100,0,100)}%"></i></div></div>`:'';
  const pipelineUi=pipeProject?`<div class="note offshore-project"><b>${o.pipelineLevel===0?'ساخت خط لوله':'ارتقای خط لوله'} → سطح ${fa(pipeProject.target)}</b> · ${fa(pipeProject.days)} روز مانده<div class="offshore-progress"><i style="width:${cl((1-pipeProject.days/def.pipelineProjects[pipeProject.target].days)*100,0,100)}%"></i></div></div>`:'';
  return `<article class="offshore-card"><h3>🌊 ${def.rig}</h3>
   <div class="eq"><span>توسعه میدان</span><b class="${stage===5?'ok':'wn'}">${stage===5?(o.online?'سکو در سرویس':'سکو متوقف'):stage===0?'آغاز نشده':steps[stage].name}</b></div>
   <div class="eq"><span>ذخیره قابل برداشت</span><b>${confirmedText}</b></div>
   ${hasReserve?`<div class="offshore-reserve-bar" role="progressbar" aria-valuenow="${reserveWidth}" aria-valuemin="0" aria-valuemax="100" aria-label="سهم باقی‌مانده ذخیره"><i style="width:${reserveWidth}%"></i></div><div class="eq"><span>شاخص فشار مخزن</span><b class="${metrics.pressurePct<35?'bd':metrics.pressurePct<65?'wn':'ok'}">${fa(metrics.pressurePct)}٪</b></div>`:''}
   ${stage===5?`<div class="offshore-integrity-top"><span class="offshore-status ${alarm?'alarm':o.pipelineIsolated?'isolated':'normal'}">${alarm?'🚨 '+alarm:maintenance?'🛠 تعمیرات در جریان':o.pipelineIsolated?'⛔ خط ایزوله است':'✓ آماده بهره‌برداری'}</span><small>شرایط دریا: ${sea}</small></div>
   <div class="offshore-health-grid"><div><small>سلامت سکوی دریایی</small><b class="${o.health<30?'bd':o.health<55?'wn':'ok'}">${f1(o.health)}٪</b><div class="offshore-health-bar"><i style="width:${o.health}%" class="${o.health<30?'bad':o.health<55?'warn':''}"></i></div></div><div><small>سلامت خط لوله</small><b class="${o.pipeHealth<30?'bd':o.pipeHealth<55?'wn':'ok'}">${f1(o.pipeHealth)}٪</b><div class="offshore-health-bar"><i style="width:${o.pipeHealth}%" class="${o.pipeHealth<30?'bad':o.pipeHealth<55?'warn':''}"></i></div></div></div>`:''}
   <div class="eq"><span>موجودی مخزن خشکی</span><b>${fa(S.tanks[def.product]||0)} / ${fa(cap(def.product))}</b></div>
   ${stage<5?`<div class="offshore-stage">${project?'مرحله در دست اجرا':`مرحله بعدی: ${next?.name||'—'}`}<br>${next?`هزینه: ${fa(next.cost)} · زمان: ${fa(next.days)} روز`:''}</div>${projectUi}<div class="offshore-actions"><button class="p" data-a="offshore-start" data-p="${key}" ${project?'disabled':''}>${project?'در حال اجرا':`شروع مرحله بعد (${fa(next.cost)})`}</button></div>`:
   `<div class="offshore-divider"><b>بهره‌برداری و افت طبیعی تولید</b><small>تولید اسمی اولیه: ${fa(def.rate)} واحد / روز</small></div>
   <div class="eq"><span>تولید از چاه امروز</span><b class="ok">${f1(o.producedToday||0)} واحد</b></div>
   <div class="eq"><span>هدف بهره‌برداری</span><b>${fa(o.productionTarget)}٪</b></div>
   <div class="offshore-target-actions" role="group" aria-label="تنظیم هدف تولید ${def.name}">${[50,75,100].map(q=>`<button data-a="offshore-target" data-p="${key}" data-q="${q}" aria-pressed="${o.productionTarget===q}" class="${o.productionTarget===q?'selected':''}">${fa(q)}٪</button>`).join('')}</div>
   <div class="offshore-actions"><button data-a="offshore-toggle" data-p="${key}" ${maintenance||incident||o.pipelineIsolated||(!o.online&&(remaining<=0||o.health<30||(o.pipelineLevel>0&&o.pipeHealth<30)))?'disabled':''}>${o.online?'⏸ توقف کنترل‌شده سکو':'▶ راه‌اندازی مجدد سکو'}</button></div>
   ${alarm?`<div class="offshore-incident" role="alert"><b>⚠ ${alarm}</b><small>${incident.kind==='pipeline-leak'?'جریان به‌صورت حفاظتی قطع شده است؛ ابتدا فرمان ایزولاسیون را اجرا و سپس تعمیر کنید. تا زمان ایزولاسیون، جریمه و افت HSE ادامه دارد.':'سکو خاموش شده است؛ برای بازگشت به سرویس باید تعمیر اضطراری انجام شود.'}</small></div>`:''}
   ${maintenance?`<div class="note offshore-project"><b>🛠 ${maintenance.emergency?'تعمیر اضطراری':'سرویس دوره‌ای'} ${maintenance.kind==='rig'?'سکو':'خط لوله'}</b> · ${fa(maintenance.days)} روز مانده</div>`:''}
   <div class="offshore-divider"><b>تعمیرات و واکنش اضطراری (HSE)</b><small>شروع سرویس باعث توقف کنترل‌شده می‌شود</small></div>
   <div class="offshore-actions"><button class="offshore-esd" data-a="offshore-isolate" data-p="${key}" ${o.pipelineLevel===0||o.pipelineIsolated?'disabled':''}>⛔ ایزولاسیون اضطراری خط (ESD)</button>
   ${o.pipelineIsolated?`<button data-a="offshore-pipe-resume" data-p="${key}" ${incident||maintenance||o.pipeHealth<30?'disabled':''}>🔓 بازگشایی خط پس از بازرسی</button>`:''}</div>
   <div class="offshore-actions"><button data-a="offshore-maintenance" data-p="${key}" data-k="rig" ${maintenance||(incident&&incident.kind!=='rig-failure')?'disabled':''}>${incident?.kind==='rig-failure'?'تعمیر اضطراری سکو (۳٬۲۰۰ · ۵ روز)':'سرویس سکو (۱٬۲۵۰ · ۳ روز)'}</button>
   ${o.pipelineLevel>0?`<button data-a="offshore-maintenance" data-p="${key}" data-k="pipeline" ${maintenance||(incident&&incident.kind!=='pipeline-leak')||(incident?.kind==='pipeline-leak'&&!o.pipelineIsolated)?'disabled':''}>${incident?.kind==='pipeline-leak'?'رفع نشتی خط (۴٬۲۰۰ · ۶ روز)':'سرویس خط (۱٬۴۵۰ · ۴ روز)'}</button>`:''}</div>
   <div class="offshore-divider"><b>خط لوله زیردریایی → پایانه خشکی</b><small class="${o.pipelineLevel?'ok':'wn'}">${pipelineStatus}</small></div>
   <div class="eq"><span>ظرفیت انتقال خط در روز</span><b>${fa(def.pipelineCapacity[o.pipelineLevel])} واحد</b></div>
   <div class="eq"><span>خوراک تحویلی امروز به خشکی</span><b class="${o.deliveredToday?'ok':'wn'}">${f1(o.deliveredToday||0)} واحد</b></div>
   <div class="eq"><span>بافر / مخزن موقت روی سکو</span><b>${f1(o.buffer||0)} / ${fa(def.bufferCapacity)}</b></div>
   <div class="eq"><span>کاهش تولید به‌علت محدودیت</span><b class="${o.shutInToday>1?'wn':'ok'}">${f1(o.shutInToday||0)} واحد</b></div>
   <div class="eq"><span>هزینه روزانه سکو، انتقال، بازیافت و جریمه</span><b>${fa(o.operatingCostToday||0)}</b></div>
   ${o.fineToday>0?`<div class="eq"><span>جریمه روزانه HSE بابت نشتی باز</span><b class="bd">${fa(o.fineToday)}</b></div>`:''}
   ${pipelineUi}
   <div class="offshore-actions">${o.pipelineLevel<3?`<button class="p" data-a="offshore-pipeline" data-p="${key}" ${pipeProject?'disabled':''}>${pipeProject?'پروژه انتقال در حال اجرا':`${o.pipelineLevel===0?'احداث خط لوله':'ارتقای خط به سطح '+fa(o.pipelineLevel+1)} (${fa(pipeNext.cost)} · ${fa(pipeNext.days)} روز)`}</button>`:'<span class="tag run">ظرفیت خط لوله تکمیل شده</span>'}</div>
   ${o.pipelineLevel===0?'<p class="offshore-warning">تا زمان نصب خط لوله، خوراک به مخازن خشکی نمی‌رسد. با پر شدن بافر سکو، برداشت از مخزن متوقف می‌شود.</p>':''}
   <div class="offshore-divider"><b>افزایش برداشت با فناوری کمکی</b><small>سطح ${fa(o.recoveryLevel)} از ۲</small></div>
   <div class="eq"><span>${def.recoveryName}</span><b>${o.recoveryLevel===0?'نصب نشده':o.recoveryEnabled?(boostActive?'فعال':'فاقد یوتیلیتی کافی / آماده‌به‌کار'):'غیرفعال'}</b></div>
   <div class="eq"><span>مصرف یوتیلیتی امروز</span><b>${fa(o.utilityUsedToday||0)} ${def.utility==='water'?'آب':'برق'}</b></div>
   ${recoveryWorking?`<div class="note offshore-project"><b>پروژه ارتقای بازیافت سطح ${fa(o.recoveryProject.target)}</b> · ${fa(o.recoveryProject.days)} روز باقی‌مانده</div>`:''}
   <div class="offshore-actions">${o.recoveryLevel<2?`<button data-a="offshore-recovery" data-p="${key}" ${recoveryWorking||!recoveryUnlocked||maintenance||incident?'disabled':''}>${recoveryWorking?'پروژه بازیافت در حال اجرا':recoveryUnlocked?`نصب / ارتقا: ${def.recoveryName} (${fa(recoveryNext.cost)} · ${fa(recoveryNext.days)} روز)`:'پس از ۱۰٪ برداشت و احداث خط لوله قابل بازگشایی'}</button>`:'<span class="tag run">طرح تقویت سطح ۲ تکمیل شد</span>'}
   ${o.recoveryLevel>0?`<button data-a="offshore-recovery-toggle" data-p="${key}">${o.recoveryEnabled?'توقف فناوری کمکی':'فعال‌سازی فناوری کمکی'}</button>`:''}</div>
   <p class="muted offshore-compact-note">فناوری کمکی تولید روزانه را در افت فشار بهبود می‌دهد، اما ذخیره نفت و گاز را افزایش نمی‌دهد. هر سطح برای نفت ${fa(def.utilityPerLevel)} واحد آب و برای گاز ${fa(def.utilityPerLevel)} واحد برق در روز مصرف می‌کند؛ در نبود یوتیلیتی، اثر کمکی خودکار حذف می‌شود.</p>
   ${remaining<=0?'<p class="offshore-warning">ذخیرهٔ بخش فعال پایان یافته است. بافر قابل انتقال است؛ پس از اتصال بخش تازه، فرمان راه‌اندازی بده.</p>':''}
   <div class="offshore-divider"><b>توسعهٔ بخش تازهٔ میدان</b><small>${fa(o.extensionLevel||0)} از ۲ بخش تکمیل شد</small></div>
   ${o.extensionProject?`<p class="note">اتصال بخش تازه · ${fa(o.extensionProject.days)} روز مانده</p>`:extension?`<p>از ۱۰٪ ذخیرهٔ باقی‌مانده با استفاده از سکوی فعلی قابل سفارش است.</p><button data-a="offshore-extension" data-p="${key}" ${remaining>start*.1||!o.pipelineLevel||maintenance||incident||S.money<extension.cost?'disabled':''}>اتصال بخش جدید · ${fa(extension.cost)} · ${fa(extension.days)} روز · ذخیره ${fa(extension.reserve)}</button>`:'<p>بخش‌های قابل توسعهٔ میدان مصرف شده‌اند. برای ادامهٔ تأمین از میدان دیگر یا واردات استفاده کن.</p>'}`}
   <div class="offshore-actions offshore-import-actions"><button data-a="offshore-import" data-p="${key}" ${(S.portRemainingToday??S.port)<=0||(S.tanks[def.product]||0)>=cap(def.product)?'disabled':''}>واردات ${def.name} · تا ۵۰۰ واحد</button></div>
  </article>`;
 });
 return `<section class="card wide" id="offshore-management"><div class="offshore-entry-head"><h2>اکتشاف، ذخایر، قابلیت اطمینان و انتقال فراساحلی</h2><button data-a="offshore-map" class="p">🌊 ورود به نقشه مستقل میادین</button></div><p class="muted offshore-help">در آغاز بازی برای نفت خام و گاز ترش به واردات وابسته هستید. پس از تأیید ذخیره و نصب سکو، خوراک ابتدا وارد بافر دریایی می‌شود و فقط از طریق خط لوله زیردریایی به مخزن خشکی و سپس واحدهای فرایندی می‌رسد. مخزن برداشت‌پذیر محدود است و افت فشار، دبی چاه را به‌تدریج کاهش می‌دهد. سلامت سکو و خطوط انتقال باید پایش شود؛ پس از ۱۰٪ برداشت، فناوری‌های تقویت تولید قابل نصب هستند.</p><div class="offshore-grid">${cards.join('')}</div><p class="muted offshore-model-note">مدل مخزن و فشار، ساده‌شده و مخصوص گیم‌پلی است (نه شبیه‌ساز مهندسی مخزن). ذخیره در مرحله تأیید مشخص می‌شود؛ تولید واقعی با ظرفیت مخزن موقت، خط لوله و مخزن خشکی محدود است. تولید متوقف‌شده از ذخیره کسر نمی‌شود. تعمیر سکو/خط، جریان مربوط را ایزوله می‌کند و پس از تکمیل، راه‌اندازی مجدد دستی است. نشتی خط قبل از تعمیر به ESD و ایزولاسیون اپراتوری نیاز دارد. فناوری کمکی ذخیره قابل برداشت را بیشتر نمی‌کند.</p></section>`;
}
function integrationCard(){
 const {links,issues}=auditSystemLinks(S),names={ok:'متصل',warn:'نیازمند اقدام',info:'اطلاع'};
 return `<section class="card wide integration-panel" id="integration-audit"><div class="integration-head"><div><span class="hmi-kicker">SYSTEM LINKS / GAMEPLAY AUDIT</span><h2>پایش ارتباط بخش‌های بازی</h2><p class="muted">بررسی زنده ارتباط خوراک، سکو، صنعت، شهر، اقتصاد، تجارت و HSE؛ وضعیت به‌صورت خودکار همراه روزهای بازی به‌روز می‌شود.</p></div><span class="tag ${issues?'trip':'run'}">${issues?`${fa(issues)} گلوگاه`: 'بدون گلوگاه بحرانی'}</span></div><div class="integration-grid">${links.map(x=>`<div class="integration-item ${x.status}"><div class="integration-item-head"><b>${x.label}</b><span>${names[x.status]}</span></div><p>${x.detail}</p>${x.next?`<small>اقدام پیشنهادی: ${x.next}</small>`:''}</div>`).join('')}</div><small class="muted">نکته: این پایش مبتنی بر قوانین واقعی بازی است؛ مقادیر عملکردی در مدل ساده‌شده محاسبه می‌شوند، نه بر پایه داده‌های صنعتی واقعی.</small></section>`;
}
function developmentCard(){return renderDevelopment(S,t=>projectEstimate(S,D[t],PR,IMP,feedCost(t)).total)}
const manageSections=[['inventory','انبار و فروش · خرید محصولات'],['trade','تجارت'],['development','توسعه کشور'],['finance','مالی'],['research','تحقیق و زیرساخت'],['fields','میادین'],['maintenance','نگهداری خودکار'],['overview','گزارش‌ها'],['legacy','شهر من و افتخارات']];
function manageNavigation(){return `<nav class="card wide manage-navigation" aria-label="بخش‌های مدیریت محصولات">${manageSections.map(([k,n])=>`<button data-a="manage-section" data-k="${k}" aria-pressed="${(S.manageSection||'inventory')===k}">${n}</button>`).join('')}</nav>`}
function viewManage(){
 const section=manageSections.some(([k])=>k===S.manageSection)?S.manageSection:'inventory';
 const pages={development:()=>developmentCard(),legacy:()=>renderLegacyCenter(S,{CITIES,PR,IN}),maintenance:()=>maintenanceFleet(S,D),trade:()=>contractCard()+tradeCard(),finance:()=>bank(),research:()=>techCard()+infraCard(),fields:()=>offshoreCard(),overview:()=>integrationCard()+advCard()+missionCard()+statsCard()+rivalCard()+esgCard()};
 if(pages[section])return manageNavigation()+crisisCard()+pages[section]();
 return manageNavigation()+(S.cr?crisisCard():'')+renderProductMarket(S,{D,PR,cap,IN,OUT,importMultiplier:IMP});}

const CT={sea:'#4aa8e0',sand:'#f3dfa0',grass:'#8ccf62',forest:'#74bd58',hill:'#b4c878',mount:'#9e9a93',desert:'#eecb82',river:'#58bff0'},TN={sea:'دریا',sand:'ساحل',grass:'دشت',forest:'جنگل',hill:'تپه',mount:'کوه',desert:'بیابان',river:'رودخانه'},SEAC=['#2e8b5718','#e0a80022','#c0702022','#4a7bc828'],CROP=['#7fcf55','#6fc24a','#d9a53c','#cfe6ee'];
function rng(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
let TERR=null;
function terr(){
 // Preserve deterministic geometry by map seed, but match the NEW country artwork:
 // alpine north-west, river along the west/centre and the sea along the SOUTH.
 if(TERR&&TERR.seed===S.seed&&TERR.layout==='south-coast-v51.4')return TERR;
 const R=rng(S.seed),T=[];
 for(let y=0;y<GH;y++)for(let x=0;x<GW;x++){
  const jitter=R();let t='grass';
  // The visible shoreline curves northward on the east side of the map.
  const shoreRow=x>=9?5.3:x>=7?6.15:x>=3?6.65:6.85;
  if(y+.5>shoreRow)t='sea';
  else if(y+.5>shoreRow-.88)t='sand';
  else if(x<=2&&y<=1)t='mount';
  else if(x<=1&&y<=3)t='hill';
  else if(x>=9&&y<=2)t='hill';
  else if(x>=9&&y>=2&&y<=4)t='desert';
  else if(x<=3&&y>=2&&y<=4)t='forest';
  else if(jitter>.84&&y<=3)t='forest';
  // River corridor passes from the mountains down toward the southern delta.
  if(t!=='sea'&&t!=='mount'&&x>=2&&x<=5&&y>=2&&y<=5&&Math.abs(x-(2.7+(y-2)*.56))<.52)t='river';
  T.push(t);
 }
 TERR={seed:S.seed,layout:'south-coast-v51.4',T};return TERR;
}
const buildable=i=>Number.isInteger(i)&&i>=0&&i<S.grid.length;
const hsh=(x,y)=>(((x*73856093)^(y*19349663)^(S.seed||1))>>>0)%1000/1000;
const nightI=()=>{const p=(Date.now()/1000%90)/90,d=Math.abs(p-.8);return d<.2?(1-d/.2)*.55:0};
function tdeco(t,x,y,v){const X=x*CELL,Y=y*CELL;
 if(t==='sea')return `<path d="M${X+8} ${Y+20}q6-6 12 0t12 0t12 0M${X+20} ${Y+44}q6-6 12 0t12 0" stroke="#fff" stroke-opacity=".5" fill="none" stroke-width="2"/>`;
 if(t==='river')return `<path d="M${X} ${Y+32}q16-10 32 0t32 0" stroke="#fff" stroke-opacity=".55" fill="none" stroke-width="2"/>`;
 if(t==='grass')return v<.35?`<circle cx="${X+14+v*60}" cy="${Y+46}" r="3" fill="#ffd54f"/><circle cx="${X+44}" cy="${Y+18+v*20}" r="2.5" fill="#fff"/>`:'';
 if(t==='forest')return [[16,22],[42,18],[30,44]].map(([a,b])=>`<rect x="${X+a-2}" y="${Y+b+6}" width="4" height="8" fill="#8a5a2b"/><circle cx="${X+a}" cy="${Y+b}" r="10" fill="#3f9e46"/><circle cx="${X+a-3}" cy="${Y+b-3}" r="4" fill="#56b85c"/>`).join('');
 if(t==='hill')return `<circle cx="${X+22}" cy="${Y+38}" r="16" fill="#a3b866"/><circle cx="${X+44}" cy="${Y+30}" r="13" fill="#98ad5c"/>`;
 if(t==='mount')return `<polygon points="${X+6},${Y+56} ${X+30},${Y+10} ${X+54},${Y+56}" fill="#8c8780"/><polygon points="${X+30},${Y+10} ${X+40},${Y+28} ${X+30},${Y+24} ${X+22},${Y+30}" fill="#fff"/><polygon points="${X+34},${Y+56} ${X+50},${Y+30} ${X+64},${Y+56}" fill="#a29d95"/>`;
 if(t==='desert')return `<path d="M${X+6} ${Y+44}q14-14 28 0t24 0" stroke="#d9a94e" fill="none" stroke-width="3"/>`+(v<.3?`<rect x="${X+40}" y="${Y+14}" width="5" height="16" rx="2" fill="#4f9d58"/>`:'');
 return t==='sand'?`<circle cx="${X+20+v*20}" cy="${Y+40}" r="2" fill="#e0c47a"/>`:''}
const NATIONAL_ART_RATIO={"farm-3":0.86279,"factory-1":0.66512,"home-2":0.71395,"factory-2":0.73953,"home-1":0.57907,"home-3":0.93953,"factory-3":0.86279,"farm-1":0.80698,"farm-2":0.84884};
// Country settlement art: one clickable/upgradeable tile, with artwork by saved level.
function bld(b,x,y,col){
 const X=x*CELL+32,Y=y*CELL+32,l=Math.max(1,Math.min(3,Number(b.l)||1));
 const kind=b.t==='h'?'home':b.t==='f'?'farm':'factory',key=`${kind}-${l}`;
 const artWidth=59,artHeight=artWidth*(NATIONAL_ART_RATIO[key]||.78),groundY=Y+17;
 const needs=Object.keys(TY[b.t].need);
 const dots=needs.map((p,k)=>`<circle cx="${X-12+k*12}" cy="${Y+24}" r="2.6" fill="${b.c[p]?((S.fr[p]??1)>=.9?'#55d6ad':(S.fr[p]??1)>=.5?'#f4d178':'#ed8580'):'#d1d9d3'}" stroke="#153c38" stroke-width=".75" pointer-events="none"/>`).join('');
 return `<g class="national-building-art national-${kind}" pointer-events="none"><ellipse cx="${X}" cy="${groundY-2}" rx="24" ry="8" fill="#173c35" opacity=".20"/><image href="./assets/national-buildings/${kind}-${l}.webp" x="${X-artWidth/2}" y="${groundY-artHeight}" width="${artWidth}" height="${artHeight}" preserveAspectRatio="none"/>${dots}<circle class="national-level-badge" cx="${X+22}" cy="${Y-25}" r="7"/><text x="${X+22}" y="${Y-22}" class="national-building-level" text-anchor="middle">${l}</text></g>`;
}
function roads(){const bs=[];S.grid.forEach((b,i)=>{if(b)bs.push([i%GW,Math.floor(i/GW)])});const seen=new Set(),out=[];
 bs.forEach(([x,y],k)=>{if(!k)return;let best=null,bd=1e9;for(let j=0;j<k;j++){const d=Math.abs(bs[j][0]-x)+Math.abs(bs[j][1]-y);if(d<bd){bd=d;best=bs[j]}}
  let cx=x,cy=y;const pts=[[cx,cy]];while(cx!==best[0]){cx+=Math.sign(best[0]-cx);pts.push([cx,cy])}while(cy!==best[1]){cy+=Math.sign(best[1]-cy);pts.push([cx,cy])}
  const key=pts.map(q=>q.join(',')).join('>');if(!seen.has(key)){seen.add(key);out.push(pts)}});return out}
function mapSig(){const si=Math.floor(((S.day-1)%360)/90);return S.grid.map(b=>b?b.t+b.l+Object.keys(b.c).join(''):'-').join('')+'|'+S.sel+'|'+si+'|'+['power','gas','water','fuel'].map(p=>Math.round((S.fr[p]??1)*4)).join('')+'|'+((S.inc.ex||0)>0?1:0)+'|'+S.seed+'|'+(S.citySelected??'')+'|'+(S.offshoreSelected||'')+'|'+['oil','gas'].map(k=>{const o=S.offshore?.[k]||{};return [o.stage,o.pipelineLevel,o.pipelineIsolated?1:0,o.incident?.kind||'',o.online?1:0].join(':')}).join('|')}
function nightUpdate(){const n=document.getElementById('night'),sv=document.getElementById('cmap'),I=nightI();if(n)n.setAttribute('opacity',I.toFixed(2));if(sv)sv.classList.toggle('night',I>.2)}
function camApply(){const g=document.getElementById('cam');if(g)g.setAttribute('transform',`translate(${S.cam.x} ${S.cam.y}) scale(${S.cam.k})`)}
function mapPatch(v){if(S.countryHub||S.cityView!=null||S.offshoreView||document.querySelector('.city-world-section,.offshore-world-section'))return false;const mb=document.getElementById('mapbox');if(!mb||mb.dataset.sig!==mapSig())return false;const t=document.createElement('div');t.innerHTML=v;
 let dockChanged=false;['cadv','country-economy','chud','cside','map-build-dock','regional-overview'].forEach(id=>{const a=t.querySelector('#'+id),b=document.getElementById(id);if(a&&b){if(a.innerHTML!==b.innerHTML){b.innerHTML=a.innerHTML;if(id==='map-build-dock')dockChanged=true}if(id==='map-build-dock')b.hidden=a.hidden}});camApply();nightUpdate();if(dockChanged&&window.matchMedia('(max-width: 700px)').matches&&(S.sel!=null||S.citySelected!=null)){requestAnimationFrame(()=>document.getElementById('map-build-dock')?.scrollIntoView({behavior:'smooth',block:'nearest'}))}return true}
function countryEconomyCard(){
 const security=['power','gas','water','fuel'].map(p=>S.dem?.[p]>0?Math.max(0,Math.min(1,S.fr?.[p]??1)):1);
 const nationalCapacity=Object.values(S.nationalProjects||{}).reduce((a,b)=>a+(Number(b)||0),0);
 const energySecurity=cl(security.reduce((a,b)=>a+b,0)/security.length*100+(S.nationalProjects?.power||0)*1.5+(S.nationalProjects?.pipeline||0),0,100);
 const gdp=(S.inc?.dom||0)+(S.inc?.tax||0)+(S.inc?.eco||0)+(S.inc?.ex||0)+(S.inc?.ct||0);
 const levels=['power','gas','water','fuel'];
 const names={power:'برق',gas:'گاز',water:'آب',fuel:'سوخت'};
 const costs=[1800,2800,4200,6000];
 const rows=levels.map(p=>{const lv=Math.max(0,Math.min(4,S.network?.[p]||0)),loss=Math.max(2,10-lv*2);return `<div class="country-network-row"><div><b>${names[p]}</b><small class="muted">تلفات انتقال ${fa(loss)}٪ · سطح ${fa(lv)}/۴</small></div><div class="row"><button data-a="network" data-p="${p}" ${lv>=4||S.govBudget<costs[lv]?'disabled':''}>ارتقا (${fa(costs[lv])} از بودجه ملی)</button><span class="tag ${lv>=4?'run':''}">${lv>=4?'تکمیل':`مرحله ${fa(lv+1)}`}</span></div></div>`}).join('');
 const rate=Number(S.govRate)||1;
 return `<section id="country-economy" class="wide country-economy"><div class="country-heading"><div><span class="hmi-kicker">NATIONAL ECONOMY / PUBLIC FINANCE</span><h2>داشبورد اقتصاد و مدیریت ملی</h2><p class="muted">شاخص‌های کلان، بودجه عمومی و سرمایه‌گذاری در شبکه‌های انرژی و خدمات</p></div><span class="tag">نسخه آزمایشی اقتصاد ملی</span></div><div class="country-kpis"><div><small>جمعیت</small><b>${fa(S.pop||0)}</b></div><div><small>توسعه افزوده‌شده شهرهای مستقل</small><b>${fa(S.urbanToday?.developed||0)} سطح</b></div><div><small>مالیات شهری افزوده (تخمینی)</small><b>${fa(S.urbanToday?.tax||0)}</b></div><div><small>رضایت عمومی</small><b class="${S.sat<50?'bd':S.sat<75?'wn':'ok'}">${fa(S.sat||0)}٪</b></div><div><small>امنیت تأمین انرژی و خدمات</small><b class="${energySecurity<70?'bd':energySecurity<90?'wn':'ok'}">${f1(energySecurity)}٪</b></div><div><small>فعالیت اقتصادی روزانه (GDP Proxy)</small><b>${fa(gdp)}</b></div><div><small>بودجه عمومی</small><b>${fa(S.govBudget||0)}</b></div><div><small>درآمد عمومی امروز</small><b class="ok">+${fa(S.govIncomeToday||0)}</b></div><div><small>شاخص ظرفیت توسعه ملی</small><b>${fa(nationalCapacity)} / ۱۲</b></div></div><div class="country-columns"><div class="card"><h3>سیاست مالی و درآمد عمومی</h3><p class="muted">بودجه عمومی از بخشی از مالیات شهروندان و عوارض صادرات/قرارداد تأمین می‌شود. این مبلغ از درآمد نقدی شرکت کسر و به بودجه عمومی منتقل می‌شود؛ بنابراین پول جدید خلق نمی‌شود.</p><div class="row"><b>ضریب اخذ مالیات و عوارض: ×${f1(rate)}</b><button data-a="gov-rate" data-d="-0.1" ${rate<=.5?'disabled':''}>کاهش</button><button data-a="gov-rate" data-d="0.1" ${rate>=1.5?'disabled':''}>افزایش</button></div><div class="muted">بازه سیاست مالی: ۰٫۵ تا ۱٫۵ برابر پایه. افزایش آن درآمد عمومی را بالا می‌برد اما نقدینگی در دسترس شرکت را کاهش می‌دهد.</div></div><div class="card"><h3>توسعه شبکه‌های ملی</h3><p class="muted">هر ارتقا تلفات انتقال را از ۱۰٪ پایه، به‌ازای هر سطح ۲ واحد درصد کاهش می‌دهد. این سرمایه‌گذاری از بودجه عمومی پرداخت می‌شود و تحویل مؤثر خدمات را بهبود می‌دهد.</p>${rows}</div></div><div class="card wide national-projects"><h3>پروژه‌های توسعه ملی</h3><p class="muted">سرمایه‌گذاری بلندمدت از بودجه عمومی؛ هر سطح ظرفیت زیرساختی و تاب‌آوری کشور را افزایش می‌دهد. این پروژه‌ها مستقل از واحدهای عملیاتی شرکت هستند.</p><div class="trade-grid">${[['refinery','پالایشگاه ملی','توسعه ظرفیت پالایش و امنیت سوخت',12000],['power','نیروگاه ملی','افزایش ظرفیت پشتیبان تولید برق',16000],['petrochem','مجتمع پتروشیمی','افزایش ظرفیت صنایع پایین‌دستی',18000],['pipeline','خطوط انتقال سراسری','بهبود انتقال بین مناطق و کاهش گلوگاه',9000]].map(([k,n,ds,c])=>{const lv=S.nationalProjects?.[k]||0,cost=c*(lv+1);return `<div class="card"><b>${n}</b><div class="muted">${ds}</div><div class="eq"><span>سطح توسعه</span><b>${fa(lv)}/۳</b></div><div class="bar"><i style="width:${lv/3*100}%"></i></div><button data-a="national-build" data-p="${k}" ${lv>=3||S.govBudget<cost?'disabled':''}>${lv>=3?'تکمیل شده':`اجرای مرحله بعد (${fa(cost)} از بودجه ملی)`}</button></div>`}).join('')}</div></div><div class="card wide dynamic-economy"><h3>اقتصاد پویا و وضعیت اجتماعی</h3><p class="muted">شاخص‌ها هر ۳۰ روز شبیه‌سازی بازبینی می‌شوند. کمبود خدمات، بیکاری و شوک‌های اقتصادی بر تورم، ثبات و رضایت عمومی اثر می‌گذارند.</p><div class="country-kpis"><div><small>شاخص قیمت / تورم تجمعی</small><b class="${(S.economy?.inflation||100)>140?'bd':(S.economy?.inflation||100)>120?'wn':'ok'}">${f1(S.economy?.inflation||100)}</b></div><div><small>بیکاری تخمینی</small><b class="${(S.economy?.unemployment||8)>20?'bd':'ok'}">${f1(S.economy?.unemployment||8)}٪</b></div><div><small>اشتغال تخمینی</small><b>${f1(S.economy?.employment||0)}٪</b></div><div><small>ثبات اقتصادی</small><b>${f1(S.economy?.stability||75)}٪</b></div><div><small>شوک فعال</small><b>${S.economy?.shock?`${S.economy.shock.name} · ${fa(S.economy.shock.days)} روز`:'ندارد'}</b></div></div><div class="row"><span class="muted">بسته حمایتی عمومی: هزینه ۲٬۵۰۰ از بودجه ملی؛ اثر کوتاه‌مدت بر رضایت و ثبات</span><button data-a="economic-relief" ${(S.govBudget||0)<2500?'disabled':''}>اجرای بسته حمایتی</button></div></div><div class="muted country-foot">GDP Proxy شاخص ساده‌شده‌ای از ارزش فروش داخلی، مالیات، فعالیت کشاورزی/صنعتی، صادرات و قراردادهاست؛ تولید ناخالص داخلی رسمی محسوب نمی‌شود.</div></section>`;
}
function viewIndustrialSite(){return renderIndustrySite(S,D,fa,mapSheetOpen)}
const CITY_PLOT_STORAGE='process-tycoon-city-plot-layout-v1';
const CITY_PLOT_DEFAULTS=[[410.4,59.6],[537.3,82.6],[334.8,97.9],[601.2,136.9],[279.0,137.6],[533.7,160.6],[657.9,175.1],[363.6,175.9],[212.4,179.7],[285.3,198.8],[596.7,209.5],[735.3,210.3],[163.8,260.7],[587.7,260.7],[729.0,260.7],[268.2,261.5],[647.1,296.7],[222.3,297.4],[527.4,306.6],[357.3,312.7],[602.1,337.2],[293.4,338.0],[536.4,380.0],[406.8,421.3]];
const clampCityCoord=(v,max)=>Math.round(Math.min(max,Math.max(0,Number(v)||0))*10)/10;
function loadCityPlotLayout(){try{const raw=JSON.parse(localStorage.getItem(CITY_PLOT_STORAGE)||'null'),pts=Array.isArray(raw)?raw:raw?.points;if(Array.isArray(pts)&&pts.length===24&&pts.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)))return pts.map(p=>[clampCityCoord(p[0],900),clampCityCoord(p[1],510)]);}catch{}return CITY_PLOT_DEFAULTS.map(p=>[...p]);}
const cityPlotLayout=loadCityPlotLayout();
let cityMoveCell=null,cityBuildingDrag=null,cityClickSuppressUntil=0;
function cityBuildingPos(city,cell){
 const stored=S.cityBuildingPositions?.[city]?.[cell];
 return Array.isArray(stored)&&stored.length===2&&stored.every(Number.isFinite)
  ?[clampCityCoord(stored[0],900),clampCityCoord(stored[1],510)]
  :[...cityPlotLayout[cell%24]];
}
function setCityBuildingPos(city,cell,x,y,updateDOM=false){
 if(!city||!Number.isInteger(cell)||cell<0||cell>=81||!S.cityMaps?.[city]?.[cell])return false;
 if(!updateDOM)rememberCityMove(S,city,cell,cityBuildingPos(city,cell));
 S.cityBuildingPositions ||= {};
 S.cityBuildingPositions[city] ||= {};
 const pos=[clampCityCoord(x,900),clampCityCoord(y,510)];
 S.cityBuildingPositions[city][cell]=pos;
 if(updateDOM){const el=document.querySelector(`.city-free-building[data-city-building="${cell}"]`);if(el)el.setAttribute('transform',`translate(${pos.join(' ')})`);}
 return true;
}
function pointFromCityPointer(e,svg){const pt=svg.createSVGPoint();pt.x=e.clientX;pt.y=e.clientY;const m=svg.getScreenCTM();if(!m)return null;const v=pt.matrixTransform(m.inverse());return [clampCityCoord(v.x,900),clampCityCoord(v.y,510)];}
function hubAllowed(hub,type){return ({energy:'k',north:'f',housing:'h'})[hub]===type}
let mapSheetOpen=false;
function viewCountry(){return renderCountry({S,TY,PR,CITIES,fa,cityDevelopmentMetrics,offshoreCard,countryEconomyCard,REGIONS,regionMetrics,sheetOpen:mapSheetOpen,expanded:countryExpanded,notice:countryNotice})}
function syncCountryScene(){mountCountryScene(S,CITIES,pick=>{
 countryNotice='';
 if(['ship','route','team','alarm','crisis-alarm'].includes(pick.kind)){
  chooseActivity(['alarm','crisis-alarm'].includes(pick.kind)?'district':pick.kind,pick.id);
 }else if(pick.kind==='zone'){
  const deploy=S.atlasActivity?.kind==='team';
  chooseActivity('district',pick.id);
  if(deploy)B['country-team']({k:pick.id});
 }else if(pick.kind==='network'){S.mapStep=pick.id;mapSheetOpen=true}
 else if(pick.kind==='unit'){S.siteSelectedUnit=pick.id;S.tab='site'}
 else if(pick.kind==='district'){S.atlasSelected=pick.id;S.offshoreMapSelected=pick.id==='gas'?'gas':'oil';
  if(S.mapLayer==='readiness'&&Object.hasOwn(DRILL_ZONES,pick.id)){
   const deploy=S.atlasActivity?.kind==='team';
   chooseActivity('district',pick.id);
   if(deploy)B['country-team']({k:pick.id});
  }
  if(S.mapLayer==='services'&&S.tab==='c'&&!S.offshoreView){
   const key=networkKey(S);
   if(key==='water')S.mapStep=pick.id==='water-desal'?'source':pick.id==='energy'?'treatment':pick.id==='capital'?'city':S.mapStep;
   if(key==='power')S.mapStep=pick.id==='energy'?'generation':'power-city';
   if(key==='feed'&&['oil','gas','port'].includes(pick.id))S.mapStep=pick.id==='port'?'terminal':pick.id;
  }
 }
 else if(pick.kind==='city-lot')S.cityCell=pick.id;
 else if(pick.kind==='lot')S.sel=pick.id;
 mapSheetOpen=true;draw();save();


})}
// Prevent the 500 ms simulation refresh from replacing the native DCS selector
// while the operator is opening or navigating its option list.
let hmiSelectionCommit=false,renderedScreen=null;
const AP={set h(v){
 if(S.tab==='hmi'&&!hmiSelectionCommit&&document.activeElement?.id==='hmi-unit-select')return;
 clearNavigationHighlight();
 const screen=['c','site'].includes(S.tab)?null:S.tab+':'+(S.tab==='hmi'?S.hmiUnit+':'+S.hmiMode+':'+S.hmiSection+':'+S.hmiLoop:S.tab==='m'?(S.manageSection||'inventory'):'');
 const same=screen&&screen===renderedScreen;renderedScreen=screen;
 if(same&&refreshScreenMarkup($('#app'),(S.tab==='hmi'||(S.tab==='m'&&(!S.manageSection||S.manageSection==='inventory'))?'':playerHelp())+v)){syncCountryScene();return}

 if((S.tab==='i'||(S.tab==='m'&&['overview','maintenance'].includes(S.manageSection)))&&refreshAdvisorMarkup($('#app'),playerHelp()+v)){syncCountryScene();return}
 if((S.tab==='c'||S.tab==='site')&&refreshMapMarkup($('#app'),v)){syncCountryScene();return}
 if(S.tab==='hmi'&&!hmiSelectionCommit&&document.activeElement?.id==='hmi-unit-select')return;
 
 const priorCountryView=document.getElementById('country-three')?.dataset?.view;
 const countryDetails=[...document.querySelectorAll('.atlas details')].map(d=>d.open);
 const inspectorScroll=document.querySelector('.atlas-inspector')?.scrollTop||0;
 const productsScroll=document.querySelector('.product-table-scroll');
 const productLeft=productsScroll?.scrollLeft??0;
 const cityScroll=document.querySelector('.city-world-map-wrap')?.scrollLeft||0;
 const siteScroll=document.querySelector('.site-map-viewport')?.scrollLeft||0;
 const offshoreScroll=document.querySelector('.offshore-seascape')?.scrollLeft||0;
 const mimic=document.querySelector('.mimic-scroll');
 const mimicLeft=mimic?mimic.scrollLeft:0;
 const mimicTop=mimic?mimic.scrollTop:0;
 $('#app').innerHTML=(['c','site','hmi'].includes(S.tab)||(S.tab==='m'&&(!S.manageSection||S.manageSection==='inventory'))?'':playerHelp())+v;
 syncCountryScene();
 document.querySelectorAll('.atlas details').forEach((d,i)=>{if(priorCountryView===document.getElementById('country-three')?.dataset?.view&&countryDetails[i]!=null)d.open=countryDetails[i]});
 const inspector=document.querySelector('.atlas-inspector');if(inspector)inspector.scrollTop=inspectorScroll;
 if(S.tab==='c'&&S.cityView!=null&&cityScroll){const next=document.querySelector('.city-world-map-wrap');if(next)next.scrollLeft=cityScroll}
 if(S.tab==='site'&&siteScroll){const next=document.querySelector('.site-map-viewport');if(next)next.scrollLeft=siteScroll}
 if(S.tab==='c'&&S.offshoreView&&offshoreScroll){const next=document.querySelector('.offshore-seascape');if(next)next.scrollLeft=offshoreScroll}
 if(S.tab==='m'&&productLeft){const next=document.querySelector('.product-table-scroll');if(next)next.scrollLeft=productLeft}
 if(S.tab==='hmi'&&(mimicLeft||mimicTop)){
  const next=document.querySelector('.mimic-scroll');
  if(next){next.scrollLeft=mimicLeft;next.scrollTop=mimicTop}
 }
 if(S.tab==='c'&&!S.offshoreView&&S.cityView==null){camApply();nightUpdate()}
}};
function estimateUI(t){const e=projectEstimate(S,D[t],PR,IMP,feedCost(t));return `<details><summary>برآورد هزینه تا اولین راه‌اندازی: ${fa(e.total)}</summary><p>زمین و مجوز: ${fa(e.land)} · نصب: ${fa(e.install)} · خرید کسری مصالح: ${fa(e.materials)} · خوراک اولیه: ${fa(e.feed)}</p><p>سرمایه باقی‌مانده: ${fa(S.money-e.total)} · خرید خوراک روزانه با قیمت فعلی: ${fa(e.feed)} · کنترلرهای اختیاری: ${fa(e.controllers)}</p><small>برآورد با موجودی و قیمت فعلی؛ رفع ایراد نصب، اپراتور، حقوق، تعمیرات و سایر هزینه‌های بهره‌برداری جدا هستند.</small></details>`}
function starterPlan(){if(S.day>60||S.u.length>3)return '';const e=projectEstimate(S,D[0],PR,IMP,feedCost(0)),reserve=Math.ceil(feedCost(0)*10+500);return `<details class="card wide" open><summary>مسیر پیشنهادی شروع کم‌ریسک</summary><ol><li>صنعت: ابتدا یک پالایشگاه نفت بساز؛ هزینه تکمیل فعلی ${fa(e.total)} است. حداقل ${fa(reserve)} برای ده روز خوراک و حاشیه نقد نگه دار. ${S.money<e.total+reserve?'اکنون نقد کافی برای ساخت همراه این ذخیره نداری؛ ابتدا درآمد پایدار جمع کن.':''}</li><li>مدیریت محصولات ← انبار و فروش: نفت خام را نگه‌داری کن تا خوراک فروخته نشود؛ مخزن سوخت و فروش روزانه را بررسی کن. قرارداد صادراتی و خرید کنترلرهای متعدد را فعلاً عقب بینداز.</li><li>کشور ← قطب کشاورزی شمالی: بعد از تأمین آب و سوخت، یک مزرعه بساز و شبکه‌هایش را وصل کن؛ محصول کشاورزی درآمد ایجاد می‌کند. تا آن زمان خانه تازه نساز، چون تقاضای خدمات را بیشتر می‌کند.</li><li>پس از پایدار شدن جریان نقد و تأمین خوراک، تصفیه آب را برای آب شهر و کشاورزی اضافه کن؛ کارخانه در مرکز انرژی را پس از تأمین برق و گاز بساز.</li></ol><small>این مسیر پیشنهاد است؛ قیمت بازار، خرابی و ظرفیت واردات روی نتیجه اثر دارند. سود تضمین‌شده نیست.</small></details>`}
function playerHelp(){
 const a=nextAction(S,D,advice().items),t=S.tutorial;
 if(t&&!t.done&&Object.values(S.marketDay||{}).some(m=>m.sold>0))t.done=true;
 return `${starterPlan()}<section class="card wide player-help" aria-label="راهنمای اقدام بعدی"><h2>اقدام پیشنهادی</h2><p>${a.text}</p>${a.fix?`<p><b>راه رسیدگی:</b> ${a.fix}</p>`:''}${a.target?quickButton({...a,title:a.label}):`<button data-a="help-go" data-t="${a.tab}" data-i="${a.index??''}">${a.label}</button>`}${t&&!t.dismissed?`<details open><summary>مسیر اولین تولید و فروش ${t.done?'✓ تکمیل شد':''}</summary><ol><li>از پروژه‌های جدید، یک واحد متناسب با سرمایه انتخاب کن.</li><li>تجهیزات را نصب و مشکلات نصب را برطرف کن.</li><li>خوراک اولیه را بپرداز و مراحل راه‌اندازی را به ترتیب انجام بده.</li><li>زمان را ادامه بده؛ در مدیریت محصولات، تأمین خوراک و فروش را بررسی کن.</li></ol><p>خوراک کسری با هزینه و محدودیت ظرفیت واردات تأمین می‌شود. فروش به نوع محصول، نیاز کشور، موجودی و ظرفیت بندر وابسته است.</p><button data-a="help-dismiss">بستن آموزش</button></details>`:''}</section>`;
}
function draw(){discoverAchievements(S);const devButton=document.getElementById('dev-open');if(devButton){devButton.textContent=S.development?.event?'هشدار کشور · توسعه':'توسعه کشور';devButton.classList.toggle('dev-warning',!!S.development?.event)}const legacyButton=document.getElementById('legacy-open');if(legacyButton)legacyButton.textContent='شهر من'+(Object.values(legacyState(S).awards).filter(a=>!a.claimed).length?' · پاداش آماده':'');const k0=document.querySelector('.sk2'),sl0=k0?k0.scrollLeft:0;setTimeout(()=>{const k=document.querySelector('.sk2');if(k&&Math.abs(k.scrollLeft-sl0)>1)k.scrollLeft=sl0},0);
 document.querySelectorAll('#tabs button').forEach(b=>b.setAttribute('aria-pressed',b.dataset.t===S.tab));
 $('#money').textContent=fa(S.money);$('#money').className=S.money<0?'bd':'';const dock=$('#money-dock');if(dock){dock.textContent=fa(S.money);dock.className=S.money<0?'bd':''}syncAlerts();$('#day').textContent=fa(S.day);
 $('#mkt').textContent='×'+f1(S.mkt*(S.fx.sanc?.7:1)*(S.fx.spike?1.4:1));
 $('#season').textContent=SEAS[Math.floor(((S.day-1)%360)/90)];$('#esg').textContent=fa(S.esg)+'٪';$('#esg').className=S.esg<40?'bd':S.esg<70?'wn':'ok';$('#safe').textContent=fa(S.safe)+'٪';$('#safe').className=S.safe<50?'bd':S.safe<80?'wn':'ok';
 $('#diff').textContent='سختی: '+['آسان','عادی','سخت'][S.diff==null?1:S.diff];gameAudio.sync();$('#snd').textContent='صدا: '+(S.mute?'خاموش':'روشن');$('#pause').textContent=S.paused?'ادامه':'توقف';$('#spd').textContent='سرعت ×'+fa(S.spd);
 const fxs=[['sanc','تحریم'],['spike','جهش قیمت'],['exp','قرارداد صادراتی'],['strike','اعتصاب'],['rival','قیمت‌شکنی رقیب']].filter(x=>S.fx[x[0]]).map(x=>`<span class="tag">${x[1]}: ${fa(S.fx[x[0]])} روز</span>`).join(' ');
 const projectType=Object.hasOwn(D,Number(S.projectType))?Number(S.projectType):0;const shop=D.map((d,t)=>t!==projectType?'':`<div class="card catalog-illustrated"><div class="catalog-art-frame"><svg class="catalog-art" viewBox="-95 -145 190 210" role="img" aria-label="${d.n}">${renderProcessFacility(t)}</svg></div><div><b>${d.n}</b><div class="muted" style="font-size:12px">هدف: ${GOAL[t]} · درآمد ایده‌آل: ${fa(d.rev)} در روز · ${fa(d.e.length)} تجهیز · ${fa(OPN[t])} اپراتور<br>خوراک و نیاز: ${feedTxt(t)||'ندارد'} · محصول: ${prodTxt(t)} · زیرساخت سطح ${fa(INF[t])}</div>${INF[t]>(S.infra||0)?'<div class="wn" style="font-size:12px">نیاز به زیرساخت سطح '+fa(INF[t])+'</div>':''}${d.tech&&!(S.tech||{})[d.tech]?'<div class="wn" style="font-size:12px">نیاز به تحقیق: '+TECHN[d.tech]+'</div>':''}${d.nuc?'<div class="wn" style="font-size:12px">نیاز به مجوز: آموزش اپراتور ≥ ۲ و ایمنی ≥ ۸۰٪؛ سوخت هسته‌ای فقط وارداتی و گران است</div>':''}${estimateUI(t)}</div><label class="project-name">نام دلخواه واحد<input id="project-name-${t}" maxlength="32" placeholder="مثلاً ${d.n} امید" autocomplete="off"></label><button class="p" data-a="buy" data-t="${t}" ${(d.nuc&&(S.tr<2||S.safe<80))||(d.tech&&!(S.tech||{})[d.tech])||(INF[t]>(S.infra||0))?'disabled':''}>شروع پروژه (${fa(d.cost*.3)})</button></div>`).join('');
 const off=S.offers.map((o,k)=>`<div class="note">${o.txt}<div class="row"><button class="p" data-a="offer" data-o="${k}" data-y="1">${o.t==='exp'?'قبول':'مذاکره'}</button><button data-a="offer" data-o="${k}" data-y="0">${o.t==='exp'?'رد':'نادیده گرفتن'}</button></div></div>`).join('');
 const ops=`<div id="personnel-management" class="card"><h2>مدیریت و منابع انسانی</h2><div class="row">اپراتورها: <b>${fa(S.ops)}</b> (مورد نیاز: <b>${fa(opsNeed())}</b>${S.walk?' · در دسترس: <b class="bd">'+fa(opsAvail())+'</b>':''}) · آموزش: <b>${fa(S.tr)}/۳</b> · روحیه: <b class="${S.mor<35?'bd':S.mor<60?'wn':'ok'}">${fa(S.mor)}٪</b></div><div class="muted" style="font-size:12px">هر واحد تعداد مشخصی اپراتور می‌خواهد (در کارت واحد نوشته شده)؛ کمبود، تولید را کم و نوسان را بیشتر می‌کند. روحیه‌ی پایین می‌تواند به ترک کار موقت اپراتورها برسد. حقوق: ${fa(S.sal||12)} در روز برای هر نفر. مهندسان متخصص: ${fa(S.eng||0)}/۳ (هر مهندس ۱۲٪ خرابی کمتر).</div><div class="row"><button data-a="hire">استخدام اپراتور (۱٬۲۰۰)</button><button data-a="bonus">پاداش و رفاه (۱٬۰۰۰)</button><button data-a="eng" ${(S.eng||0)>=3?'disabled':''}>مهندس متخصص (۳٬۰۰۰ · ۴۰ در روز)</button><button data-a="train" ${S.tr>=3?'disabled':''}>آموزش اپراتورها (${fa(1500*(S.tr+1))})</button><button data-a="hse">دوره‌ی ایمنی (۲٬۰۰۰)</button></div>${fxs?`<div class="row">${fxs}</div>`:''}${off}<h3 style="font-size:13px;margin:8px 0 2px">روند سرمایه</h3><div class="big">${moneyChart()}</div></div>`;
 const industrySection=['operations','projects','catalog'].includes(S.industrySection)?S.industrySection:!S.u.length?'catalog':S.u.some(u=>['build','ready'].includes(u.st))?'projects':'operations';
 AP.h=S.tab==='m'?viewManage():S.tab==='c'?viewCountry():S.tab==='site'?viewIndustrialSite():S.tab==='hmi'?viewHMI():crisisCard()+renderProjectNavigation(S,fa)+(industrySection==='catalog'?`<section class="shop-section wide"><div class="project-section-head"><div><h2>پروژه‌های جدید</h2><label>انتخاب نوع پروژه<select id="project-type">${D.map((d,t)=>`<option value="${t}" ${projectType===t?'selected':''}>${d.n}</option>`).join('')}</select></label><p class="muted">انتخاب واحد صنعتی و آغاز سرمایه‌گذاری</p></div><span class="project-count">${fa(D.length)} طرح</span></div><div class="shop-grid">${shop}</div></section>`:renderProjectSections({indexes:visUnits(),units:S.u,renderUnit:unit,formatNumber:fa,sectionFilter:industrySection}))+(industrySection==='operations'?`<details class="card wide"><summary>نیرو، فیلتر واحدها و بانک</summary>${ops}${bank()}${advCard()}</details>`:'')+`<div class="card wide"><h2>گزارش رویدادها</h2><div id="log">${S.log.map(l=>`<div>${l}</div>`).join('')}</div></div>`}
document.addEventListener('keydown',e=>{
 if(e.key!=='Escape'||!countryExpanded||S.tab!=='c')return;
 countryExpanded=false;mapSheetOpen=false;draw();
 document.querySelector('[data-a="country-expand"]')?.focus({preventScroll:true});
});
let hold=0;const touchSafety=installTouchSafety(document,{onActivity:()=>{hold=Date.now()}});
document.addEventListener('click',e=>{if(e.target.closest('[data-go],[data-top]'))return;const g=e.target.closest('[data-go]');if(g){const i=+g.dataset.go;S.flash={i,t:Date.now()};draw();const el=document.getElementById('u'+i);if(el)el.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth',block:'center'});return}const tp=e.target.closest('[data-top]');if(tp){const el=document.getElementById('sky');if(el)el.scrollIntoView({behavior:'smooth',block:'start'});return}if(e.target.closest('[data-c]'))return;const b=e.target.closest('button');if(!b||b.disabled||!b.dataset.a)return;const x=b.dataset,i=+x.i,a=x.a;if(a.startsWith('legacy-')){handleLegacyAction(a,x);return}if(a.startsWith('water-')){if(a==='water-open'){S.tab='c';S.countryHub=null;S.cityView=null;S.offshoreView=false;S.atlasSelected='water-'+x.k;mapSheetOpen=true;}else if(a==='water-budget'){const w=waterNetwork(S);w.reserve=Math.max(0,Number(document.getElementById('water-cash-reserve')?.value)||0);S.waterSupply=w;}else if(!waterAction(S,x.k,a.slice(6)))log('اقدام منبع آب انجام نشد؛ نقد، ساخت و اتصال را بررسی کن.');draw();save();return}if(a.startsWith('market-')){handleMarketAction(a,x);return}if(a.startsWith('maintenance-')){handleMaintenanceAction(a,x);return}if(a==='diagnostic-go'){navigateDiagnostic(x);return}if(a==='campus-show'){mapSheetOpen=true;draw();return}if(a==='campus-select'){if(S.u[i]){S.siteSelectedUnit=i;mapSheetOpen=true}draw();save();return}if(a==='campus-locate'){S.siteMapPage=Math.floor(i/12);draw();save();return}if(a==='campus-manage'){S.tab='i';S.industrySection=['build','ready'].includes(S.u[i]?.st)?'projects':'operations';S.expandedUnit=i;draw();save();document.getElementById('u'+i)?.scrollIntoView({block:'center'});return}if(a==='atlas-display'){if(['overview','services','sea','readiness'].includes(x.k)){S.mapLayer=x.k;S.atlasActivity=null;countryNotice='';mapSheetOpen=['sea','readiness'].includes(x.k)}if(x.k==='time')S.mapTime=S.mapTime==='night'?'day':'night';if(x.k==='labels')S.mapLabels=S.mapLabels===false;draw();save();return}if(a==='atlas-camera'){countryCamera(x.k);return}if(a==='atlas-offshore'){mapSheetOpen=false;S.countryHub=null;S.cityView=null;S.offshoreView=true;draw();save();return}if(a==='atlas-select'){mapSheetOpen=true;S.atlasSelected=x.k;S.offshoreMapSelected=x.k==='gas'?'gas':'oil';draw();save();return}if(a==='atlas-home'){mapSheetOpen=false;S.countryHub=null;S.cityView=null;S.offshoreView=false;S.sel=null;S.cityCell=null;draw();save();return}if(a==='unit-rename'){if(S.u[i])S.u[i].name=cleanUnitName(document.getElementById('unit-name-'+i)?.value)||unitName(S.u[i],D,i);draw();save();return}if(a==='industry-section'){clearNavigationHighlight();S.industrySection=x.k;draw();save();return}if(a==='unit-expand'){S.expandedUnit=i;draw();return}if(a==='unit-collapse'){S.expandedUnit=null;draw();return}if(a==='hub-page'){S.hubPage=Number(x.page);S.sel=null;draw();save();return}if(a==='port-trade'){S.tab='m';S.manageSection='trade';draw();save();return}if(a==='hub-cell'){S.sel=+x.i;mapSheetOpen=true;countryNotice='';draw();save();return}if(a==='hub-open'){S.countryHub=x.k;mapSheetOpen=false;countryNotice='';S.hubPage=0;S.sel=null;S.cityView=null;S.offshoreView=false;draw();save();return}if(a==='hub-close'){S.countryHub=null;S.sel=null;draw();save();return}if(a==='hmi-section'){S.hmiSection=['overview','controls','equipment','alarms'].includes(x.k)?x.k:'overview';S.hmiMode=S.hmiSection==='overview'?'summary':'advanced';draw();save();return}if(a==='hmi-loop'){S.hmiLoop=Math.max(0,Number(x.k)||0);S.hmiSection='controls';S.hmiMode='advanced';draw();save();return}if(a==='hmi-mode'){S.hmiMode=x.v==='advanced'?'advanced':'summary';S.hmiSection=S.hmiMode==='advanced'?'controls':'overview';draw();save();return}if(a==='manage-section'){S.manageSection=x.k;draw();save();return}if(a==='help-dismiss'){S.tutorial.dismissed=true;draw();save();return}if(a==='help-go'&&x.i!==undefined&&x.i!==''&&S.u[Number(x.i)]){navigateDiagnostic({target:'unit',i:x.i});return}if(a==='help-go'){S.tab=x.t;if(x.t==='i')S.industrySection=S.u.some(u=>['build','ready'].includes(u.st))?'projects':S.u.length?'operations':'catalog';if(x.t==='m')S.manageSection='inventory';S.flt='all';draw();if(x.i!==undefined&&x.i!=='')document.getElementById('u'+x.i)?.scrollIntoView({block:'center'});else document.querySelector('.shop-section')?.scrollIntoView({block:'start'});save();return}if(B[a]){B[a](x);draw();save();return}
 if(a==='pid-toggle'){const key=`${i}:${+x.k}`,cfg=S.pid[key]||(S.pid[key]={sp:D[S.u[i].t].v[+x.k][2],kp:0.25,ki:0.06,kd:0.02,integral:0,previousError:0,output:0,mv:50,mode:'manual'});if(S.u[i].st!=='run'||!S.u[i].au?.[+x.k]){log('برای فعال‌سازی AUTO ابتدا باید کنترلر PID این متغیر را خریداری و نصب کنید.');return}cfg.mode=cfg.mode==='auto'?'manual':'auto';if(cfg.mode==='manual'){cfg.integral=0;cfg.previousError=0}else{cfg.rampedSp=S.u[i].v[+x.k];cfg.sp=Number.isFinite(cfg.sp)?cfg.sp:D[S.u[i].t].v[+x.k][2];cfg.integral=0;cfg.previousError=0}log(`کنترلر PID متغیر ${D[S.u[i].t].v[+x.k][0]} به حالت ${cfg.mode==='auto'?'خودکار':'دستی'} رفت.`)}else if(a==='disturb'){const key=`${i}:${+x.k}`,cfg=S.pid[key]||(S.pid[key]={mode:'manual',mv:50});const amount=applyProcessDisturbance(cfg,D[S.u[i].t].v[+x.k][3]);log(`اختلال آزمایشی به متغیر ${D[S.u[i].t].v[+x.k][0]} اعمال شد؛ پاسخ فرایند قابل مشاهده است.`)}else if(a==='buy'){const before=S.u.length;A.buy(+x.t,document.getElementById('project-name-'+x.t)?.value);if(S.u.length>before){S.industrySection='projects';S.expandedUnit=S.u.length-1;}}else if(a==='fix')A.fix(i,x.n==='1');else if(a==='adj'){const key=`${i}:${+x.k}`,cfg=S.pid[key]||(S.pid[key]={mode:'manual',mv:50,integral:0,previousError:0,output:0});if(cfg.mode!=='auto'){cfg.mv=cl((Number(cfg.mv)||50)+(+x.s)*5,0,100);log(`خروجی دستی محرک ${D[S.u[i].t].v[+x.k][0]} به ${f1(cfg.mv)}٪ تغییر کرد.`)}}else if(a==='up')A.up(i,+x.j);
 else if(a==='part')A.part(i,+x.j,x.f==='1',x.role);else if(a==='repair')A.repair(i,+x.j,x.role);else if(a==='auto')A.auto(i,+x.k);else if(a==='offer')A.offer(+x.o,x.y==='1');else A[a](i);draw();save()});
// A selected building can be arranged in-place as part of normal city gameplay.
// The map's buildable lot IDs stay fixed; only that one building sprite moves.
document.addEventListener('pointerdown',e=>{
 if(S.cityView==null||cityMoveCell==null||!e.isPrimary)return;
 const building=e.target.closest?.('[data-city-building]');
 if(!building||Number(building.dataset.cityBuilding)!==cityMoveCell)return;
 const svg=building.closest('svg.city-world-map'),city=CITIES[Number(S.cityView)];
 if(!svg||!city)return;
 const start=pointFromCityPointer(e,svg),pos=cityBuildingPos(city.name,cityMoveCell);
 if(!start)return;
 cityBuildingDrag={pointerId:e.pointerId,svg,building,city:city.name,cell:cityMoveCell,start,origin:pos,moved:false};
 building.setPointerCapture?.(e.pointerId);
 e.preventDefault();e.stopPropagation();
},true);
document.addEventListener('pointermove',e=>{
 const d=cityBuildingDrag;if(!d||e.pointerId!==d.pointerId)return;
 const p=pointFromCityPointer(e,d.svg);if(!p)return;
 const dx=p[0]-d.start[0],dy=p[1]-d.start[1];
 if(Math.hypot(dx,dy)>1)d.moved=true;
 if(d.moved)setCityBuildingPos(d.city,d.cell,d.origin[0]+dx,d.origin[1]+dy,true);
 e.preventDefault();
},true);
function finishCityBuildingDrag(e){
 const d=cityBuildingDrag;if(!d||e.pointerId!==d.pointerId)return;
 if(d.building.hasPointerCapture?.(e.pointerId))d.building.releasePointerCapture(e.pointerId);
 cityBuildingDrag=null;
 if(d.moved){rememberCityMove(S,d.city,d.cell,d.origin);draw();cityClickSuppressUntil=Date.now()+350;save();e.preventDefault();e.stopPropagation()}
}
document.addEventListener('pointerup',finishCityBuildingDrag,true);
document.addEventListener('pointercancel',finishCityBuildingDrag,true);
document.addEventListener('click',e=>{
 if(cityClickSuppressUntil>Date.now()&&e.target.closest?.('.city-world-map')){e.stopImmediatePropagation();e.preventDefault();return;}
 if(S.cityView==null||cityMoveCell==null||cityBuildingDrag)return;
 const svg=e.target.closest?.('svg.city-world-map');if(!svg)return;
 if(e.target.closest?.('[data-city-building]')){e.preventDefault();e.stopImmediatePropagation();return;}
 const city=CITIES[Number(S.cityView)];if(!city||!S.cityMaps?.[city.name]?.[cityMoveCell])return;
 // Tap anywhere on the image to place that building; works on mobile without dragging.
 const pos=pointFromCityPointer(e,svg);if(!pos)return;
 setCityBuildingPos(city.name,cityMoveCell,pos[0],pos[1]);draw();save();
 e.stopImmediatePropagation();e.preventDefault();
},true);
const mp=new Map();let mg=null,mapMoved=0;
const unitK=()=>{const sv=document.getElementById('cmap');return sv?GW*CELL/sv.getBoundingClientRect().width:1};
function clampCam(){const c=S.cam;c.k=cl(c.k,1,3.5);c.x=cl(c.x,GW*CELL*(1-c.k),0);c.y=cl(c.y,GH*CELL*(1-c.k),0)}
function zoomAt(f,px,py){const c=S.cam,k=cl(c.k*f,1,3.5),r=k/c.k;c.x=px-(px-c.x)*r;c.y=py-(py-c.y)*r;c.k=k;clampCam();camApply()}
const toV=(e)=>{const sv=document.getElementById('cmap'),r=sv.getBoundingClientRect(),u=GW*CELL/r.width;return[(e.clientX-r.left)*u,(e.clientY-r.top)*u]};
document.addEventListener('pointerdown',e=>{if(!e.target.closest||!e.target.closest('#mapbox')||e.target.closest('button'))return;mp.set(e.pointerId,[e.clientX,e.clientY]);mg={x:e.clientX,y:e.clientY,cx:S.cam.x,cy:S.cam.y}},true);
document.addEventListener('pointermove',e=>{if(!mp.has(e.pointerId))return;const o=mp.get(e.pointerId);
 if(mp.size===2){const n=[...mp.entries()],other=n.find(([id])=>id!==e.pointerId)[1],d0=Math.hypot(o[0]-other[0],o[1]-other[1]);mp.set(e.pointerId,[e.clientX,e.clientY]);const d1=Math.hypot(e.clientX-other[0],e.clientY-other[1]);if(d0>0){const[vx,vy]=toV({clientX:(e.clientX+other[0])/2,clientY:(e.clientY+other[1])/2});zoomAt(d1/d0,vx,vy)}mapMoved=Date.now();return}
 mp.set(e.pointerId,[e.clientX,e.clientY]);if(!mg)return;const u=unitK(),dx=e.clientX-mg.x,dy=e.clientY-mg.y;if(Math.hypot(dx,dy)>8||Date.now()-mapMoved<300){mapMoved=Date.now();S.cam.x=mg.cx+dx*u;S.cam.y=mg.cy+dy*u;clampCam();camApply()}});
const mUp=e=>{if(mp.delete(e.pointerId)&&!mp.size){mg=null;save()}};document.addEventListener('pointerup',mUp);document.addEventListener('pointercancel',mUp);
document.addEventListener('wheel',e=>{if(!e.target.closest||!e.target.closest('#mapbox'))return;e.preventDefault();const[vx,vy]=toV(e);zoomAt(e.deltaY>0?.87:1.15,vx,vy)},{passive:false});

document.addEventListener('click',e=>{const field=e.target.closest&&e.target.closest('[data-offshore-select]');if(field&&S.tab==='c'&&S.offshoreView){S.offshoreMapSelected=field.dataset.offshoreSelect==='gas'?'gas':'oil';draw();save();return}const marine=e.target.closest&&e.target.closest('[data-offshore-country]');if(marine&&S.tab==='c'&&!S.offshoreView){B['offshore-country-select']({p:marine.dataset.offshoreCountry});draw();save();return}const cityCell=e.target.closest&&e.target.closest('[data-city-cell]');if(cityCell&&S.cityView!=null){S.cityCell=Number(cityCell.dataset.cityCell);cityMoveCell=null;draw();save();return}const city=e.target.closest&&e.target.closest('[data-city]');if(city&&Date.now()-mapMoved>300){const i=Number(city.dataset.city);if(Number.isInteger(i)&&CITIES[i]){S.citySelected=i;S.sel=null;draw();save()}return}const t=e.target.closest&&e.target.closest('[data-c]');if(t&&Date.now()-mapMoved>300){S.citySelected=null;S.sel=+t.dataset.c;draw();save()}});
document.addEventListener('keydown',e=>{if(e.key!=='Enter'&&e.key!==' ')return;const target=e.target.closest?.('[data-city-cell],[data-offshore-select],[data-offshore-country]');if(target){e.preventDefault();target.dispatchEvent(new MouseEvent('click',{bubbles:true}))}});
const hd=e=>{if(e.type==='pointermove'&&!e.buttons)return;if(e.target&&e.target.closest&&e.target.closest('.sk2,#mapbox,#country-three,#industry-three'))hold=Date.now()};
['pointerdown','pointermove','pointerup','touchstart','touchmove','wheel'].forEach(t=>document.addEventListener(t,hd,{capture:true,passive:true}));
document.addEventListener('scroll',e=>{
 if(e.target.classList&&(e.target.classList.contains('sk2')||e.target.classList.contains('mimic-scroll')))hold=Date.now();
},true);
// Keep the live simulation from replacing the Mimic DOM during touch/drag and
// momentum scrolling. Scroll position is also restored by the AP setter.
const markMimicInteraction=e=>{if(e.target?.closest?.('.mimic-scroll'))hold=Date.now()};
['pointerdown','pointermove','touchstart','touchmove','wheel'].forEach(type=>document.addEventListener(type,markMimicInteraction,{capture:true,passive:true}));
document.addEventListener('keydown',e=>{const h=e.target.closest&&e.target.closest('.site-unit[data-hmi]');if(h&&(e.key==='Enter'||e.key===' ')){e.preventDefault();const i=Number(h.dataset.hmi);if(Number.isInteger(i)&&S.u[i]&&!['build','ready'].includes(S.u[i].st)){S.hmiUnit=i;S.tab='hmi';draw();save()}}});
document.addEventListener('click',e=>{const h=e.target.closest('[data-hmi]');if(h){const i=Number(h.dataset.hmi);if(Number.isInteger(i)&&S.u[i]&&!['build','ready'].includes(S.u[i].st)){S.hmiUnit=i;S.tab='hmi';draw();save();window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth'})}return}const g=e.target.closest('[data-go]');if(g){const i=+g.dataset.go;S.flash={i,t:Date.now()};draw();const el=document.getElementById('u'+i);if(el)el.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth',block:'center'});return}const tp=e.target.closest('[data-top]');if(tp){const el=document.getElementById('sky');if(el)el.scrollIntoView({behavior:'smooth',block:'start'})}});
// Portable, versioned save backups: upgrades should never require restarting the game.
$('#exportSave').onclick=()=>{
 const payload={format:'process-tycoon-save',schemaVersion:1,gameVersion:'58.0',savedAt:new Date().toISOString(),state:S};
 const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob);
 const a=document.createElement('a');a.href=url;a.download=`process-tycoon-save-day-${S.day}-v51.json`;document.body.append(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),3000);
};
$('#importSaveBtn').onclick=()=>$('#importSaveInput').click();
$('#importSaveInput').onchange=async event=>{
 const input=event.target,file=input.files?.[0];if(!file)return;
 try{
  const parsed=JSON.parse(await file.text());
  if(parsed?.format!=='process-tycoon-save'||parsed?.schemaVersion!==1||!parsed?.state)throw Error('این فایل پشتیبان معتبر بازی نیست.');
  const candidate=parsed.state;
  if(!Array.isArray(candidate.u)||!Array.isArray(candidate.grid)||!candidate.u.every(u=>Number.isInteger(u?.t)&&!!D[u.t]&&Array.isArray(u.v)&&Array.isArray(u.eq)))throw Error('ساختار ذخیره ناقص یا ناسازگار است.');
  candidate.log=Array.isArray(candidate.log)?candidate.log.slice(0,40).map(x=>String(x).replace(/[<>]/g,'')):[];
  normalizeState(candidate,{setImportMultiplier,D,PR,MK,GW,GH});
  if(!window.confirm('وضعیت کنونی بازی با ذخیره انتخاب‌شده جایگزین شود؟ بهتر است ابتدا از بازی فعلی پشتیبان بگیرید.'))return;
  S=candidate;A.setState(S);processModel.setState(S);S.cityView=null;S.offshoreView=false;S.offshoreSelected=null;
  log('ذخیره پشتیبان بازی بازیابی شد.');draw();save();
 }catch(error){window.alert('بازیابی انجام نشد: '+(error?.message||'خطای خواندن فایل'));}
 finally{input.value=''}
};
$('#diff').onclick=()=>{S.diff=((S.diff==null?1:S.diff)+1)%3;normalizeState(S,{setImportMultiplier,D,PR,MK,GW,GH});draw();save()};$('#snd').onclick=()=>{S.mute=!S.mute;draw();save()};
$('#pause').onclick=()=>{S.paused=!S.paused;draw()};$('#spd').onclick=()=>{S.spd=S.spd===4?1:S.spd*2;draw()};
let rc=0;$('#reset').onclick=()=>{const b=$('#reset');if(!rc){b.textContent='تأیید شروع دوباره؟';rc=setTimeout(()=>{rc=0;b.textContent='شروع دوباره'},3000);return}clearTimeout(rc);rc=0;b.textContent='شروع دوباره';countryExpanded=false;countryNotice='';{const dd=S.diff==null?1:S.diff;S=createFreshState();S.diff=dd;S.money=[8000,5000,3500][dd];normalizeState(S,{setImportMultiplier,D,PR,MK,GW,GH});A.setState(S);processModel.setState(S);draw();save()}};
document.addEventListener('click',e=>{const valve=e.target.closest('[data-mimic-valve]');if(valve){const u=S.u[S.hmiUnit];if(u&&u.st==='run'){u.processState=u.processState||{};u.processState.valveOpen=u.processState.valveOpen===false;log(u.processState.valveOpen?'فرمان OPEN برای شیر XV-101 صادر شد؛ مسیر جریان باز است.':'فرمان CLOSE برای شیر XV-101 صادر شد؛ مسیر جریان مسدود است.');draw();save()}return}const pump=e.target.closest('[data-mimic-pump]');if(pump){const u=S.u[S.hmiUnit],d=u&&D[u.t];if(u&&d&&u.st==='run'){const pumpIndex=d.e.findIndex((item,index)=>/پمپ|pump/i.test(String(item?.[0]||''))&&item?.[1]);if(pumpIndex<0){log('این واحد تجهیز پمپ دارای آرایش رزرو تعریف‌شده ندارد.');return}const asset=u.eq[pumpIndex],nextStandby=!(u.processState?.pumpStandby===true),candidate=nextStandby?asset.reserve:asset;if(!candidate||candidate.f||Number(candidate.h)<30){log('فرمان رد شد: پمپ '+(nextStandby?'رزرو':'اصلی')+' آماده بهره‌برداری نیست (سلامت باید حداقل ۳۰٪ باشد).');return}u.processState=u.processState||{};u.processState.pumpStandby=nextStandby;asset.running=!nextStandby;if(asset.reserve)asset.reserve.running=nextStandby;log(nextStandby?'پمپ رزرو وارد سرویس شد و پمپ اصلی به حالت آماده‌به‌کار رفت.':'پمپ اصلی وارد سرویس شد و پمپ رزرو به حالت آماده‌به‌کار رفت.');draw();save()}return}});
document.addEventListener('click',e=>{const close=e.target.closest('[data-mimic-close]');if(close){S.mimicEq=null;S.mimicLoop=null;draw();save();return}const loop=e.target.closest('[data-mimic-loop]');if(loop){const k=Number(loop.dataset.mimicLoop),unit=S.u[S.hmiUnit];if(unit&&D[unit.t]?.v[k]){S.mimicEq=null;S.mimicLoop=k;draw();save()}return}const node=e.target.closest('[data-mimic-eq]');if(node){const index=Number(node.dataset.mimicEq);const unit=S.u[S.hmiUnit];if(unit&&Number.isInteger(index)&&unit.eq[index]){S.mimicEq=index;S.mimicLoop=null;draw();save()}return}});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.closest?.('[data-mimic-eq]')){e.preventDefault();e.target.closest('[data-mimic-eq]').click()}});
document.addEventListener('click',e=>{const b=e.target.closest('[data-mimic-scroll]');if(!b)return;const box=b.closest('.mimic-panel')?.querySelector('.mimic-scroll');if(box)box.scrollBy({left:Number(b.dataset.mimicScroll)*Math.max(220,box.clientWidth*.72),behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth'})});
document.addEventListener('change',e=>{const input=e.target.closest?.('[data-pid-sp]');if(!input)return;const i=Number(input.dataset.i),k=Number(input.dataset.k),u=S.u[i],d=u&&D[u.t];if(!d||!d.v[k])return;const base=d.v[k][2],span=Math.max(d.v[k][3],0.0001),value=Number(input.value);if(!Number.isFinite(value)){input.value=base;return}const key=`${i}:${k}`,cfg=S.pid[key]||(S.pid[key]={kp:0.25,ki:0.06,kd:0.02,integral:0,previousError:0,output:0,mode:'manual'});cfg.sp=cl(value,base-span*3,base+span*3);cfg.integral=0;cfg.previousError=(cfg.sp-u.v[k])/span;input.value=cfg.sp;log(`Setpoint متغیر ${d.v[k][0]} به ${f1(cfg.sp)} ${d.v[k][1]} تنظیم شد.`);save();draw()});
let lastClockPaintDay=S.day;
const clock=createProcessClock({tick,getState:()=>S,draw:()=>{if(S.day!==lastClockPaintDay&&!touchSafety.busy()&&Date.now()-hold>900&&!document.activeElement?.matches?.('input,select,textarea')){lastClockPaintDay=S.day;draw()}},save});
clock.start();
draw();

document.addEventListener('change',e=>{
 const select=e.target;
 if(!select||select.id!=='hmi-unit-select')return;
 const selectedIndex=Number(select.value);
 const isAvailable=Number.isInteger(selectedIndex)&&S.u[selectedIndex]&&!['build','ready'].includes(S.u[selectedIndex].st);
 if(!isAvailable)return;
 S.hmiUnit=selectedIndex;
 S.mimicEq=null;S.mimicLoop=null;
 hmiSelectionCommit=true;
 try{draw();save()}finally{hmiSelectionCommit=false}
});


// Native button click supports Enter/Space without synthetic pointer events.

function navigateDiagnostic(x){
 if(x.target==='resilience'){B['country-response']();draw();save();return}
 if(x.target==='development'){S.tab='m';S.manageSection='development';draw();save();scrollMarketTo(document.getElementById('development-contracts'));return}
 const target=x.target,raw=Number(x.i),index=x.i!==undefined&&x.i!==''&&Number.isInteger(raw)&&S.u[raw]?raw:null;let anchor='';
 if(target==='time'&&S.cr){log('پیش از ثبت روز تازه، بحران فعال را تعیین تکلیف کن.');S.tab='i';draw();save();document.getElementById('app')?.scrollIntoView({block:'start'});return}
 if(target==='time'){S.diagnosticPauseDay=S.day+1;S.paused=false;draw();save();return}
 if(target==='controls'&&index!=null){S.tab='hmi';S.hmiUnit=index;S.hmiMode='advanced';S.hmiSection='controls';anchor='hmi-unit-select'}
 else if(target==='unit'&&index!=null){S.tab='i';S.industrySection=['build','ready'].includes(S.u[index]?.st)?'projects':'operations';S.flt='all';S.expandedUnit=index;anchor='u'+index}
 else if(target==='personnel'){S.tab='i';anchor='personnel-management'}
 else if(target==='crisis'){S.tab='i';anchor='app'}
 else if(target==='advisor'){S.tab='m';S.manageSection='overview';S.advisorUnit=index;anchor=index!=null&&S.adv?'advisor-unit-'+index:'crisis-advisor'}
 else{S.tab='m';S.manageSection=({finance:'finance',trade:'trade',research:'research',maintenance:'maintenance',offshore:'fields'})[target]||'inventory';anchor=target==='maintenance'&&index!=null?'maintenance-unit-'+index:target==='finance'?'company-finance':x.p?'product-'+x.p:'app'}
 if(x.p&&Object.hasOwn(PR,x.p)){S.marketProduct=x.p;S.marketFilter='all';S.marketPage=Math.floor(Object.keys(PR).indexOf(x.p)/12)}
 draw();save();const el=document.getElementById(anchor);if(target==='advisor'&&el?.tagName==='DETAILS')el.open=true;el?.scrollIntoView({block:'center',behavior:'auto'});if(el){highlightNavigationTarget(el);el.focus?.({preventScroll:true})}
}

function handleMaintenanceAction(action,x){
 if(action==='maintenance-filter'){S.maintenanceFilter=['all','attention','enabled','unowned'].includes(x.k)?x.k:'all';draw();save();return}
 if(action==='maintenance-center'){S.tab='m';S.manageSection='maintenance';draw();save();document.getElementById('maintenance-fleet')?.scrollIntoView({block:'start'});return}
 const i=Number(x.i),u=S.u[i],d=u&&D[u.t];if(!u||!d)return;
 if(action==='maintenance-open'){S.tab='i';S.industrySection=['build','ready'].includes(S.u[i]?.st)?'projects':'operations';S.expandedUnit=i;S.flt='all';draw();save();document.getElementById('maintenance-unit-'+i)?.scrollIntoView({block:'center'});return}
 const m=normalizeMaintenance(u,d);
 if(action==='maintenance-buy'){if(purchaseMaintenance(S,i,D))log('مجوز نگهداری خودکار «'+d.n+'» خریداری و فعال شد؛ قطعه و تعمیر هزینه جدا دارند.');else log(m.owned?'این واحد قبلاً مجوز دارد.':'نقد کافی یا شرایط خرید مجوز فراهم نیست.');}
 else if(m.owned){
  if(action==='maintenance-toggle'){m.enabled=!m.enabled;m.status=m.enabled?'فعال؛ ارزیابی روز بعد':'غیرفعال شده توسط بازیکن';log('نگهداری خودکار «'+d.n+'» '+(m.enabled?'فعال':'غیرفعال')+' شد.')}
  if(action==='maintenance-restart')m.restart=!m.restart;
  if(action==='maintenance-shipping'){const modes=['smart','normal','urgent'];m.shipping=modes[(modes.indexOf(m.shipping)+1)%3]}
  if(action==='maintenance-reserve'){const reserves=[0,1000,5000];m.reserve=reserves[(reserves.indexOf(m.reserve)+1)%3]}
  if(action==='maintenance-limit')m.limitMultiplier=(m.limitMultiplier||1)%3+1;
 }
 draw();save();
}

function performMarketTrade(product,side,quantity){
 const receipt=executeProductTrade(S,product,side,quantity,{PR,cap,importMultiplier:IMP});
 log(receipt.ok?`${side==='buy'?'خرید':'فروش'} ${f1(receipt.quantity)} ${PR[product][1]} ${PR[product][0]}؛ ${side==='buy'?'پرداخت':'دریافت'} ${f1(receipt.total)}. ${receipt.reason}`:receipt.reason);
}
function scrollMarketTo(el){if(!el)return;const height=['body > header'].reduce((sum,key)=>{const node=document.querySelector(key);return sum+(node&&typeof getComputedStyle==='function'&&['sticky','fixed'].includes(getComputedStyle(node).position)?node.getBoundingClientRect().height:0)},0);el.style?.setProperty('scroll-margin-top',Math.ceil(height+16)+'px');el.scrollIntoView({block:'start'})}
function handleMarketAction(action,x){
 if(action==='market-show'){scrollMarketTo(document.getElementById('trade-desk'));return}

 if(action==='market-program-toggle'){S.marketAutomation||={};S.marketAutomation.enabled=S.marketAutomation.enabled===false;draw();save();return}
 if(action==='market-rule-save'&&Object.hasOwn(PR,x.p)){
  const read=key=>document.getElementById('auto-market-'+key),number=key=>Number(read(key)?.value)||0;
  const raw={buy:!!read('buy')?.checked,emergency:!!read('emergency')?.checked,sellMode:read('sellMode')?.value,...Object.fromEntries(['min','target','max','reserve','maxBuy','minSell','quantityLimit'].map(k=>[k,number(k)]))};
  saveProductRule(S,x.p,raw,PR);S.marketAutomation.reserve=Math.max(0,number('cashReserve'));S.marketAutomation.dailyLimit=Math.max(0,number('dailyLimit'));log('تنظیم خودکار '+PR[x.p][0]+' ذخیره شد؛ از روز بعد ارزیابی می‌شود.');draw();save();return
 }

 if(action==='market-page'){S.marketPage=Math.max(0,Number(x.page)||0);draw();save();scrollMarketTo(document.querySelector('.tank-yard'));return}
 if(action==='market-back'){scrollMarketTo(document.getElementById('product-market'));return}
 if(action==='market-filter'){S.marketFilter=x.k;S.marketPage=0;draw();save();return}
 if(action==='market-tank'&&Object.hasOwn(PR,x.p)){S.marketProduct=x.p;draw();save();return}
 if(action==='market-preset'&&Object.hasOwn(PR,x.p)&&['hold','feed','surplus'].includes(x.k)){const a=productRule(S,x.p,PR);a.buy=x.k==='feed';a.sellMode=x.k==='surplus'?'threshold':'off';if(x.k==='feed')a.emergency=true;if(x.k==='surplus'){a.min=20;a.target=55;a.max=85;a.reserve=Math.max(30,a.reserve)}saveProductRule(S,x.p,a,PR);S.marketNotice={product:x.p,text:'برنامه ذخیره شد؛ از روز بعد و در حدود بودجه و قیمت تعیین‌شده اجرا می‌شود.'};draw();save();return}
 if(action==='market-config'&&Object.hasOwn(PR,x.p))S.marketProduct=x.p;
 if(action==='market-select'&&Object.hasOwn(PR,x.p)){S.marketProduct=x.p;S.marketSide=x.k==='sell'?'sell':'buy'}
 if(action==='market-side')S.marketSide=x.k==='sell'?'sell':'buy';
 if(action==='market-quantity')S.marketQuantity=Number(x.q);
 if(action==='market-execute')performMarketTrade(x.p,x.k,Number(document.getElementById('market-quantity')?.value??x.q));
 draw();save();if(action==='market-select')document.getElementById('trade-desk')?.scrollIntoView({block:'center'});if(action==='market-config'){const details=document.getElementById('product-advanced-'+x.p);if(details)details.open=true;document.getElementById('product-automation')?.scrollIntoView({block:'start'});}
}
document.addEventListener('change',e=>{
 if(e.target.id==='legacy-item'){S.legacyItem=e.target.value;draw();save()}
 if(e.target.id==='legacy-city'){S.legacyCity=Number(e.target.value);draw();save()}
 if(e.target.id==='project-type'){S.projectType=Number(e.target.value);draw();save()}
 if(e.target.id==='market-cash-unit'){S.marketCashUnit=Number(e.target.value);draw();save()}
 if(e.target.id==='market-product'&&Object.hasOwn(PR,e.target.value)){S.marketProduct=e.target.value;draw();save()}
 if(e.target.id==='market-quantity'){const value=Number(e.target.value);S.marketQuantity=Number.isFinite(value)&&value>0?value:0;draw();save()}
});

document.addEventListener('input',e=>{if(e.target.id==='market-quantity'){const v=Number(e.target.value);S.marketQuantity=Number.isFinite(v)&&v>0?v:0;draw()}});

mountAudioControls({getState:()=>S,engine:gameAudio,save,draw});
if(typeof window!=='undefined')window.addEventListener('pagehide',e=>{if(!e.persisted)gameAudio.dispose()});

function handleLegacyAction(action,x){
 if(action==='legacy-open'){S.tab='m';S.manageSection='legacy';if(x.section)S.legacySection=x.section;draw();save();scrollMarketTo(document.querySelector('.legacy-center'));return}
 if(action==='legacy-section'){S.legacySection=x.key;draw();save();return}
 if(action==='legacy-filter'){S.legacyFilter=x.key;draw();save();return}
 if(action==='legacy-campus'){S.tab='site';draw();save();return}
 if(action==='legacy-choose'){const i=Math.max(0,Math.min(CITIES.length-1,Number(S.legacyCity)||0));S.tab='c';B['city-enter']({i});S.countryHub=null;S.offshoreView=false;S.cityCell=null;S.cityDesignOpen=true;S.legacyItem=x.key;{const l=legacyState(S);l.notice='یک قطعه روی نقشه انتخاب کن؛ سپس ساخت را تأیید کن.';S.legacy=l}draw();save();scrollMarketTo(document.querySelector('.atlas-stage'));return}
 const i=Number(S.cityView),city=S.cityView!=null?CITIES[i]:null,cell=S.cityCell;const data={key:x.key,city:city?.name,cell};
 if(action==='legacy-sponsor')data.amount=document.getElementById('legacy-sponsor-amount')?.value;
 if(action==='legacy-district'){data.key=document.getElementById('legacy-district-style')?.value;data.name=document.getElementById('legacy-district-name')?.value}
 if(action==='legacy-sign'){data.name=document.getElementById('legacy-sign-name')?.value;data.logo=document.getElementById('legacy-sign-logo')?.value}
 const result=legacyAction(S,action.slice(7),data,{CITIES,PR,IN});if(!result.ok){const l=legacyState(S);l.notice=result.reason;S.legacy=l}else log(result.message);draw();save();
}
