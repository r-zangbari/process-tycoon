// Fictional country events and recovery, expressed in game days and points.
export const RESILIENCE_ZONES={
 port:{name:'بندر جنوبی',impact:'ظرفیت مشترک بارگیری'},
 industry:{name:'سایت صنعتی',impact:'ظرفیت تولید واحدهای فرایندی'},
 capital:{name:'پایتخت',impact:'درآمد محلی پایتخت'},
 north:{name:'قطب کشاورزی',impact:'تولید و ظرفیت ذخیرهٔ محصولات کشاورزی'},
 energy:{name:'قطب تولید کالا',impact:'تولید کالا و درآمد قطب'},
 'water-desal':{name:'آب‌شیرین‌کن ساحلی',impact:'تولید آب خام ساحلی و انتقال از مخزن ساحلی'}
};
export const PROTECTION={
 reserve:{name:'ذخیره و زیرساخت پشتیبان',cost:360,days:2},
 station:{name:'پایگاه واکنش منطقه‌ای',cost:540,days:2}
};
export const CONVOY_COST=24;
const zones=Object.keys(RESILIENCE_ZONES);
const routes=['island','bay'];
const clamp=(value,min,max)=>Number.isFinite(value)?Math.max(min,Math.min(max,Math.floor(value))):min;
const hasZone=id=>Object.hasOwn(RESILIENCE_ZONES,id);
const hasProject=k=>Object.hasOwn(PROTECTION,k);
const districtsOf=S=>S.resilience?.districts||{};

export function resilienceState(S){
 const v=S.resilience||{};
 const districts=Object.fromEntries(zones.map(id=>{
  const row=v.districts?.[id]||{},projects={};
  for(const k of Object.keys(PROTECTION)){
   const p=row.projects?.[k];
   if(p?.level>0)projects[k]={level:clamp(p.level,1,2),ready:clamp(p.ready,0,1e9)};
  }
  return [id,{projects,crew:row.crew===true,damage:clamp(row.damage,0,50),repair:clamp(row.repair,0,1e9)}];
 }));
 const w=v.warning,last=v.last,c=v.closure;
 const hasWarning=hasZone(w?.zone)&&Number.isSafeInteger(w.due);
 return {districts,clock:clamp(v.clock,0,1e9),lastDay:clamp(v.lastDay,0,1e9),
  protected:zones.filter(id=>Array.isArray(v.protected)&&v.protected.includes(id)),
  warning:hasWarning?{zone:w.zone,due:w.due,strength:clamp(w.strength,1,6),route:routes.includes(w.route)?w.route:null}:null,
  last:hasZone(last?.zone)?{zone:last.zone,day:clamp(last.day,0,1e9),damage:clamp(last.damage,0,50),reward:clamp(last.reward,0,1000)}:null,
  closure:routes.includes(c?.route)&&Number.isSafeInteger(c.until)?{route:c.route,until:c.until}:null,
  reward:clamp(v.reward,0,1000)};
}

export function resilienceFactor(S,id){
 return 1-clamp(districtsOf(S)[id]?.damage,0,50)/100;
}
export function routeClosedUntil(S,route){
 const c=S.resilience?.closure;
 return c?.route===route&&c.until>=S.day?c.until:null;
}
// Reserve available staff once. Existing absenteeism is deducted before this function.
export function staffedStations(S,available){
 if(!S.resilience||!(S.tr>=1))return [];
 return zones.filter(id=>{
  const r=districtsOf(S)[id],p=r?.projects?.station;
  return r?.crew&&p?.level>0&&p.ready<=S.day;
 }).slice(0,Math.max(0,available));
}
export function baseCrew(S){
 const unavailable=(S.personnel?.injuryDays>0?1:0)+(S.personnel?.fatalities||0);
 const present=Math.max(0,(S.ops||0)-unavailable);
 return S.walk?Math.floor(present*(1-S.walk.f*(S.walk.c?.5:1))):present;
}
export function protectionPoints(S,id){
 const r=districtsOf(S)[id],reserve=r?.projects?.reserve,station=r?.projects?.station;
 const team=S.strategy?.drill;
 const teamHere=team?.moving?team.moving===id&&team.arrival<=S.day:(team?.team||'capital')===id;
 const powered=(S.fr?.power||0)>=.5;
 const staff=staffedStations(S,baseCrew(S)).includes(id);
 return (reserve?.ready<=S.day?reserve.level:0)+(staff&&powered?station.level*2:0)+(teamHere&&S.tr>=1&&powered?2:0);
}
export function repairCost(damage){return 60+damage*6}

export function resilienceAction(S,action,zone,kind){
 const state=resilienceState(S);
 if(action==='warn-auto'){
  const eligible=zones.filter(id=>id!==state.last?.zone);
  zone=eligible[state.clock%eligible.length];
  action='warn';
 }
 if(!hasZone(zone))return 'منطقه را از روی نقشه انتخاب کن.';
 const row=state.districts[zone];
 if(action==='warn'){
  if(state.warning||state.last&&S.day<state.last.day+8)return 'سناریو فعال است یا هنوز دورهٔ بازیابی تمام نشده.';
  const strength=state.protected.includes(zone)?5:3;
  state.warning={zone,strength,due:S.day+3,route:zone==='port'?routes[state.clock%2]:null};
  state.clock++;
 }else if(action==='build'){
  if(!hasProject(kind))return 'پروژه معتبر نیست.';
  const def=PROTECTION[kind],p=row.projects[kind],cost=def.cost*((p?.level||0)+1);
  if(p?.level>=2||p?.ready>S.day||S.money<cost)return 'ساخت در این مرحله ممکن نیست.';
  S.money-=cost;
  row.projects[kind]={level:(p?.level||0)+1,ready:S.day+def.days};
 }else if(action==='crew'){
  const p=row.projects.station;
  if(!p||p.ready>S.day||!row.crew&&(S.tr<1||staffedStations(S,baseCrew(S)).length>=baseCrew(S)))return 'پایگاه آماده و یک اپراتور آموزش‌دیدهٔ آزاد لازم است.';
  row.crew=!row.crew;
 }else if(action==='repair'){
  const cost=repairCost(row.damage);
  if(!row.damage||row.repair||S.money<cost)return 'درخواست تعمیر، سرمایه یا آسیب قابل تعمیر وجود ندارد.';
  S.money-=cost;row.repair=S.day+2;
 }else return 'فرمان معتبر نیست.';
 S.resilience=state;
 return '';
}
export function advanceResilienceDay(S,log=()=>{}){
 if(!S.resilience||S.resilience.lastDay===S.day)return 0;
 const state=resilienceState(S);
 state.lastDay=S.day;state.reward=0;
 for(const row of Object.values(state.districts)){
  if(row.repair&&row.repair<=S.day){row.damage=0;row.repair=0;}
  else row.damage=Math.max(0,row.damage-5);
  if(row.damage===0)row.repair=0;
 }
 if(state.closure&&state.closure.until<S.day)state.closure=null;
 if(state.warning&&state.warning.due<=S.day){
  const {zone,strength,route}=state.warning;
  const row=state.districts[zone],damage=Math.max(0,strength-protectionPoints(S,zone))*10;
  if(damage>0){
   row.damage=Math.min(50,row.damage+damage);if(route)state.closure={route,until:S.day+2};
  }else if(!state.protected.includes(zone)){state.protected.push(zone);state.reward=700;}
  state.last={zone,day:S.day,damage:Math.min(50,damage),reward:state.reward};
  state.warning=null;
  log(damage>0?'بحران «'+RESILIENCE_ZONES[zone].name+'» ظرفیت منطقه را کاهش داد.':'دفاع موفق در «'+RESILIENCE_ZONES[zone].name+'»؛ نشان تداوم خدمت ثبت شد.');
 }
 S.resilience=state;
 return state.reward;
}
