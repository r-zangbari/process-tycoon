import {RESILIENCE_ZONES,CONVOY_COST,resilienceFactor,routeClosedUntil} from './resilience.js';
import {storyFactor} from './development.js';
import {effectiveTradePort,importTradeFactor} from './trade-conditions.js';

export const GOODS={produce:'تره‌بار',fodder:'خوراک دام',milk:'شیر خام',dairy:'لبنیات'};
export const FARMS={
 greenhouse:{name:'گلخانه',cost:650,days:2,need:{water:4,power:2},out:{produce:6}},
 field:{name:'مزرعهٔ علوفه',cost:450,days:2,need:{water:4,fuel:1},out:{fodder:6}},
 barn:{name:'دامداری',cost:850,days:3,need:{water:3,power:1},input:{fodder:4},out:{milk:4}},
 dairy:{name:'کارخانهٔ لبنیات',cost:950,days:3,need:{water:1,power:3},input:{milk:4},out:{dairy:4}},
 silo:{name:'سیلوی خوراک دام',cost:500,days:2,need:{},store:{fodder:40}},
 cold:{name:'سردخانه',cost:650,days:2,need:{power:2},store:{produce:24,milk:16,dairy:24}}
};
export const PLOTS=12;
export const ROUTES={
 island:{name:'جزیرهٔ مهتاب',days:3,rate:1},
 bay:{name:'بندر سپیدار',days:5,rate:1.2}
};
export const DRILL_ZONES=Object.fromEntries(Object.entries(RESILIENCE_ZONES).map(([id,zone])=>[id,zone.name]));
const DRILL_TARGETS=['port','industry','capital'];
const STOCK={produce:12,fodder:18,milk:12,dairy:12};
const SALES={produce:12,dairy:28};
const whole=(x,a,b)=>Number.isFinite(x)?Math.min(b,Math.max(a,Math.floor(x))):a;
const bounded=(x,a,b)=>Number.isFinite(x)?Math.min(b,Math.max(a,x)):a;
export function farmCellAvailable(S,id){
 return Number.isInteger(id)&&id>=0&&id<(S.grid?.length||0)&&id%3===0&&!S.grid[id];
}
function placeSavedFarms(S,plots){
 const used=new Set();
 for(const [slot,b] of plots.entries()){
  if(!b)continue;
  const overflow=b.cell===(S.grid?.length||0)+slot;
  if((!overflow&&!farmCellAvailable(S,b.cell))||used.has(b.cell))b.cell=null;
  else used.add(b.cell);
 }
 for(let i=0;i<plots.length;i++){
  const b=plots[i];
  if(!b||b.cell!=null)continue;
  const found=S.grid?.findIndex((_,id)=>farmCellAvailable(S,id)&&!used.has(id))??-1;
  b.cell=found>=0?found:(S.grid?.length||0)+i;
  used.add(b.cell);
 }
}
export function strategyState(S){
 const s=S.strategy||{};
 const stock=Object.fromEntries(Object.keys(GOODS).map(p=>[p,bounded(s.stock?.[p],0,10_000)]));
 const plots=Array.from({length:PLOTS},(_,i)=>{
  const b=s.plots?.[i];
  return b&&Object.hasOwn(FARMS,b.kind)?{kind:b.kind,level:whole(b.level,1,3),ready:whole(b.ready,0,1e9),active:b.active!==false,cell:Number.isInteger(b.cell)?b.cell:null}:null;
 });
 placeSavedFarms(S,plots);
 const ships=(Array.isArray(s.ships)?s.ships:[]).filter(v=>v&&Number.isSafeInteger(v.id)&&v.id>0&&Object.hasOwn(ROUTES,v.route)&&
  Object.hasOwn(GOODS,v.product)&&Number.isFinite(v.qty)&&v.qty>0&&Number.isSafeInteger(v.start)&&Number.isSafeInteger(v.due)&&Number.isFinite(v.price)&&v.price>=0).slice(0,4);
 const history=(Array.isArray(s.history)?s.history:[]).filter(v=>v&&Object.hasOwn(ROUTES,v.route)&&Object.hasOwn(GOODS,v.product)&&Number.isFinite(v.day)).slice(0,10);
 const d=s.drill||{};
 const team=Object.hasOwn(DRILL_ZONES,d.team)?d.team:'capital';
 const target=Object.hasOwn(DRILL_ZONES,d.target)?d.target:null;
 const moving=Object.hasOwn(DRILL_ZONES,d.moving)?d.moving:null;
 return {stock,plots,ships,sequence:Math.max(whole(s.sequence,0,1e9),...ships.map(v=>v.id)),today:s.today||null,history,
  drill:{team,moving,arrival:whole(d.arrival,0,1e9),target,lastTarget:Object.hasOwn(DRILL_ZONES,d.lastTarget)?d.lastTarget:null,due:whole(d.due,0,1e9),wins:whole(d.wins,0,1e9),attempts:whole(d.attempts,0,1e9),result:['covered','gap'].includes(d.result)?d.result:null}};
}

export function changeFarm(S,slot,action,kind,cell){
 if(!Number.isInteger(slot)||slot<0||slot>=PLOTS)return 'زمین معتبر نیست.';
 const s=strategyState(S),b=s.plots[slot],def=Object.hasOwn(FARMS,kind)?FARMS[kind]:null;
 if(action==='build'&&def&&!b&&S.money>=def.cost){
  if(cell!=null&&(!farmCellAvailable(S,cell)||s.plots.some(v=>v?.cell===cell)))return 'این زمین برای ساخت آزاد نیست.';
  S.money-=def.cost;s.plots[slot]={kind,level:1,ready:S.day+def.days,active:true,cell:cell??null};
  placeSavedFarms(S,s.plots);
 }else if(action==='upgrade'&&b&&b.ready<=S.day&&b.level<3&&S.money>=FARMS[b.kind].cost*(b.level+1)){
  S.money-=FARMS[b.kind].cost*(b.level+1);b.level++;b.ready=S.day+2;
 }else if(action==='toggle'&&b&&b.ready<=S.day){
  b.active=!b.active;
 }else return 'زمین، مرحلهٔ ساخت یا موجودی نقد اجازهٔ انجام فرمان را نمی‌دهد.';
 S.strategy=s;
 return '';
}
const working=(s,day)=>s.plots.flatMap((b,slot)=>b&&b.active&&b.ready<=day?[{...b,slot,def:FARMS[b.kind]}]:[]);
export function farmDemand(S){
 const demand={};
 for(const b of working(strategyState(S),S.day)){
  for(const [p,n] of Object.entries(b.def.need))demand[p]=(demand[p]||0)+n*b.level;
 }
 return demand;
}
export function farmStorage(S,s=strategyState(S),supply=S.fr||{}){
 const cap={...STOCK},district=resilienceFactor(S,'north');
 for(const b of working(s,S.day)){
  const util=Math.min(1,...Object.keys(b.def.need).map(p=>supply[p]??0));
  for(const [p,n] of Object.entries(b.def.store||{}))cap[p]+=n*b.level*util*district;
 }
 return cap;
}

export function voyageQuote(S,route,product,qty){
 if(!Object.hasOwn(ROUTES,route)||!Object.hasOwn(GOODS,product)||!Number.isInteger(qty)||qty<1||qty>12)return null;
 const s=strategyState(S),buy=product==='fodder';
 if(!buy&&!Object.hasOwn(SALES,product))return null;
 const total=qty*(buy?8*importTradeFactor(S,'food'):SALES[product]*ROUTES[route].rate*(S.fx?.sanc?.7:1)*(S.fx?.spike?1.4:1)*(S.fx?.rival?.9:1))*(S.economy?.shock?.type===(buy?'supply':'demand')?(buy?1.18:.82):1);
 const available=Math.min(effectiveTradePort(S),S.portRemainingToday??S.port);
 return {buy,total,days:ROUTES[route].days,queued:available<qty,allowed:s.ships.length<4&&(buy?S.money>=total:s.stock[product]>=qty)};
}
export function dispatchVoyage(S,route,product,qty){
 const q=voyageQuote(S,route,product,qty);
 if(!q?.allowed)return 'موجودی، نقد یا ظرفیت ناوگان کافی نیست.';
 const s=strategyState(S);
 if(q.buy)S.money-=q.total;
 else s.stock[product]-=qty;
 if(!q.queued){
  S.portRemainingToday=Math.max(0,(S.portRemainingToday??S.port)-qty);
  S.portUsedToday=(S.portUsedToday||0)+qty;
 }
 s.ships.push({id:++s.sequence,route,product,qty,buy:q.buy,price:q.total,start:S.day,due:S.day+q.days,queued:q.queued});
 S.strategy=s;
 return '';
}

export function loadScheduledVoyages(S,remaining,log=()=>{}){
 if(!S.strategy?.ships?.some(v=>v.queued))return remaining;
 const s=strategyState(S);
 for(const v of s.ships){
  if(!v.queued||remaining<v.qty)continue;
  remaining-=v.qty;v.queued=false;v.start=S.day;v.due=S.day+ROUTES[v.route].days;
  log('رزرو پایانه انجام شد و کشتی سفر «'+ROUTES[v.route].name+'» را شروع کرد.');
 }
 S.strategy=s;
 return remaining;
}

export function protectVoyage(S,id){
 const s=strategyState(S),ship=s.ships.find(v=>v.id===id);
 if(!ship||ship.protected||ship.waiting||S.money<CONVOY_COST)return 'همراهی برای این سفر در دسترس نیست.';
 S.money-=CONVOY_COST;ship.protected=true;S.strategy=s;
 return '';
}

export function changeDrill(S,action,zone,trained){
 const s=strategyState(S),d=s.drill;
 if(action==='start'&&!d.target){
  const options=DRILL_TARGETS.filter(k=>k!==d.team);
  d.target=options[d.attempts%options.length];
  d.due=S.day+3;d.result=null;d.attempts++;
 }else if(action==='move'&&Object.hasOwn(DRILL_ZONES,zone)&&d.team!==zone&&!d.moving){
  if(!trained)return 'برای جابه‌جایی تیم، یک سطح آموزش اپراتورها لازم است.';
  d.moving=zone;d.arrival=S.day+2;
 }else return 'فرمان در این مرحله در دسترس نیست.';
 S.strategy=s;
 return '';
}

export function settleStrategy(S,supply,log=()=>{}){
 const s=strategyState(S);
 if(s.today?.day===S.day)return s.today.income;
 let income=0;
 const d=s.drill;
 if(d.moving&&S.day>=d.arrival){d.team=d.moving;d.moving=null}
 if(d.target&&S.day>=d.due){
  const won=d.team===d.target&&!d.moving&&S.tr>=1&&(supply.power||0)>=.5;
  d.result=won?'covered':'gap';d.lastTarget=d.target;
  if(won){d.wins++;income+=d.wins===1?550:100;}
  log(won?'مانور کشور: خدمات منطقه برقرار ماند و پاداش آمادگی ثبت شد.':'مانور کشور: منطقه در شبیه‌سازی بدون پوشش ماند.');
  d.target=null;
 }
 const cap=farmStorage(S,s,supply),rows={},sea={arrivals:0,revenue:0,unloaded:0},lost={};
 for(const p of Object.keys(GOODS)){
  lost[p]=Math.max(0,s.stock[p]-cap[p]);
  s.stock[p]-=lost[p];
 }
 const ready=working(s,S.day),district=resilienceFactor(S,'north');
 // Upstream output is available to later stages during the same game day.
 for(const kind of Object.keys(FARMS)){
  for(const b of ready.filter(x=>x.kind===kind)){
   const util=Math.min(1,...Object.keys(b.def.need).map(p=>supply[p]??0));
   const input=Object.entries(b.def.input||{});
   const rate=Math.min(util*district,...input.map(([p,n])=>s.stock[p]/(n*b.level)));
   for(const [p,n] of input)s.stock[p]-=n*b.level*rate;
   rows[b.slot]={rate,util,district,out:{}};
   for(const [p,n] of Object.entries(b.def.out||{})){
    const made=n*b.level*rate,stored=Math.max(0,Math.min(made,cap[p]-s.stock[p]));
    s.stock[p]+=stored;lost[p]+=made-stored;rows[b.slot].out[p]=stored;
   }
  }
 }
 income+=S.resilience?.lastDay===S.day?S.resilience.reward||0:0;
 const active=[];
 const delayed=(S.fx?.sanc||storyFactor(S,'port')<1||S.economy?.shock?.type==='supply')&&S.day%2===0;
 for(const ship of s.ships){
  if(ship.queued){active.push(ship);continue}
  const routeDelay=!ship.protected&&routeClosedUntil(S,ship.route)!=null;
  if(!ship.waiting&&(delayed||routeDelay)){
   active.push({...ship,due:ship.due+1,delayDays:(ship.delayDays||0)+1,delayed:true,routeDelay});
   continue;
  }
  if(S.day<ship.due){active.push({...ship,delayed:false,routeDelay:false});continue}
  if(ship.buy){
   const qty=Math.min(ship.qty,Math.max(0,cap[ship.product]-s.stock[ship.product]));
   s.stock[ship.product]+=qty;sea.unloaded+=qty;
   if(qty+.0001<ship.qty){active.push({...ship,qty:ship.qty-qty,waiting:true,delayed:false,routeDelay:false});continue}
  }else{sea.revenue+=ship.price;income+=ship.price}
  sea.arrivals++;
  s.history.unshift({route:ship.route,product:ship.product,buy:ship.buy,day:S.day});
  log('سفر دریایی «'+ROUTES[ship.route].name+'» تسویه شد.');
 }
 s.ships=active;s.history=s.history.slice(0,10);
 s.today={day:S.day,rows,sea,lost,income};S.strategy=s;
 return income;
}
