// v51 — One source of truth for independent city layouts and their national effects.
// Population is an illustrative game metric; marginal utilities and tax are balanced
// for the game economy rather than physical city-scale engineering units.
const size=81;
const validTypes=new Set(['home','shop','service','park']);
const starterHomeCells=[31,39,40,41,49];
export function createStarterCityGrid(){
 const grid=Array(size).fill(null);
 for(const i of starterHomeCells)grid[i]={type:'home',level:1};
 grid[22]={type:'park',level:1};
 grid[58]={type:'service',level:1};
 return grid;
}
export function safeCityGrid(grid){
 return Array.isArray(grid)&&grid.length===size?grid:createStarterCityGrid();
}
export function cityDevelopmentMetrics(input){
 const grid=safeCityGrid(input),counts={home:0,shop:0,service:0,park:0},levels={home:0,shop:0,service:0,park:0};
 const homes=[],support=[],occupied=[];
 grid.forEach((b,i)=>{
  if(!b||!validTypes.has(b.type))return;
  const level=Math.max(1,Math.min(3,Math.floor(Number(b.level)||1)));
  counts[b.type]++;levels[b.type]+=level;occupied.push(i);
  if(b.type==='home')homes.push(i);
  if(b.type==='service'||b.type==='park')support.push(i);
 });
 const covered=homes.filter(i=>support.some(j=>Math.abs(i%9-j%9)+Math.abs(Math.floor(i/9)-Math.floor(j/9))<=2)).length;
 const coverage=homes.length?Math.round(covered/homes.length*100):0;
 let connected=0;
 if(occupied.length){
  const seen=new Set([occupied[0]]),queue=[occupied[0]];
  while(queue.length){const i=queue.shift(),x=i%9,y=Math.floor(i/9);
   for(const j of [x>0?i-1:-1,x<8?i+1:-1,y>0?i-9:-1,y<8?i+9:-1])if(j>=0&&grid[j]&&validTypes.has(grid[j].type)&&!seen.has(j)){seen.add(j);queue.push(j)}
  }
  connected=seen.size;
 }
 const pop=25000+levels.home*700+levels.shop*90+levels.service*35;
 return {homes:counts.home,shops:counts.shop,services:counts.service,parks:counts.park,
  levels,coverage,connectivity:occupied.length?Math.round(connected/occupied.length*100):0,pop};
}
export function summarizeUrbanDevelopment(cityMaps={},cities=[],taxFactor=()=>1){
 const places={},demand={power:0,gas:0,water:0,fuel:0};let population=0,tax=0,developed=0;
 for(const city of cities){
  const metric=cityDevelopmentMetrics(cityMaps?.[city.name]);places[city.name]=metric;population+=metric.pop;
  const h=Math.max(0,metric.levels.home-5),s=metric.levels.shop,
   v=Math.max(0,metric.levels.service-1),p=Math.max(0,metric.levels.park-1);
  developed+=h+s+v+p;
  // Existing starter neighborhoods are already represented by the initial economy;
  // only buildings/upgrades beyond their baseline demand additional utilities.
  demand.power+=h*.9+s*1.5+v*2+p*.3;
  demand.gas+=h*.5+s*.85+v*.35;
  demand.water+=h*.8+s*.5+v*1.4+p*.7;
  demand.fuel+=h*.25+s*.35+v*.25;
  const serviceMultiplier=.7+.3*metric.coverage/100;
  tax+=(h*2+s*6+v*1.5)*serviceMultiplier*taxFactor(city);
 }
 return {places,population,demand,tax,developed};
}
