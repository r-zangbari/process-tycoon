import { settleDistrictProduction } from '../features/country/model/district-production.js';
import { appearanceBonus } from '../features/legacy/model/legacy-development.js';
import { collectUrbanWastewater } from '../features/water/model/water-supply.js';
import { expectedProductNeed, productRule, productSaleMode } from '../features/products/model/product-automation.js';
import { IN } from '../data/catalog.js';
import { effectiveTradePort } from '../features/products/model/trade-conditions.js';
// Country-level utility demand, delivery, taxation and export settlement.
import { summarizeUrbanDevelopment } from '../features/country/model/urban-economy.js';
export function createProcessModel(ctx) {
  let { S } = ctx;
  const { TY, SF, PR, MK, cl, r, log } = ctx;
  function country(fm, remainingPort = S.port, cities = []) {
    const dem = { power: 0, gas: 0, fuel: 0, water: 0 },
      del = {},
      fr = {};
    let dom = 0,
      tax = 0,
      eco = 0,
      ex = 0,
      pop = 0,
      sat = [];
    S.grid.forEach((b) => {
      if (!b) return;
      const t = TY[b.t];
      for (const p in t.need) if (b.c[p]) dem[p] += t.need[p] * b.l;
    });
    const urban = summarizeUrbanDevelopment(S.cityMaps, cities);
    for (const p in urban.demand) dem[p] += urban.demand[p];
    {
      const sf = SF[Math.floor(((S.day - 1) % 360) / 90)];
      dem.gas *= sf.g;
      dem.power *= sf.p;
    }
    for (const p in dem) {
      const level = Math.max(0, Math.min(4, Number(S.network?.[p]) || 0));
      const loss = Math.max(0.02, 0.1 - level * 0.02);
      const withdrawal = Math.min(S.tanks[p], dem[p] / (1 - loss));
      del[p] = withdrawal * (1 - loss);
      S.tanks[p] -= withdrawal;
      fr[p] = dem[p] ? Math.min(1, del[p] / dem[p]) : 1;
      dom += del[p] * PR[p][2];
    }
    const districts = settleDistrictProduction(S, fr, TY, MK);
    tax += districts.tax;
    eco += districts.eco;
    pop += districts.pop;
    sat.push(...districts.sat);
    pop += urban.population;
    const urbanTax = cities.reduce((total, city) => {
      return total + (urban.places[city.name]?.tax || 0);
    }, 0);
    tax += urbanTax * (0.4 + (0.6 * (fr.power + fr.gas + fr.water + fr.fuel)) / 4);
    S.foodIndex = Math.min(
      1,
      ((S.pd.veg || 0) + (S.pd.meat || 0) + (S.pd.food || 0)) / Math.max(20, pop * 0.5)
    );
    tax *= 1 + 0.12 * S.foodIndex;
    S.urbanToday = {
      population: urban.population,
      tax: urbanTax,
      demand: urban.demand,
      developed: urban.developed
    };
    for (const k in MK) S.pm[k] = cl((S.pm[k] || 1) + (r() - 0.5) * 0.08, 0.6, 1.6);
    let ctInc = 0,
      cp = Math.max(0, Math.min(Number(S.port) || 0, Number(remainingPort) || 0));
    const sv = {};
    for (const p in del) sv[p] = del[p] * PR[p][2];
    for (const p in S.ic) sv[p] = (sv[p] || 0) + S.ic[p] * PR[p][2];
    const contractDeliveries = S.tradeDeliveriesToday || {};
    for (const [p, delivery] of Object.entries(contractDeliveries))
      sv[p] = (sv[p] || 0) + delivery.gross;
    const legacyDeliveries = {};
    S.ct = (S.ct || []).filter((c) => {
      const dl = Math.min(S.tanks[c.p], c.q, cp),
        bs = PR[c.p][2];
      S.tanks[c.p] -= dl;
      cp -= dl;
      ctInc += dl * bs * c.pr - (c.q - dl) * bs * c.pen;
      sv[c.p] = (sv[c.p] || 0) + dl * bs * c.pr;
      legacyDeliveries[c.p] = (legacyDeliveries[c.p] || 0) + dl;
      if (dl < c.q && S.day % 5 === 0) log('کسری تحویل قرارداد ' + PR[c.p][0] + '؛ جریمه می‌شوید.');
      if (--c.d <= 0) {
        log('قرارداد ' + PR[c.p][0] + ' به پایان رسید.');
        return false;
      }
      return true;
    });
    const le = Math.min(S.tanks.power, S.line || 0);
    S.tanks.power -= le;
    ex += le * 6 * fm;
    sv.power = (sv.power || 0) + le * 6 * fm;
    // Spot market: price strategy changes both realized price and market demand.
    const marketBase = {
      methanol: 70,
      ethylene: 85,
      sulfur: 35,
      crude: 120,
      naphtha: 55,
      ammonia: 55,
      urea: 65,
      propane: 45,
      butane: 45,
      fueloil: 60,
      steel: 35,
      cement: 65
    };
    const marketDay = {}, autoDay = S.autoMarketDay?.day === S.day ? S.autoMarketDay : {};
    S.rp = {};
    for (const p in PR) {
      const rule = productRule(S, p, PR), saleMode = productSaleMode(S, p, PR, rule);
      const threshold = autoDay.saleAttempts?.[p];
      const flow = {
        saleMode,
        saleReason: threshold?.reason,
        salePortLimited: threshold?.portLimited === true,
        thresholdSold: threshold?.sold || 0,
        contractDelivered: (contractDeliveries[p]?.quantity || 0) + (legacyDeliveries[p] || 0),
        industrialUse: S.ic?.[p] || 0,
        domesticDelivered: del[p] || 0,
        domesticDemand: dem[p] || 0,
        lineDelivered: p === 'power' ? le : 0,
        sold: 0
      };
      sv[p] = (sv[p] || 0) + (threshold?.revenue || 0);
      if (saleMode === 'paused') flow.saleReason = 'برنامهٔ مخزنی سراسری خاموش بود و فروش آستانه‌ای اجرا نشد.';
      if (saleMode === 'hold') flow.saleReason = 'فروش روزانه برای این کالا آزاد نشده بود.';
      if (saleMode === 'off' && PR[p][3]) flow.saleReason = 'فروش خودکار این کالا خاموش بود.';
      if (PR[p][3]) {
        S.pm[p] = cl((S.pm[p] || 1) + (r() - 0.5) * 0.1, 0.5, 1.8);
        const strategy = cl(Number(S.salePrice?.[p]) || 1, 0.7, 1.5),
          baseDemand = marketBase[p] || 40;
        const demandFactor = cl(1.25 - (strategy - 1) * 0.78, 0.35, 1.45),
          shockFactor = S.economy?.shock?.type === 'demand' ? 0.72 : 1,
          demand = baseDemand * demandFactor * shockFactor;
        const unitPrice = PR[p][2] * S.pm[p] * strategy * fm * (S.mkt || 1);
        let revenue = 0;
        if (saleMode === 'legacy') {
          const reserve = S.marketAutomation?.rules?.[p]
            ? Math.max((150 * (1 + 0.5 * (S.tl?.[p] || 0)) * rule.reserve) / 100,
              (S.cs?.[p] || 0) + (dem[p] || 0), expectedProductNeed(S, p, IN))
            : 0;
          const available = Math.max(0, S.tanks[p] - reserve);
          const buyers = Math.max(0, demand - (autoDay.sold?.[p] || 0));
          if (unitPrice < rule.minSell) flow.saleReason = 'فروش متوقف شد چون قیمت از کف تعیین‌شده کمتر بود.';
          else if (autoDay.bought?.[p] > 0) flow.saleReason = 'موجودی خریداری‌شده در همین روز دوباره برای فروش روزانه عرضه نشد.';
          else if (available <= .001) flow.saleReason = S.tanks[p] > 0 ? 'موجودی برای ذخیرهٔ خوراک یا حداقل مخزن کنار گذاشته شد.' : 'در زمان فروش روزانه موجودی قابل عرضه باقی نماند.';
          else {
            flow.sold = Math.min(available, buyers, cp);
            flow.salePortLimited = cp < Math.min(available, buyers) - .001;
            if (flow.salePortLimited) flow.saleReason = 'ظرفیت باقی‌ماندهٔ بندر، مقدار قابل فروش را محدود کرد.';
            else if (buyers < available - .001) flow.saleReason = 'تقاضای باقی‌ماندهٔ بازار، مقدار قابل فروش را محدود کرد.';
            S.tanks[p] -= flow.sold;
            cp -= flow.sold;
            revenue = flow.sold * unitPrice;
            ex += revenue;
            sv[p] += revenue;
          }
        }
        Object.assign(flow, { demand, revenue, unitPrice, strategy });
      }
      const produced = S.pd[p] || 0;
      const allocated = produced > 0 ? Math.min(PR[p][2] * 1.8, sv[p] / produced) : 0;
      flow.inventoryValued = produced > 0 && PR[p][3] && ['hold', 'off'].includes(saleMode) && allocated < PR[p][2];
      S.rp[p] = flow.inventoryValued ? PR[p][2] : allocated;
      marketDay[p] = flow;
    }
    S.marketDay = marketDay;
    S.portRemainingToday = cp;
    S.portUsedToday = Math.max(0, (S.portCapacityToday ?? effectiveTradePort(S)) - cp);
    const beauty = appearanceBonus(S);
    if (sat.length)
      S.sat = 0.9 * S.sat + 0.1 * Math.min(100, (100 * sat.reduce((x, y) => x + y, 0)) / sat.length + beauty);
    else if (beauty > 0 && urban.population > 0)
      S.sat = 0.9 * S.sat + 0.1 * Math.min(100, 25 * (fr.power + fr.gas + fr.water + fr.fuel) + beauty);
    let pen = 0;
    if (S.day > 30 && S.sat < 35) {
      pen = 25;
      if (S.day % 10 === 0) log('نارضایتی شهروندان بالاست؛ اعتراض‌ها هزینه دارد.');
    }
    if (fr.power < 0.7 && dem.power && S.day % 7 === 0) log('خاموشی در شهر: برق کافی نیست.');
    collectUrbanWastewater(S, {
      urbanDemand: urban.demand.water || 0,
      housingDemand: S.grid.reduce(
        (n, b) => n + (b?.t === 'h' && b.c?.water ? (TY.h?.need?.water || 0) * b.l : 0),
        0
      ),
      deliveryRatio: fr.water
    });
    S.dem = dem;
    S.fr = fr;
    S.pop = pop;
    S.inc = { dom, tax, eco, ex, pen, ct: ctInc };
    return dom + tax + eco + ex - pen + ctInc;
  }
  return {
    country,
    setState(next) {
      S = next;
    }
  };
}
