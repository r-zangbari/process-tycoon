import { effectiveTradePort, remainingTradePort, tradeConditionsText } from '../features/products/model/trade-conditions.js';
// Read-only connection checks; never mutates game state or advances the simulation.
// Intended to surface actual dependencies, bottlenecks and currently simplified links.
export function auditSystemLinks(S) {
  const links = [];
  const add = (label, status, detail, next = '') => links.push({ label, status, detail, next });
  const units = Array.isArray(S.u) ? S.u : [];
  const active = units.filter(u => u.st === 'run');
  const oil = S.offshore?.oil || {}, gas = S.offshore?.gas || {};
  const feedUse = { crude: active.some(u => u.t === 0), sourgas: active.some(u => [2, 3].includes(u.t)) };
  for (const [key, o, p, used] of [['oil', oil, 'crude', feedUse.crude], ['gas', gas, 'sourgas', feedUse.sourgas]]) {
    const title = key === 'oil' ? 'نفت خام / سکوی نفتی' : 'گاز خام / سکوی گازی';
    if ((o.stage || 0) < 5) {
      add(title, used ? 'warn' : 'info', `استخراج فراساحلی قفل است (مرحله ${o.stage || 0} از ۵). ${used ? 'واحدهای فعال خوراک را از مخزن یا واردات فرایندی دریافت می‌کنند.' : 'تأمین خوراک در این مرحله مبتنی بر واردات است.'}`, 'ادامه اکتشاف و ساخت سکو در مدیریت فراساحلی.');
    }
    else if (!(o.pipelineLevel > 0)) {
      add(title, 'warn', 'سکو نصب شده ولی خط زیردریایی وجود ندارد؛ خوراک از بافر دریایی به خشکی منتقل نمی‌شود.', 'خط لوله سطح ۱ را احداث کنید.');
    }
    else if (o.incident || o.pipelineIsolated) {
      add(title, 'warn', 'به‌دلیل رخداد یا ESD، انتقال فراساحلی محدود/متوقف است.', 'رفع حادثه، پایان تعمیر و بازگشایی ایمن خط.');
    }
    else if (o.online === false || (o.reserveRemaining === 0 && !(o.buffer > 0))) {
      add(title, 'warn', o.reserveRemaining === 0 ? 'ذخیره برداشتنی و بافر میدان خالی است.' : 'تولید سکو متوقف است. انتقال فقط تا پایان موجودی بافر ادامه دارد.', 'وضعیت سکو، بافر و بخش‌های ذخیره را در مدیریت میادین بررسی کن.');
    }
    else if ((o.buffer || 0) > 0 && (S.tanks?.[p] || 0) >= 150 * (1 + .5 * (S.tl?.[p] || 0)) - .01) {
      add(title, 'warn', 'مخزن خشکی پر است؛ انتقال سکوی دریایی با گلوگاه ذخیره مواجه می‌شود.', 'مصرف/فروش خوراک یا ارتقای مخزن خشکی.');
    }
    else
      add(title, 'ok', `سکوی سطح عملیاتی فعال است و خط انتقال سطح ${o.pipelineLevel} دارد؛ ورود خوراک فقط از مسیر بافر و خط لوله انجام می‌شود.`);
  }
  const shortages = ['power', 'gas', 'water', 'fuel'].filter(p => (S.dem?.[p] || 0) > 0 && (S.fr?.[p] ?? 1) < .9);
  if (shortages.length) {
    const names = { power: 'برق', gas: 'گاز', water: 'آب', fuel: 'سوخت' };
    add('تأمین کشور', 'warn', `کسری خدمات: ${shortages.map(p => `${names[p]} ${Math.round((S.fr[p] || 0) * 100)}٪`).join('، ')}.`, 'افزایش تولید/موجودی و ارتقای شبکه توزیع.');
  }
  else if (Object.values(S.dem || {}).some(need => need > 0))
    add('تأمین کشور', 'ok', 'خدمات شهری از مخازن و شبکه‌های ملی تغذیه می‌شوند؛ ارتقای شبکه تلفات را کاهش می‌دهد.');
  else
    add('تأمین کشور', 'info', 'برای ارزیابی تحویل خدمات، یک روز بازی را ثبت کن.');
  const water = S.waterSupply?.today;
  const treatments = active.filter(u => u.t === 1);
  const rawWater = S.tanks?.rawwater || 0;
  const waterUsed = treatments.flatMap(u => u.dayEconomics?.day === S.day ? u.dayEconomics.feeds || [] : [])
    .filter(f => f.product === 'rawwater');
  const waterLacking = waterUsed.some(f => f.missing > 0.001);
  const number = n => Number(n).toLocaleString('fa-IR', { maximumFractionDigits: 1 });
  add('منابع آب خام ↔ تصفیه ↔ کشور', waterLacking ? 'warn' : waterUsed.length ? 'ok' : 'info',
    `موجودی آب خام ${number(rawWater)} · تصفیه‌خانه فعال ${number(treatments.length)}` +
    (water?.day === S.day ? ` · ورود آب خام از منابع و ذخیرهٔ ساحلی ${number((water.quantity || 0) - (water.coastalStored || 0) + (water.coastalDelivered || 0))}` : '') +
    (waterLacking ? ' · کسری خوراک در گزارش واحد ثبت شده است.' : ''),
    waterLacking ? 'منابع آب، مخزن آب خام و دفتر خوراک واحد تصفیه را مقایسه کن.' : '');
  const agriculture = (S.grid || []).filter(b => ['f', 'g', 'l', 'p'].includes(b?.t));
  if (agriculture.length) {
    const missingFeed = agriculture.some(b => b.t === 'l') && !agriculture.some(b => b.t === 'f');
    const missingInputs = agriculture.some(b => b.t === 'p') && !agriculture.some(b => b.t === 'f' || b.t === 'g');
    add('کشاورزی ↔ دام و فراوری', missingFeed || missingInputs ? 'warn' : 'info',
      missingFeed || missingInputs ? 'زنجیرهٔ غذا ساختمان لازم برای تأمین مواد اولیه را ندارد.' : 'خوراک دام و مواد ورودی فراوری از تولید همان روز و پس از تأمین خدمات می‌آیند.',
      missingFeed || missingInputs ? 'در قطب کشاورزی ساختمان‌های تأمین‌کننده را بساز و خدمات لازم را وصل کن.' : '');
  }
  const urban = S.urbanToday || {};
  add('شهرهای مستقل ↔ اقتصاد ملی', urban.developed > 0 ? 'ok' : 'info', urban.developed > 0 ? `${urban.developed} سطح توسعه افزوده شده؛ تقاضای خدمات، جمعیت و درآمد شهری در محاسبات ملی لحاظ می‌شوند.` : 'محله‌های اولیه به‌عنوان خط مبنا محسوب می‌شوند؛ ساخت و ارتقای شهرها تقاضا و مالیات ملی را تغییر می‌دهد.');
  const runningShort = active.filter(u => Number.isFinite(u.fs) && u.fs < .7);
  if (runningShort.length)
    add('خوراک واحدهای فرایندی', 'warn', `${runningShort.length} واحد فعال کمتر از ۷۰٪ خوراک موردنیاز را دریافت می‌کنند.`, 'موجودی خوراک، توان واردات و نقدینگی را بررسی کنید.');
  else
    add('خوراک واحدهای فرایندی', 'ok', 'برداشت از مخزن و واردات فرایندی بر اساس موجودی و بودجه خرید محاسبه می‌شود.');
  const port = effectiveTradePort(S), remaining = remainingTradePort(S);
  if (port <= 0 || remaining < port * .1)
    add('پایانه واردات / صادرات', 'warn', `تنها ${Math.round(remaining)} از ${Math.round(port)} واحد ظرفیت روزانه باقی مانده است.`, 'توسعه پایانه یا تغییر زمان‌بندی واردات/فروش.');
  else
    add('پایانه واردات / صادرات', 'ok', `ظرفیت باقی‌مانده روزانه ${number(remaining)} از ${number(port)} است. ${tradeConditionsText(S)}`);
  const contracts = Array.isArray(S.tradeContracts) ? S.tradeContracts : [];
  let totalDue = 0;
  const overbooked = [...contracts].sort((a, b) => a.days - b.days).some(c => {
    totalDue += c.remaining || 0;
    return totalDue > (c.days || 0) * port;
  });
  if (overbooked)
    add('تعهدات صادراتی', 'warn', 'مجموع تعهدهای هم‌زمان با ظرفیت مؤثر فعلی و مهلت تحویل سازگار نیست.', 'ظرفیت، اولویت تحویل و موجودی را در تجارت بررسی کن.');
  else
    add('تعهدات صادراتی', contracts.length ? 'ok' : 'info', contracts.length ? 'ظرفیت قابل استفاده پایانه برای زمان باقی‌مانده قراردادها کفایت دارد؛ موجودی باید جداگانه تأمین شود.' : 'قرارداد فعالی وجود ندارد.');
  if (S.money < 0)
    add('نقدینگی / تأمین مالی', 'warn', 'موجودی نقد منفی است؛ برخی خریدها ممکن نیستند اما هزینه‌های ثابت ادامه دارند.', 'توقف واحد زیان‌ده، مدیریت هزینه و وام/بازسازی اضطراری.');
  else
    add('نقدینگی / تأمین مالی', 'ok', 'سرمایه نقدی برای تصمیم‌گیری‌های بعدی قابل استفاده است؛ بودجه عمومی حسابی مجزا دارد.');
  if ((S.safe ?? 100) < 60)
    add('HSE و اپراتورها', 'warn', 'شاخص ایمنی پایین است و ریسک حوادث و هزینه‌های آن افزایش یافته است.', 'آموزش و اقدام HSE.');
  else
    add('HSE و اپراتورها', 'ok', 'آموزش، حوادث، سلامت تجهیزات و وضعیت نیروی انسانی در عملکرد بازی اثر دارند.');
  add('پروژه‌های توسعه ملی', 'info', 'در این نسخه بیشتر روی شاخص‌های ملی، امنیت تأمین و پایداری اثر می‌گذارند؛ تولید فیزیکی مستقلِ پروژه‌های ملی هنوز مدل نشده است.');
  return { links, issues: links.filter(x => x.status === 'warn').length };
}
