import { ALT, OPT } from '../../../data/catalog.js';

const n = v => (Number(v) || 0).toLocaleString('fa-IR', { maximumFractionDigits: 1 });
const outsideIndustry = {
  power: 'شبکهٔ کشور، انواع منابع آب خام و بازیافت کمکی سکوی گاز هم برق مصرف می‌کنند. مازاد برق می‌تواند از خط انتقال عبور کند.',
  gas: 'شبکهٔ کشور به شهرها و ساختمان‌های نیازمند گاز تحویل می‌دهد.',
  fuel: 'شهر و ساختمان‌های متصل قطب‌ها، از جمله مزرعه و گلخانه، از مخزن سوخت استفاده می‌کنند.',
  water: 'شهر، کشاورزی و دامداری از شبکهٔ آب استفاده می‌کنند. سکوی نفتی در بازیافت کمکی آب مصرف می‌کند.',
  steel: 'نصب تجهیزات پروژه‌های صنعتی از این مخزن مصالح برداشت می‌کند.',
  cement: 'نصب تجهیزات پروژه‌های صنعتی از این مخزن مصالح برداشت می‌کند.'
};
const outsideSupply = {
  rawwater: 'آب زیرزمینی، آب سطحی، بازچرخانی پساب شهری و آب‌شیرین‌کن کشور با خط انتقال متصل.',
  crude: 'سکوی نفتی فعال با بافر و خط زیردریایی متصل.',
  sourgas: 'سکوی گازی فعال با بافر و خط زیردریایی متصل.'
};

export function renderSupplyGuide(S, p, { D = [], PR, IN = [], OUT = [], cap }) {
  const producers = OUT.map((o, t) => ({ t, o })).filter(x => x.o[p] > 0), consumers = IN.map((o, t) => ({ t, o })).filter(x => x.o[p] > 0), stock = S.tanks[p] || 0;
  const unitLabel = t => D[t]?.n || 'واحد ' + (t + 1);
  const supplier = [
    ...producers.map(({ t, o }) => `${unitLabel(t)} (${n(o[p])} اسمی در روز)`),
    outsideSupply[p]
  ].filter(Boolean).join('، ') || 'این کالا تولیدکنندهٔ داخلی ثبت‌شده ندارد. برای تأمین، خرید را بررسی کن.';
  const usedFor = consumers.map(({ t, o }) => `${unitLabel(t)} (${n(o[p])} اسمی در روز، ${OPT[t]?.[p] ? 'کمکی' : 'الزامی'}${ALT[t]?.[p] ? '، جایگزین ' + PR[ALT[t][p]][0] : ''})`);
  const substitutes = Object.entries(ALT).flatMap(([t, inputs]) => Object.entries(inputs)
    .filter(([primary, substitute]) => substitute === p && IN[t]?.[primary])
    .map(([primary]) => unitLabel(Number(t)) + ' هنگام کسری ' + PR[primary][0]));
  const usage = [...usedFor, ...substitutes].join('، ');
  const flow = S.marketDay?.[p];
  const delivery = flow?.domesticDemand > 0 ? `تحویل امروز شبکه ${n(flow.domesticDelivered)} از ${n(flow.domesticDemand)} ${PR[p][1]}.` : '';
  const sales = PR[p][3] ? 'فروش دستی، آستانه‌ای، روزانه و قراردادی موجودی را کم می‌کنند.' : 'فروش دستی و آستانه‌ای در بازار ممکن است. فروش روزانهٔ صادراتی و قرارداد صادرات برای این کالا تعریف نشده‌اند.';
  return `<details class="supply-guide" id="supply-guide-${p}"><summary>راهنمای ${PR[p][0]} · از تأمین تا مصرف و فروش</summary>
  <div class="product-chain">
    <article><h4>تأمین</h4><p>${supplier}</p><p>بار، خوراک، اپراتور و کیفیت بر تولید واقعی اثر دارند.</p></article>
    <article><h4>مخزن مشترک</h4><p>موجودی ${n(stock)} از ${n(cap(p))} ${PR[p][1]}.</p><p>تولید پذیرفته‌شده و خرید مخزنی وارد موجودی می‌شوند. خرید فوری کسری، مستقیم در همان واحد مصرف می‌شود.</p></article>
    <article><h4>مصرف</h4>${usage ? `<p>${usage}</p>` : ''}${outsideIndustry[p] ? `<p>${outsideIndustry[p]}</p>` : ''}${delivery ? `<p>${delivery}</p>` : ''}${!usage && !outsideIndustry[p] ? '<p>مصرف‌کنندهٔ مستقیم در زنجیرهٔ تولید ثبت نشده است.</p>' : ''}</article>
    <article><h4>فروش و ذخیره</h4><p>${sales}</p><p>قبل از فروش، ذخیرهٔ مصرف‌کننده‌ها، تقاضا و ظرفیت حمل را ببین.</p></article>
  </div>
  <a class="guide-link" href="PRODUCTS-GUIDE-fa.html" target="_blank" rel="noopener">راهنمای کامل مدیریت محصولات و اثر بخش‌ها</a></details>`;
}
