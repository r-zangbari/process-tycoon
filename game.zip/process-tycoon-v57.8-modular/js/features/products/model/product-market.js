import { effectiveTradePort, importTradeFactor, remainingTradePort } from './trade-conditions.js';
// Immediate trades use real inventory, cash, daily buyer demand and the shared port.
export const LOCAL_PRODUCTS = new Set(['power', 'gas', 'water', 'rawwater', 'steam']);
const baseDemand = {
  methanol: 70, ethylene: 85, sulfur: 35, crude: 120, naphtha: 55, ammonia: 55, urea: 65, propane: 45, butane: 45, fueloil: 60, steel: 35, cement: 65
};
const positive = v => Number.isFinite(Number(v)) ? Math.max(0, Number(v)) : 0;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export function quoteProductTrade(S, p, side, quantity, { PR, cap, importMultiplier = 1.4, reservedPort = 0 }) {
  if (!Object.hasOwn(PR, p) || !['buy', 'sell'].includes(side))
    return { ok: false, quantity: 0, reason: 'محصول یا نوع معامله نامعتبر است.' };
  const requested = positive(quantity), base = PR[p][2], strategy = clamp(Number(S.salePrice?.[p]) || 1, .7, 1.5);
  const fx = S.fx || {}, fm = (fx.sanc ? .7 : 1) * (fx.spike ? 1.4 : 1) * (fx.exp ? 1.3 : 1) * (S.esg >= 70 ? 1.1 : S.esg < 40 ? .9 : 1) * (fx.rival ? .9 : 1);
  const sellPrice = base * (S.pm?.[p] || 1) * (S.mkt || 1) * (PR[p][3] ? strategy * fm : 1);
  const buyPrice = Math.max(sellPrice * 1.15, base * importMultiplier * importTradeFactor(S, p) * Math.max(1, (S.pm?.[p] || 1) * (S.mkt || 1)) * 1.22 * clamp(1 + ((S.economy?.inflation ?? 100) - 100) * .002, .9, 1.3) * (S.economy?.shock?.type === 'supply' ? 1.18 : 1));
  const price = side === 'buy' ? buyPrice : sellPrice, stock = positive(S.tanks?.[p]), free = Math.max(0, cap(p) - stock);
  const physicalPort = LOCAL_PRODUCTS.has(p) ? Infinity : remainingTradePort(S);
  const port = Math.max(0, physicalPort - reservedPort);
  const record = S.manualMarket?.day === S.day ? S.manualMarket : null;
  const demand = PR[p][3] ? (S.marketDay?.[p]?.demand ?? (baseDemand[p] || 40) * clamp(1.25 - (strategy - 1) * .78, .35, 1.45) * (S.economy?.shock?.type === 'demand' ? .72 : 1)) : 40;
  const remainingDemand = Math.max(0, demand - positive(S.marketDay?.[p]?.sold) - positive(record?.sold?.[p]) - positive(S.autoMarketDay?.day === S.day ? S.autoMarketDay.sold?.[p] : 0));
  const cash = positive(S.money) / price, limits = side === 'buy' ? [[free, 'فضای مخزن'], [cash, 'نقدینگی'], [port, 'ظرفیت بندر']] : [[stock, 'موجودی'], [remainingDemand, 'تقاضای باقی‌مانده بازار'], [port, 'ظرفیت بندر']];
  const quantityFilled = Math.floor(Math.min(requested, ...limits.map(([v]) => v)) * 1000) / 1000;
  const reasons = limits.filter(([v]) => v < requested - .001).map(([, label]) => label);
  return {
    ok: requested > 0 && quantityFilled > 0, product: p, side, requested, quantity: quantityFilled, price, total: quantityFilled * price, stock, free, port, physicalPort, remainingDemand, reason: requested <= 0 ? 'مقدار مثبت وارد کن.' : reasons.length ? 'محدودیت: ' + reasons.join('، ') : 'کل مقدار درخواستی قابل معامله است.'
  };
}
export function executeProductTrade(S, p, side, quantity, ctx) {
  const q = quoteProductTrade(S, p, side, quantity, ctx);
  if (!q.ok)
    return q;
  const key = ctx.source === 'auto' ? 'autoMarketDay' : 'manualMarket';
  if (!S[key] || S[key].day !== S.day)
    S[key] = { day: S.day, sold: {}, bought: {}, income: 0, expense: 0, spent: 0, emergency: {} };
  const m = S[key];
  m.sold ||= {};
  m.bought ||= {};
  S.tanks[p] = q.stock + (side === 'buy' ? q.quantity : -q.quantity);
  S.money += side === 'buy' ? -q.total : q.total;
  if (!LOCAL_PRODUCTS.has(p)) {
    S.portCapacityToday = effectiveTradePort(S);
    S.portRemainingToday = Math.max(0, q.physicalPort - q.quantity);
    S.portUsedToday = Math.max(0, S.portCapacityToday - S.portRemainingToday);
  }
  if (side === 'sell') {
    m.sold[p] = (m.sold[p] || 0) + q.quantity;
    m.income = (m.income || 0) + q.total;
  }
  else {
    m.bought[p] = (m.bought[p] || 0) + q.quantity;
    m.expense = (m.expense || 0) + q.total;
    if (ctx.source === 'auto')
      m.spent = (m.spent || 0) + q.total;
  }
  S.productTrades = Array.isArray(S.productTrades) ? S.productTrades : [];
  S.productTrades.unshift({
    day: S.day, source: ctx.source === 'auto' ? 'auto' : 'manual', product: p, side, quantity: q.quantity, price: q.price, total: q.total
  });
  S.productTrades.length = Math.min(40, S.productTrades.length);
  return q;
}
