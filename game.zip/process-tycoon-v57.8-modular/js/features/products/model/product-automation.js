import { ALT, ALTERNATIVE_FEED_FACTOR, OPT } from '../../../data/catalog.js';
import { LOCAL_TRADE } from './trade-conditions.js';
import { quoteProductTrade, executeProductTrade } from './product-market.js';
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const value = (v, f) => Number.isFinite(Number(v)) ? Number(v) : f;
export function automationSettings(S) {
  const a = S.marketAutomation || {};
  return {
    reserve: Math.max(0, value(a.reserve, 0)), dailyLimit: Math.max(0, value(a.dailyLimit, 0)), enabled: a.enabled !== false
  };
}
export function productRule(S, p, PR) {
  const a = S.marketAutomation?.rules?.[p] || {}, min = clamp(value(a.min, 20), 0, 80), max = clamp(value(a.max, 85), min + 10, 100);
  return {
    buy: a.buy === true, emergency: a.emergency !== false, sellMode: ['legacy', 'threshold', 'off'].includes(a.sellMode) ? a.sellMode : PR[p]?.[3] ? 'legacy' : 'off', min, target: clamp(value(a.target, 55), min + 5, max - 5), max, reserve: clamp(value(a.reserve, 30), 0, 100), maxBuy: Math.max(0, value(a.maxBuy, 0)), minSell: Math.max(0, value(a.minSell, 0)), quantityLimit: Math.max(0, value(a.quantityLimit, 0))
  };
}
export function productSaleMode(S, p, PR, rule = productRule(S, p, PR)) {
  if (rule.sellMode === 'threshold')
    return automationSettings(S).enabled ? 'threshold' : 'paused';
  if (rule.sellMode === 'legacy' && PR[p]?.[3])
    return S.hold?.[p] ? 'hold' : 'legacy';
  return 'off';
}
export const SALE_MODE_LABELS = {
  hold: 'فروش روزانه آزاد نشده',
  legacy: 'فروش روزانه',
  threshold: 'فروش مازاد در آستانه',
  paused: 'فروش آستانه‌ای متوقف در برنامهٔ سراسری',
  off: 'فروش خودکار خاموش'
};
export function saveProductRule(S, p, raw, PR) {
  if (!Object.hasOwn(PR, p))
    return false;
  S.marketAutomation ||= {};
  S.marketAutomation.rules ||= {};
  S.marketAutomation.rules[p] = raw;
  S.marketAutomation.rules[p] = productRule(S, p, PR);
  return true;
}
export function automationDay(S) {
  if (S.autoMarketDay?.day !== S.day)
    S.autoMarketDay = { day: S.day, sold: {}, bought: {}, income: 0, expense: 0, emergency: {}, spent: 0 };
  return S.autoMarketDay;
}
export function expectedProductNeed(S, p, IN) {
  const units = (S.u || []).filter(u => u.st === 'run');
  const need = (u, product) => (IN[u.t]?.[product] || 0) * (u.load || 100) / 100;
  const substituteFor = {};
  for (const u of units) {
    for (const [primary, substitute] of Object.entries(ALT[u.t] || {})) {
      if (substitute === p) substituteFor[primary] = (substituteFor[primary] || 0) + need(u, primary);
    }
  }
  let substituteNeed = 0;
  for (const [primary, limit] of Object.entries(substituteFor)) {
    const shortage = units.reduce((n, u) => n + need(u, primary), 0) - (S.tanks?.[primary] || 0);
    substituteNeed += Math.max(0, Math.min(limit, shortage)) / ALTERNATIVE_FEED_FACTOR;
  }
  return substituteNeed + Math.max(0, S.dem?.[p] || 0) + (S.ct || []).reduce((n, c) => n + (c.p === p ? c.q || 0 : 0), 0) + units.reduce((n, u) => n + need(u, p), 0);
}
function expectedOutput(S, p, OUT) {
  return (S.u || []).reduce((n, u) => n + (u.st === 'run' ? (OUT[u.t]?.[p] || 0) * (u.load || 100) / 100 * (1 + .35 * Math.max(0, (u.eq || []).reduce((a, e) => a + (e.l || 1), 0) / Math.max(1, u.eq?.length || 0) - 1)) : 0), 0);
}

export function requiredFeedPort(S, IN, PR, units = S.u || [], includeStockPurchases = true) {
  const inventory = { ...S.tanks };
  const missing = {};
  for (const u of units) {
    if (u.st !== 'run') continue;
    for (const [p, nominal] of Object.entries(IN[u.t] || {})) {
      if (OPT[u.t]?.[p]) continue;
      const need = nominal * (u.load || 100) / 100 * (S.tech?.heat ? .85 : 1);
      const own = Math.min(inventory[p] || 0, need);
      inventory[p] = (inventory[p] || 0) - own;
      const alt = ALT[u.t]?.[p];
      const substitute = alt ? Math.min(inventory[alt] || 0, (need - own) / ALTERNATIVE_FEED_FACTOR) : 0;
      if (alt) inventory[alt] = (inventory[alt] || 0) - substitute;
      const rule = productRule(S, p, PR);
      if (!LOCAL_TRADE.has(p) && (rule.emergency || (includeStockPurchases && rule.buy))) {
        missing[p] = (missing[p] || 0) + Math.max(0, need - own - substitute * ALTERNATIVE_FEED_FACTOR);
      }
    }
  }
  return missing;
}
const sumPort = (need, except) => Object.entries(need).reduce((total, [p, n]) => total + (p === except ? 0 : n), 0);

export function runProductAutomation(S, ctx) {
  const { PR, cap, IN = {}, OUT = {} } = ctx;
  S.marketAutomation ||= {};
  const program = S.marketAutomation;
  if (program.lastDay === S.day)
    return;
  program.lastDay = S.day;
  const settings = automationSettings(S), day = automationDay(S);
  S.autoTradeStatus = {};
  S.emergencyTradeStatus = {};
  if (!settings.enabled) {
    S.autoTradeStatus.global = 'خرید مخزنی و فروش آستانه‌ای متوقف‌اند؛ تأمین فوری هر محصول تنظیم مستقل دارد.';
    return;
  }
  const products = Object.keys(PR), status = (p, t) => {
    S.autoTradeStatus[p] = (S.autoTradeStatus[p] ? S.autoTradeStatus[p] + ' · ' : '') + t;
  };
  // Release storage before today's production; never sell the estimated next-day feed reserve.
  for (const p of products) {
    const a = productRule(S, p, PR);
    if (productSaleMode(S, p, PR, a) !== 'threshold')
      continue;
    day.saleAttempts ||= {};
    const record = (reason, receipt, portLimited = false) => {
      day.saleAttempts[p] = { reason, sold: receipt?.ok ? receipt.quantity : 0, revenue: receipt?.ok ? receipt.total : 0, portLimited };
      status(p, receipt?.ok ? 'فروش خودکار ' + receipt.quantity.toLocaleString('fa-IR', { maximumFractionDigits: 2 }) + '؛ ' + reason : reason);
    };
    const stock = S.tanks[p] || 0, c = cap(p), need = expectedProductNeed(S, p, IN), floor = Math.min(c, Math.max(c * a.reserve / 100, need)), incoming = expectedOutput(S, p, OUT);
    if (stock < c * a.max / 100 && stock + incoming <= c) {
      record('موجودی و تولید برآوردی هنوز به شرط فروش آستانه‌ای نرسیدند.');
      continue;
    }
    const qty = Math.max(0, Math.min(stock - floor, stock - c * a.target / 100, a.quantityLimit || Infinity));
    if (qty <= 0) {
      record('ذخیرهٔ خوراک یا موجودی هدف، مازاد قابل فروش باقی نگذاشت.');
      continue;
    }
    const quote = quoteProductTrade(S, p, 'sell', qty, ctx);
    if (quote.price < a.minSell) {
      record('فروش متوقف شد چون قیمت از کف تعیین‌شده کمتر بود.');
      continue;
    }
    const reservedPort = sumPort(requiredFeedPort(S, IN, PR));
    const r = executeProductTrade(S, p, 'sell', qty, { ...ctx, source: 'auto', reservedPort });
    const tradeable = Math.min(qty, r.stock, r.remainingDemand);
    const portLimited = r.port < tradeable - .001;
    const feedPriority = portLimited && r.physicalPort > r.port + .001;
    record(feedPriority ? 'بخشی از ظرفیت بندر برای خوراک ضروری کنار گذاشته شد.' : r.reason, r, portLimited);
  }
  // Buy urgent feed inventories first. The existing per-unit fallback consumes only any remaining deficit.
  products.sort((a, b) => expectedProductNeed(S, b, IN) - expectedProductNeed(S, a, IN));
  for (const p of products) {
    const a = productRule(S, p, PR);
    if (!a.buy)
      continue;
    const c = cap(p), stock = S.tanks[p] || 0, need = expectedProductNeed(S, p, IN);
    if (stock >= c * a.min / 100 && stock >= need) {
      status(p, 'خرید: موجودی بالاتر از حداقل است');
      continue;
    }
    if ((day.sold[p] || 0) > 0) {
      status(p, 'خرید پس از فروش همین روز انجام نمی‌شود');
      continue;
    }
    const qty = Math.max(0, Math.min(c, Math.max(c * a.target / 100, expectedProductNeed(S, p, IN))) - stock), q = quoteProductTrade(S, p, 'buy', qty, ctx);
    if (a.maxBuy > 0 && q.price > a.maxBuy) {
      status(p, 'خرید متوقف: قیمت بالاتر از سقف تعیین‌شده');
      continue;
    }
    const budget = Math.max(0, Math.min(S.money - settings.reserve, settings.dailyLimit > 0 ? settings.dailyLimit - day.spent : Infinity)), limit = a.quantityLimit || Infinity;
    const reservedPort = sumPort(requiredFeedPort(S, IN, PR), p);
    const r = executeProductTrade(S, p, 'buy', Math.min(qty, limit, budget / q.price), { ...ctx, source: 'auto', reservedPort });
    status(p, r.ok ? 'خرید خودکار ' + r.quantity.toLocaleString('fa-IR', { maximumFractionDigits: 2 }) + '؛ ' + r.reason : budget <= 0 ? 'خرید متوقف: ذخیره نقد یا سقف هزینه روزانه' : r.reason);
  }
}
export function emergencyImportAllowance(S, p, qty, price, PR) {
  const a = productRule(S, p, PR), settings = automationSettings(S), day = automationDay(S);
  S.emergencyTradeStatus ||= {};
  if (!a.emergency) {
    S.emergencyTradeStatus[p] = 'تأمین فوری خاموش است';
    return 0;
  }
  if (a.maxBuy > 0 && price > a.maxBuy) {
    S.emergencyTradeStatus[p] = 'تأمین فوری متوقف: قیمت واقعی بالاتر از سقف خرید';
    return 0;
  }
  const allowed = Math.max(0, Math.min(qty, settings.dailyLimit > 0 ? (settings.dailyLimit - day.spent) / price : Infinity));
  if (allowed < qty - .001)
    S.emergencyTradeStatus[p] = 'تأمین فوری محدود به سقف هزینه روزانه';
  return allowed;
}
export function recordEmergencyImport(S, p, qty, price) {
  if (qty <= 0)
    return;
  const d = automationDay(S);
  d.emergency ||= {};
  const e = d.emergency[p] || (d.emergency[p] = { quantity: 0, cost: 0 });
  e.quantity += qty;
  e.cost += qty * price;
  d.spent = (d.spent || 0) + qty * price;
}
