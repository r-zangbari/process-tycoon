import { fa } from '../../../core/format.js';

// Exact reconciliation of one simulation tick; internal inventory valuation is excluded from cash.
export function closeCashDay(S, opening, {
  sales = 0, publicTransfer = 0, contractExpense = 0, penalties = 0, debtInterest = 0
} = {}) {
  const current = (S.u || []).filter(u => u.dayEconomics?.day === S.day).map(u => u.dayEconomics), feed = current.reduce((n, e) => n + (e.costs?.feedImported || 0), 0), energy = current.reduce((n, e) => n + (e.costs?.energy || 0), 0), a = S.autoMarketDay?.day === S.day ? S.autoMarketDay : {}, stockBuy = a.expense || 0, stockSell = a.income || 0, water = S.waterSupply?.today?.day === S.day ? S.waterSupply.today.cost || 0 : 0, closing = S.money;
  S.cashDay = {
    day: S.day, opening, closing, stockBuy, stockSell, feed, energy, water,
    sales, publicTransfer, contractExpense, penalties, debtInterest,
    other: closing - opening + stockBuy - stockSell + feed + energy + water - sales
      + publicTransfer + contractExpense + penalties + debtInterest
  };
  return S.cashDay;
}

export const cashRows = [
  ['sales', 'درآمد فروش و تحویل', 1],
  ['stockSell', 'فروش آستانه‌ای', 1],
  ['publicTransfer', 'انتقال به بودجهٔ عمومی', -1],
  ['contractExpense', 'جریمه و بازپرداخت قرارداد', -1],
  ['penalties', 'جریمه‌های ایمنی و محیط‌زیست', -1],
  ['debtInterest', 'بهرهٔ وام', -1],
  ['stockBuy', 'خرید مخزنی خودکار', -1],
  ['feed', 'خوراک فوری واحدها', -1],
  ['energy', 'انرژی عملیاتی', -1],
  ['water', 'برداشت آب داخلی', -1]
];

export function cashSummary(S) {
  const c = S.cashDay;
  if (!c || c.day !== S.day) return null;
  const delta = c.closing - c.opening;
  const direction = Math.sign(delta);
  const factors = cashRows.filter(([key, , sign]) => sign === direction && c[key] > 0);
  const biggest = factors.sort(([a], [b]) => c[b] - c[a])[0];
  return { delta, reason: biggest ? biggest[1] + ' · ' + fa(c[biggest[0]]) : '' };
}

export function cashWarning(S) {
  const pending = [];
  const auditDays = 60 - S.day % 60;
  const environmentDays = 5 - S.day % 5;
  if (S.safe < 70 && auditDays <= 3)
    pending.push({ label: 'جریمهٔ احتمالی ممیزی ایمنی', amount: 1500, days: auditDays });
  if (S.esg < 30 && environmentDays <= 3)
    pending.push({ label: 'جریمهٔ احتمالی محیط‌زیست', amount: 500, days: environmentDays });
  for (const contract of S.tradeContracts || []) {
    if (contract.days > 3) continue;
    const amount = contract.remaining * contract.unitPrice * .18 + (contract.advanceBalance || 0);
    if (amount > 0)
      pending.push({ label: 'هزینهٔ احتمالی در صورت عدم تحویل قرارداد', amount, days: contract.days, projected: true });
  }
  return pending.sort((a, b) => a.days - b.days || b.amount - a.amount)[0];
}
