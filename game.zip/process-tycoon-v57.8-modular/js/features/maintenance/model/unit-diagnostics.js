import { hasEquipmentFaults } from './unit-recovery.js';
import { nextProjectStep } from '../../industry/model/project-progress.js';
import { OPTIONAL_FEED_EFFECT } from '../../../data/catalog.js';
import { unitName } from '../../../engine/unit-names.js';
const finite = v => Number.isFinite(v) ? v : 0;
const num = v => finite(v).toLocaleString('fa-IR', { maximumFractionDigits: 1 });
const issue = (code, priority, title, evidence, fix, target, index, product) => ({ code, priority, title, evidence, fix, target, index, product });
const EPSILON = 0.001;

function feedDiagnosis(feed, ledger, PR) {
  const [name, unit] = PR[feed.product];
  const coverage = Math.min(1, feed.delivered / feed.required);
  const quantities = `نیاز ${num(feed.required)}، تأمین ${num(feed.delivered)} و کسری ${num(feed.missing)} ${unit}.`;
  const constraints = [
    feed.policyLimited && (feed.policyReason || 'تنظیم تأمین فوری، خرید را محدود کرد'),
    feed.cashLimited && 'نقد قابل استفاده برای خرید کافی نبود',
    feed.portLimited && 'ظرفیت آزاد بندر برای تأمین کافی نبود'
  ].filter(Boolean).join(' · ');
  if (feed.optional) {
    if (ledger.factors.feed === 0 || !ledger.products.some(output => output.accepted > EPSILON && output.spilled <= EPSILON))
      return null;
    const factor = ledger.factors.optionalFeed ?? 1 - OPTIONAL_FEED_EFFECT * (1 - coverage);
    const effect = num(100 * (1 - factor));
    return {
      priority: 58,
      title: 'تأمین ناقص ' + name + ' کمکی',
      evidence: `${quantities} واحد با خوراک اصلی کار کرده و کسری خوراک کمکی، ضریب تولید را ${effect}٪ نسبت به تأمین کامل کاهش داده است. ${constraints}`,
      fix: 'پس از رفع گلوگاه‌های اصلی، هزینهٔ تأمین بیشتر را با ارزش خروجی اضافه مقایسه کن. پیش از تغییر برنامهٔ این محصول، نیاز واحدهای مصرف‌کنندهٔ دیگر را هم ببین.',
      target: 'inventory'
    };
  }
  const bottleneck = coverage <= (ledger.factors.feed ?? coverage) + EPSILON;
  return {
    priority: (bottleneck ? 94 : 84) + 4 * (1 - coverage),
    title: 'کسری ' + name + ' الزامی',
    evidence: `${quantities} ${bottleneck ? 'این کسری ضریب تأمین خوراک اصلی را محدود کرده است.' : 'این خوراک هم کسری دارد. فعلاً خوراک دیگری با پوشش کمتر، تولید را محدود می‌کند.'} ${constraints}`,
    fix: feed.cashLimited ? 'بودجهٔ خرید را در مالی و ذخیرهٔ نقد برنامهٔ خودکار بررسی کن.' :
      feed.portLimited ? 'در تجارت، ظرفیت مؤثر بندر و سهم قراردادها، خرید و فروش را بررسی کن.' :
      feed.policyLimited ? 'در تنظیمات همان محصول، فعال‌بودن تأمین فوری، سقف قیمت و سقف هزینهٔ روزانه را بررسی کن.' :
      'در کارت همین مخزن، موجودی، تولیدکننده‌های داخلی و راه تأمین خوراک را مقایسه کن.',
    target: feed.cashLimited ? 'finance' : feed.portLimited ? 'trade' : 'inventory'
  };
}

function productDiagnosis(S, output, ledger, PR) {
  const p = output.product, [name, unit, basePrice, exportable] = PR[p], m = (ledger.market || S.marketDay)?.[p];
  const port = ledger.port || { capacity: S.port, used: S.portUsedToday, remaining: S.portRemainingToday };
  const rate = `ارزش منتسب هر واحد ${num(output.unitValue)} از قیمت پایهٔ ${num(basePrice)}.`;
  if (!m?.saleMode) {
    const full = exportable && port.capacity > 0 && port.remaining <= EPSILON && port.used >= port.capacity - EPSILON;
    return {
      evidence: rate + (full ? ' ظرفیت بندر در پایان روز پر بوده؛ مانع فروش همین محصول در این گزارش ثبت نشده است.' : ' مسیر خروج این کالا در گزارش روز کامل ثبت نشده است.'),
      fix: full ? 'ظرفیت مؤثر بندر و سهم خرید، فروش و قراردادها را در تجارت مقایسه کن.' : 'موجودی، مسیرهای مصرف و برنامهٔ فروش را بررسی کن و یک روز تازه ثبت کن.',
      target: full ? 'trade' : 'inventory'
    };
  }
  const flows = [
    `برداشت از مخزن برای تولید ${num(m.industrialUse)}`,
    m.domesticDemand > 0 && `تحویل شبکه ${num(m.domesticDelivered)} از نیاز ${num(m.domesticDemand)}`,
    m.lineDelivered > 0 && `تحویل خط برق ${num(m.lineDelivered)}`,
    `فروش خودکار ${num((m.sold || 0) + (m.thresholdSold || 0))}`,
    m.contractDelivered > 0 && `تحویل قرارداد ${num(m.contractDelivered)}`
  ].filter(Boolean).join('، ');
  return {
    evidence: `${rate} ${flows} ${unit}. ${m.saleReason || ''}`,
    fix: m.salePortLimited ? 'در تجارت ببین چه مقدار از بندر صرف واردات یا تعهدهای قبلی شد و فروش را با ظرفیت مؤثر هماهنگ کن.' :
      m.saleMode === 'threshold' || m.saleMode === 'paused' || exportable ?
        'در کارت مخزن، حالت فروش، آستانه، کف قیمت، ذخیرهٔ خوراک و تقاضا را با نتیجهٔ همین روز مقایسه کن.' :
        `در راهنمای مخزن ${name}، مصرف‌کننده‌های فعال و فروش دستی را بررسی کن${p === 'power' ? ' و ظرفیت خط انتقال برق را ببین' : ''}.`,
    target: m.salePortLimited ? 'trade' : 'inventory'
  };
}

export function analyzeUnit(S, index, { D, PR }) {
  const u = S.u[index], d = D[u.t], running = u.st === 'run',
    ledger = running && u.dayEconomics?.day === S.day ? u.dayEconomics : null, causes = [];
  const name = unitName(u, D, index);
  if (nextProjectStep(u, d))
    return { index, name, ledger: null, causes, loss: false, recovering: false };
  const push = (code, priority, title, evidence, fix, target, product) => causes.push(issue(code, priority, title, evidence, fix, target, index, product));
  if (u.st === 'trip' || u.st === 'broken')
    push('trip', 110, 'واحد خارج از سرویس است', u.st === 'trip' ? 'حفاظت واحد عمل کرده است.' : hasEquipmentFaults(u) ? 'تجهیز اصلی یا رزرو خرابی ثبت‌شده دارد.' : 'خرابی تجهیز ثبت نشده است؛ واحد در انتظار تأیید بازگشت به سرویس مانده است.', u.st === 'broken' && !hasEquipmentFaults(u) ? 'در DCS موانع آمادگی را بررسی کن؛ اگر مانعی نیست «بازگشت به سرویس پس از بررسی» را بزن. تعمیر یا خرید قطعه اضافی لازم نیست.' : 'پیش از راه‌اندازی مجدد، آلارم، باز بودن مسیر و آماده بودن تجهیزات را بررسی و علت را رفع کن.', 'controls');
  if (u.processState?.valveOpen === false && (running || u.st === 'trip' || u.st === 'broken'))
    push('isolation', 108, 'شیر ورودی بسته است', 'XV-101 مسیر ورودی را ایزوله کرده است.', 'در DCS علت ایزوله‌سازی را بررسی کن؛ فقط پس از رفع علت و تأیید آماده‌بودن مسیر، فرمان مناسب را بده.', 'controls');
  (u.eq || []).forEach((e, j) => {
    if (e.f || e.reserve?.f) {
      const f = e.f || e.reserve.f;
      push('equipment-' + j, 109, 'خرابی ' + d.e[j][0], f.st === 0 ? 'قطعه هنوز سفارش نشده است.' : f.st === 1 ? 'قطعه در مسیر است؛ زمان رسیدن ' + num(f.eta) + ' روز.' : 'قطعه رسیده و تعمیر در انتظار اقدام است.', f.st === 0 ? 'در مدیریت واحد قطعه را سفارش بده و هزینه و زمان ارسال را بررسی کن.' : f.st === 1 ? 'تا رسیدن قطعه وضعیت رزرو و سلامت آن را پایش کن.' : 'در مدیریت واحد تعمیر تجهیز را تکمیل و سپس آماده‌بودن آن را بررسی کن.', u.maintenance?.owned && u.maintenance?.enabled ? 'maintenance' : 'unit');
    }
  });
  for (const [k, variable] of (running ? d.v : []).entries()) {
    const pv = u.v?.[k], span = variable[3];
    if (Number.isFinite(pv) && span > 0 && Math.abs(pv - variable[2]) / span > 1.3)
      push('deviation-' + k, Math.abs(pv - variable[2]) / span > 2.5 ? 106 : 90, 'انحراف ' + variable[0], `مقدار فعلی ${num(pv)} ${variable[1]}؛ هدف طراحی ${num(variable[2])}؛ نیم‌پهنای باند ${num(span)}.`, 'در DCS مقدار PV، هدف SP، حالت حلقه و علت اختلال را بررسی کن. جهت حرکت محرک را از نوع آن تعیین کن؛ فرمان افزایش یا کاهش کورکورانه پیشنهاد نمی‌شود.', 'controls');
  }
  if (ledger) {
    for (const feed of ledger.feeds) {
      if (feed.missing <= EPSILON || !PR[feed.product] || !(feed.required > 0)) continue;
      const finding = feedDiagnosis(feed, ledger, PR);
      if (finding) push('feed-' + feed.product, finding.priority, finding.title, finding.evidence, finding.fix, finding.target, feed.product);
    }
    for (const output of ledger.products) {
      if (output.spilled > EPSILON) {
        const m = ledger.market?.[output.product];
        const fix = m?.salePortLimited
          ? 'در تجارت، ظرفیت مؤثر بندر و سهم واردات و قراردادها را ببین. برای روز بعد، فضای آزاد مخزن را با تولید برنامه‌ریزی‌شده مقایسه کن.'
          : 'در کارت همین محصول، فضای مخزن، فروش مازاد و نیاز واحدهای مصرف‌کننده را بررسی کن. اگر تخلیه کافی نیست، ظرفیت مخزن را افزایش بده یا بار واحد را با خروجی قابل جذب هماهنگ کن.';
        push('storage-' + output.product, 96, 'کمبود فضای مخزن ' + PR[output.product][0], `از ${num(output.requested)} تولید، ${num(output.accepted)} ذخیره شد و ${num(output.spilled)} به‌علت نبود جا از دست رفت. ${m?.saleReason || ''}`, fix, m?.salePortLimited ? 'trade' : 'inventory', output.product);
      }
    }
    if (ledger.factors.availableOperators < ledger.factors.requiredOperators && ledger.factors.operator < .999)
      push('operators', 93, 'کمبود اپراتور در واحدهای فعال', `نیروی در دسترس ${num(ledger.factors.availableOperators)} از ${num(ledger.factors.requiredOperators)} مورد نیاز؛ ضریب تولید ناشی از نیروی انسانی ${num(ledger.factors.operator * 100)}٪.`, 'در منابع انسانی، تعداد نیروی حاضر، مصدوم، اعتصاب و نیاز واحدهای فعال را بررسی کن؛ سپس استخدام یا برنامه سرویس واحدها را اصلاح کن.', 'personnel');
    if (ledger.factors.strike < 1)
      push('strike', 99, 'اعتصاب ظرفیت تولید را کم کرده است', `ضریب تولید ناشی از اعتصاب ${num(ledger.factors.strike * 100)}٪ است.`, 'در منابع انسانی مذاکره یا تأمین نیروی موقت را بررسی کن.', 'personnel');
    if (ledger.factors.feedIncident < 1)
      push('feed-incident', 95, 'اختلال عملیاتی خوراک ثبت شده است', `ضریب تولید ناشی از رخداد خوراک ${num(ledger.factors.feedIncident * 100)}٪.`, 'در تصمیم بحران، وضعیت رخداد و اقدام‌های مربوط به خوراک را بررسی کن.', 'crisis');
    if (ledger.factors.story < 1)
      push('story-incident', 96, 'بحران داستانی ظرفیت تولید را کم کرده است', `ظرفیت این روز به ${num(ledger.factors.story * 100)}٪ رسید.`, 'از «توسعه کشور» مدت اختلال و امکان رزرو خدمات جایگزین را بررسی کن.', 'development');
    if (ledger.factors.grid < 1)
      push('grid-incident', 95, 'اختلال شبکه تولید را محدود کرده است', `ضریب شبکه ${num(ledger.factors.grid * 100)}٪؛ این افت ناشی از خرید خوراک نیست.`, 'در تصمیم بحران اختلال شبکه و زمان باقی‌مانده را بررسی کن.', 'crisis');
    if (ledger.factors.avgHealth < 70)
      push('wear', 82, 'فرسودگی تجهیزات مصرف انرژی را افزایش داده است', `میانگین سلامت تجهیزات ${num(ledger.factors.avgHealth)}٪؛ هزینه انرژی روز ${num(ledger.costs.energy)}.`, 'در مدیریت واحد وضعیت تجهیزات و هزینه سرویس را بررسی کن؛ سرویس بدون رفع خرابی قطعه جایگزین تعمیر نیست.', 'unit');
    if (ledger.factors.quality < 85)
      push('quality', 83, 'کیفیت محصول پایین است', `کیفیت ${num(ledger.factors.quality)}٪؛ ضریب خروجی ناشی از کیفیت ${num(ledger.factors.qualityFactor * 100)}٪.`, 'در DCS انحراف PV از محدوده طراحی، وضعیت کنترلرها، اضافه‌بار و سلامت تجهیز را بررسی کن؛ خرید خوراک گران‌تر به‌تنهایی تضمین سود نیست.', 'controls');
    if (ledger.factors.capacityUse > 100)
      push('overload', 88, 'بار بالاتر از ظرفیت نامی تجهیزات', `بهره‌برداری ظرفیت ${num(ledger.factors.capacityUse)}٪؛ هزینه انرژی ${num(ledger.costs.energy)}.`, 'بار را در DCS با ظرفیت نامی هماهنگ کن؛ سپس تغییر تولید، کیفیت و هزینه انرژی را در روز بعد مقایسه کن.', 'controls');
    if (ledger.costs.feedImported > 0 && ledger.profit < 0) {
      const top = ledger.feeds.filter(f => f.importCost > 0).sort((a, b) => b.importCost - a.importCost)[0];
      const share = top && PR[top.product]
        ? ` بیشترین سهم خرید فوری مربوط به ${PR[top.product][0]} بود، ${num(top.importCost)} واحد هزینه.` : '';
      push('import-cost', 76, 'هزینهٔ خرید فوری خوراک', `خرید خوراک ${num(ledger.costs.feedImported)} از هزینهٔ کل ${num(ledger.totalCost)} را تشکیل داده است.${share}`, 'در کارت محصول مصرف و قیمت خرید را ببین. هزینهٔ تأمین داخلی و ارزش خروجی را با هزینهٔ خرید فوری مقایسه کن.', 'inventory', top?.product);
    }
    const low = ledger.products.filter(p => p.accepted > EPSILON && p.valuation !== 'inventory' && p.unitValue < PR[p.product][2] * .3);
    for (const product of low) {
      const p = product.product, finding = productDiagnosis(S, product, ledger, PR);
      push('realization-' + p, PR[p][3] ? 82 : 78, 'درآمد منتسب کم برای ' + PR[p][0], finding.evidence, finding.fix, finding.target, p);
    }
    if (ledger.profit < 0)
      push('cost-gap', 60, 'درآمد منتسب امروز هزینه را پوشش نداده است', `${num(ledger.revenue)} درآمد منتسب − ${num(ledger.totalCost)} هزینه = ${num(ledger.profit)} نتیجه امروز.`, 'ردیف‌های هزینه و عوامل ثبت‌شده را به ترتیب اولویت بررسی کن. اگر با رفع گلوگاه‌ها زیان ادامه داشت، بار یا برنامه سرویس را با مقایسه نتیجه روز بعد تغییر بده.', 'controls');
    if (ledger.profit >= 0 && u.pl < 0)
      push('recovering', 42, 'نتیجه امروز بهتر شده؛ میانگین هنوز منفی است', `نتیجه امروز ${num(ledger.profit)}؛ میانگین هموارشده ${num(u.pl)}.`, 'چند روز نتیجه را پایش کن؛ میانگین با تأخیر بهبود می‌یابد. صرفاً به علت منفی ماندن میانگین، توقف پیشنهاد نمی‌شود.', 'controls');
  }
  else if (u.st === 'run' && u.pl < 0)
    push('missing-ledger', 74, 'برای علت دقیق، یک روز داده تازه لازم است', 'این ذخیره میانگین سود دارد ولی ریز تسویه مربوط به روز جاری ثبت نشده است.', 'زمان را یک روز ادامه بده؛ سپس گزارش درآمد، خوراک، هزینه و تولید ازدست‌رفته همین واحد را دوباره باز کن.', 'time');
  causes.sort((a, b) => b.priority - a.priority);
  return {
    index, name, ledger, causes, primary: causes[0], loss: running && (u.pl < 0 || ledger?.profit < 0), recovering: ledger?.profit >= 0 && u.pl < 0
  };
}
export function recommendations(S, ctx) {
  const reports = S.u.map((_, i) => analyzeUnit(S, i, ctx)), items = [];
  if (S.cr)
    items.push(issue('crisis', 130, 'بحران فعال نیاز به تصمیم دارد', 'رخداد عملیاتی هنوز بسته نشده است.', 'شرح رخداد و پیامد هر گزینه را بخوان و اقدام مناسب را انتخاب کن؛ پیش از رفع علت، راه‌اندازی مجدد نکن.', 'crisis'));
  for (const report of reports) {
    const p = report.primary;
    if (p && (report.loss || p.priority >= 88 || ['trip', 'broken'].includes(S.u[report.index].st)))
      items.push({ ...p, title: report.name + '؛ ' + p.title });
  }
  if (S.money < 0)
    items.push(issue('cash', 101, 'نقد شرکت منفی است', `کسری نقد ${num(-S.money)}؛ بدهی ${num(S.debt)}.`, 'در مالی، هزینه جاری و تعهدات را بررسی کن. وام هزینه بهره دارد و علت زیان عملیاتی را رفع نمی‌کند.', 'finance'));
  S.u.forEach((u, i) => {
    const step = nextProjectStep(u, ctx.D[u.t]);
    if (step) items.push({
      ...issue('project-' + i, 35, unitName(u, ctx.D, i), step.text, '', 'project', i),
      label: step.label
    });
  });
  return { reports, items: items.sort((a, b) => b.priority - a.priority) };
}
