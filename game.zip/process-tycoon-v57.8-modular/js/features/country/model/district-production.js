export function settleDistrictProduction(S, fr, buildingTypes, markets) {
  let eco = 0,
    tax = 0,
    pop = 0;
  const sat = [];
  // Farm-to-food chain: farms and greenhouses grow, livestock eats crops, the food plant processes whatever is in the pool.
  const pool = { crop: 0, veg: 0, meat: 0 },
    sell = (k, q) => {
      S.pd[k] = (S.pd[k] || 0) + q;
      eco += q * markets[k][1] * (S.pm[k] || 1);
    },
    eat = (k, q) => {
      pool[k] -= q;
      S.pd[k] = Math.max(0, (S.pd[k] || 0) - q);
      eco -= q * markets[k][1] * (S.pm[k] || 1);
    };
  for (const stage of [0, 1, 2])
    S.grid.forEach((b) => {
      if (!b) return;
      const t = buildingTypes[b.t];
      if ((b.t === 'l' ? 1 : b.t === 'p' ? 2 : 0) !== stage) return;
      const ks = Object.keys(t.need),
        m = ks.map((p) => (b.c[p] ? fr[p] : 0));
      if (b.t === 'h') {
        const a = m.reduce((x, y) => x + y, 0) / ks.length;
        tax += t.tax * b.l * a;
        pop += 4 * b.l;
        sat.push(a);
      } else if (b.t === 'l') {
        const cap = Math.min(...m),
          need = t.feed * b.l * cap,
          used = Math.min(need, pool.crop);
        if (used > 0) eat('crop', used);
        const q = t.q * b.l * cap * (need ? used / need : 1);
        sell(t.key, q);
        pool.meat += q;
      } else if (b.t === 'p') {
        const cap = Math.min(...m),
          need = t.inputs * b.l * cap;
        let got = 0;
        for (const k of ['crop', 'veg', 'meat']) {
          const u = Math.min(need - got, pool[k]);
          if (u > 0) {
            eat(k, u);
            got += u;
          }
        }
        sell(t.key, t.q * b.l * cap * (need ? got / need : 1));
      } else {
        const q = t.q * b.l * Math.min(...m);
        sell(t.key, q);
        if (t.key in pool) pool[t.key] += q;
      }
    });
  return { eco, tax, pop, sat };
}
