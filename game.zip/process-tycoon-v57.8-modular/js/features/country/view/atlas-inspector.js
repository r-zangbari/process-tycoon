import { DISTRICTS } from '../model/country-planning.js';
import { renderCountryNetwork } from './map-operations.js';
import { renderWaterSource } from '../../water/view/water-supply.js';
import { districtStatus } from './map-design.js';
import { mapButton as btn } from './map-button.js';

export function renderAtlasInspector(S, CITIES, selected) {
  let panel;
  const enter = selected.water
    ? ''
    : selected.city != null
      ? btn('city-enter', 'ورود به شهر', `data-i="${selected.city}"`)
      : ['oil', 'gas'].includes(selected.id)
        ? btn('atlas-offshore', 'اکتشاف و بهره‌برداری')
        : btn('hub-open', 'ورود به قطب', `data-k="${selected.id}"`);
  panel = `<small>مقصد انتخاب‌شده</small><h2>${selected.name}</h2><p>${selected.description}</p><p class="map-district-status">${districtStatus(S, selected)}</p>${enter}<hr><h3>مقصدهای کشور</h3><div class="atlas-destinations">${DISTRICTS.map((d) => btn('atlas-select', d.name, `data-k="${d.id}" aria-pressed="${selected.id === d.id}"`)).join('')}</div>${selected.water ? renderWaterSource(S, selected.water) : ''}<h3>شهرهای مستقل</h3><div class="atlas-destinations">${CITIES.map((c, i) => btn('city-enter', c.name, `data-i="${i}"`)).join('')}</div><p class="muted">انتخاب روی نقشه یا این فهرست؛ سپس ورود به مقصد. خطوط رنگی مسیر ارتباط را نشان می‌دهند؛ مقدار واقعی تحویل در جدول خدمات است.</p>`;
  if (S.mapLayer === 'services')
    panel =
      renderCountryNetwork(S) +
      (selected.water
        ? renderWaterSource(S, selected.water)
        : '<details><summary>مدیریت مقصد جغرافیایی</summary>' + panel + '</details>');
  else if (selected.water)
    panel =
      renderWaterSource(S, selected.water) +
      `<details><summary>مقصدهای دیگر کشور</summary><div class="atlas-destinations">${DISTRICTS.map((d) => btn('atlas-select', d.name, `data-k="${d.id}"`)).join('')}</div></details>`;
  return panel;
}
