// اکشن‌های کشور: اطلس، قطب‌ها، شهرها، مناطق و آب.
import { NETWORKS, countryNetwork } from './view/map-operations.js';
import { CELL, GH, GW, TY } from '../../data/catalog.js';
import { createStarterCityGrid } from './model/urban-economy.js';
import { LANDMARKS, cityDesign } from '../legacy/model/legacy-development.js';
import { rememberCityMove, undoCityMove } from './model/city-move-history.js';
import { districtLots, HUB_TYPES } from './model/country-planning.js';
import { waterAction, waterNetwork } from '../water/model/water-supply.js';
import { countryCamera, retryCountryRenderer } from './view/country-scene.js';
import { cl, f1, fa } from '../../core/format.js';
import { CITIES, REGIONS } from '../../data/world-map.js';
export function installCountryActions(game) {
  const { S, log, pay, save } = game;
  Object.assign(game.actions, {
    'ops-close'() {
      game.ui.mapSheetOpen = false;
    },
    'ops-show'() {
      game.ui.mapSheetOpen = true;
    },
    'country-expand'() {
      game.ui.countryExpanded = !game.ui.countryExpanded;
      game.ui.mapSheetOpen = false;
    },
    'country-pause'() {
      game.togglePause();
    },
    'map-graphics'() {
      const host = document.getElementById(S.tab === 'site' ? 'industry-three' : 'country-three');
      S.mapGraphics = host?.dataset.renderer === 'webgl' ? 'lite' : 'auto';
      retryCountryRenderer();
    },
    'ops-network'(x) {
      if (Object.hasOwn(NETWORKS, x.k)) {
        S.mapLayer = 'services';
        S.mapNetwork = x.k;
        S.mapStep = null;
        game.ui.mapSheetOpen = false;
      }
    },
    'ops-step'(x) {
      if (countryNetwork(S).steps.some(p => p.id === x.k)) {
        S.mapStep = x.k;
        game.ui.mapSheetOpen = true;
      }
    },
    'ops-treatment'() {
      const i = S.u.findIndex(u => u.t === 1 && u.st === 'run');
      const unit = i >= 0 ? i : S.u.findIndex(u => u.t === 1);
      if (unit >= 0) {
        S.tab = 'site';
        S.siteMapPage = Math.floor(unit / 12);
        S.siteSelectedUnit = unit;
        game.ui.mapSheetOpen = true;
      }
      else {
        S.tab = 'i';
        S.industrySection = 'catalog';
        S.projectType = 1;
        game.ui.mapSheetOpen = false;
      }
    },
    zin() {
      game.zoomAt(1.35, GW * CELL / 2, GH * CELL / 2);
    },
    zout() {
      game.zoomAt(1 / 1.35, GW * CELL / 2, GH * CELL / 2);
    },
    zreset() {
      S.cam = { x: 0, y: 0, k: 1 };
      game.camApply();
    },
    'map-3d'() {
      S.map3d = !S.map3d;
      const box = document.getElementById('mapbox');
      if (box)
        box.classList.toggle('map-3d', !!S.map3d);
      const toggle = box?.querySelector('[data-a=\"map-3d\"]');
      if (toggle) {
        toggle.textContent = S.map3d ? '۲بعدی' : '۳بعدی';
        toggle.setAttribute('aria-pressed', String(!!S.map3d));
      }
      log(S.map3d ? 'نمای برجسته سه‌بعدی نقشه فعال شد.' : 'نمای دوبعدی نقشه فعال شد.');
    },
    'economic-relief'() {
      if ((S.govBudget || 0) < 2500) {
        log('بودجه عمومی برای بسته حمایتی کافی نیست.');
        return;
      }
      S.govBudget -= 2500;
      S.sat = cl((S.sat || 70) + 5, 0, 100);
      S.economy = S.economy || {};
      S.economy.relief = 3;
      S.economy.stability = cl((S.economy.stability ?? 75) + 3, 0, 100);
      log('بسته حمایتی عمومی اجرا شد؛ رضایت و ثبات اقتصادی موقتاً تقویت شد. هزینه: ۲٬۵۰۰ از بودجه عمومی.');
    },
    'gov-rate'(x) {
      S.govRate = cl((Number(S.govRate) || 1) + Number(x.d), .5, 1.5);
      S.govRate = Math.round(S.govRate * 10) / 10;
      log('ضریب اخذ مالیات و عوارض ملی روی ×' + f1(S.govRate) + ' تنظیم شد.');
    },
    'national-build'(x) {
      const p = x.p, defs = {
        refinery: ['پالایشگاه ملی', 12000], power: ['نیروگاه ملی', 16000], petrochem: ['مجتمع پتروشیمی', 18000], pipeline: ['خطوط انتقال سراسری', 9000]
      }, d = defs[p];
      if (!d)
        return;
      S.nationalProjects = S.nationalProjects || {};
      const lv = S.nationalProjects[p] || 0;
      if (lv >= 3) {
        log('این زیرساخت به حداکثر سطح توسعه رسیده است.');
        return;
      }
      const cost = d[1] * (lv + 1);
      if ((S.govBudget || 0) < cost) {
        log('بودجه عمومی برای اجرای این پروژه کافی نیست.');
        return;
      }
      S.govBudget -= cost;
      S.nationalProjects[p] = lv + 1;
      log(`${d[0]} به سطح ${fa(lv + 1)} توسعه یافت؛ هزینه ${fa(cost)} از بودجه عمومی پرداخت شد.`);
    },
    'map-deselect'() {
      S.sel = null;
      S.citySelected = null;
    },
    'city-deselect'() {
      S.citySelected = null;
    },
    'city-upgrade'(x) {
      const city = CITIES[Number(x.i)];
      if (!city)
        return;
      S.cities = S.cities || {};
      const state = S.cities[city.name] || (S.cities[city.name] = { level: 0, satisfaction: 70 }), lv = Number(state.level) || 0, cost = 6000 * (lv + 1);
      if (lv >= 3) {
        log(`خدمات شهری «${city.name}» به حداکثر سطح رسیده است.`);
        return;
      }
      if ((S.govBudget || 0) < cost) {
        log('بودجه عمومی برای ارتقای خدمات این شهر کافی نیست.');
        return;
      }
      S.govBudget -= cost;
      state.level = lv + 1;
      state.satisfaction = cl((state.satisfaction ?? 70) + 4, 0, 100);
      S.regions = S.regions || {};
      const rs = S.regions[city.region] || (S.regions[city.region] = { investment: 0, satisfaction: 70 });
      rs.satisfaction = cl((rs.satisfaction ?? 70) + 2, 0, 100);
      log(`خدمات شهری «${city.name}» به سطح ${fa(lv + 1)} ارتقا یافت؛ هزینه ${fa(cost)} از بودجه عمومی.`);
    },
    'city-enter'(x) {
      game.ui.mapSheetOpen = false;
      const i = Number(x.i);
      if (!Number.isInteger(i) || !CITIES[i])
        return;
      S.offshoreView = false;
      S.offshoreSelected = null;
      S.cityView = i;
      S.cityCell = null;
      S.cityMapPage = 0;
      S.cityMaps = S.cityMaps || {};
      if (!Array.isArray(S.cityMaps[CITIES[i].name]))
        S.cityMaps[CITIES[i].name] = createStarterCityGrid();
      S.cityCam = S.cityCam || { x: 0, y: 0, k: 1 };
      log(`وارد نقشه مستقل شهر «${CITIES[i].name}» شدید.`);
    },
    'city-exit'() {
      game.ui.cityMoveCell = null;
      game.ui.cityBuildingDrag = null;
      S.cityView = null;
      S.cityCell = null;
    },
    'city-map-page'(x) {
      game.ui.cityMoveCell = null;
      const next = Math.max(0, Math.min(3, (Number(S.cityMapPage) || 0) + Number(x.d || 0)));
      S.cityMapPage = next;
      S.cityCell = null;
    },
    'city-cell'(x) {
      game.ui.mapSheetOpen = true;
      game.ui.cityMoveCell = null;
      const i = Number(x.i);
      if (Number.isInteger(i) && i >= 0 && i < 81)
        S.cityCell = i;
    },
    'city-build'(x) {
      const i = Number(S.cityView), cell = Number(S.cityCell), city = CITIES[i];
      if (!city || !Number.isInteger(cell) || cell < 0 || cell >= 81)
        return;
      S.cityMaps = S.cityMaps || {};
      const grid = S.cityMaps[city.name] || (S.cityMaps[city.name] = Array(81).fill(null));
      if (grid[cell] || LANDMARKS[cityDesign(S, city.name).placements[cell]?.item])
        return;
      const defs = {
        home: ['خانه مسکونی', 850], shop: ['مرکز تجاری', 1250], service: ['مرکز خدماتی', 2100], park: ['پارک شهری', 650]
      }, d = defs[x.t];
      if (!d)
        return;
      if ((S.govBudget || 0) < d[1]) {
        log('بودجه عمومی برای ساخت این مجموعه شهری کافی نیست.');
        return;
      }
      S.govBudget -= d[1];
      grid[cell] = { type: x.t, level: 1 };
      const st = S.cities?.[city.name] || (S.cities[city.name] = { level: 0, satisfaction: 70 });
      if (x.t === 'service')
        st.satisfaction = cl((st.satisfaction ?? 70) + 1.5, 0, 100);
      if (x.t === 'park')
        st.satisfaction = cl((st.satisfaction ?? 70) + 1, 0, 100);
      log(`${d[0]} در شهر «${city.name}» ساخته شد؛ هزینه ${fa(d[1])} از بودجه عمومی.`);
    },
    'city-building-undo'() {
      const city = CITIES[Number(S.cityView)];
      if (city && undoCityMove(S, city.name)) {
        game.ui.cityMoveCell = null;
        game.ui.cityBuildingDrag = null;
        log('آخرین جابه‌جایی ساختمان در این شهر بازگردانده شد.');
      }
    },
    'city-building-move'() {
      const city = CITIES[Number(S.cityView)];
      const cell = Number(S.cityCell);
      if (!city || !S.cityMaps?.[city.name]?.[cell])
        return;
      game.ui.cityMoveCell = game.ui.cityMoveCell === cell ? null : cell;
      game.ui.cityBuildingDrag = null;
    },
    'city-building-nudge'(x) {
      const city = CITIES[Number(S.cityView)], cell = Number(S.cityCell);
      if (!city || game.ui.cityMoveCell !== cell)
        return;
      const p = game.cityBuildingPos(city.name, cell);
      game.setCityBuildingPos(city.name, cell, p[0] + Number(x.dx || 0), p[1] + Number(x.dy || 0));
    },
    'city-building-reset-position'() {
      const city = CITIES[Number(S.cityView)], cell = Number(S.cityCell);
      if (!city || game.ui.cityMoveCell !== cell)
        return;
      rememberCityMove(S, city.name, cell, game.cityBuildingPos(city.name, cell));
      if (S.cityBuildingPositions?.[city.name])
        delete S.cityBuildingPositions[city.name][cell];
    },
    'city-building-upgrade'() {
      const i = Number(S.cityView), cell = Number(S.cityCell), city = CITIES[i], grid = city && S.cityMaps?.[city.name], b = grid?.[cell];
      if (!b || b.level >= 3)
        return;
      const costs = { home: 500, shop: 750, service: 1200, park: 350 }, cost = costs[b.type] * b.level;
      if ((S.govBudget || 0) < cost) {
        log('بودجه عمومی برای ارتقای این ساختمان کافی نیست.');
        return;
      }
      S.govBudget -= cost;
      b.level++;
      if (b.type === 'service' || b.type === 'park') {
        const st = S.cities?.[city.name] || (S.cities[city.name] = { level: 0, satisfaction: 70 });
        st.satisfaction = cl((st.satisfaction ?? 70) + .8, 0, 100);
      }
      log('ساختمان شهری به سطح ' + fa(b.level) + ' ارتقا یافت؛ هزینه ' + fa(cost) + '.');
    },
    'city-building-demolish'() {
      const i = Number(S.cityView), cell = Number(S.cityCell), city = CITIES[i], grid = city && S.cityMaps?.[city.name], b = grid?.[cell];
      if (!b)
        return;
      const refund = { home: 250, shop: 350, service: 600, park: 180 }[b.type] * b.level;
      S.govBudget = (S.govBudget || 0) + refund;
      grid[cell] = null;
      if (S.cityMoveHistory?.[city.name])
        S.cityMoveHistory[city.name] = S.cityMoveHistory[city.name].filter(m => m.cell !== cell);
      if (S.cityBuildingPositions?.[city.name])
        delete S.cityBuildingPositions[city.name][cell];
      game.ui.cityMoveCell = null;
      S.cityCell = null;
      log('ساختمان شهری تخریب شد؛ ' + fa(refund) + ' به بودجه عمومی بازگشت.');
    },
    'regional-invest'(x) {
      const i = Number(x.i);
      if (!Number.isInteger(i) || i < 0 || i >= REGIONS.length)
        return;
      S.regions = S.regions || {};
      const state = S.regions[i] || (S.regions[i] = { investment: 0, satisfaction: 70 }), lv = state.investment || 0, cost = 3500 * (lv + 1);
      if (lv >= 3) {
        log('برنامه توسعه این منطقه به سقف سرمایه‌گذاری رسیده است.');
        return;
      }
      if ((S.govBudget || 0) < cost) {
        log('بودجه عمومی برای توسعه این منطقه کافی نیست.');
        return;
      }
      S.govBudget -= cost;
      state.investment = lv + 1;
      state.satisfaction = cl((state.satisfaction ?? 70) + 2, 0, 100);
      log(`زیرساخت محلی منطقه «${REGIONS[i][0]}» به سطح ${fa(lv + 1)} ارتقا یافت؛ هزینه ${fa(cost)} از بودجه عمومی.`);
    },
    'regional-infra-toggle'(x) {
      const i = Number(x.i);
      if (!Number.isInteger(i) || i < 0 || i >= REGIONS.length)
        return;
      S.openRegionalInfra = S.openRegionalInfra === i ? null : i;
    },
    'regional-infra'(x) {
      const i = Number(x.i), p = x.p;
      if (!Number.isInteger(i) || i < 0 || i >= REGIONS.length || !['power', 'gas', 'water', 'roads'].includes(p))
        return;
      S.regions = S.regions || {};
      const state = S.regions[i] || (S.regions[i] = { investment: 0, satisfaction: 70 });
      state.infrastructure = state.infrastructure || {};
      const lv = cl(Number(state.infrastructure[p]) || 0, 0, 3), base = { power: 1700, gas: 1900, water: 1600, roads: 1300 }[p], cost = base * (lv + 1), label = { power: 'شبکه برق', gas: 'شبکه گاز', water: 'شبکه آب', roads: 'راه‌های دسترسی' }[p];
      if (lv >= 3) {
        log(`${label} منطقه «${REGIONS[i][0]}» به حداکثر سطح رسیده است.`);
        return;
      }
      if ((S.govBudget || 0) < cost) {
        log('بودجه عمومی برای این ارتقای منطقه‌ای کافی نیست.');
        return;
      }
      S.govBudget -= cost;
      state.infrastructure[p] = lv + 1;
      state.satisfaction = cl((state.satisfaction ?? 70) + 1.2, 0, 100);
      log(`${label} منطقه «${REGIONS[i][0]}» به سطح ${fa(lv + 1)} ارتقا یافت؛ هزینه ${fa(cost)} از بودجه عمومی.`);
    },
    network(x) {
      const p = x.p;
      if (!['power', 'gas', 'water', 'fuel'].includes(p))
        return;
      S.network = S.network || {};
      const lv = Math.max(0, Math.min(4, S.network[p] || 0)), cost = [1800, 2800, 4200, 6000][lv];
      if (lv < 4 && (S.govBudget || 0) >= cost) {
        S.govBudget -= cost;
        S.network[p] = lv + 1;
        log('شبکه ملی ' + ({ power: 'برق', gas: 'گاز', water: 'آب', fuel: 'سوخت' }[p]) + ' ارتقا یافت؛ تلفات انتقال به ' + fa(Math.max(2, 10 - (lv + 1) * 2)) + '٪ رسید.');
      }
      else if (lv < 4)
        log('بودجه عمومی برای این سرمایه‌گذاری کافی نیست.');
    },
    build(x) {
      const t = TY[x.t];
      if (!t || !S.countryHub || !HUB_TYPES[S.countryHub]?.includes(x.t)) {
        log('ساخت این ساختمان فقط در قطب مربوط مجاز است.');
        return;
      }
      if (S.sel === null || S.grid[S.sel] || !districtLots(S, S.countryHub).some(l => l.id === S.sel) || !game.buildable(S.sel) || !pay(t.cost))
        return;
      S.grid[S.sel] = { t: x.t, l: 1, c: {}, hub: S.countryHub };
      log(t.n + ' ساخته شد؛ آن را به شبکه‌ها وصل کنید.');
    },
    conn(x) {
      const b = S.grid[S.sel];
      if (b && Object.hasOwn(TY[b.t].need, x.p) && !b.c[x.p] && pay(100))
        b.c[x.p] = 1;
    },
    cup() {
      const b = S.grid[S.sel];
      if (b && b.l < 3 && pay(TY[b.t].cost * b.l * 1.2)) {
        b.l++;
        log(TY[b.t].n + ' به سطح ' + fa(b.l) + ' ارتقا یافت.');
      }
    },
    demo() {
      const b = S.grid[S.sel];
      if (b) {
        S.money += TY[b.t].cost * b.l * .3;
        S.grid[S.sel] = null;
      }
    },
  });
  game.clickHandlers.push((e, b, x, i, a) => {
    if (a.startsWith('water-')) {
      if (a === 'water-open') {
        S.tab = 'c';
        S.countryHub = null;
        S.cityView = null;
        S.offshoreView = false;
        S.atlasSelected = 'water-' + x.k;
        game.ui.mapSheetOpen = true;
      }
      else if (a === 'water-budget') {
        const w = waterNetwork(S);
        w.reserve = Math.max(0, Number(document.getElementById('water-cash-reserve')?.value) || 0);
        S.waterSupply = w;
      }
      else if (!waterAction(S, x.k, a.slice(6)))
        log('اقدام منبع آب انجام نشد؛ نقد، ساخت و اتصال را بررسی کن.');
      game.draw();
      save();
      return true;
    }
    if (a === 'atlas-display') {
      if (['overview', 'services'].includes(x.k)) {
        S.mapLayer = x.k;
        game.ui.countryNotice = '';
        game.ui.mapSheetOpen = false;
      }
      if (x.k === 'time')
        S.mapTime = S.mapTime === 'night' ? 'day' : 'night';
      if (x.k === 'labels')
        S.mapLabels = S.mapLabels === false;
      game.draw();
      save();
      return true;
    }
    if (a === 'atlas-camera') {
      countryCamera(x.k);
      return true;
    }
    if (a === 'atlas-offshore') {
      game.ui.mapSheetOpen = false;
      S.countryHub = null;
      S.cityView = null;
      S.offshoreView = true;
      game.draw();
      save();
      return true;
    }
    if (a === 'atlas-select') {
      game.ui.mapSheetOpen = true;
      S.atlasSelected = x.k;
      S.offshoreMapSelected = x.k === 'gas' ? 'gas' : 'oil';
      game.draw();
      save();
      return true;
    }
    if (a === 'atlas-home') {
      game.ui.mapSheetOpen = false;
      S.countryHub = null;
      S.cityView = null;
      S.offshoreView = false;
      S.sel = null;
      S.cityCell = null;
      game.draw();
      save();
      return true;
    }
    if (a === 'hub-page') {
      S.hubPage = Number(x.page);
      S.sel = null;
      game.draw();
      save();
      return true;
    }
    if (a === 'hub-cell') {
      S.sel = +x.i;
      game.draw();
      save();
      return true;
    }
    if (a === 'hub-open') {
      S.countryHub = x.k;
      S.hubPage = 0;
      S.sel = null;
      S.cityView = null;
      S.offshoreView = false;
      game.draw();
      save();
      return true;
    }
    if (a === 'hub-close') {
      S.countryHub = null;
      S.sel = null;
      game.draw();
      save();
      return true;
    }
    return false;
  });
}
