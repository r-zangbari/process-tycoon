// صفحه‌ی «کشور»: اطلس، صحنه‌ی سه‌بعدی و اقتصاد ملی.
import { renderCountry } from './view/country-view.js';
import { PR, TY } from '../../data/catalog.js';
import { cityDevelopmentMetrics } from './model/urban-economy.js';
import { mountCountryScene } from './view/country-scene.js';
import { networkKey } from './view/map-operations.js';
import { cl, f1, fa } from '../../core/format.js';
import { CITIES, REGIONS } from '../../data/world-map.js';
export function installCountryPage(game) {
  const { S, save } = game;
  function countryEconomyCard() {
    const security = ['power', 'gas', 'water', 'fuel'].map(p => S.dem?.[p] > 0 ? Math.max(0, Math.min(1, S.fr?.[p] ?? 1)) : 1);
    const nationalCapacity = Object.values(S.nationalProjects || {}).reduce((a, b) => a + (Number(b) || 0), 0);
    const energySecurity = cl(security.reduce((a, b) => a + b, 0) / security.length * 100 + (S.nationalProjects?.power || 0) * 1.5 + (S.nationalProjects?.pipeline || 0), 0, 100);
    const gdp = (S.inc?.dom || 0) + (S.inc?.tax || 0) + (S.inc?.eco || 0) + (S.inc?.ex || 0) + (S.inc?.ct || 0);
    const levels = ['power', 'gas', 'water', 'fuel'];
    const names = { power: 'برق', gas: 'گاز', water: 'آب', fuel: 'سوخت' };
    const costs = [1800, 2800, 4200, 6000];
    const rows = levels.map(p => {
      const lv = Math.max(0, Math.min(4, S.network?.[p] || 0)), loss = Math.max(2, 10 - lv * 2);
      return `<div class="country-network-row"><div><b>${names[p]}</b><small class="muted">تلفات انتقال ${fa(loss)}٪ · سطح ${fa(lv)}/۴</small></div><div class="row"><button data-a="network" data-p="${p}" ${lv >= 4 || S.govBudget < costs[lv] ? 'disabled' : ''}>ارتقا (${fa(costs[lv])} از بودجه ملی)</button><span class="tag ${lv >= 4 ? 'run' : ''}">${lv >= 4 ? 'تکمیل' : `مرحله ${fa(lv + 1)}`}</span></div></div>`;
    }).join('');
    const rate = Number(S.govRate) || 1;
    return `<section id="country-economy" class="wide country-economy"><div class="country-heading"><div><span class="hmi-kicker">NATIONAL ECONOMY / PUBLIC FINANCE</span><h2>داشبورد اقتصاد و مدیریت ملی</h2><p class="muted">شاخص‌های کلان، بودجه عمومی و سرمایه‌گذاری در شبکه‌های انرژی و خدمات</p></div><span class="tag">نسخه آزمایشی اقتصاد ملی</span></div><div class="country-kpis"><div><small>جمعیت</small><b>${fa(S.pop || 0)}</b></div><div><small>توسعه افزوده‌شده شهرهای مستقل</small><b>${fa(S.urbanToday?.developed || 0)} سطح</b></div><div><small>مالیات شهری افزوده (تخمینی)</small><b>${fa(S.urbanToday?.tax || 0)}</b></div><div><small>رضایت عمومی</small><b class="${S.sat < 50 ? 'bd' : S.sat < 75 ? 'wn' : 'ok'}">${fa(S.sat || 0)}٪</b></div><div><small>امنیت تأمین انرژی و خدمات</small><b class="${energySecurity < 70 ? 'bd' : energySecurity < 90 ? 'wn' : 'ok'}">${f1(energySecurity)}٪</b></div><div><small>فعالیت اقتصادی روزانه (GDP Proxy)</small><b>${fa(gdp)}</b></div><div><small>بودجه عمومی</small><b>${fa(S.govBudget || 0)}</b></div><div><small>درآمد عمومی امروز</small><b class="ok">+${fa(S.govIncomeToday || 0)}</b></div><div><small>شاخص ظرفیت توسعه ملی</small><b>${fa(nationalCapacity)} / ۱۲</b></div></div><div class="country-columns"><div class="card"><h3>سیاست مالی و درآمد عمومی</h3><p class="muted">بودجه عمومی از بخشی از مالیات شهروندان و عوارض صادرات/قرارداد تأمین می‌شود. این مبلغ از درآمد نقدی شرکت کسر و به بودجه عمومی منتقل می‌شود؛ بنابراین پول جدید خلق نمی‌شود.</p><div class="row"><b>ضریب اخذ مالیات و عوارض: ×${f1(rate)}</b><button data-a="gov-rate" data-d="-0.1" ${rate <= .5 ? 'disabled' : ''}>کاهش</button><button data-a="gov-rate" data-d="0.1" ${rate >= 1.5 ? 'disabled' : ''}>افزایش</button></div><div class="muted">بازه سیاست مالی: ۰٫۵ تا ۱٫۵ برابر پایه. افزایش آن درآمد عمومی را بالا می‌برد اما نقدینگی در دسترس شرکت را کاهش می‌دهد.</div></div><div class="card"><h3>توسعه شبکه‌های ملی</h3><p class="muted">هر ارتقا تلفات انتقال را از ۱۰٪ پایه، به‌ازای هر سطح ۲ واحد درصد کاهش می‌دهد. این سرمایه‌گذاری از بودجه عمومی پرداخت می‌شود و تحویل مؤثر خدمات را بهبود می‌دهد.</p>${rows}</div></div><div class="card wide national-projects"><h3>پروژه‌های توسعه ملی</h3><p class="muted">سرمایه‌گذاری بلندمدت از بودجه عمومی؛ هر سطح ظرفیت زیرساختی و تاب‌آوری کشور را افزایش می‌دهد. این پروژه‌ها مستقل از واحدهای عملیاتی شرکت هستند.</p><div class="trade-grid">${[['refinery', 'پالایشگاه ملی', 'توسعه ظرفیت پالایش و امنیت سوخت', 12000], ['power', 'نیروگاه ملی', 'افزایش ظرفیت پشتیبان تولید برق', 16000], ['petrochem', 'مجتمع پتروشیمی', 'افزایش ظرفیت صنایع پایین‌دستی', 18000], ['pipeline', 'خطوط انتقال سراسری', 'بهبود انتقال بین مناطق و کاهش گلوگاه', 9000]].map(([k, n, ds, c]) => {
      const lv = S.nationalProjects?.[k] || 0, cost = c * (lv + 1);
      return `<div class="card"><b>${n}</b><div class="muted">${ds}</div><div class="eq"><span>سطح توسعه</span><b>${fa(lv)}/۳</b></div><div class="bar"><i style="width:${lv / 3 * 100}%"></i></div><button data-a="national-build" data-p="${k}" ${lv >= 3 || S.govBudget < cost ? 'disabled' : ''}>${lv >= 3 ? 'تکمیل شده' : `اجرای مرحله بعد (${fa(cost)} از بودجه ملی)`}</button></div>`;
    }).join('')}</div></div><div class="card wide dynamic-economy"><h3>اقتصاد پویا و وضعیت اجتماعی</h3><p class="muted">شاخص‌ها هر ۳۰ روز شبیه‌سازی بازبینی می‌شوند. کمبود خدمات، بیکاری و شوک‌های اقتصادی بر تورم، ثبات و رضایت عمومی اثر می‌گذارند.</p><div class="country-kpis"><div><small>شاخص قیمت / تورم تجمعی</small><b class="${(S.economy?.inflation || 100) > 140 ? 'bd' : (S.economy?.inflation || 100) > 120 ? 'wn' : 'ok'}">${f1(S.economy?.inflation || 100)}</b></div><div><small>بیکاری تخمینی</small><b class="${(S.economy?.unemployment || 8) > 20 ? 'bd' : 'ok'}">${f1(S.economy?.unemployment || 8)}٪</b></div><div><small>اشتغال تخمینی</small><b>${f1(S.economy?.employment || 0)}٪</b></div><div><small>ثبات اقتصادی</small><b>${f1(S.economy?.stability || 75)}٪</b></div><div><small>شوک فعال</small><b>${S.economy?.shock ? `${S.economy.shock.name} · ${fa(S.economy.shock.days)} روز` : 'ندارد'}</b></div></div><div class="row"><span class="muted">بسته حمایتی عمومی: هزینه ۲٬۵۰۰ از بودجه ملی؛ اثر کوتاه‌مدت بر رضایت و ثبات</span><button data-a="economic-relief" ${(S.govBudget || 0) < 2500 ? 'disabled' : ''}>اجرای بسته حمایتی</button></div></div><div class="muted country-foot">GDP Proxy شاخص ساده‌شده‌ای از ارزش فروش داخلی، مالیات، فعالیت کشاورزی/صنعتی، صادرات و قراردادهاست؛ تولید ناخالص داخلی رسمی محسوب نمی‌شود.</div></section>`;
  }
  function viewCountry() {
    return renderCountry({
      S, TY, PR, CITIES, fa, cityDevelopmentMetrics, offshoreCard: game.offshoreCard, countryEconomyCard, REGIONS, regionMetrics: game.regionMetrics, sheetOpen: game.ui.mapSheetOpen, expanded: game.ui.countryExpanded, notice: game.ui.countryNotice
    });
  }
  function syncCountryScene() {
    mountCountryScene(S, CITIES, pick => {
      if (pick.kind === 'network') {
        S.mapStep = pick.id;
        game.ui.mapSheetOpen = true;
      }
      else if (pick.kind === 'unit') {
        S.siteSelectedUnit = pick.id;
        S.tab = 'site';
      }
      else if (pick.kind === 'district') {
        S.atlasSelected = pick.id;
        S.offshoreMapSelected = pick.id === 'gas' ? 'gas' : 'oil';
        if (S.mapLayer === 'services' && S.tab === 'c' && !S.offshoreView) {
          const key = networkKey(S);
          if (key === 'water')
            S.mapStep = pick.id === 'water-desal' ? 'source' : pick.id === 'energy' ? 'treatment' : pick.id === 'capital' ? 'city' : S.mapStep;
          if (key === 'power')
            S.mapStep = pick.id === 'energy' ? 'generation' : 'power-city';
          if (key === 'feed' && ['oil', 'gas', 'port'].includes(pick.id))
            S.mapStep = pick.id === 'port' ? 'terminal' : pick.id;
        }
      }
      else if (pick.kind === 'city-lot')
        S.cityCell = pick.id;
      else if (pick.kind === 'lot')
        S.sel = pick.id;
      game.ui.mapSheetOpen = true;
      game.draw();
      save();
    });
  }
  Object.assign(game, { syncCountryScene, viewCountry });
}
