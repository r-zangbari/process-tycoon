// میان‌برهای کیبورد (Escape).
export function installKeyboard(game) {
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape')
      return;
    if (game.ui.countryExpanded) {
      game.ui.countryExpanded = false;
      game.draw();
    }
  });
}
