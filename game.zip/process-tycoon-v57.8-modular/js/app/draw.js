// رندر اصلی: به‌روزرسانی نوار بالا و تعویض/وصله‌ی محتوای صفحه‌ی فعال.
import { clearNavigationHighlight } from '../ui-kit/navigation-highlight.js';
import { refreshAdvisorMarkup, refreshMapMarkup, refreshScreenMarkup } from '../ui-kit/map-refresh.js';
import { discoverAchievements, legacyState } from '../features/legacy/model/legacy-development.js';
import { SEAS } from '../data/catalog.js';
import { $, f1, fa } from '../core/format.js';
import { renderScreen } from './screens.js';
import { cashSummary, cashWarning } from '../features/products/model/cash-clarity.js';
export function installDraw(game) {
  const { S, gameAudio } = game;
  const AP = {
    set h(v) {
      if (S.tab === 'hmi' && !game.ui.hmiSelectionCommit && document.activeElement?.id === 'hmi-unit-select')
        return;
      clearNavigationHighlight();
      const screen = ['c', 'site'].includes(S.tab) ? null : S.tab + ':' + (S.tab === 'hmi' ? S.hmiUnit + ':' + S.hmiMode + ':' + S.hmiSection + ':' + S.hmiLoop : S.tab === 'm' ? (S.manageSection || 'inventory') : '');
      const same = screen && screen === game.ui.renderedScreen;
      game.ui.renderedScreen = screen;
      if (same && refreshScreenMarkup($('#app'), (S.tab === 'hmi' || (S.tab === 'm' && (!S.manageSection || S.manageSection === 'inventory')) ? '' : game.playerHelp()) + v)) {
        game.syncCountryScene();
        return;
      }
      if ((S.tab === 'i' || (S.tab === 'm' && ['overview', 'maintenance'].includes(S.manageSection))) && refreshAdvisorMarkup($('#app'), game.playerHelp() + v)) {
        game.syncCountryScene();
        return;
      }
      if ((S.tab === 'c' || S.tab === 'site') && refreshMapMarkup($('#app'), v)) {
        game.syncCountryScene();
        return;
      }
      if (S.tab === 'hmi' && !game.ui.hmiSelectionCommit && document.activeElement?.id === 'hmi-unit-select')
        return;
      const priorCountryView = document.getElementById('country-three')?.dataset?.view;
      const countryDetails = [...document.querySelectorAll('.atlas details')].map(d => d.open);
      const inspectorScroll = document.querySelector('.atlas-inspector')?.scrollTop || 0;
      const productsScroll = document.querySelector('.product-table-scroll');
      const productLeft = productsScroll?.scrollLeft ?? 0;
      const cityScroll = document.querySelector('.city-world-map-wrap')?.scrollLeft || 0;
      const siteScroll = document.querySelector('.site-map-viewport')?.scrollLeft || 0;
      const offshoreScroll = document.querySelector('.offshore-seascape')?.scrollLeft || 0;
      const mimic = document.querySelector('.mimic-scroll');
      const mimicLeft = mimic ? mimic.scrollLeft : 0;
      const mimicTop = mimic ? mimic.scrollTop : 0;
      $('#app').innerHTML = (['c', 'site', 'hmi'].includes(S.tab) || (S.tab === 'm' && (!S.manageSection || S.manageSection === 'inventory')) ? '' : game.playerHelp()) + v;
      game.syncCountryScene();
      document.querySelectorAll('.atlas details').forEach((d, i) => {
        if (priorCountryView === document.getElementById('country-three')?.dataset?.view && countryDetails[i] != null)
          d.open = countryDetails[i];
      });
      const inspector = document.querySelector('.atlas-inspector');
      if (inspector)
        inspector.scrollTop = inspectorScroll;
      if (S.tab === 'c' && S.cityView != null && cityScroll) {
        const next = document.querySelector('.city-world-map-wrap');
        if (next)
          next.scrollLeft = cityScroll;
      }
      if (S.tab === 'site' && siteScroll) {
        const next = document.querySelector('.site-map-viewport');
        if (next)
          next.scrollLeft = siteScroll;
      }
      if (S.tab === 'c' && S.offshoreView && offshoreScroll) {
        const next = document.querySelector('.offshore-seascape');
        if (next)
          next.scrollLeft = offshoreScroll;
      }
      if (S.tab === 'm' && productLeft) {
        const next = document.querySelector('.product-table-scroll');
        if (next)
          next.scrollLeft = productLeft;
      }
      if (S.tab === 'hmi' && (mimicLeft || mimicTop)) {
        const next = document.querySelector('.mimic-scroll');
        if (next) {
          next.scrollLeft = mimicLeft;
          next.scrollTop = mimicTop;
        }
      }
      if (S.tab === 'c' && !S.offshoreView && S.cityView == null) {
        game.camApply();
        game.nightUpdate();
      }
    }
  };
  function draw() {
    discoverAchievements(S);
    const devButton = document.getElementById('dev-open');
    if (devButton) {
      devButton.textContent = S.development?.event ? 'هشدار کشور · توسعه' : 'توسعه کشور';
      devButton.classList.toggle('dev-warning', !!S.development?.event);
    }
    const legacyButton = document.getElementById('legacy-open');
    if (legacyButton)
      legacyButton.textContent = 'شهر من' + (Object.values(legacyState(S).awards).filter(a => !a.claimed).length ? ' · پاداش آماده' : '');
    const k0 = document.querySelector('.sk2'), sl0 = k0 ? k0.scrollLeft : 0;
    setTimeout(() => {
      const k = document.querySelector('.sk2');
      if (k && Math.abs(k.scrollLeft - sl0) > 1)
        k.scrollLeft = sl0;
    }, 0);
    document.querySelectorAll('#tabs button').forEach(b => b.setAttribute('aria-pressed', b.dataset.t === S.tab));
    $('#money').textContent = fa(S.money);
    $('#money').className = S.money < 0 ? 'bd' : '';
    const cash = cashSummary(S);
    const delta = cash ? (cash.delta > 0 ? '+' : '') + fa(cash.delta) : '—';
    const why = $('#cash-change');
    if (why) why.textContent = cash ? 'تغییر روز · ' + delta + (cash.reason ? ' · ' + cash.reason : '') : 'تغییر روز پس از اولین تسویه';
    const expense = cashWarning(S);
    const warning = $('#cash-warning');
    if (warning) {
      warning.hidden = !expense;
      warning.textContent = expense ? expense.label + ' · ' + (expense.projected ? 'تا ' : '') + fa(expense.amount) + ' · ' + (expense.days > 0 ? fa(expense.days) + ' روز دیگر' : 'امروز') : '';
    }
    const dockChange = $('#money-dock-change');
    if (dockChange) dockChange.textContent = cash ? 'روز ' + delta : '';
    const dock = $('#money-dock');
    if (dock) {
      dock.textContent = fa(S.money);
      dock.className = S.money < 0 ? 'bd' : '';
    }
    game.syncAlerts();
    $('#day').textContent = fa(S.day);
    $('#mkt').textContent = '×' + f1(S.mkt * (S.fx.sanc ? .7 : 1) * (S.fx.spike ? 1.4 : 1));
    $('#season').textContent = SEAS[Math.floor(((S.day - 1) % 360) / 90)];
    $('#esg').textContent = fa(S.esg) + '٪';
    $('#esg').className = S.esg < 40 ? 'bd' : S.esg < 70 ? 'wn' : 'ok';
    $('#safe').textContent = fa(S.safe) + '٪';
    $('#safe').className = S.safe < 50 ? 'bd' : S.safe < 80 ? 'wn' : 'ok';
    $('#diff').textContent = 'سختی: ' + ['آسان', 'عادی', 'سخت'][S.diff == null ? 1 : S.diff];
    gameAudio.sync();
    $('#snd').textContent = 'صدا: ' + (S.mute ? 'خاموش' : 'روشن');
    $('#pause').textContent = S.paused ? 'ادامه' : 'توقف';
    $('#spd').textContent = 'سرعت ×' + fa(S.spd);
    AP.h = renderScreen(game);
  }
  Object.assign(game, { draw });
}
