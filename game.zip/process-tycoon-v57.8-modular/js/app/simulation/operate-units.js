import { ALT, ALTERNATIVE_FEED_FACTOR, D, EM, IMP, IN, OPN, OPT, OPTIONAL_FEED_EFFECT, OUT, PR } from '../../data/catalog.js';
import { storyFactor } from '../../features/development/model/development.js';
import { importTradeFactor, LOCAL_TRADE } from '../../features/products/model/trade-conditions.js';
import {
  emergencyImportAllowance,
  recordEmergencyImport,
  requiredFeedPort
} from '../../features/products/model/product-automation.js';
import { changeSafety } from '../../features/safety/model/safety.js';
import {
  advanceProcessVariable,
  calculateProcessCoupling,
  calculateProductQuality
} from '../../features/control-room/model/process-dynamics.js';
import {
  actuatorPosition,
  describeFinalElement
} from '../../features/control-room/model/control-elements.js';
import { stepOperatingDrift } from '../../features/control-room/model/operating-drift.js';
import { stepUnitProcessModel } from '../../features/control-room/model/process-unit-model.js';
import { cl, f1, fa } from '../../core/format.js';

const tripDeviationSafe = (vars, values) =>
  (vars || []).reduce((m, v, k) => {
    const measured = Number(values?.[k]);
    return Math.max(
      m,
      Math.abs((Number.isFinite(measured) ? measured : v[2]) - v[2]) / Math.max(Number(v[3]) || 0.001, 0.001)
    );
  }, 0);

export function operateUnits(
  { S, anyOut, cap, lvl, pidController, r, recordSOE, log },
  { running, avail, rt, opF, nz, inflationCost, supplyShock, availablePortForFeed, importCashBudget, net }
) {
  S.u.forEach((u, ui) => {
    const d = D[u.t];
    if (u.tb > 0) u.tb--;
    if (u.st === 'tar') {
      if (--u.tar <= 0) {
        u.eq.forEach((e) => {
          e.h = 100;
        });
        u.tb = 60;
        u.v = d.v.map((x) => x[2] + (r() < 0.5 ? -1 : 1) * x[3] * 1.2);
        u.st = 'run';
        log('تعمیرات اساسی «' + d.n + '» تمام شد؛ واحد دوباره در مدار است.');
      }
      return;
    }
    u.load = cl(Number(u.load) || 100, 50, 140);
    u.feedGrade = cl(Number(u.feedGrade) || 90, 70, 100);
    u.overloadTicks = u.overloadTicks || 0;
    const preStress = tripDeviationSafe(d.v, u.v);
    u.eq.forEach((e, j) => {
      const nm = d.e[j][0],
        sb = d.e[j][1];
      // Random breakdowns are disabled above 30% health. Severe process excursions
      // accelerate wear and make low-health equipment more failure-prone.
      const isPumpEquipment = /پمپ|pump/i.test(String(nm));
      const mainInService = !isPumpEquipment || e.running !== false;
      const failureRisk =
        mainInService && e.h < 30
          ? (0.0015 + (30 - e.h) * 0.00035 + Math.max(0, preStress - 1.5) * 0.002) / e.l
          : 0;
      if (
        u.st === 'run' &&
        !e.f &&
        failureRisk > 0 &&
        r() <
          failureRisk *
            (u.tb > 0 ? 0.5 : 1) *
            ((S.tech || {}).pred ? 0.6 : 1) *
            Math.pow(0.88, S.eng || 0) *
            [0.7, 1, 1.4][S.diff == null ? 1 : S.diff]
      ) {
        e.f = { st: 0, eta: 0, dl: sb ? 8 : 0 };
        if (sb) {
          recordSOE('خرابی تجهیز ' + nm + '؛ بررسی ورود رزرو.', 'HIGH', ui);
          if (/پمپ|pump/i.test(nm) && e.reserve && !e.reserve.f && e.reserve.h >= 30) {
            u.processState = u.processState || {};
            u.processState.pumpStandby = true;
            e.running = false;
            e.reserve.running = true;
          }
          log(
            nm +
              ' اصلی خراب شد؛ تجهیز رزرو در صورت آماده‌بودن وارد مدار شد. تا ۸ روز قطعه را تهیه و تعمیر کنید وگرنه رزرو هم از دسترس خارج می‌شود!'
          );
        } else {
          recordSOE('خرابی تجهیز ' + nm + ' و خروج واحد از سرویس.', 'HIGH', ui);
          log(nm + ' خراب شد و واحد «' + d.n + '» از سرویس خارج شد.');
          changeSafety(S, -0.75, 'خرابی تجهیز بحرانی؛ خروج خودکار واحد از سرویس', {
            routine: true,
            key: ui + ':equipment',
            unit: ui
          });
        }
      }
      if (e.f) {
        if (u.st === 'run' && sb && e.f.dl > 0 && --e.f.dl === 0) {
          log('استندبای ' + nm + ' هم از کار افتاد! «' + d.n + '» از سرویس خارج شد.');
          changeSafety(S, -1.25, 'اتمام مهلت بهره‌برداری رزرو بدون تکمیل تعمیر', {
            routine: true,
            key: ui + ':reserve',
            unit: ui
          });
        }
      }
    });
    if (u.st === 'run' && anyOut(u)) {
      u.st = 'broken';
      u.tripReason = 'equipment';
    }
    if (u.st !== 'run') return;
    let w = 0;
    const couplingOffsets = calculateProcessCoupling(d.v, u.v);
    if (u.coolingIncident?.days > 0) {
      const tk = d.v.findIndex((x) => /دما|temperature|temp/i.test(x[0]));
      if (tk >= 0) couplingOffsets[tk] += (u.coolingIncident.offset || 0.7) * d.v[tk][3];
    }
    if (u.instrumentIncident?.days > 0 && Number.isInteger(u.instrumentIncident.k)) {
      const ik = u.instrumentIncident.k;
      couplingOffsets[ik] += (u.instrumentIncident.bias || 0.6) * d.v[ik][3];
    }
    const requestedLoadRatio = (u.load || 100) / 100;
    const flowVariableIndex = d.v.findIndex((x) => /دبی|جریان|flow/i.test(x[0]));
    if (flowVariableIndex >= 0)
      couplingOffsets[flowVariableIndex] += (requestedLoadRatio - 1) * d.v[flowVariableIndex][3] * 0.65;
    const levelK = d.v.findIndex((x) => /سطح|لول|level/i.test(x[0]));
    const flowK = d.v.findIndex((x) => /دبی|جریان|flow/i.test(x[0]));
    d.v.forEach((x, k) => {
      const key = `${ui}:${k}`;
      const pidConfig =
        S.pid?.[key] || (S.pid[key] = { mode: 'manual', mv: 50, integral: 0, previousError: 0, output: 0 });
      if (!Number.isFinite(pidConfig.mv)) pidConfig.mv = 50;
      const pvBefore = u.v[k];
      const finalElement = describeFinalElement(x[0]);
      pidConfig.actuatorTag = finalElement.tag;
      pidConfig.actuatorLabel = finalElement.label;
      pidConfig.actuatorType = finalElement.type;
      pidConfig.actuatorDirection = finalElement.direction;
      if (pidConfig.mode === 'auto' && u.au?.[k]) {
        const requestedSp = Number.isFinite(pidConfig.sp) ? pidConfig.sp : x[2];
        if (!Number.isFinite(pidConfig.rampedSp)) pidConfig.rampedSp = pvBefore;
        const rampStep = Math.max(x[3] * 0.12, 0.0001);
        pidConfig.rampedSp += cl(requestedSp - pidConfig.rampedSp, -rampStep, rampStep);
        const result = pidController.step({
          pv: pvBefore,
          sp: pidConfig.rampedSp,
          span: x[3],
          config: pidConfig
        });
        pidConfig.mv = actuatorPosition(result.output, finalElement.direction);
      }
      if (pidConfig.mode === 'auto' && !u.au?.[k]) {
        pidConfig.mode = 'manual';
        pidConfig.integral = 0;
        pidConfig.previousError = 0;
      }
      stepOperatingDrift(pidConfig, {
        span: x[3],
        variableName: x[0],
        automatic: pidConfig.mode === 'auto' && !!u.au?.[k],
        random: r
      });
      const mv = cl(pidConfig.mv, 0, 100);
      const isCoupled = k === levelK || k === flowK;
      if (!isCoupled) {
        const noise = (r() - 0.5) * x[3] * 0.04 * nz;
        const dynamic = advanceProcessVariable({
          pv: pvBefore,
          nominal: x[2],
          span: x[3],
          mv,
          variableName: x[0],
          state: pidConfig,
          disturbance: pidConfig.disturbance || 0,
          interactionOffset: (couplingOffsets[k] || 0) + (pidConfig.naturalBias || 0),
          noise
        });
        u.v[k] = dynamic.pv;
        pidConfig.disturbance = dynamic.state.disturbance;
        pidConfig.processTarget = dynamic.state.target;
        pidConfig.actuatorEffect = dynamic.state.actuatorEffect;
      }
      const controlReference =
        pidConfig.mode === 'auto' && Number.isFinite(pidConfig.sp) ? pidConfig.sp : x[2];
      w = Math.max(w, Math.abs(u.v[k] - controlReference) / Math.max(x[3], 0.001));
      u.h[k].push(+u.v[k].toFixed(2));
      if (u.h[k].length > 40) u.h[k].shift();
      pidConfig.mvHistory = pidConfig.mvHistory || [];
      pidConfig.mvHistory.push(+mv.toFixed(1));
      if (pidConfig.mvHistory.length > 40) pidConfig.mvHistory.shift();
    });
    u.processState = u.processState || {};
    if (typeof u.processState.valveOpen !== 'boolean')
      u.processState.valveOpen = typeof S.mimicValve === 'boolean' ? S.mimicValve : true;
    if (typeof u.processState.pumpStandby !== 'boolean') u.processState.pumpStandby = !!S.mimicPump;
    const unitProcess = stepUnitProcessModel({
      unit: u,
      definition: d,
      unitIndex: ui,
      pid: S.pid || {},
      valveOpen: u.processState.valveOpen,
      pumpStandby: u.processState.pumpStandby
    });
    if (unitProcess) {
      w = 0;
      d.v.forEach((x, k) => {
        const cfg = S.pid?.[`${ui}:${k}`] || {};
        const controlReference = cfg.mode === 'auto' && Number.isFinite(cfg.sp) ? cfg.sp : x[2];
        w = Math.max(w, Math.abs(u.v[k] - controlReference) / Math.max(x[3], 0.0001));
        if (u.h[k]?.length) u.h[k][u.h[k].length - 1] = +u.v[k].toFixed(2);
      });
      u.processState = u.processState || {};
      u.processState.lastFlowFactor = unitProcess.flowFactor;
      u.processState.lastPumpReady = unitProcess.pumpReady;
      u.processState.pumpRunning = unitProcess.pumpRunning;
      u.processState.pressureEffect = unitProcess.pressureEffect;
      u.processState.temperatureEffect = unitProcess.temperatureEffect;
      u.processState.flowCouplingEffect = unitProcess.flowCouplingEffect;
    }
    // Safety limits are independent of operator SP: SP error is a control issue,
    // while a sustained excursion beyond the engineering safety envelope trips the unit.
    let tripDeviation = 0;
    d.v.forEach((x, k) => {
      tripDeviation = Math.max(tripDeviation, Math.abs(u.v[k] - x[2]) / Math.max(x[3], 0.0001));
    });
    const equipmentCapacities = u.eq.map((e, j) => {
      const name = String(d.e[j]?.[0] || '');
      const critical = /پمپ|pump|کمپرسور|compressor|کوره|furnace|توربین|turbine|فن|blower/i.test(name);
      return 100 + Math.max(0, (e.l || 1) - 1) * (critical ? 18 : 12);
    });
    const ratedCapacity = equipmentCapacities.length ? Math.min(...equipmentCapacities) : 100;
    u.ratedCapacity = ratedCapacity;
    const loadRatio = (u.load || 100) / ratedCapacity;
    u.capacityUse = Math.round(loadRatio * 100);
    const overload = Math.max(0, loadRatio - 1);
    u.overloadTicks = overload > 0.25 ? (u.overloadTicks || 0) + 1 : Math.max(0, (u.overloadTicks || 0) - 1);
    const baseQuality = calculateProductQuality({
      variables: d.v,
      values: u.v,
      pid: S.pid || {},
      unitIndex: ui,
      equipment: u.eq
    });
    const feedQualityBonus = (u.feedGrade - 90) * 0.22;
    const quality = cl(baseQuality + feedQualityBonus - Math.max(0, (u.load || 100) - 100) * 0.22, 25, 100);
    u.quality = quality;
    const qualityFactor = 0.65 + 0.35 * (quality / 100),
      feedQualityFactor = 0.72 + 0.28 * (u.feedGrade / 100),
      L = lvl(u);
    // Wear and failure risk follow the equipment actually in service. A standby
    // pump is not charged operating wear while it is available but idle.
    u.eq.forEach((e, j) => {
      const isPump = /پمپ|pump/i.test(String(d.e[j]?.[0] || ''));
      const stressWear =
        (w > 1 ? 0.18 : 0) +
        (w > 1.7 ? 0.45 : 0) +
        (tripDeviationSafe(d.v, u.v) > 2 ? 0.35 : 0) +
        overload * 0.9;
      const activeWear = (0.08 + stressWear) / e.l;
      const mainActive = !isPump || e.running !== false;
      if (mainActive) e.h = Math.max(0, e.h - activeWear);
      if (e.reserve) {
        const reserveActive = isPump && e.reserve.running === true;
        if (reserveActive) e.reserve.h = Math.max(0, e.reserve.h - activeWear);
      }
    });
    // Closing XV-101 is an operator isolation command, not an instantaneous
    // catastrophic process deviation. Give the operator a short response window;
    // sustained low flow still trips the unit as a protective action.
    u.processState = u.processState || {};
    const flowIndexForTrip = d.v.findIndex((x) => /دبی|جریان|flow/i.test(x[0]));
    const nominalFlowForTrip = flowIndexForTrip >= 0 ? d.v[flowIndexForTrip][2] : 0;
    const isolatedByValve = u.processState.valveOpen === false;
    if (isolatedByValve && flowIndexForTrip >= 0 && u.v[flowIndexForTrip] < nominalFlowForTrip * 0.2) {
      u.processState.lowFlowTicks = (u.processState.lowFlowTicks || 0) + 1;
      tripDeviation = d.v.reduce(
        (peak, x, k) =>
          k === flowIndexForTrip ? peak : Math.max(peak, Math.abs(u.v[k] - x[2]) / Math.max(x[3], 0.0001)),
        0
      );
      if (u.processState.lowFlowTicks < 4)
        log('هشدار: شیر XV-101 بسته است و دبی پایین‌تر از حد عملیاتی قرار دارد.');
    } else u.processState.lowFlowTicks = 0;
    if (tripDeviation > 3.1 || (u.processState.lowFlowTicks || 0) >= 4 || (u.overloadTicks || 0) >= 5) {
      u.st = 'trip';
      u.tripReason =
        (u.processState.lowFlowTicks || 0) >= 4
          ? 'low-flow'
          : (u.overloadTicks || 0) >= 5
            ? 'overload'
            : 'process';
      recordSOE('تریپ حفاظتی واحد به‌دلیل عبور از محدوده عملیاتی ثبت شد.', 'HIGH', ui);
      Object.entries(S.pid || {})
        .filter(([key]) => key.startsWith(`${ui}:`))
        .forEach(([, cfg]) => {
          cfg.integral = 0;
          cfg.previousError = 0;
          cfg.output = 0;
          cfg.disturbance = 0;
        });
      S.esg = Math.max(0, S.esg - 3);
      changeSafety(
        S,
        u.tripReason === 'low-flow' && u.processState?.valveOpen === false ? 0 : d.nuc ? -1.5 : -0.5,
        u.tripReason === 'low-flow' && u.processState?.valveOpen === false
          ? 'توقف حفاظتی پس از ایزوله‌کردن شیر؛ جریمه ایمنی ندارد'
          : 'عملکرد حفاظت فرایند؛ علت ' +
              { 'low-flow': 'دبی پایین', overload: 'اضافه‌بار', process: 'انحراف متغیر' }[u.tripReason],
        { routine: true, key: ui + ':' + u.tripReason, unit: ui }
      );
      log(
        'تریپ حفاظتی «' + d.n + '»: دبی پایین پایدار، اضافه‌بار ممتد تجهیزات یا عبور متغیر از محدوده ایمنی.'
      );
    } else {
      u.dayEconomics = {
        day: S.day,
        feeds: [],
        products: [],
        costs: {
          base: d.rev * 0.25 * inflationCost,
          wages: OPN[u.t] * (S.sal || 12) * inflationCost,
          feedImported: 0,
          feedInternal: 0,
          energy: 0
        },
        factors: {
          story: storyFactor(S, 'industry'),
          operator: rt < 1 ? 0.4 + 0.6 * rt : 1,
          availableOperators: avail,
          requiredOperators: running,
          strike: S.fx.strike ? 0.5 : 1,
          quality,
          qualityFactor,
          capacityUse: u.capacityUse,
          grid: S.gridIncident?.days > 0 ? S.gridIncident.factor : 1,
          feedIncident: u.feedIncident?.days > 0 ? u.feedIncident.factor : 1,
          avgHealth: 0
        }
      };
      net -= d.rev * 0.25 * inflationCost;
      const loadFactor = (u.load || 100) / 100;
      const k0 =
        storyFactor(S, 'industry') *
        opF *
        (S.fx.strike ? 0.5 : 1) *
        loadFactor *
        (u.feedIncident?.days > 0 ? u.feedIncident.factor : 1);
      let ff = 1,
        impc = 0,
        qf = 1;
      const optionalFeeds = OPT[u.t] || {};
      const feedProducts = Object.keys(IN[u.t]).sort((a, b) => Number(!!optionalFeeds[a]) - Number(!!optionalFeeds[b]));
      for (const p of feedProducts) {
        const optional = !!optionalFeeds[p];
        if (optional && ff === 0) continue;
        const feedPremium = 1 + Math.max(0, u.feedGrade - 90) * 0.006;
        const n = IN[u.t][p] * k0 * ((S.tech || {}).heat ? 0.85 : 1),
          tk = Math.min(S.tanks[p], n);
        S.tanks[p] -= tk;
        let alternativeQuantity = 0;
        const al = (ALT[u.t] || {})[p];
        if (al && tk < n) {
          alternativeQuantity = Math.min(S.tanks[al], (n - tk) / ALTERNATIVE_FEED_FACTOR);
          S.tanks[al] -= alternativeQuantity;
          S.ic[al] = (S.ic[al] || 0) + alternativeQuantity;
          S.cs[al] = (S.cs[al] || 0) + alternativeQuantity;
        }
        const alternative = alternativeQuantity * ALTERNATIVE_FEED_FACTOR;
        const got = tk + alternative;
        const deficit = Math.max(0, n - got);
        const pc =
            PR[p][2] *
            IMP *
            (p === 'power' ? 1 : feedPremium) *
            inflationCost *
            supplyShock *
            importTradeFactor(S, p),
          shipsByPort = !LOCAL_TRADE.has(p),
          policyAllowance = pc > 0 && deficit > 0 ? emergencyImportAllowance(S, p, deficit, pc, PR) : 0,
          cashAllowance = pc > 0 ? importCashBudget / pc : 0,
          portReserved = optional && shipsByPort && deficit > 0
            ? Object.values(requiredFeedPort(S, IN, PR, S.u.slice(ui + 1), false)).reduce((sum, n) => sum + n, 0)
            : 0,
          portAllowance = shipsByPort ? Math.max(0, availablePortForFeed - portReserved) : Infinity,
          buy = Math.min(policyAllowance, cashAllowance, portAllowance),
          importCost = buy * pc,
          internalCost = (tk * PR[p][2] + (al ? alternativeQuantity * PR[al][2] : 0)) * 0.5;
        recordEmergencyImport(S, p, buy, pc);
        importCashBudget = Math.max(0, importCashBudget - importCost);
        if (shipsByPort) {
          availablePortForFeed = Math.max(0, availablePortForFeed - buy);
          S.feedPortUsedToday += buy;
        }
        u.dayEconomics.costs.feedImported += importCost;
        u.dayEconomics.costs.feedInternal += internalCost;
        u.dayEconomics.feeds.push({
          product: p,
          required: n,
          local: tk,
          alternative,
          alternativeProduct: alternativeQuantity > 0 ? al : null,
          alternativeQuantity,
          imported: buy,
          delivered: got + buy,
          missing: Math.max(0, n - got - buy),
          importCost,
          internalCost,
          optional,
          policyLimited:
            policyAllowance < deficit - 0.001 && policyAllowance <= buy + 0.001,
          policyReason: policyAllowance < deficit - 0.001 ? S.emergencyTradeStatus?.[p] : '',
          cashLimited: cashAllowance < policyAllowance - 0.001 && cashAllowance <= buy + 0.001,
          portLimited: portAllowance < policyAllowance - 0.001 && portAllowance <= buy + 0.001
        });
        impc += internalCost + importCost;
        net -= importCost;
        S.imc += importCost;
        S.cs[p] = (S.cs[p] || 0) + n;
        S.imp[p] = (S.imp[p] || 0) + buy;
        S.ic[p] = (S.ic[p] || 0) + tk;
        if (n > 0) {
          const fr = (got + buy) / n;
          if (optional) qf = Math.min(qf, fr);
          else ff = Math.min(ff, fr);
        }
      }
      u.qf = qf;
      const optionalFeedFactor = 1 - OPTIONAL_FEED_EFFECT * (1 - qf);
      u.dayEconomics.factors.optionalFeed = optionalFeedFactor;
      // Unit-specific utility demand: higher load raises energy intensity non-linearly; worn equipment wastes more energy.
      const avgHealth = u.eq.length ? u.eq.reduce((a, e) => a + e.h, 0) / u.eq.length : 100;
      const energyIntensity = (EM[u.t] || 1) * Math.pow(loadFactor, 1.35) * (1 + (100 - avgHealth) / 180);
      u.energyUse = energyIntensity;
      u.energyCost = energyIntensity * PR.power[2] * IMP * 0.28 * inflationCost;
      net -= u.energyCost;
      u.dayEconomics.factors.avgHealth = avgHealth;
      u.dayEconomics.costs.energy = u.energyCost;
      u.dayEconomics.factors.feed = ff;
      u.feedGradeCostFactor = 1 + Math.max(0, u.feedGrade - 90) * 0.006;
      u.fs = ff;
      if (u.feedIncident?.days > 0 && --u.feedIncident.days <= 0) {
        u.feedIncident = null;
        recordSOE('کیفیت/دبی خوراک به وضعیت عادی بازگشت.', 'INFO', ui);
        log('اختلال خوراک در «' + d.n + '» برطرف شد.');
      }
      if (u.coolingIncident?.days > 0 && --u.coolingIncident.days <= 0) {
        u.coolingIncident = null;
        recordSOE('سیستم خنک‌کاری به وضعیت عادی بازگشت.', 'INFO', ui);
        log('اختلال خنک‌کاری «' + d.n + '» برطرف شد.');
      }
      if (u.instrumentIncident?.days > 0 && --u.instrumentIncident.days <= 0) {
        u.instrumentIncident = null;
        recordSOE('سیگنال ابزار دقیق به وضعیت عادی بازگشت.', 'INFO', ui);
        log('اختلال ابزار دقیق «' + d.n + '» برطرف شد.');
      }
      if (ff < 0.5 && S.day % 6 === 0) log('کمبود خوراک «' + d.n + '»؛ تولید کاهش یافت.');
      const k =
        k0 *
        qualityFactor *
        feedQualityFactor *
        ff *
        optionalFeedFactor *
        (1 + 0.35 * (L - 1)) *
        ((S.tech || {}).cat ? 1.15 : 1);
      u.out = {};
      u.cst =
        d.rev * 0.25 * inflationCost + OPN[u.t] * (S.sal || 12) * inflationCost + impc + (u.energyCost || 0);
      for (const p in OUT[u.t]) {
        const requested = OUT[u.t][p] * k,
          free = Math.max(0, cap(p) - S.tanks[p]),
          accepted = Math.min(requested, free),
          lost = Math.max(0, requested - accepted);
        u.dayEconomics.products.push({
          product: p,
          requested,
          accepted,
          spilled: lost,
          unitValue: 0,
          value: 0
        });
        u.out[p] = accepted;
        S.pd[p] = (S.pd[p] || 0) + accepted;
        S.tanks[p] += accepted;
        if (lost > 0.0001) S.prodLoss[p] = (S.prodLoss[p] || 0) + lost;
      }
    }
  });
  if (Object.values(S.prodLoss).some((v) => v > 0.01) && S.day % 3 === 0) {
    const top = Object.entries(S.prodLoss).sort((a, b) => b[1] - a[1])[0];
    log(
      'محدودیت ظرفیت ذخیره‌سازی: تولید ' +
        PR[top[0]][0] +
        ' به میزان ' +
        f1(top[1]) +
        ' واحد به‌دلیل پر بودن مخزن قابل ذخیره نبود. ظرفیت مخزن را افزایش دهید یا موجودی را تخلیه کنید.'
    );
  }
  return { net, availablePortForFeed };
}
