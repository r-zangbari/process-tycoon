import { PR } from '../../data/catalog.js';
import { effectiveTradePort } from '../../features/products/model/trade-conditions.js';
import { fa } from '../../core/format.js';

export function settleExportContracts(S, log) {
  // Export contracts draw down stored inventory and share the daily port limit.
  S.portCapacityToday = effectiveTradePort(S);
  let contractPort = S.portCapacityToday,
    contractIncome = 0;
  const deliveries = {};
  (S.tradeContracts || []).slice().forEach((c) => {
    const available = Math.max(0, S.tanks[c.p] || 0),
      deliver = Math.min(available, c.remaining, contractPort);
    if (deliver > 0) {
      S.tanks[c.p] -= deliver;
      c.remaining -= deliver;
      c.delivered = (c.delivered || 0) + deliver;
      contractPort -= deliver;
      const gross = deliver * c.unitPrice;
      const totals = deliveries[c.p] ||= { quantity: 0, gross: 0 };
      totals.quantity += deliver;
      totals.gross += gross;
      const applied = Number.isFinite(c.advanceBalance) ? Math.min(gross, Math.max(0, c.advanceBalance)) : 0;
      if (Number.isFinite(c.advanceBalance)) c.advanceBalance -= applied;
      contractIncome += gross - applied;
    }
    c.days--;
    if (c.remaining <= 0.001) {
      S.tradeHistory.unshift({
        p: c.p,
        qty: c.qty,
        delivered: c.delivered,
        status: 'تحویل کامل',
        day: S.day
      });
      S.tradeContracts = S.tradeContracts.filter((q) => q !== c);
      log(`قرارداد صادرات ${PR[c.p][0]} با تحویل کامل تسویه شد.`);
    } else if (c.days <= 0) {
      const penalty = c.remaining * c.unitPrice * 0.18,
        refund = Number.isFinite(c.advanceBalance) ? Math.max(0, c.advanceBalance) : 0;
      S.money -= penalty + refund;
      S.tradeHistory.unshift({
        p: c.p,
        qty: c.qty,
        delivered: c.delivered,
        status: 'نقض قرارداد',
        day: S.day,
        penalty,
        refund
      });
      S.tradeContracts = S.tradeContracts.filter((q) => q !== c);
      log(
        `مهلت قرارداد ${PR[c.p][0]} تمام شد؛ ${fa(c.delivered)} تحویل، بازپرداخت پیش‌دریافت ${fa(refund)} و جریمه ${fa(penalty)} اعمال شد.`
      );
    }
  });
  S.tradeRevenueToday = contractIncome;
  S.tradeDeliveriesToday = deliveries;
  return contractPort;
}
