import test from 'node:test';
import assert from 'node:assert/strict';
import { installDailyTick } from '../js/app/simulation/daily-tick.js';
import { createFreshState } from '../js/core/game-state.js';
import { ALT, ALTERNATIVE_FEED_FACTOR, D, GH, GW, IN, MK, OPN, OPT, OUT, PR, SF, TY } from '../js/data/catalog.js';
import { createEconomy } from '../js/engine/economy.js';
import { createProcessModel } from '../js/engine/process.js';
import { installMaintenanceAdvisor } from '../js/features/maintenance/advisor.js';
import { analyzeUnit } from '../js/features/maintenance/model/unit-diagnostics.js';
import { renderAdvisorReport } from '../js/features/maintenance/view/crisis-advisor.js';
import { installProductMarket } from '../js/features/products/market.js';
import { saveProductRule } from '../js/features/products/model/product-automation.js';
import { renderProductMarket } from '../js/features/products/view/product-market.js';
import { cl } from '../js/core/format.js';

const ctx = { D, IN, OUT, PR, cap: () => 150 };

function scenario(types) {
  const S = createFreshState();
  S.money = 10_000;
  S.ops = 40;
  S.port = 1000;
  S.grid = Array(GW * GH).fill(null);
  S.u = types.map(t => ({
    t, st: 'run',
    eq: D[t].e.map(([, standby]) => ({
      h: 100, l: 1, f: null, running: true,
      ...(standby ? { reserve: { h: 100, f: null, running: false } } : {})
    })),
    v: D[t].v.map(v => v[2]), h: D[t].v.map(() => [])
  }));
  const noop = () => {};
  const model = createProcessModel({ S, TY, SF, PR, MK, cl, r: () => .5, log: noop });
  const game = {
    S, cap: ctx.cap, country: model.country, r: () => .5, emission: () => 0,
    opsNeed: () => S.u.reduce((n, u) => n + (u.st === 'run' ? OPN[u.t] : 0), 0),
    opsAvail: () => S.ops,
    lvl: () => 1, anyOut: () => false, pinc: () => 0,
    MS: [], log: noop, recordSOE: noop, updateDynamicEconomy: noop, updateRegionalEconomy: noop
  };
  installDailyTick(game);
  return game;
}

function refinery({ crude = 35, power = 10, hydrogen = 0, naphtha = 150 } = {}) {
  const game = scenario([0]), { S } = game;
  Object.assign(S.tanks, { crude, power, hydrogen, naphtha });
  S.u[0].name = 'پالایشگاه ساحل';
  S.hold.naphtha = true;
  return game;
}

function rule(S, product, values) {
  saveProductRule(S, product, values, PR);
}

test('threshold sales leave enough effective capacity to import required refinery feed', () => {
  const { S, tick } = refinery({ crude: 0, naphtha: 150 });
  S.port = 40;
  rule(S, 'naphtha', { sellMode: 'threshold' });
  tick();
  const { ledger } = analyzeUnit(S, 0, ctx);
  assert.equal(ledger.market.naphtha.thresholdSold, 20);
  assert.match(ledger.market.naphtha.saleReason, /خوراک ضروری/);
  assert.equal(ledger.feeds.find(f => f.product === 'crude').imported, 20);
  assert.equal(ledger.factors.feed, 1);
  assert.ok(ledger.products.find(p => p.product === 'fuel').accepted > 0);
});

test('naphtha sold on threshold earns product credit despite the legacy hold flag, and the recorded day survives an edit', () => {
  const { S, tick } = refinery({ naphtha: 127.5, hydrogen: 2 });
  rule(S, 'naphtha', { sellMode: 'threshold' });
  tick();
  const report = analyzeUnit(S, 0, ctx);
  const flow = report.ledger.market.naphtha;
  const output = report.ledger.products.find(p => p.product === 'naphtha');
  assert.equal(report.name, 'پالایشگاه ساحل');
  assert.equal(S.hold.naphtha, true);
  assert.equal(flow.saleMode, 'threshold');
  assert.equal(flow.thresholdSold, 45);
  assert.equal(output.valuation, 'allocated');
  assert.ok(output.value > 0 && output.spilled === 0);
  assert.ok(!report.causes.some(c => c.code === 'held-naphtha' || c.code === 'realization-naphtha'));
  assert.equal(S.cashDay.stockSell, S.productTrades.find(t => t.product === 'naphtha' && t.side === 'sell').total);
  rule(S, 'naphtha', { sellMode: 'off' });
  const afterEdit = analyzeUnit(S, 0, ctx);
  assert.deepEqual(afterEdit.causes, report.causes);
  const html = renderAdvisorReport(afterEdit, S, PR);
  assert.match(html, /فروش مازاد در آستانه/);
  S.marketProduct = 'naphtha';
  const market = renderProductMarket(S, ctx);
  assert.match(market, /فروش خودکار تنظیم‌شده · فروش خودکار خاموش/);
  assert.match(market, /فروش خودکار ثبت‌شده.*فروش مازاد در آستانه/);
});

test('naphtha overflow explains a price floor, even when the effective port was also exhausted', () => {
  const { S, tick } = refinery({ hydrogen: 2, naphtha: 148 });
  S.port = 40;
  S.fx.sanc = 3;
  S.tanks.steel = 40;
  S.tradeContracts = [{ id: 1, p: 'steel', qty: 40, remaining: 40, days: 5, unitPrice: 40 }];
  rule(S, 'naphtha', { sellMode: 'threshold', minSell: 9999 });
  tick();
  const { ledger, causes } = analyzeUnit(S, 0, ctx);
  assert.equal(ledger.port.capacity, 26);
  assert.equal(ledger.port.remaining, 0);
  assert.equal(ledger.market.naphtha.salePortLimited, false);
  assert.match(causes.find(c => c.code === 'storage-naphtha').evidence, /کف تعیین‌شده/);
  const realization = causes.find(c => c.code === 'realization-naphtha');
  assert.equal(realization.target, 'inventory');
  assert.match(realization.evidence, /کف تعیین‌شده/);
  assert.ok(!causes.some(c => c.code === 'held-naphtha'));
});

test('paused threshold sales describe the global pause rather than legacy hold or an imaginary port limit', () => {
  const { S, tick } = refinery({ hydrogen: 2, naphtha: 130 });
  rule(S, 'naphtha', { sellMode: 'threshold' });
  S.marketAutomation.enabled = false;
  tick();
  const { ledger, causes } = analyzeUnit(S, 0, ctx);
  assert.equal(ledger.market.naphtha.saleMode, 'paused');
  assert.equal(ledger.market.naphtha.thresholdSold, 0);
  const cause = causes.find(c => c.code === 'realization-naphtha');
  assert.equal(cause.target, 'inventory');
  assert.match(cause.evidence, /برنامهٔ مخزنی سراسری خاموش بود/);
  assert.ok(!causes.some(c => c.code === 'held-naphtha'));
});

test('daily export attributes only its actual port restriction and contracted shipments count toward output credit', () => {
  const { S, tick } = refinery({ hydrogen: 2, naphtha: 100 });
  S.port = 40;
  S.tradeContracts = [{ id: 1, p: 'naphtha', qty: 40, remaining: 40, days: 5, unitPrice: 7, advanceBalance: 50 }];
  S.hold.naphtha = false;
  tick();
  const { ledger } = analyzeUnit(S, 0, ctx);
  assert.equal(ledger.market.naphtha.sold, 0);
  assert.equal(ledger.market.naphtha.contractDelivered, 40);
  assert.equal(ledger.market.naphtha.salePortLimited, true);
  assert.equal(S.tradeRevenueToday, 230);
  assert.ok(ledger.products.find(p => p.product === 'naphtha').value > 0);
});

test('the configured daily sale releases a legacy hold, and trade navigation opens the matching product or port', () => {
  const { S } = refinery();
  let anchor = '';
  const originalDocument = globalThis.document;
  const game = { S, cap: ctx.cap, actions: {}, clickHandlers: [], draw() {}, save() {}, log() {} };
  installProductMarket(game);
  installMaintenanceAdvisor(game);
  try {
    globalThis.document = {
      getElementById(id) {
        if (id === 'auto-market-sellMode') return { value: 'legacy' };
        anchor = id;
        return null;
      }
    };
    game.clickHandlers[0](null, null, { p: 'naphtha' }, 0, 'market-rule-save');
    assert.equal(S.hold.naphtha, false);
    game.navigateDiagnostic({ target: 'inventory', p: 'naphtha' });
    assert.equal(S.marketProduct, 'naphtha');
    assert.equal(anchor, 'trade-desk');
    game.navigateDiagnostic({ target: 'trade', p: 'naphtha' });
    assert.equal(S.manageSection, 'trade');
    assert.equal(anchor, 'trade-product-naphtha');
    game.navigateDiagnostic({ target: 'trade', p: 'hydrogen' });
    assert.equal(anchor, 'trade-overview');
  } finally {
    globalThis.document = originalDocument;
  }
});

test('hydrogen is a quantified optional shortfall in the refinery but a production blocker in the ammonia plant', () => {
  const oil = refinery({ naphtha: 0 });
  rule(oil.S, 'hydrogen', { emergency: false });
  oil.tick();
  const report = analyzeUnit(oil.S, 0, ctx);
  const hydrogen = report.causes.find(c => c.code === 'feed-hydrogen');
  assert.equal(report.ledger.factors.feed, 1);
  assert.equal(report.ledger.factors.optionalFeed, .6);
  assert.ok(report.ledger.products.every(p => p.accepted > 0));
  assert.match(hydrogen.title, /هیدروژن کمکی/);
  assert.match(hydrogen.evidence, /۴۰٪/);
  assert.notEqual(report.primary.code, 'feed-hydrogen');
  const ammonia = scenario([11]);
  ammonia.S.tanks.power = 10;
  rule(ammonia.S, 'hydrogen', { emergency: false });
  ammonia.tick();
  const blocked = analyzeUnit(ammonia.S, 0, ctx);
  assert.equal(blocked.primary.code, 'feed-hydrogen');
  assert.match(blocked.primary.title, /هیدروژن الزامی/);
  assert.equal(blocked.ledger.factors.feed, 0);
  assert.ok(blocked.ledger.products.every(p => p.accepted === 0));
});

test('when a required feed is completely blocked, optional hydrogen does not use cash and an off rule is the actual cause', () => {
  const { S, tick } = refinery({ crude: 0, hydrogen: 0, naphtha: 0 });
  S.marketAutomation = { reserve: S.money };
  rule(S, 'crude', { emergency: false });
  tick();
  const { ledger, primary, causes } = analyzeUnit(S, 0, ctx);
  assert.equal(primary.code, 'feed-crude');
  assert.equal(primary.target, 'inventory');
  assert.match(primary.evidence, /تأمین فوری خاموش/);
  assert.doesNotMatch(primary.evidence, /نقد قابل استفاده/);
  assert.ok(!causes.some(c => c.code === 'feed-hydrogen'));
  assert.ok(!ledger.feeds.some(f => f.product === 'hydrogen'));
  const economy = createEconomy({ getState: () => S, PR, IN, OUT, IMP: () => 1, fa: String });
  assert.equal(economy.feedCost(0), 20 * PR.crude[2] + 2 * PR.power[2]);
});

test('ethane offered for sale retains enough for ethylene, and actual withdrawal counts as internal feed cost', () => {
  const { S, tick } = scenario([6]);
  Object.assign(S.tanks, { ethane: 130, steam: 12 });
  rule(S, 'naphtha', { emergency: false });
  rule(S, 'ethane', { sellMode: 'threshold' });
  tick();
  const { ledger, causes } = analyzeUnit(S, 0, ctx);
  const feed = ledger.feeds.find(f => f.product === 'naphtha');
  assert.equal(feed.alternativeProduct, 'ethane');
  assert.ok(Math.abs(feed.alternativeQuantity - IN[6].naphtha / ALTERNATIVE_FEED_FACTOR) < 1e-8);
  assert.ok(feed.missing < .001);
  assert.ok(Math.abs(feed.internalCost - feed.alternativeQuantity * PR.ethane[2] * .5) < 1e-8);
  assert.ok(Math.abs(ledger.totalCost - Object.values(ledger.costs).reduce((a, b) => a + b, 0)) < 1e-8);
  assert.ok(!causes.some(c => c.code === 'feed-naphtha'));
});

test('grid disruption and personnel shortage are independent, and catalog connections use real stock keys', () => {
  const { S, tick } = refinery({ hydrogen: 2 });
  S.gridIncident = { days: 3, factor: .68 };
  tick();
  const { ledger, causes } = analyzeUnit(S, 0, ctx);
  assert.equal(ledger.factors.operator, 1);
  assert.ok(causes.some(c => c.code === 'grid-incident'));
  assert.ok(!causes.some(c => c.code === 'operators'));
  assert.equal(IN.length, D.length);
  assert.equal(OUT.length, D.length);
  D.forEach((_, index) => {
    for (const product of [...Object.keys(IN[index]), ...Object.keys(OUT[index])])
      assert.ok(Object.hasOwn(PR, product));
    for (const product of Object.keys(OPT[index] || {})) assert.ok(IN[index][product] > 0);
    for (const [main, substitute] of Object.entries(ALT[index] || {}))
      assert.ok(IN[index][main] > 0 && Object.hasOwn(PR, substitute));
  });
});
