import test from 'node:test';
import assert from 'node:assert/strict';
import { createGame } from '../js/app/create-game.js';
import { createFreshState } from '../js/core/game-state.js';
import { importSnapshot, exportSnapshot } from '../js/core/save-store.js';
import { projectEstimate } from '../js/features/industry/view/player-help.js';
import { effectiveTradePort, remainingTradePort } from '../js/features/products/model/trade-conditions.js';
import { renderVectorMap } from '../js/features/country/view/map-vector.js';
import { CITIES } from '../js/data/world-map.js';
import { D, OPN, PR, IMP } from '../js/data/catalog.js';

test('fresh game builds its second project from sales and normal game rewards', t => {
  const previous = {
    document: globalThis.document, localStorage: globalThis.localStorage,
    interval: globalThis.setInterval, timeout: globalThis.setTimeout, random: Math.random
  };
  const elements = new Map(), listeners = new Map(), stored = new Map();
  const element = key => {
    if (!elements.has(key)) elements.set(key, {
      dataset: {}, classList: { toggle() {} }, setAttribute() {}, scrollIntoView() {}, focus() {}
    });
    return elements.get(key);
  };
  globalThis.document = {
    activeElement: null, hidden: false, querySelector: key => key.startsWith('#') ? element(key) : null,
    querySelectorAll: () => [], getElementById: id => element('#' + id),
    addEventListener: (key, callback) => listeners.set(key, [...(listeners.get(key) || []), callback])
  };
  globalThis.localStorage = {
    getItem: key => stored.get(key) ?? null,
    setItem: (key, value) => stored.set(key, value),
    removeItem: key => stored.delete(key)
  };
  globalThis.setInterval = () => 1;
  globalThis.setTimeout = () => 1;
  Math.random = () => .5;
  try {
    const game = createGame(), { S } = game;
    const click = (a, data) => listeners.get('click')[1]({
      target: { disabled: false, dataset: { a, ...data }, closest(selector) { return selector === 'button' ? this : null; } }
    });
    const build = type => {
      const i = String(S.u.length);
      click('buy', { t: String(type) });
      for (const _ of D[type].e) click('install', { i });
      assert.equal(S.u[Number(i)].st, 'ready');
      click('start', { i });
      for (let k = 0; k < 5; k++) click('step', { i, k: String(k) });
      assert.equal(S.u[Number(i)].st, 'run');
    };
    assert.equal(S.money, 5000);
    build(0);
    const estimate = projectEstimate(S, D[1], PR, IMP, game.feedCost(1));
    const operators = OPN[0] + OPN[1] - S.ops;
    const goalCash = estimate.total + operators * 1200 + 1000;
    do {
      game.tick();
      assert.equal(S.military, undefined);
      if (S.day === 2 || S.day === 20) {
        assert.ok(S.cashDay.closing > S.cashDay.opening);
        assert.equal(S.portCapacityToday, 40);
        assert.ok(S.marketDay.naphtha.sold > 0 && S.marketDay.fueloil.sold > 0);
      }
    } while (S.money < goalCash && S.day < 120);
    assert.ok(S.money >= goalCash);
    for (let i = 0; i < operators; i++) click('hire', {});
    build(1);
    assert.equal(S.debt || 0, 0);
    assert.ok(S.money >= 1000);
    t.diagnostic('Second project started on day ' + S.day + ', cash remaining ' + Math.round(S.money));
  } finally {
    globalThis.document = previous.document;
    globalThis.localStorage = previous.localStorage;
    globalThis.setInterval = previous.interval;
    globalThis.setTimeout = previous.timeout;
    Math.random = previous.random;
  }
});

test('a backup keeps cash and market settings and retires scheduled country effects', () => {
  const old = createFreshState();
  Object.assign(old, {
    day: 20, money: 2175, port: 40, portCapacityToday: 14, portRemainingToday: 9, portUsedToday: 5,
    mapLayer: 'defense', hold: { naphtha: true },
    military: { blockade: { until: 28 }, damaged: { port: 27 }, raid: { incoming: { day: 21 } } },
    cashDay: { day: 20, opening: 2885, closing: 2175, other: 20, nationalExpense: 700, countryUpkeep: 30 }
  });
  const restored = importSnapshot(JSON.stringify({ ...exportSnapshot(old), gameVersion: '57.7' }));
  assert.equal(restored.money, 2175);
  assert.equal(restored.hold.naphtha, true);
  assert.equal(restored.mapLayer, 'overview');
  assert.equal(restored.military, undefined);
  assert.equal(restored.cashDay.other, -710);
  assert.equal(effectiveTradePort(restored), 40);
  assert.equal(remainingTradePort(restored), 35);
  const map = renderVectorMap({ ...restored, tab: 'c' }, CITIES);
  assert.match(map, /data-map-kind="district"/);
  assert.doesNotMatch(map, /vector-military|data-map-kind="enemy"/);
});
