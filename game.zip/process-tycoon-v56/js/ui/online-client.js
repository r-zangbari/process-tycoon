const goods={water:'آب',fuel:'سوخت',cement:'سیمان',steel:'فولاد',naphtha:'نفتا'};
const prices={water:480,fuel:600,cement:520,steel:900,naphtha:650};
const plans={steady:'پایدار',reserve:'ذخیره',fast:'سریع'};
const statuses={active:'فعال',offered:'در انتظار پذیرش',expired:'منقضی',complete:'تکمیل',declined:'رد شده',invited:'دعوت'};
const $=q=>document.querySelector(q),connect=$('#connect'),world=$('#world');
const number=x=>Number(x||0).toLocaleString('fa-IR');
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const date=x=>new Date(x).toLocaleString('fa-IR');
const goodsList=()=>Object.entries(goods).map(([k,v])=>`<option value="${k}">${v}</option>`).join('');
const amount=(max=500)=>`<label>مقدار <input name="quantity" type="number" min="1" max="${max}" value="1" required></label>`;
const form=(action,fields,label,id='')=>`<form data-action="${action}" data-id="${esc(id)}">${fields}<button>${label}</button></form>`;
let endpoint='',token='',busy=false;
const say=message=>{$('#message').textContent=message};
function serverUrl(value){
 const url=new URL(value||'.',location.href);
 const local=url.protocol==='http:'&&(url.origin===location.origin||['127.0.0.1','localhost','[::1]'].includes(url.hostname));
 if((url.protocol!=='https:'&&!local)||url.username||url.password||url.search||url.hash)throw Error('نشانی HTTPS معتبر سرور بازی را وارد کن.');
 return url.origin;
}
async function request(path,body){
 const headers={};
 if(token)headers.Authorization='Bearer '+token;
 if(body)headers['Content-Type']='application/json';
 let res;
 try{res=await fetch(endpoint+'/api/'+path,{method:body?'POST':'GET',headers,body:body?JSON.stringify(body):undefined})}
 catch{throw Error('اتصال به سرور برقرار نشد. نشانی، اینترنت و تنظیم اتصال GitHub Pages را بررسی کن.')}
 const content=await res.json().catch(()=>null);
 if(!res.ok||!content)throw Error(content?.error||'سرور آنلاین در این نشانی پیدا نشد.');
 if(!content.me)throw Error('پاسخ سرور آنلاین نامعتبر است.');
 return content;
}
function readSession(key){
 try{return localStorage.getItem(key)||''}catch{return ''}
}
function storeSession(key,value){
 try{localStorage.setItem(key,value)}catch{}
}
async function receive(fn,onResult){
 if(busy)return;
 busy=true;say('در حال ارتباط با سرور…');
 try{const result=await fn();if(onResult)onResult(result);render(result);say('اطلاعات جهان به‌روز شد.')}
 catch(e){say(e.message)}
 finally{busy=false}
}
connect.elements.server.value=readSession('tycoon-online-server');
connect.addEventListener('submit',e=>{
 e.preventDefault();
 const data=new FormData(connect),join=e.submitter?.value==='join';
 receive(async()=>{
  endpoint=serverUrl(data.get('server'));
  token=join?'':String(data.get('token')||readSession('tycoon-token:'+endpoint)).trim().toLowerCase();
  if(!join&&!token)throw Error('کلید حساب قبلی را وارد کن یا یک کشور جدید بساز.');
  return request(join?'join':'world',join?{name:data.get('name'),code:data.get('code')}:null);
 },result=>{
  token=result.token||token;storeSession('tycoon-token:'+endpoint,token);storeSession('tycoon-online-server',endpoint);
  connect.elements.token.value='';
  $('#connection').open=false;
 });
});
function render(data){
 const me=data.me;
 const peers=`<label>کشور مقصد <select name="target" required><option value="">انتخاب کن</option>${data.people.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select></label>`;
 const terms=`<label>محصول <select name="product">${goodsList()}</select></label>${amount()}<label>قیمت واحد <input name="price" type="number" min="1" max="200" value="10" required></label>`;
 world.hidden=false;
 world.innerHTML=`
 <section class="online-card"><h2>${esc(me.name)}</h2><p>نقد ${number(me.cash)} · پیروزی در رقابت ${number(me.wins)}</p>
 ${me.freightDelayUntil>data.now?`<p>تحویل تولید آنلاین تا ${date(me.freightDelayUntil)} به تأخیر افتاده است.</p>`: ''}
 <div class="online-grid">${Object.entries(goods).map(([p,label])=>`<div class="online-tile"><b>${label}</b> · ${number(me.stock[p])}
 ${me.projects[p]?(me.projects[p].next<=data.now&&me.freightDelayUntil<=data.now?form('collect',`<input type="hidden" name="product" value="${p}">`,'دریافت تولید'):`<small>نوبت تولید ${date(me.projects[p].next)}</small>`):form('project',`<input type="hidden" name="product" value="${p}">`,'ساخت پروژه · '+number(prices[p]))}</div>`).join('')}</div>
 ${form('refresh','','تازه‌سازی جهان')}<details><summary>کلید بازیابی این حساب</summary><p>کلید را در محل امن نگه دار و برای ورود روی دستگاه دیگر استفاده کن.</p><input readonly dir="ltr" aria-label="کلید بازیابی" value="${esc(token)}"></details></section>
 <section class="online-card"><h2>بازار صادرات و واردات</h2><p>آگهی فروش موجودی را تا خرید، لغو یا انقضای سه‌روزه رزرو می‌کند. قیمت کل قبل از خرید نمایش داده می‌شود.</p>
 ${form('offer',terms,'ثبت آگهی فروش')}
 <div class="online-grid">${data.offers.map(o=>`<div class="online-tile">${esc(o.sellerName)} · ${goods[o.product]} · ${number(o.quantity)} واحد<br>قیمت کل ${number(o.quantity*o.price)}
 ${o.seller===me.id?form('withdraw','','لغو آگهی',o.id):form('buy','','خرید و واردات',o.id)}</div>`).join('')||'<p>آگهی فعالی وجود ندارد.</p>'}</div></section>
 <section class="online-card"><h2>قرارداد چندروزهٔ تحویل</h2><p>خریدار هنگام پذیرش اعتبار را رزرو می‌کند. فروشنده می‌تواند در چند نوبت تحویل دهد و پس از هر تحویل پول همان مقدار را بگیرد. پس از مهلت، اعتبارِ تحویل‌نشده به خریدار برمی‌گردد.</p>
 ${form('contract',peers+terms+'<label>مهلت پس از پذیرش، روز <input name="days" type="number" min="1" max="14" value="3" required></label>','فرستادن پیشنهاد')}
 <div class="online-grid">${data.agreements.map(o=>`<div class="online-tile">${esc(o.sellerName)} ← ${esc(o.buyerName)} · ${goods[o.product]}<br>${statuses[o.status]} · تحویل ${number(o.delivered)} از ${number(o.quantity)} · کل ${number(o.quantity*o.price)}<small>مهلت ${date(o.deadline)}</small>
 ${o.status==='offered'?(o.buyer===me.id?form('accept-contract','','پذیرش و رزرو اعتبار',o.id):'')+form('close-contract','','بستن پیشنهاد',o.id):o.status==='active'&&o.seller===me.id?form('deliver',amount(o.quantity-o.delivered),'تحویل از مخزن',o.id):''}</div>`).join('')||'<p>قراردادی ثبت نشده است.</p>'}</div></section>
 <section class="online-card"><h2>اتحاد و پایانهٔ مشترک</h2>
 ${data.alliance?`<p>${esc(data.alliance.name)} · ${number(data.alliance.members.length)} عضو · ${number(data.alliance.fund)} از ۶۰ سیمان</p>
 <p>پایانهٔ تکمیل‌شده به تحویل هر نوبت تولید اعضا ۴ واحد اضافه می‌کند.</p>
 ${data.alliance.leader===me.id?form('invite',peers,'دعوت به اتحاد'):''}
 ${data.alliance.fund<60?form('contribute',amount(60-data.alliance.fund),'تحویل سیمان به پایانه'):''}`:
 form('alliance','<label>نام اتحاد <input name="name" maxlength="32" required></label>','ساخت اتحاد · ۱۵۰')+
 data.invites.map(i=>form('accept-invite',`<span>${esc(i.name)}</span>`,'پذیرش دعوت',i.id)).join('')}</section>
 <section class="online-card"><h2>نبرد داوطلبانهٔ تدارکات</h2><p>با پذیرش دعوت، دو کشور تا ۲۴ ساعت برای ثبت تصمیم فرصت دارند. هر طرف ۱ تا ۸ واحد سوخت و یک روش تدارکات ثبت می‌کند. پایدار بر ذخیره، ذخیره بر سریع و سریع بر پایدار ۳ امتیاز برتری دارد. نتیجه پس از ثبت هر دو طرف اعلام می‌شود. تحویل تولید آنلاین کشور بازنده یک ساعت به تأخیر می‌افتد. تساوی یا پایان مهلت، سوخت ثبت‌شده را برمی‌گرداند.</p>
 ${form('challenge',peers,'دعوت به نبرد')}
 <div class="online-grid">${data.contests.map(c=>`<article class="online-tile">${esc(c.hostName)} و ${esc(c.guestName)} · ${statuses[c.status]}<small>مهلت ${date(c.deadline)}</small>
 ${c.status==='invited'&&c.guest===me.id?form('accept-challenge','','پذیرش نبرد',c.id)+form('decline-challenge','','رد دعوت',c.id):''}
 ${c.status==='active'?(c.submitted?'<p>تصمیم ثبت شد.</p>':form('contest-submit',amount(8)+`<label>روش <select name="plan">${Object.entries(plans).map(([k,n])=>`<option value="${k}">${n}</option>`).join('')}</select></label>`,'ثبت تصمیم و مصرف سوخت',c.id)):''}
 ${c.result?`<p>${c.winner?(c.winner===me.id?'پیروزی':'پیروزی کشور مقابل'):'تساوی'} · ${number(c.result.hostScore)} به ${number(c.result.guestScore)}</p>`:''}</article>`).join('')||'<p>رقابتی ثبت نشده است.</p>'}</div></section>`;
}
world.addEventListener('submit',e=>{
 const form=e.target.closest('form[data-action]');if(!form)return;
 e.preventDefault();
 const action=form.dataset.action;
 const input=Object.fromEntries(new FormData(form));input.action=action;input.id=form.dataset.id;
 for(const key of ['quantity','price','days'])if(key in input)input[key]=Number(input[key]);
 receive(()=>action==='refresh'?request('world'):request('action',input));
});
if(readSession('tycoon-token:'+readSession('tycoon-online-server'))){
 try{
  endpoint=serverUrl(connect.elements.server.value);token=readSession('tycoon-token:'+endpoint);
  receive(()=>request('world'),()=>{$('#connection').open=false});
 }catch(e){say(e.message)}
}
