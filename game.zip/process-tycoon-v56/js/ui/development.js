import {developmentSummary,storyFactor} from '../systems/development.js';
const n=x=>Number(x||0).toLocaleString('fa-IR',{maximumFractionDigits:1});
export function renderDevelopment(S,estimate){
 const opportunities=developmentSummary(S).filter(x=>x.status!=='waiting');
 const event=S.development?.event;
 const active=event&&S.day>=event.startDay;
 const notice=event?'<aside class="dev-crisis" role="status"><b>'+
  (event.type==='port'?'اختلال داستانی تجارت ساحلی':'اختلال داستانی خدمات صنعتی')+'</b><p>'+
  (active?'فعال · '+n(event.endDay-S.day)+' روز باقی‌مانده · ظرفیت '+n(100*storyFactor(S,event.type))+'٪':n(event.startDay-S.day)+' روز تا آغاز · مدت اختلال ۳ روز')+
  '</p><p>'+(event.type==='port'?'ذخیرهٔ خوراک و ظرفیت پایهٔ بندر ۸۰ یا بالاتر برای ادامهٔ کار کمک می‌کنند.':'تولید در زمان اختلال کمتر می‌شود؛ برای قراردادها موجودی اطمینان نگه دار.')+
  '</p><button data-a="dev-prepare" '+(event.prepared||S.money<280?'disabled':'')+'>'+
  (event.prepared?'خدمات جایگزین رزرو شد':'رزرو خدمات جایگزین · ۲۸۰')+'</button> <button data-a="dev-stock">دیدن مخازن</button></aside>':'';
 return '<section class="card wide development-card" id="development-contracts"><h2>قراردادهای توسعهٔ کشور</h2>'+
  notice+(opportunities.length?opportunities.map(info=>{
   const {key,title,project,output,reward,demand,delivered,shortage,status,streak,daysRequired}=info;
   const price=estimate(project);
   return '<article><h3>'+title+'</h3><p>خریدار: شبکهٔ خدمات شهری · نیاز روزانه '+n(demand)+' · تحویل '+n(delivered)+' · کسری '+n(shortage)+' '+(key==='water'?'هزار مترمکعب':'واحد برق بازی')+'</p>'+
   (status==='complete'?'<p>تکمیل شد · اعتبار '+n(reward)+' به بودجهٔ عمومی رسید.</p>':
   '<p>پنج روزِ متوالی دست‌کم ۹۵٪ نیاز واقعی شهر را تأمین کن. خرید از بازار و تولید داخلی هر دو قابل استفاده‌اند.</p>'+
   '<label>پیشرفت <progress max="'+daysRequired+'" value="'+streak+'"></progress> '+n(streak)+' از '+n(daysRequired)+' روز</label>'+
   (status==='offered'?'<p><button data-a="dev-accept" data-k="'+key+'">پذیرش قرارداد</button></p>':'')+
   '<p>پروژهٔ پیشنهادی: '+(key==='water'?'تصفیه آب · خوراک آب خام':'نیروگاه خورشیدی · بدون خوراک مادی')+' · خروجی اسمی '+n(output)+' در روز. هزینهٔ برآوردی '+n(price)+'، نقد پس از ساخت حدود '+n(S.money-price)+'.</p>'+
   '<button data-a="dev-project" data-i="'+project+'">دیدن پروژهٔ پیشنهادی</button> <button data-a="dev-stock" data-k="'+key+'">دیدن مخزن</button>')+'</article>';
  }).join(''):'<p>پس از اولین روز تولید و ثبت کسری واقعی آب یا برق شهر، فرصت توسعه ظاهر می‌شود.</p>')+'</section>';
}
