import test from 'node:test';import assert from 'node:assert/strict';
import {analyzeUnit,recommendations} from '../js/systems/unit-diagnostics.js';
import {nextAction} from '../js/ui/player-help.js';
import {D,PR,OPN} from '../js/data/catalog.js';
const ctx={D,PR,OPN};
const make=()=>({day:4,money:10000,port:100,portUsedToday:0,portRemainingToday:100,hold:{},marketDay:{methanol:{sold:0,demand:80}},u:[{t:5,st:'run',eq:[],v:D[5].v.map(v=>v[2]),pl:-100,dayEconomics:{day:4,revenue:200,totalCost:300,profit:-100,costs:{base:80,wages:20,feedImported:100,feedInternal:50,energy:50},feeds:[],products:[{product:'methanol',requested:10,accepted:10,spilled:0,unitValue:0,value:0}],factors:{operator:1,strike:1,quality:100,qualityFactor:1,capacityUse:100,avgHealth:95,feedIncident:1,grid:1}}}]});
test('no sales does not invent a full port; actual capacity exhaustion is distinguished',()=>{
 const s=make();const first=analyzeUnit(s,0,ctx);assert.ok(!first.causes.find(c=>c.code==='realization-methanol').evidence.includes('به سقف مشترک رسیده'));
 s.portRemainingToday=0;s.portUsedToday=100;const full=analyzeUnit(s,0,ctx);assert.equal(full.causes.find(c=>c.code==='realization-methanol').target,'trade');
});
test('only this unit actual spilled production is blamed; the global spill counter is not attributed to other units',()=>{
 const s=make();s.prodLoss={methanol:200};assert.ok(!analyzeUnit(s,0,ctx).causes.some(c=>c.code.startsWith('storage')));
 s.u[0].dayEconomics.products[0].spilled=3;const report=analyzeUnit(s,0,ctx);assert.equal(report.primary.code,'storage-methanol');assert.equal(report.primary.product,'methanol');
});
test('feed shortages retain product and real cash/port constraints for direct navigation',()=>{
 const s=make();s.u[0].dayEconomics.feeds=[{product:'gas',required:60,delivered:20,missing:40,importCost:20,cashLimited:true,portLimited:false}];
 const c=analyzeUnit(s,0,ctx).causes.find(c=>c.code==='feed-gas');assert.equal(c.target,'finance');assert.equal(c.product,'gas');
 s.u[0].dayEconomics.feeds[0].cashLimited=false;s.u[0].dayEconomics.feeds[0].portLimited=true;assert.equal(analyzeUnit(s,0,ctx).primary.target,'trade');
});
test('positive day with negative smoothed result is identified as recovery, not another loss day',()=>{
 const s=make();s.u[0].dayEconomics.profit=50;s.u[0].dayEconomics.revenue=350;s.u[0].dayEconomics.products[0].unitValue=40;const r=analyzeUnit(s,0,ctx);assert.ok(r.recovering);assert.equal(r.primary.code,'recovering');assert.ok(!r.causes.some(c=>c.code==='cost-gap'));
});
test('safety and active crisis outrank construction and a deliberately idle unit',()=>{
 const s=make();s.u.unshift({t:0,st:'off',eq:[],v:D[0].v.map(v=>v[2])});s.u.push({t:1,st:'trip',eq:[],v:D[1].v.map(v=>v[2])});
 let data=recommendations(s,ctx),next=nextAction(s,D,data.items);assert.equal(next.index,2);assert.equal(next.target,'controls');
 s.cr={k:'feed'};assert.equal(nextAction(s,D,recommendations(s,ctx).items).target,'crisis');
});
test('legacy and stale daily ledgers explicitly request fresh evidence',()=>{
 const s=make();s.u[0].dayEconomics.day=3;const report=analyzeUnit(s,0,ctx);assert.equal(report.ledger,null);assert.equal(report.primary.code,'missing-ledger');assert.equal(report.primary.target,'time');
});
