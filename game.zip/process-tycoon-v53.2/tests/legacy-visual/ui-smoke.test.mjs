import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState,normalizeState,STORAGE_KEY} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';

test('DOM-free JS smoke: renders management cards and accepts new pipeline/order actions',async()=>{
 const pre=createFreshState();normalizeState(pre,{D,PR,MK,GW,GH,setImportMultiplier});
 pre.tab='m';pre.manageSection='fields';pre.money=200000;pre.offshore.oil.stage=5;
 let saved=JSON.stringify(pre);
 globalThis.localStorage={getItem:(k)=>k===STORAGE_KEY?saved:null,setItem:(k,v)=>{if(k===STORAGE_KEY)saved=v}};
 const refs=new Map(),events=new Map();
 const el=(name)=>refs.get(name)||refs.set(name,{textContent:'',innerHTML:'',className:'',dataset:{},setAttribute(){},classList:{toggle(){}}}).get(name);
 globalThis.document={activeElement:null,
  querySelector:(q)=>q.startsWith('#')?el(q):null,
  querySelectorAll:()=>[],
  getElementById:()=>null,
  addEventListener:(name,callback)=>{const arr=events.get(name)||[];arr.push(callback);events.set(name,arr)}
 };
 const oldInterval=globalThis.setInterval;globalThis.setInterval=()=>1;
 try{
  await import('../js/main.js');
  const html=el('#app').innerHTML;
  assert.match(html,/ذخیره قابل برداشت/);
  assert.match(html,/خط لوله زیردریایی/);
  assert.match(html,/data-a="offshore-pipeline"/);
  const target={dataset:{a:'offshore-pipeline',p:'oil'},disabled:false,
   closest(sel){return sel==='button'?this:null}};
  const handler=events.get('pointerdown')?.[0];assert.equal(typeof handler,'function');handler({target});
  const state=JSON.parse(saved);
  assert.equal(state.offshore.oil.pipelineLevel,0);
  assert.equal(state.offshore.oil.pipeProject.target,1);
  assert.equal(state.money,200000-7500);
  assert.match(el('#app').innerHTML,/پروژه انتقال در حال اجرا/);
  const press=(a,props={})=>handler({target:{dataset:{a,...props},disabled:false,closest(sel){return sel==='button'?this:null}}});
  press('tab',{t:'c'});
  assert.doesNotMatch(el('#app').innerHTML,/national-buildings\/(?:home|farm|factory|rooftop)-|class="national-plot-hit"/);
  press('hub-open',{k:'housing'});
  const homes=JSON.parse(saved).grid.filter(b=>b?.t==='h').length;
  let visible=0;
  const pages=[...el('#app').innerHTML.matchAll(/data-a="hub-page" data-page="(\d+)"/g)];
  for(const [,page] of pages){press('hub-page',{page});visible+=(el('#app').innerHTML.match(/national-buildings\/home-/g)||[]).length}
  assert.equal(visible,homes);press('hub-close');press('hub-open',{k:'energy'});
  assert.match(el('#app').innerHTML,/مرکز انرژی/);
  const before=JSON.parse(saved);const free=before.grid.findIndex((b,i)=>!b&&el('#app').innerHTML.includes(`data-i="${i}"`));assert.ok(free>=0);
  press('hub-cell',{i:String(free)});press('build',{t:'f'});assert.equal(JSON.parse(saved).grid[free],null);
  press('build',{t:'k'});assert.equal(JSON.parse(saved).grid[free].hub,'energy');
  assert.equal(JSON.parse(saved).money,before.money-1500);
  press('hub-close');assert.equal(JSON.parse(saved).countryHub,null);
  press('hub-open',{k:'north'});assert.match(el('#app').innerHTML,/north-map\.png/);
  press('hub-page',{page:'1'});assert.equal(JSON.parse(saved).hubPage,1);
  press('hub-close');press('hub-open',{k:'port'});
  assert.match(el('#app').innerHTML,/port-map\.png/);
  const oldPort=JSON.parse(saved).port;
  press('port');assert.ok(JSON.parse(saved).port>oldPort);
  press('port-trade');assert.equal(JSON.parse(saved).manageSection,'trade');


 } finally {globalThis.setInterval=oldInterval}
});
