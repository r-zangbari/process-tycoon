import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const root=new URL('../',import.meta.url);
const src=readFileSync(new URL('js/main.js',root),'utf8');
const css=readFileSync(new URL('css/style.css',root),'utf8');
test('retains 81 build lots, removes common-point editor UI',()=>{
 const m=src.match(/const CITY_PLOT_DEFAULTS=(\[\[.*?\]\]);/);
 assert.ok(m);
 assert.equal(JSON.parse(m[1]).length,24);
 assert.match(src,/pageStart=cityPage\*24/);
 assert.match(src,/data-city-cell="\$\{i\}"/);
 assert.doesNotMatch(src,/data-editor-action/);
 assert.doesNotMatch(src,/cityEditorPanel/);
});
test('individual movable buildings are persisted by city and cell, independent of other lots',()=>{
 for(const marker of ['S.cityBuildingPositions[city]','S.cityBuildingPositions[city][cell]','cityBuildingPos(city.name,i)','cityMoveCell===selected','data-city-building="${i}"','setCityBuildingPos','city-building-reset-position','city-building-nudge','city-building-move','setPointerCapture','getScreenCTM'])assert.ok(src.includes(marker),marker);
 assert.ok(src.includes('!S.cityMaps?.[city]?.[cell]'));
 assert.match(css,/\.city-free-building\.moving/);
 assert.match(src,/save\(\);/);
});
test('each building placement is visual and does not replace economic cell IDs',()=>{
 assert.match(src,/S\.cityMaps\[city.name\]/);
 assert.match(src,/grid\[cell\]=null/);
 assert.match(src,/delete S\.cityBuildingPositions\[city.name\]\[cell\]/);
 assert.match(src,/cityPage\*24/);
});
