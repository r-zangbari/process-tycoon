import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const src=readFileSync(new URL('../js/main.js',import.meta.url),'utf8');

test('country ocean is south and old west-sea coastline is no longer generated',()=>{
 assert.match(src,/layout:'south-coast-v51\.4'/);
 assert.match(src,/if\(y\+\.5>shoreRow\)t='sea'/);
 assert.doesNotMatch(src,/if\(x<co\)t='sea'/);
 assert.match(src,/const buildable=i=>!\['sea','mount','river'\]\.includes\(terr\(\)\.T\[i\]\)/);
});
test('five persistent city names have non-marine on-map targets and consistent overlay',()=>{
 const m=src.match(/const CITIES=\[([\s\S]*?)\];/);
 assert.ok(m);
 const c=[...m[1].matchAll(/\{name:'([^']+)',x:(\d+),y:(\d+),region:(\d+),kind:'([^']+)'\}/g)].map(v=>({name:v[1],x:+v[2],y:+v[3],region:+v[4],kind:v[5]}));
 assert.equal(c.length,5);
 assert.deepEqual(new Set(c.map(x=>x.name)).size,5);
 for(const city of c){assert.ok(city.x>30&&city.x<740);assert.ok(city.y>70&&city.y<390);}
 assert.ok(c.find(x=>x.kind==='port').y>300);
 assert.ok(c.find(x=>x.kind==='capital').y<300);
 assert.match(src,/const hubs=CITIES\.map\(c=>\[c\.x,c\.y,c\.name\]\)/);
 assert.match(src,/CITIES\.map\(\(c,i\)=>`<circle data-city=/);
});
test('both country marine targets and their pipelines use southern sea anchors',()=>{
 assert.match(src,/const MARINE_FIELDS=\{oil:\{x:175,y:462/);
 assert.match(src,/gas:\{x:623,y:441/);
 assert.match(src,/const x=MARINE_FIELDS\[key\]\.x,y=MARINE_FIELDS\[key\]\.y/);
 assert.match(src,/const f=MARINE_FIELDS\[key\],level=o\.pipelineLevel/);
 assert.match(src,/clipPath id="country-land-clip"/);
 assert.match(src,/REGION_DISPLAY_ANCHORS\[ri\]/);
});
