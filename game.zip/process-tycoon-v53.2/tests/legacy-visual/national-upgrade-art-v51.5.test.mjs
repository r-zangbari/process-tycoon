import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
const main=readFileSync(new URL('../js/main.js',import.meta.url),'utf8');
const graphics=readFileSync(new URL('../js/ui/strategy-graphics.js',import.meta.url),'utf8');
const dir=new URL('../assets/national-buildings/',import.meta.url);
test('all seven building archetypes have an offline image at each upgrade level',()=>{
 for(const name of ['home','farm','factory','shop','park','service','rooftop'])for(let level=1;level<=3;level++)assert.ok(existsSync(new URL(`${name}-${level}.webp`,dir)),`${name}-${level}`);
});
test('national tile artworks use saved building level without altering underlying click selection',()=>{
 assert.match(main,/const kind=b\.t==='h'\?'home':b\.t==='f'\?'farm':'factory'/);
 assert.match(main,/national-buildings\/\$\{kind\}-\$\{l\}\.webp/);
 assert.match(main,/data-c="\$\{i\}"/);
 assert.match(main,/data-a="cup"/);
});
test('city artwork uses existing type and saved level; national hubs and regional clusters render upgraded assets',()=>{
 assert.match(graphics,/export function renderCityBuildingArt\(type,level=1\)/);
 assert.match(main,/renderCityBuildingArt\(obj\.type,obj\.level\)/);
 assert.doesNotMatch(main,/national-buildings\/rooftop-\$\{/);
 assert.match(main,/const regionalTownLayers/);
});
