import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const root=new URL('../',import.meta.url);
const source=readFileSync(new URL('js/main.js',root),'utf8');
const html=readFileSync(new URL('index.html',root),'utf8');
test('offshore entry is contextual inside the national map, not a main top navigation tab',()=>{
 assert.doesNotMatch(html,/data-t="offshore"/);
 assert.match(source,/function viewCountry\(\)\{\s*if\(S\.offshoreView\)return viewOffshoreMap\(\)/);
 assert.match(source,/const offshoreCountryTargets=/);
 assert.match(source,/data-offshore-country="\$\{key\}"/);
 assert.match(source,/offshoreCountryDock\(S\.offshoreSelected\)/);
 assert.match(source,/data-a="offshore-map" data-p="\$\{key\}"/);
});
test('old independent offshore tab is migrated without resetting the petroleum simulation',()=>{
 assert.match(source,/if\(S\.tab==='offshore'\)\{\s*S\.tab='c';\s*S\.offshoreView=true;/);
 assert.match(source,/'offshore-map'\(x\)\{[\s\S]*?S\.offshoreView=true;/);
 assert.match(source,/'offshore-country'\(\)\{S\.tab='c';S\.cityView=null;S\.offshoreView=false/);
});
