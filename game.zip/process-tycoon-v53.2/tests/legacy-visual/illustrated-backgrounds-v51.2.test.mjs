import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync,statSync} from 'node:fs';
const root=new URL('../',import.meta.url);
const source=readFileSync(new URL('js/main.js',root),'utf8');
const css=readFileSync(new URL('css/style.css',root),'utf8');
test('all five provided backgrounds are bundled and selected in the correct map',()=>{
 for(const name of ['national','industry','city','offshore-oil','offshore-gas']){
  const u=new URL(`assets/maps/${name}.${['industry','city'].includes(name)?'png':'webp'}`,root);assert.ok(existsSync(u));assert.ok(statSync(u).size>20000);
 }
 assert.match(source,/assets\/maps\/industry\.png/);
 assert.match(source,/assets\/maps\/national\.webp/);
 assert.match(source,/assets\/maps\/city\.png/);
 assert.match(source,/assets\/maps\/offshore-\$\{chosen\}\.webp/);
});
test('interactive unit, city and national targets still overlay background images',()=>{
 assert.match(source,/data-hmi="\$\{i\}"/);
 assert.match(source,/data-city-cell="\$\{i\}"/);
 assert.match(source,/data-c="\$\{i\}"/);
 assert.match(source,/data-offshore-country="\$\{key\}"/);
 assert.match(css,/\.city-tile\.selected > polygon/);
});
