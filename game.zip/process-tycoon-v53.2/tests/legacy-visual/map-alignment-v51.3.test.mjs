import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const root=new URL('../',import.meta.url);
const src=readFileSync(new URL('js/main.js',root),'utf8');
const css=readFileSync(new URL('css/style.css',root),'utf8');
test('industry 5x5 raster locations remain within the pictured concrete footprint',()=>{
 const coords=[];
 for(let slot=0;slot<25;slot++){
  const col=slot%5,row=Math.floor(slot/5);
  const x=540+(col-row)*101.8,y=84+(col+row)*64.1;
  assert.ok(x>100&&x<980&&y>=84&&y<=610);coords.push(`${x},${y}`);
 }
 assert.equal(new Set(coords).size,25);
 assert.match(src,/Math\.ceil\(S\.u\.length\/25\)/);
 assert.match(src,/iso\(slot%5,Math\.floor\(slot\/5\)%5\)/);
 assert.match(src,/site-unit-hit/);
});
test('all 81 city save indices can be reached from four contiguous visual pages',()=>{
 let indices=[];
 for(let page=0;page<4;page++)for(let slot=0;slot<24;slot++){
  const i=page*24+slot;if(i>=81)continue;
  indices.push(i);
 }
 assert.match(src,/const CITY_PLOT_DEFAULTS=\[/);
 assert.match(src,/const cityPlotCenters=cityPlotLayout/);
 assert.deepEqual(indices,Array.from({length:81},(_,i)=>i));
 assert.match(src,/'city-map-page'/);
 assert.match(src,/data-city-cell="\$\{i\}"/);
 assert.match(css,/city-map-pager/);
});
test('marine end terminals are mapped toward respective coasts and reserve simulation is unchanged',()=>{
 assert.match(src,/shoreX=chosen==='oil'\?105:894/);
 assert.match(src,/assets\/maps\/offshore-\$\{chosen\}\.webp/);
 assert.match(src,/data-offshore-select="\$\{chosen\}"/);
});
