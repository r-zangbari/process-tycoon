import test from 'node:test';
import assert from 'node:assert/strict';
import {renderProcessFacility,renderCityBuilding,renderNationalHub,renderOffshoreRig,facilityImagePath,offshoreImagePath} from '../js/ui/strategy-graphics.js';
import {readFileSync,existsSync} from 'node:fs';
import {createFreshState,normalizeState,STORAGE_KEY} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';

test('all 16 industrial unit images are locally bundled and uniquely mapped',()=>{
 const art=D.map((_,t)=>renderProcessFacility(t,'run'));
 assert.equal(new Set(art).size,16);
 for(let i=0;i<16;i++){
  const url=facilityImagePath(i),p=new URL(`../${url.replace(/^\.\//,'')}`,import.meta.url);
  assert.match(art[i],/facility-art/);assert.match(art[i],/facility-scene/);
  assert.ok(art[i].includes(`href="${url}"`));
  assert.ok(existsSync(p),`missing visual asset ${url}`);
  const bytes=readFileSync(p);assert.equal(bytes.toString('ascii',0,4),'RIFF');assert.equal(bytes.toString('ascii',8,12),'WEBP');
  assert.doesNotMatch(art[i],/undefined|NaN/);
 }
 const fault=renderProcessFacility(0,'trip'),build=renderProcessFacility(0,'build');
 assert.match(fault,/#ed6f64/);
 assert.match(build,/construction/);
 assert.match(build,/در ساخت/);
});

test('city and national architecture distinguish use and upgrade',()=>{
 for(const kind of ['home','shop','service','park']){
  const a=renderCityBuilding(kind,1),b=renderCityBuilding(kind,3);
  assert.notEqual(a,b);
  assert.match(a,/city-iso-building/);
  assert.doesNotMatch(a,/undefined|NaN/);
 }
 for(const kind of ['city','capital','port','industrial'])assert.doesNotMatch(renderNationalHub(kind),/undefined|NaN/);
 assert.notEqual(renderNationalHub('capital'),renderNationalHub('industrial'));
});

test('offshore artwork appears only after the rig is built and both assets are offline',()=>{
 const pending=renderOffshoreRig('oil',false),oil=renderOffshoreRig('oil',true,80),gas=renderOffshoreRig('gas',true,20);
 assert.match(pending,/طرح توسعه/);
 assert.doesNotMatch(pending,/offshore-oil.webp/);
 assert.match(oil,/offshore-oil.webp/);
 assert.match(gas,/offshore-gas.webp/);
 assert.notEqual(gas,oil);
 assert.match(gas,/#ef7973/);
 for (const kind of ['oil','gas'])assert.ok(existsSync(new URL('../'+offshoreImagePath(kind).replace(/^\.\//,''),import.meta.url)));
});

test('v49 saved state is compatible with v50 independent map selection',()=>{
 const s=createFreshState();s.tab='offshore';s.offshoreMapSelected='gas';
 normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});
 assert.equal(s.tab,'offshore');
 assert.equal(s.offshoreMapSelected,'gas');
 assert.equal(s.offshore.oil.stage,0);
 assert.equal(s.offshore.oil.pipelineLevel,0);
 assert.equal(s.tanks.crude,0);
 assert.equal(s.tanks.sourgas,0);
});

test('independent marine map renders and selection/button handlers persist',async()=>{
 const s=createFreshState();s.tab='offshore';s.paused=true;
 normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});
 let stored=JSON.stringify(s);
 globalThis.localStorage={getItem:k=>k===STORAGE_KEY?stored:null,setItem:(k,v)=>{if(k===STORAGE_KEY)stored=v}};
 const nodes=new Map(),listeners=new Map();
 const el=k=>nodes.get(k)||nodes.set(k,{textContent:'',className:'',innerHTML:'',dataset:{},setAttribute(){},classList:{toggle(){}},scrollLeft:0,scrollTop:0}).get(k);
 globalThis.document={activeElement:null,querySelector:k=>k.startsWith('#')?el(k):null,querySelectorAll:()=>[],getElementById:()=>null,addEventListener:(kind,fn)=>listeners.set(kind,[...(listeners.get(kind)||[]),fn])};
 const oldSetInterval=globalThis.setInterval;globalThis.setInterval=()=>1;
 globalThis.requestAnimationFrame=(fn)=>{}; globalThis.window={scrollTo(){},matchMedia:()=>({matches:false})};
 try{
  await import('../js/main.js?v50-test');
  assert.match(el('#app').innerHTML,/نقشه مستقل میادین فراساحلی/);
  assert.match(el('#app').innerHTML,/data-offshore-select="oil"/);
  assert.match(el('#app').innerHTML,/offshore-oil\.webp/);
  const g={dataset:{a:'offshore-map',p:'gas'},disabled:false,closest(selector){return selector==='button'?this:null}};
  listeners.get('click')[1]({target:g});
  assert.equal(JSON.parse(stored).offshoreMapSelected,'gas');
  assert.match(el('#app').innerHTML,/offshore-gas\.webp/);
  const button={dataset:{a:'offshore-country'},disabled:false,closest(selector){return selector==='button'?this:null}};
  listeners.get('click')[1]({target:button});
  assert.equal(JSON.parse(stored).tab,'c');
  assert.match(el('#app').innerHTML,/نقشه راهبردی کشور/);
 }finally{globalThis.setInterval=oldSetInterval}
});
