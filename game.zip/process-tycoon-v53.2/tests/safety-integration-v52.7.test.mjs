import test from 'node:test';import assert from 'node:assert/strict';
import {createFreshState,normalizeState} from '../js/core/game-state.js';import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';
test('a real simulation day with several protective trips caps site-wide HSE loss and records each reason',async()=>{
 const s=createFreshState();normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});s.safe=80;s.tab='i';s.paused=false;s.money=500000;s.ops=50;s.port=1000;
 s.u=Array.from({length:6},()=>({t:0,st:'run',eq:D[0].e.map(e=>({h:100,l:1,f:null,running:true,...(e[1]?{reserve:{h:100,f:null,running:false}}:{})})),v:D[0].v.map(v=>v[2]+v[3]*8),au:D[0].v.map(()=>0),h:D[0].v.map(()=>[])}));
 let saved=JSON.stringify(s),now=0,clock;const refs=new Map(),el=q=>refs.get(q)||refs.set(q,{innerHTML:'',textContent:'',dataset:{},setAttribute(){},classList:{toggle(){},add(){}}}).get(q);
 const oldInterval=setInterval,oldRandom=Math.random,oldPerf=performance;
 globalThis.localStorage={getItem:()=>saved,setItem:(k,v)=>saved=v};globalThis.document={activeElement:null,querySelector:q=>q.startsWith('#')?el(q):null,querySelectorAll:()=>[],getElementById:()=>null,addEventListener(){}};globalThis.setInterval=f=>{clock=f;return 1};globalThis.performance={now:()=>now};Math.random=()=>.5;
 try{await import('../js/main.js?safety527');now=1600;clock();const after=JSON.parse(saved);assert.ok(after.u.filter(u=>u.st==='trip').length>=3);assert.ok(after.safe>=78.5);assert.ok(after.safe<80);assert.ok(after.safetyReport.history.length>=3);assert.ok(after.safetyReport.history.some(e=>e.suppressed));assert.match(el('#app').innerHTML,/چرا ایمنی تغییر کرد/)}finally{globalThis.setInterval=oldInterval;Math.random=oldRandom;globalThis.performance=oldPerf}
});
