import test from 'node:test';import assert from 'node:assert/strict';
import {D,IN,OPT,PR,OPN} from '../js/data/catalog.js';
import {normalizeMaintenance,purchaseMaintenance,maintenanceLicenseCost,runAutoMaintenance,advancePartOrders,requestPart,finishRepair} from '../js/systems/auto-maintenance.js';
const make=()=>{const t=0,u={t,st:'broken',eq:D[t].e.map(e=>({h:100,l:1,f:null,running:true,...(e[1]?{reserve:{h:100,f:null,running:false}}:{})})),v:D[t].v.map(v=>v[2]),load:100,ratedCapacity:100,processState:{valveOpen:true}};u.eq[1].f={st:0,eta:0,dl:0};u.eq[1].h=20;const s={day:1,money:10000,port:1000,safe:100,ops:10,u:[u],tanks:Object.fromEntries(Object.keys(PR).map(p=>[p,1000])),pid:{}};return s};
const context=()=>({D,IN,OPT,PR,OPN,importMultiplier:()=>1.4,availableOperators:()=>10,remainingPort:()=>1000,random:()=>.5,log(){}});
const go=(s)=>runAutoMaintenance(s,context());
test('license is one-time, owned by each unit, survives toggling, and cannot be enabled without purchase',()=>{
 const s=make();s.u[0].maintenance={owned:false,enabled:true};normalizeMaintenance(s.u[0],D[0]);assert.equal(s.u[0].maintenance.enabled,false);const money=s.money;assert.equal(purchaseMaintenance(s,0,D),true);assert.equal(s.money,money-maintenanceLicenseCost(D[0]));assert.equal(purchaseMaintenance(s,0,D),false);assert.equal(s.money,money-maintenanceLicenseCost(D[0]));s.u[0].maintenance.enabled=false;normalizeMaintenance(s.u[0],D[0]);assert.ok(s.u[0].maintenance.owned);assert.ok(!s.u[0].maintenance.enabled);
});
test('paid order, real delivery, paid repair, and guarded return occur on separate days; repeated evaluation cannot spend twice',()=>{
 const s=make();purchaseMaintenance(s,0,D);const money=s.money;go(s);assert.equal(s.u[0].eq[1].f.st,1);assert.equal(s.u[0].eq[1].f.eta,1);assert.equal(s.money,money-640);assert.equal(s.u[0].st,'broken');go(s);assert.equal(s.money,money-640);
 s.day++;advancePartOrders(s,D,()=>{});go(s);assert.equal(s.u[0].eq[1].f,null);assert.equal(s.u[0].st,'run');assert.equal(s.money,money-640-80-80);assert.equal(s.u[0].maintenance.totalSpent,800);assert.equal(s.u[0].maintenance.history.length,3);const after=s.money;go(s);assert.equal(s.money,after);
});
test('disabled automation lets existing paid shipment arrive, but neither repairs nor starts the unit',()=>{
 const s=make();purchaseMaintenance(s,0,D);go(s);s.u[0].maintenance.enabled=false;s.day++;advancePartOrders(s,D,()=>{});const money=s.money;go(s);assert.equal(s.u[0].eq[1].f.st,2);assert.equal(s.u[0].st,'broken');assert.equal(s.money,money);
});
test('cash reserve and daily spending cap block purchases without creating debt',()=>{
 const s=make();purchaseMaintenance(s,0,D);s.money=1500;go(s);assert.equal(s.money,1500);assert.equal(s.u[0].eq[1].f.st,0);assert.match(s.u[0].maintenance.status,/ذخیره نقد/);
 const a=make();purchaseMaintenance(a,0,D);a.u[0].eq[2].f={st:0,eta:0,dl:0};go(a);assert.equal(a.u[0].maintenance.spentToday,640);assert.equal(a.u[0].eq[2].f.st,0);assert.match(a.u[0].maintenance.status,/سقف/);
});
test('intentional stop never gets overridden, and closed valve blocks restart after successful repair',()=>{
 const s=make();purchaseMaintenance(s,0,D);s.u[0].st='off';const cash=s.money;go(s);assert.equal(s.money,cash);assert.equal(s.u[0].eq[1].f.st,0);assert.equal(s.u[0].st,'off');
 s.u[0].st='broken';s.u[0].processState.valveOpen=false;s.u[0].eq[1].f.st=2;s.day++;go(s);assert.equal(s.u[0].eq[1].f,null);assert.equal(s.u[0].st,'broken');assert.match(s.u[0].maintenance.status,/XV-101/);
});
test('active incident, overload and old unknown trip are not erased to force a restart',()=>{
 for(const kind of ['incident','overload','unknown']){const s=make();purchaseMaintenance(s,0,D);s.u[0].eq[1].f.st=2;if(kind==='incident')s.u[0].coolingIncident={days:4,offset:.7};if(kind==='overload')s.u[0].load=140;if(kind==='unknown')s.u[0].st='trip';go(s);assert.notEqual(s.u[0].st,'run');if(kind==='incident')assert.equal(s.u[0].coolingIncident.days,4);if(kind==='overload')assert.equal(s.u[0].load,140)}
});
test('restart can be disabled independently of automatic part purchase and repair',()=>{
 const s=make();purchaseMaintenance(s,0,D);s.u[0].maintenance.restart=false;s.u[0].eq[1].f.st=2;go(s);assert.equal(s.u[0].eq[1].f,null);assert.equal(s.u[0].st,'broken');assert.equal(s.u[0].maintenance.spentToday,80);
});
test('reserve component uses the same paid order/repair rules and advances while automation is disabled',()=>{
 const s=make(),u=s.u[0];u.eq[0].reserve.f={st:0,eta:0};let paid=0;const pay=n=>{paid+=n;return true};assert.ok(requestPart({u,d:D[0],j:0,role:'reserve',fast:false,pay,random:()=>0}));assert.equal(paid,160);s.day++;advancePartOrders(s,D,()=>{});assert.equal(u.eq[0].reserve.f.eta,1);s.day++;advancePartOrders(s,D,()=>{});assert.equal(u.eq[0].reserve.f.st,2);assert.ok(finishRepair({u,d:D[0],j:0,role:'reserve',pay}));assert.equal(paid,240);assert.equal(u.eq[0].reserve.f,null);
});
