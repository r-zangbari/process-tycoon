import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState,normalizeState} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';
import {OFFSHORE,normalizeOffshoreState,reservoirMetrics,advanceOffshoreProjects,simulateOffshoreDay,recoveryReady,recoveryAvailable,startOffshoreMaintenance,isolateOffshore,resumeOffshorePipeline,seaCondition} from '../js/systems/offshore.js';
const prep=()=>{const s=createFreshState();normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});s.pd={};s.money=150000;s.tanks.crude=0;s.tanks.sourgas=0;return s;};
const logs=[],cap=()=>10000,log=t=>logs.push(t);
const advance=(s,n)=>{for(let i=0;i<n;i++){s.day++;normalizeOffshoreState(s);advanceOffshoreProjects(s,log);s.pd={};simulateOffshoreDay(s,cap,log);}};
test('v47 save migrates integrity, technology and incident flags without losing reserves',()=>{
 const s=prep();s.offshore.oil={stage:5,reserveInitial:24000,reserveRemaining:9975,pipelineLevel:2,buffer:27,health:76};normalizeOffshoreState(s);
 const o=s.offshore.oil;
 assert.equal(o.reserveRemaining,9975);assert.equal(o.buffer,27);assert.equal(o.pipeHealth,100);
 assert.equal(o.recoveryLevel,0);assert.equal(o.incident,null);assert.equal(o.pipelineIsolated,false);
 o.pipeHealth=-5;o.recoveryLevel=78;normalizeOffshoreState(s);
 assert.equal(o.pipeHealth,0);assert.equal(o.recoveryLevel,2);
});
test('a subsea leak blocks deliveries, incurs daily HSE cost, and requires isolation before repair',()=>{
 const s=prep(),o=s.offshore.oil;o.stage=5;o.pipelineLevel=2;o.pipeHealth=24;normalizeOffshoreState(s);
 const initialSafety=s.safe;
 const first=simulateOffshoreDay(s,cap,log,null,()=>{});
 assert.equal(o.incident.kind,'pipeline-leak');assert.equal(o.deliveredToday,0);
 assert.equal(s.tanks.crude,0);assert.ok(first>=180);assert.ok(o.buffer>0);
 assert.ok(s.safe<initialSafety);
 assert.equal(startOffshoreMaintenance(s,'oil','pipeline',log,()=>true),false);
 assert.equal(isolateOffshore(s,'oil',log),true);
 assert.equal(o.online,false);assert.equal(o.pipelineIsolated,true);
 assert.equal(simulateOffshoreDay(s,cap,log),0);
 let spent=0;assert.equal(startOffshoreMaintenance(s,'oil','pipeline',log,c=>{spent+=c;return true}),true);
 assert.equal(spent,4200);assert.equal(o.maintenance.days,6);
 advance(s,6);
 assert.equal(o.maintenance,null);assert.equal(o.incident,null);assert.ok(o.pipeHealth>=85);
 assert.equal(o.pipelineIsolated,true);assert.equal(o.online,false);
 assert.equal(resumeOffshorePipeline(s,'oil',log),true);
 simulateOffshoreDay(s,cap,log);assert.ok(o.deliveredToday>0);
});
test('rig critical failure trips production; emergency repair does not auto-start',()=>{
 const s=prep(),o=s.offshore.gas;o.stage=5;o.pipelineLevel=2;o.health=18;normalizeOffshoreState(s);
 simulateOffshoreDay(s,cap,log);
 assert.equal(o.incident.kind,'rig-failure');assert.equal(o.online,false);assert.equal(o.producedToday,0);
 assert.equal(startOffshoreMaintenance(s,'gas','rig',log,()=>true),true);
 advance(s,5);
 assert.equal(o.incident,null);assert.ok(o.health>=85);assert.equal(o.online,false);
 o.online=true;simulateOffshoreDay(s,cap,log);assert.ok(o.producedToday>0);
});
test('preventive maintenance does not consume reserve or wear inactive equipment',()=>{
 const s=prep(),o=s.offshore.oil;o.stage=5;o.pipelineLevel=3;o.health=61;o.pipeHealth=58;normalizeOffshoreState(s);
 const reserve0=o.reserveRemaining;
 assert.equal(startOffshoreMaintenance(s,'oil','rig',log,()=>true),true);
 const firstHealth=o.health;
 advance(s,3);
 assert.ok(o.health>firstHealth);assert.equal(o.reserveRemaining,reserve0);
 const pipeBefore=o.pipeHealth;
 assert.equal(startOffshoreMaintenance(s,'oil','pipeline',log,()=>true),true);
 advance(s,4);
 assert.ok(o.pipeHealth>pipeBefore);assert.equal(o.reserveRemaining,reserve0);
 assert.equal(resumeOffshorePipeline(s,'oil',log),true);
});
test('assisted recovery only unlocks after depletion and pipeline; uses utility only when producing',()=>{
 const s=prep(),o=s.offshore.oil;
 o.stage=5;o.pipelineLevel=1;normalizeOffshoreState(s);
 assert.equal(recoveryReady(o),false);
 o.reserveRemaining=.89*o.reserveInitial;assert.equal(recoveryReady(o),true);
 o.recoveryProject={target:1,days:2};advanceOffshoreProjects(s,log);
 assert.equal(o.recoveryLevel,0);
 advanceOffshoreProjects(s,log);
 assert.equal(o.recoveryLevel,1);
 const base=prep(),b=base.offshore.oil;b.stage=5;b.pipelineLevel=1;b.reserveRemaining=.89*24000;normalizeOffshoreState(base);
 base.tanks.water=100;s.tanks.water=100;
 assert.equal(recoveryAvailable(o,'oil',s),true);
 simulateOffshoreDay(base,cap,log);simulateOffshoreDay(s,cap,log);
 assert.ok(o.producedToday>b.producedToday);
 assert.equal(o.utilityUsedToday,3);assert.equal(s.tanks.water,97);
 assert.ok(Math.abs((o.reserveInitial-o.reserveRemaining)-(24000-.89*24000+o.producedToday))<1e-7);
 o.online=false;s.tanks.water=60;simulateOffshoreDay(s,cap,log);
 assert.equal(o.utilityUsedToday,0);assert.equal(s.tanks.water,60);
 o.online=true;o.recoveryEnabled=false;simulateOffshoreDay(s,cap,log);assert.equal(o.utilityUsedToday,0);
});
test('gas compression consumes electrical utility only when available, and does not invent reserves',()=>{
 const s=prep(),o=s.offshore.gas;o.stage=5;o.pipelineLevel=3;o.reserveRemaining=25000;o.recoveryLevel=2;normalizeOffshoreState(s);
 s.tanks.power=8;simulateOffshoreDay(s,cap,log);
 assert.equal(o.utilityUsedToday,8);assert.equal(s.tanks.power,0);
 assert.ok(o.reserveRemaining<25000);const before=o.reserveRemaining;
 simulateOffshoreDay(s,cap,log);
 assert.equal(o.utilityUsedToday,0);assert.ok(o.reserveRemaining<before);
});
test('storm weather limits throughput; no movement through isolated line',()=>{
 assert.equal(seaCondition(60),'متلاطم');assert.equal(seaCondition(10),'آرام');
 const a=prep(),b=prep();a.day=10;b.day=60;
 for(const state of [a,b]){state.offshore.gas.stage=5;state.offshore.gas.pipelineLevel=1;normalizeOffshoreState(state);}
 simulateOffshoreDay(a,cap,log);simulateOffshoreDay(b,cap,log);
 assert.ok(b.offshore.gas.deliveredToday<a.offshore.gas.deliveredToday);
 b.offshore.gas.pipelineIsolated=true;const previous=b.tanks.sourgas;
 simulateOffshoreDay(b,cap,log);assert.equal(b.tanks.sourgas,previous);
});
test('random low-health leakage is deterministic with injected RNG and SOE',()=>{
 const s=prep(),o=s.offshore.gas;o.stage=5;o.pipelineLevel=2;o.health=90;o.pipeHealth=40;normalizeOffshoreState(s);
 const entries=[];simulateOffshoreDay(s,cap,log,()=>0,(m,severity)=>entries.push({m,severity}));
 assert.equal(o.incident.kind,'rig-failure'); // first RNG draw targets an operating rig; deterministic injection
 assert.equal(entries[0].severity,'HIGH');
});
