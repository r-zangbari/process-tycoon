import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState,normalizeState,STORAGE_KEY} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';

test('management interface exposes new offshore HSE, ESD, upkeep and recovery; actions persist',async()=>{
 const initial=createFreshState();normalizeState(initial,{D,PR,MK,GW,GH,setImportMultiplier});
 initial.tab='m';initial.manageSection='fields';initial.paused=true;initial.money=300000;
 initial.offshore.oil.stage=5;initial.offshore.oil.pipelineLevel=2;
 initial.offshore.oil.reserveRemaining=20000;initial.offshore.oil.reserveInitial=24000;
 initial.offshore.gas.stage=5;initial.offshore.gas.pipelineLevel=1;
 let saved=JSON.stringify(initial);
 globalThis.localStorage={getItem:k=>k===STORAGE_KEY?saved:null,setItem:(k,v)=>{if(k===STORAGE_KEY)saved=v}};
 const refs=new Map(),listeners=new Map();
 const el=name=>refs.get(name)||refs.set(name,{textContent:'',innerHTML:'',className:'',dataset:{},setAttribute(){},classList:{toggle(){}}}).get(name);
 globalThis.document={activeElement:null,querySelector:q=>q.startsWith('#')?el(q):null,querySelectorAll:()=>[],getElementById:()=>null,
  addEventListener:(type,handler)=>listeners.set(type,[...(listeners.get(type)||[]),handler])};
 const oldInterval=globalThis.setInterval;globalThis.setInterval=()=>1;
 const press=(a,p,k)=>{const target={dataset:{a,p,k},disabled:false,closest(selector){return selector==='button'?this:null}};listeners.get('click')[1]({target});};
 try{
  await import('../js/main.js');
  const html=el('#app').innerHTML;
  for(const token of ['سلامت سکوی دریایی','سلامت خط لوله','data-a="offshore-isolate"','data-a="offshore-maintenance"','data-a="offshore-recovery"','نشتی خط']){
   // Leak label is intentionally shown only after an incident, all other labels must render now.
   if(token!=='نشتی خط')assert.ok(html.includes(token),`expected UI token ${token}`);
  }
  press('offshore-isolate','oil');
  let s=JSON.parse(saved);assert.equal(s.offshore.oil.pipelineIsolated,true);assert.equal(s.offshore.oil.online,false);
  assert.match(s.soe[0].message,/ESD/);
  press('offshore-pipe-resume','oil');
  s=JSON.parse(saved);assert.equal(s.offshore.oil.pipelineIsolated,false);
  press('offshore-recovery','oil');
  s=JSON.parse(saved);assert.equal(s.offshore.oil.recoveryProject.target,1);assert.equal(s.money,290000);
  press('offshore-maintenance','gas','rig');
  s=JSON.parse(saved);assert.equal(s.offshore.gas.maintenance.kind,'rig');assert.equal(s.offshore.gas.online,false);
  assert.equal(s.money,288750);
 }finally{globalThis.setInterval=oldInterval;}
});
