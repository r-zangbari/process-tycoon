import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState,normalizeState,STORAGE_KEY} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';

test('v52 complete navigation, shared assets, payment guards and offshore commands',async()=>{
 const pre=createFreshState();normalizeState(pre,{D,PR,MK,GW,GH,setImportMultiplier});
 pre.tab='m';pre.manageSection='fields';pre.money=200000;pre.offshore.oil.stage=5;
 let saved=JSON.stringify(pre);
 globalThis.localStorage={getItem:(k)=>k===STORAGE_KEY?saved:null,setItem:(k,v)=>{if(k===STORAGE_KEY)saved=v}};
 const refs=new Map(),events=new Map();
 const el=(name)=>refs.get(name)||refs.set(name,{textContent:'',innerHTML:'',className:'',dataset:{},setAttribute(){},classList:{toggle(){}}}).get(name);
 globalThis.document={activeElement:null,
  querySelector:(q)=>q.startsWith('#')?el(q):null,
  querySelectorAll:()=>[],
  getElementById:()=>null,
  addEventListener:(name,callback)=>{const arr=events.get(name)||[];arr.push(callback);events.set(name,arr)}
 };
 const oldInterval=globalThis.setInterval;globalThis.setInterval=()=>1;
 try{
  await import('../js/main.js');
  const html=el('#app').innerHTML;
  assert.match(html,/ذخیره قابل برداشت/);
  assert.match(html,/خط لوله زیردریایی/);
  assert.match(html,/data-a="offshore-pipeline"/);
  const target={dataset:{a:'offshore-pipeline',p:'oil'},disabled:false,
   closest(sel){return sel==='button'?this:null}};
  const handler=events.get('click')?.[1];assert.equal(typeof handler,'function');handler({target});
  const state=JSON.parse(saved);
  assert.equal(state.offshore.oil.pipelineLevel,0);
  assert.equal(state.offshore.oil.pipeProject.target,1);
  assert.equal(state.money,200000-7500);
  assert.match(el('#app').innerHTML,/پروژه انتقال در حال اجرا/);
  const press=(a,props={})=>handler({target:{dataset:{a,...props},disabled:false,closest(sel){return sel==='button'?this:null}}});
  press('tab',{t:'c'});
  assert.match(el('#app').innerHTML,/country-three/);
  assert.doesNotMatch(el('#app').innerHTML,/<image|<img/);
  press('hub-open',{k:'energy'});
  const before=JSON.parse(saved);
  const free=before.grid.findIndex((b,i)=>!b&&i%3===2);
  press('hub-cell',{i:String(free)});press('build',{t:'f'});assert.equal(JSON.parse(saved).grid[free],null);
  press('build',{t:'k'});let after=JSON.parse(saved);
  assert.equal(after.grid[free].hub,'energy');assert.equal(after.money,before.money-1500);
  press('conn',{p:'water'});assert.equal(JSON.parse(saved).money,after.money);
  press('conn',{p:'power'});after=JSON.parse(saved);assert.equal(after.grid[free].c.power,1);assert.equal(after.money,before.money-1600);
  press('conn',{p:'power'});assert.equal(JSON.parse(saved).money,after.money);
  press('cup');assert.equal(JSON.parse(saved).grid[free].l,2);
  press('atlas-home');press('city-enter',{i:'1'});
  assert.equal(JSON.parse(saved).cityMaps['پایتخت'].length,81);
  press('city-cell',{i:'0'});press('city-build',{t:'shop'});
  // Public budget starts at zero, so construction must be rejected.
  assert.equal(JSON.parse(saved).cityMaps['پایتخت'][0],null);
  press('atlas-home');press('hub-open',{k:'port'});
  const oldPort=JSON.parse(saved).port;press('port');assert.equal(JSON.parse(saved).port,oldPort+20);
  press('port-trade');assert.equal(JSON.parse(saved).manageSection,'trade');
  press('tab',{t:'c'});press('atlas-home');press('atlas-offshore');
  assert.equal(JSON.parse(saved).offshoreView,true);assert.match(el('#app').innerHTML,/ذخیره قابل برداشت/);
 } finally {globalThis.setInterval=oldInterval}
});
