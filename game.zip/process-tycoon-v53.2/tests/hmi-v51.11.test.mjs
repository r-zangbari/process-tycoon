import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState,normalizeState,STORAGE_KEY} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';
test('HMI summary switches to advanced and persists mode without changing unit',async()=>{
 const S=createFreshState();S.tab='hmi';S.u=[{t:0,st:'run',eq:D[0].e.map(()=>({h:100,l:1,f:null})),v:D[0].v.map(x=>x[2]),h:D[0].v.map(()=>[])}];
 normalizeState(S,{D,PR,MK,GW,GH,setImportMultiplier});let saved=JSON.stringify(S);
 globalThis.localStorage={getItem:()=>saved,setItem:(k,v)=>{saved=v}};
 const refs=new Map(),events=new Map();
 const el=q=>refs.get(q)||refs.set(q,{textContent:'',innerHTML:'',dataset:{},setAttribute(){},classList:{toggle(){}}}).get(q);
 globalThis.document={activeElement:null,querySelector:q=>q.startsWith('#')?el(q):null,querySelectorAll:()=>[],getElementById:()=>null,addEventListener:(n,c)=>events.set(n,[...(events.get(n)||[]),c])};
 const old=globalThis.setInterval;globalThis.setInterval=()=>1;
 try{await import('../js/main.js');assert.match(el('#app').innerHTML,/مقدار فعلی/);assert.doesNotMatch(el('#app').innerHTML,/data-pid-sp/);
 const press=v=>events.get('click')[1]({target:{dataset:{a:'hmi-mode',v},closest:s=>s==='button'?{dataset:{a:'hmi-mode',v},disabled:false}:null}});
 press('advanced');assert.match(el('#app').innerHTML,/data-pid-sp/);assert.equal(JSON.parse(saved).hmiMode,'advanced');assert.equal(JSON.parse(saved).hmiUnit,0);
 press('summary');assert.doesNotMatch(el('#app').innerHTML,/data-pid-sp/);
 }finally{globalThis.setInterval=old}
});
