import test from 'node:test';
import assert from 'node:assert/strict';
import {projectEstimate,nextAction,unitExplanation} from '../js/ui/player-help.js';
test('estimate buys only missing materials across all installations',()=>{
 const d={cost:1000,e:[[],[]],v:[[]]},PR={steel:['',0,10],cement:['',0,20]};
 const e=projectEstimate({tanks:{steel:.8,cement:1}},d,PR,2,50);
 assert.ok(Math.abs(e.materials-8)<1e-9);assert.equal(e.total,758);
});
test('urgent unit action links to correct unit; empty game links to catalog',()=>{
 assert.equal(nextAction({u:[]},[]).tab,'i');
 assert.equal(nextAction({u:[{t:0,st:'trip'}]},[{n:'unit'}]).index,0);
 assert.match(unitExplanation({st:'trip',processState:{valveOpen:false}}),/شیر/);
});

