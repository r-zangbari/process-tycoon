import test from 'node:test';
import assert from 'node:assert/strict';
import {createFreshState,normalizeState,STORAGE_KEY} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';

test('one simulated day: advance is credited once, contract invoices deduct remainder, port is shared',async()=>{
 const pre=createFreshState();normalizeState(pre,{D,PR,MK,GW,GH,setImportMultiplier});
 pre.tab='m';pre.paused=false;pre.money=500000;pre.mkt=1;pre.tanks.methanol=120;pre.hold.methanol=true;
 pre.tradeContracts=[{id:123,p:'methanol',qty:100,remaining:100,days:20,unitPrice:10,advance:200,advanceBalance:200,delivered:0}];
 pre.port=40;
 let saved=JSON.stringify(pre),now=0,clock;
 const oldRandom=Math.random,oldPerf=globalThis.performance,oldInterval=globalThis.setInterval;
 Math.random=()=>.5;globalThis.performance={now:()=>now};
 globalThis.localStorage={getItem:k=>k===STORAGE_KEY?saved:null,setItem:(k,v)=>{if(k===STORAGE_KEY)saved=v}};
 const refs=new Map(),el=q=>refs.get(q)||refs.set(q,{textContent:'',innerHTML:'',className:'',dataset:{},setAttribute(){},classList:{toggle(){}}}).get(q);
 globalThis.document={querySelector:q=>q.startsWith('#')?el(q):null,querySelectorAll:()=>[],getElementById:()=>null,activeElement:null,addEventListener(){}};
 globalThis.setInterval=cb=>{clock=cb;return 1};
 try{
  await import('../js/main.js?v51-contract-settlement');
  now=1600;clock();
  let S=JSON.parse(saved);
  assert.equal(S.day,2);
  assert.equal(S.tradeContracts.length,1);
  assert.equal(S.tradeContracts[0].remaining,60);
  assert.equal(S.tradeContracts[0].delivered,40);
  assert.equal(S.tradeContracts[0].advanceBalance,0);
  assert.equal(S.tradeRevenueToday,200); // 40 × 10 minus the previously credited 200.
  assert.equal(S.portRemainingToday,0);
  assert.equal(S.portUsedToday,40);
  now=3200;clock();S=JSON.parse(saved);
  assert.equal(S.day,3);
  assert.equal(S.tradeContracts[0].remaining,20);
  assert.equal(S.tradeRevenueToday,400); // The same advance is not deducted a second time.
 }finally{Math.random=oldRandom;globalThis.performance=oldPerf;globalThis.setInterval=oldInterval;}
});
