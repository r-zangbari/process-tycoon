import test from 'node:test';import assert from 'node:assert/strict';
import {createFreshState,normalizeState,STORAGE_KEY} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';
test('a real simulation day records balanced per-unit costs, exact lost output and a navigation-only advisor action',async()=>{
 const s=createFreshState();normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});s.tab='i';s.adv=1;s.paused=false;s.money=500000;s.port=1000;s.ops=10;
 s.u=[1,13].map(t=>({t,st:'run',eq:D[t].e.map(e=>({h:100,l:1,f:null,running:true,...(e[1]?{reserve:{h:100,f:null,running:false}}:{})})),v:D[t].v.map(v=>v[2]),au:D[t].v.map(()=>0),h:D[t].v.map(()=>[])}));s.tanks.water=150;
 let saved=JSON.stringify(s),now=0,clock;const events=new Map(),refs=new Map(),el=q=>refs.get(q)||refs.set(q,{innerHTML:'',textContent:'',dataset:{},className:'',setAttribute(){},classList:{toggle(){},add(){}},scrollIntoView(){}}).get(q);
 const oldInterval=setInterval,oldRandom=Math.random,oldPerf=performance;
 globalThis.localStorage={getItem:()=>saved,setItem:(k,v)=>saved=v};globalThis.document={activeElement:null,querySelector:q=>q.startsWith('#')?el(q):null,querySelectorAll:()=>[],getElementById:()=>null,addEventListener:(k,f)=>{const fs=events.get(k)||[];fs.push(f);events.set(k,fs)}};
 globalThis.performance={now:()=>now};globalThis.setInterval=f=>{clock=f;return 1};Math.random=()=>.5;
 try{await import('../js/main.js?ledger-522');now=1600;clock();let after=JSON.parse(saved);
  for(const u of after.u){const l=u.dayEconomics;assert.equal(l.day,2);assert.ok(Math.abs(Object.values(l.costs).reduce((a,v)=>a+v,0)-l.totalCost)<1e-8);assert.ok(Math.abs(l.revenue-l.totalCost-l.profit)<1e-8);assert.ok(Math.abs(l.products.reduce((a,p)=>a+p.value,0)-l.revenue)<1e-8);for(const p of l.products)assert.ok(Math.abs(p.requested-p.accepted-p.spilled)<1e-8)}
  assert.ok(after.u[0].dayEconomics.products.some(p=>p.spilled>0));assert.ok(after.u[1].dayEconomics.products.every(p=>p.spilled===0));
  const handler=events.get('click')[1],press=(target,props={})=>handler({target:{dataset:{a:'diagnostic-go',target,...props},disabled:false,closest:s=>s==='button'?{dataset:{a:'diagnostic-go',target,...props},disabled:false}:null}});
  const money=after.money;press('inventory',{p:'water'});after=JSON.parse(saved);assert.equal(after.tab,'m');assert.equal(after.manageSection,'inventory');assert.equal(after.money,money);
  press('controls',{i:'1'});after=JSON.parse(saved);assert.equal(after.hmiUnit,1);assert.equal(after.hmiMode,'advanced');assert.equal(after.money,money);
  press('time');now=3200;clock();after=JSON.parse(saved);assert.equal(after.day,3);assert.equal(after.paused,true);assert.equal(after.diagnosticPauseDay,undefined);
 }finally{globalThis.setInterval=oldInterval;Math.random=oldRandom;globalThis.performance=oldPerf}
});
