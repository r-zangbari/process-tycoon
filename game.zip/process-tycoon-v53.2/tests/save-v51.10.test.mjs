import test from 'node:test';
import assert from 'node:assert/strict';
import {saveState,STORAGE_KEY} from '../js/core/game-state.js';
test('saving reports browser storage success and failure',()=>{
 let stored;globalThis.localStorage={setItem:(key,value)=>{assert.equal(key,STORAGE_KEY);stored=value}};
 assert.equal(saveState({day:7}),true);assert.equal(JSON.parse(stored).day,7);
 globalThis.localStorage={setItem:()=>{throw Error('quota')}};
 assert.equal(saveState({day:8}),false);
 delete globalThis.localStorage;
});
