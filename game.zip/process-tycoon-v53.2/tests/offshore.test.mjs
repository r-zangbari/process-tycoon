import test from 'node:test';
import assert from 'node:assert/strict';
import {OFFSHORE,normalizeOffshoreState,advanceOffshoreProjects,simulateOffshoreDay,reservoirMetrics} from '../js/systems/offshore.js';
import {createFreshState,normalizeState} from '../js/core/game-state.js';
import {D,PR,MK,GW,GH,setImportMultiplier} from '../js/data/catalog.js';
const prepared=()=>{const s=createFreshState();normalizeState(s,{D,PR,MK,GW,GH,setImportMultiplier});s.tanks.crude=0;s.tanks.sourgas=0;return s;};
const cap=()=>10000;
const day=(s)=>{normalizeOffshoreState(s);s.day++;s.pd={};const cost=simulateOffshoreDay(s,cap,()=>{});return cost};
test('new game: offshore stages locked and no free supplies',()=>{
 const s=prepared();assert.equal(s.offshore.oil.stage,0);day(s);assert.equal(s.tanks.crude,0);assert.equal(s.tanks.sourgas,0);
 assert.equal(s.offshore.oil.reserveInitial,undefined);
});
test('v46 existing active rig: migrated reserve and transport gate',()=>{
 const s=prepared();s.offshore.oil={stage:5,health:100,project:null};normalizeOffshoreState(s);
 const o=s.offshore.oil;assert.equal(o.reserveInitial,24000);assert.equal(o.reserveRemaining,24000);
 assert.equal(o.pipelineLevel,0);day(s);assert.equal(s.tanks.crude,0);assert.ok(o.buffer>0);
 assert.equal(o.reserveInitial-o.reserveRemaining,o.producedToday);
});
test('stage 3 confirms finite reserve; pipeline job progresses on clock',()=>{
 const s=prepared(),o=s.offshore.gas;o.stage=2;o.project={target:3,days:1};
 const notes=[];advanceOffshoreProjects(s,t=>notes.push(t));
 assert.equal(o.stage,3);assert.equal(o.reserveInitial,36000);assert.equal(o.reserveRemaining,36000);
 o.stage=5;o.pipeProject={target:1,days:2};advanceOffshoreProjects(s,t=>notes.push(t));assert.equal(o.pipelineLevel,0);
 advanceOffshoreProjects(s,t=>notes.push(t));assert.equal(o.pipelineLevel,1);assert.equal(o.pipeProject,null);
 assert.ok(notes.some(t=>t.includes('خط لوله زیردریایی')));
});
test('subsea transfer is constrained to level capacity and onshore tank free space',()=>{
 const s=prepared(),o=s.offshore.oil;o.stage=5;o.pipelineLevel=1;
 let cost=day(s);assert.ok(cost>0);assert.ok(o.producedToday>o.deliveredToday);
 assert.equal(o.deliveredToday,85);assert.equal(s.pd.crude,o.deliveredToday);
 o.pipelineLevel=2;day(s);assert.ok(o.deliveredToday<=160+1e-9);
 const old=s.tanks.crude;s.tanks.crude=9999.5;day(s);
 assert.ok(o.deliveredToday<=.5+1e-9);assert.ok(s.tanks.crude<=10000+1e-9);
 assert.ok(old>0);
});
test('target rate affects production and reserve consumption; shut-in preserves reserves',()=>{
 const s=prepared(),o=s.offshore.gas;o.stage=5;o.pipelineLevel=3;o.productionTarget=50;
 day(s);const half=o.producedToday;assert.ok(half>0);
 const s2=prepared(),o2=s2.offshore.gas;o2.stage=5;o2.pipelineLevel=3;
 day(s2);assert.ok(o2.producedToday>half*1.9);
 const s3=prepared(),o3=s3.offshore.oil;o3.stage=5;o3.buffer=OFFSHORE.oil.bufferCapacity;
 normalizeOffshoreState(s3);const before=o3.reserveRemaining;day(s3);assert.equal(o3.producedToday,0);assert.equal(o3.reserveRemaining,before);
});
test('depletion decreases pressure, and never drives reserves below zero',()=>{
 const s=prepared(),o=s.offshore.oil;o.stage=5;o.pipelineLevel=3;
 normalizeOffshoreState(s);const first=reservoirMetrics(o).pressurePct;
 for(let i=0;i<220;i++){s.tanks.crude=0;day(s);assert.ok(o.reserveRemaining>=0);assert.ok(o.buffer>=0)}
 assert.ok(reservoirMetrics(o).pressurePct<first);
 o.reserveRemaining=3; s.tanks.crude=0;day(s);assert.equal(o.reserveRemaining,0);
 s.tanks.crude=0;day(s);assert.equal(o.producedToday,0);
});

test('stopped platform preserves reservoir and avoids operating cost while line can drain buffer',()=>{
 const s=prepared(),o=s.offshore.oil;o.stage=5;o.pipelineLevel=2;o.online=false;o.buffer=40;
 const cost=day(s);assert.equal(o.producedToday,0);assert.equal(o.deliveredToday,40);assert.equal(cost,OFFSHORE.oil.pipelineOpex[2]);
 const reserve=o.reserveRemaining;const nextCost=day(s);assert.equal(nextCost,0);assert.equal(o.reserveRemaining,reserve);
});
