import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
const dir=fileURLToPath(new URL('../js/ui/',import.meta.url));
let src=fs.readFileSync(dir+'country-scene.js','utf8').replace("new T.WebGLRenderer(","new FakeR(");
src+=`\nclass FakeR{constructor(){this.domElement=globalThis.document.createElement('canvas');this.shadowMap={}}setPixelRatio(){}setSize(){}render(scene){globalThis.__scene=scene;globalThis.__r=(globalThis.__r||0)+1}dispose(){}}\n`;
fs.writeFileSync(dir+'_smoke.mjs',src);
const el=()=>{const e={style:{},classList:{toggle(){}},children:[],dataset:{},parentElement:null,isConnected:true,clientWidth:800,clientHeight:600,nodeType:1,addEventListener(){},append(c){c.parentElement=e;e.children.push(c)},remove(){},setAttribute(){},setPointerCapture(){},getBoundingClientRect(){return{left:0,top:0,width:800,height:600}}};return e};
const host=el(),ov=el();ov.append=function(c){this.children.push(c)};
globalThis.document={createElement:()=>el(),getElementById:id=>id==='atlas-labels'?ov:host,querySelector:()=>null,addEventListener(){},removeEventListener(){},hidden:false};
globalThis.devicePixelRatio=1;globalThis.IntersectionObserver=class{observe(){}disconnect(){}};globalThis.ResizeObserver=class{observe(){}disconnect(){}};
let q=[];globalThis.requestAnimationFrame=f=>(q.push(f),q.length);globalThis.cancelAnimationFrame=()=>{};
const {mountCountryScene,disposeCountryScene}=await import(dir+'_smoke.mjs');
const {createFreshState}=await import('../js/core/game-state.js');
const CITIES=[{name:'a'},{name:'b'},{name:'c'},{name:'d'},{name:'e'}];
const views=[{},{countryHub:'north'},{countryHub:'energy'},{countryHub:'housing'},{countryHub:'port'},{offshoreView:true},{cityView:1},{tab:'site'}];
test('every 3D country view builds and renders without WebGL',async()=>{for(const v of views){const S=createFreshState();S.tab='c';Object.assign(S,v);S.cityMaps={b:[{type:'home',level:2},{type:'park',level:1},{type:'shop',level:3},{type:'service',level:1}]};S.inc={ex:3};S.offshore.oil.stage=5;S.offshore.oil.online=true;
 S.grid[20]={t:'f',l:2,c:{water:1,fuel:1}};S.grid[21]={t:'k',l:3,c:{}};S.u=Array.from({length:14},(_,i)=>({t:i%16,st:['run','trip','build','off'][i%4],pl:0}));
 q=[];mountCountryScene(S,CITIES,()=>{});
 assert.equal(host.dataset.renderer,'webgl');
 for(let i=0;i<3;i++){const f=q.shift();f&&f(1000+i*100)}
 assert.ok(globalThis.__r>0);
 const waters=[];globalThis.__scene.traverse(o=>{if(o.name==='map-water')waters.push(o)});
 const marine=!v.tab&&!v.cityView&&(!v.countryHub||v.countryHub==='port')||v.offshoreView;
 assert.equal(waters.length,marine?1:0,'only marine and atlas views have water');
 for(const w of waters){const p=w.geometry.attributes.position;for(let i=0;i<p.count;i++)assert.ok(p.getY(i)+w.position.y<-.15,'waves stay below dry ground');assert.equal(w.material.depthWrite,false)}
 disposeCountryScene();}});

fs.unlinkSync(dir+'_smoke.mjs');
