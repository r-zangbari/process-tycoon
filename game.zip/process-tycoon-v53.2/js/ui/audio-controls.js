import {audioPreferences} from '../systems/audio-scenes.js';
export function mountAudioControls({getState,engine,save,draw,documentRef=typeof document!=='undefined'?document:null}){
 const doc=documentRef;if(!doc)return;const byId=id=>doc.getElementById(id),dialog=byId('audio-dialog');
 const populate=()=>{const a=audioPreferences(getState());for(const k of ['master','music','ambience','effects']){const input=byId('audio-'+k),output=byId('audio-value-'+k);if(input)input.value=String(Math.round(a[k]*100));if(output)output.textContent=Math.round(a[k]*100).toLocaleString('fa-IR')+'٪'}if(byId('audio-enabled'))byId('audio-enabled').checked=!getState().mute;const status=byId('audio-status');if(status)status.textContent=getState().mute?'صدا خاموش است.':engine.status().ready?'صدا آماده · '+({industrial:'محیط صنعتی',water:'جریان آب',sea:'ساحل و دریا',field:'شهر و طبیعت',quiet:'فضای آرام'})[engine.status().scene]+'؛ حجم هر بخش مستقل است.':'برای شروع صدا یک دکمه یا «آزمایش صدا» را بزن.'};
 byId('audio-open')?.addEventListener?.('click',()=>{populate();dialog?.showModal?.();engine.unlock().then(populate)});
 byId('audio-close')?.addEventListener?.('click',()=>dialog?.close?.());
 byId('audio-preview')?.addEventListener?.('click',()=>{engine.unlock().then(()=>{engine.playEvent('success');populate()})});
 byId('audio-enabled')?.addEventListener?.('change',e=>{getState().mute=!e.target.checked;engine.sync();save();draw();populate()});
 for(const k of ['master','music','ambience','effects'])byId('audio-'+k)?.addEventListener?.('input',e=>{const S=getState();S.audio||={};S.audio[k]=Math.max(0,Math.min(100,Number(e.target.value)||0))/100;engine.sync();save();const output=byId('audio-value-'+k);if(output)output.textContent=Math.round(S.audio[k]*100).toLocaleString('fa-IR')+'٪'});
 const gesture=e=>{if(e.type==='keydown'&&!['Enter',' '].includes(e.key))return;engine.unlock();if(e.target?.closest?.('button,[data-map-kind],[data-mimic-eq]'))engine.playEvent('click')};
 doc.addEventListener('pointerdown',gesture,{capture:true});doc.addEventListener('keydown',gesture,{capture:true});doc.addEventListener('visibilitychange',()=>engine.setVisible(!doc.hidden));
}
