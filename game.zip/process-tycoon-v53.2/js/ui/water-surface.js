// Keep the entire animated water envelope below the dry-land datum (Y=0).
export const SEA_LEVEL=-.20;
export const WAVE_HEIGHT=.04;
export const hasSea=key=>key==='atlas'||key==='offshore'||key==='hub:port';
export const waterElevation=(x,z,time)=>.025*Math.sin(x*.35+time*1.2)+.015*Math.cos(z*.4+time*.9);
