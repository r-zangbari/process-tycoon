// Preserve live scroll targets, disclosure state and GPU canvases during daily updates.
function identity(node){
 if(node.nodeType!==1)return node.nodeType+':'+node.nodeName;
 if(node.id)return '#'+node.id;
 if(node.matches('button'))return 'button:'+['a','k','i','t','p','hmi','target','role','j','d','q','v'].map(k=>node.dataset[k]||'').join(':');
 return node.tagName+':'+(node.className||'');
}
function reconcile(oldNode,newNode){
 if(oldNode.nodeType!==newNode.nodeType||oldNode.nodeName!==newNode.nodeName){oldNode.replaceWith(newNode);return}
 if(oldNode.nodeType!==1){if(oldNode.nodeValue!==newNode.nodeValue)oldNode.nodeValue=newNode.nodeValue;return}
 if(oldNode.tagName==='SELECT'&&oldNode===document.activeElement)return;
 if(oldNode.id==='country-three'||oldNode.id==='industry-three'||oldNode.id==='atlas-labels')return;
 for(const attr of [...oldNode.attributes])if(attr.name!=='open'&&!newNode.hasAttribute(attr.name))oldNode.removeAttribute(attr.name);
 for(const attr of [...newNode.attributes])if(!(oldNode.tagName==='DETAILS'&&attr.name==='open')&&oldNode.getAttribute(attr.name)!==attr.value)oldNode.setAttribute(attr.name,attr.value);
 const wanted=[...newNode.childNodes];
 for(let i=0;i<wanted.length;i++){
  const next=wanted[i];let current=oldNode.childNodes[i];
  if(!current){oldNode.append(next);continue}
  if(identity(current)!==identity(next)){
   const match=[...oldNode.childNodes].slice(i+1).find(n=>identity(n)===identity(next));
   if(match){oldNode.insertBefore(match,current);current=match}else{oldNode.insertBefore(next,current);continue}
  }
  reconcile(current,next);
 }
 while(oldNode.childNodes.length>wanted.length)oldNode.lastChild.remove();
}
export function refreshMapMarkup(app,markup){
 if(!app?.nodeType)return false;
 const oldHost=app.querySelector('#country-three,#industry-three');if(!oldHost)return false;
 const template=document.createElement('template');template.innerHTML=markup;
 const newHost=template.content.querySelector('#country-three,#industry-three');
 if(!newHost||newHost.id!==oldHost.id||newHost.dataset.view!==oldHost.dataset.view)return false;
 reconcile(app.firstElementChild,template.content.firstElementChild);return true;
}
// The long diagnostic report keeps its open sections and horizontal table position.
export function refreshAdvisorMarkup(app,markup){
 if(!app?.nodeType)return false;const panel=app.querySelector('#crisis-advisor,#maintenance-fleet');if(!panel)return false;
 const incoming=document.createElement(app.tagName);incoming.innerHTML=markup;
 if(!incoming.querySelector('#'+panel.id))return false;
 for(const attr of app.attributes)incoming.setAttribute(attr.name,attr.value);
 reconcile(app,incoming);return true;
}

export function refreshScreenMarkup(app,markup){
 if(!app?.nodeType)return false;
 const incoming=document.createElement(app.tagName);incoming.innerHTML=markup;
 for(const attr of app.attributes)incoming.setAttribute(attr.name,attr.value);
 reconcile(app,incoming);return true;
}
