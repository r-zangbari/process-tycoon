// Read-only process mimic diagram for the simulated DCS screen.
const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));

function equipmentSymbol(name, x, y, statusColor, statusText, index, selectedIndex) {
  const label = esc(name);
  const common = `stroke="${statusColor}" stroke-width="3" fill="var(--card)"`;
  let shape;
  if (/پمپ/i.test(name)) {
    shape = `<circle cx="${x}" cy="${y}" r="27" ${common}/><path d="M ${x-10} ${y-13} L ${x+14} ${y} L ${x-10} ${y+13} Z" fill="${statusColor}"/>`;
  } else if (/مخزن|درام|تانک|برج|ستون/i.test(name)) {
    shape = `<rect x="${x-24}" y="${y-33}" width="48" height="66" rx="20" ${common}/><path d="M ${x-20} ${y+7} Q ${x} ${y-1} ${x+20} ${y+7}" fill="none" stroke="${statusColor}" stroke-width="2"/>`;
  } else if (/مبدل|هیتر|کولر|کندانسور|ریفلاکس/i.test(name)) {
    shape = `<rect x="${x-34}" y="${y-23}" width="68" height="46" rx="5" ${common}/><path d="M ${x-24} ${y+15} L ${x+24} ${y-15} M ${x-24} ${y-15} L ${x+24} ${y+15}" stroke="${statusColor}" stroke-width="2"/>`;
  } else {
    shape = `<rect x="${x-31}" y="${y-25}" width="62" height="50" rx="6" ${common}/><path d="M ${x-20} ${y} H ${x+20} M ${x} ${y-15} V ${y+15}" stroke="${statusColor}" stroke-width="2"/>`;
  }
  return `<g class="mimic-equipment ${index === selectedIndex ? 'selected' : ''}" data-mimic-eq="${index}" tabindex="0" role="button" aria-label="جزئیات ${label}" aria-pressed="${index === selectedIndex}"><title>${label} — ${esc(statusText)} · برای جزئیات انتخاب کنید</title><rect x="${x-80}" y="${y-45}" width="160" height="120" fill="transparent"/>${shape}<text x="${x}" y="${y+48}" class="mimic-label">${label}</text><text x="${x}" y="${y+64}" class="mimic-state" fill="${statusColor}">${esc(statusText)}</text></g>`;
}

export function renderProcessMimic({ unit, definition, formatNumber, unitIndex = 0, selectedIndex = null, valveOpen = true, pumpStandby = false, processState = null, pidLoops = [] }) {
  const pumpIndices = (definition.e || []).map((item, index) => /پمپ|pump/i.test(String(item?.[0] || '')) ? index : -1).filter(index => index >= 0);
  const selectedPumpIndex = pumpIndices[0] ?? -1;
  const pumpAsset = selectedPumpIndex >= 0 ? unit.eq?.[selectedPumpIndex] : null;
  const selectedPump = pumpAsset && pumpStandby && pumpAsset.reserve ? pumpAsset.reserve : pumpAsset;
  const pumpReady = !selectedPump || (!selectedPump.f && Number(selectedPump.h) >= 30);
  const pumpStatus = !pumpReady ? 'پمپ انتخابی آماده نیست' : selectedPump ? (pumpStandby ? 'پمپ رزرو آماده' : 'پمپ اصلی آماده') : 'پمپ بدون آرایش رزرو';
  const flowVariableIndex = (definition.v || []).findIndex(v => /دبی|جریان|flow/i.test(String(v?.[0] || '')));
  const flowVariable = flowVariableIndex >= 0 ? unit.v?.[flowVariableIndex] : null;
  const count = Math.max(1, unit.eq?.length || 0);
  const width = Math.max(760, 170 * count + 270);
  const y = 112;
  const start = 240;
  const end = width - 130;
  const step = count > 1 ? (end - start) / (count - 1) : 0;
  const running = unit.st === 'run';
  const pumpRunning = processState?.pumpRunning !== false;
  const hasStandbyPump = pumpIndices.some(index => !!definition.e[index]?.[1] && !!unit.eq?.[index]?.reserve);
  const flowActive = running && valveOpen && pumpReady && pumpRunning && Number(processState?.lastFlowFactor ?? 1) > 0;
  const levelIndex = (definition.v || []).findIndex(v => /سطح|لول|level/i.test(String(v?.[0] || '')));
  const rawLevel = levelIndex >= 0 ? Number(unit.v?.[levelIndex]) : 50;
  const levelPct = Number.isFinite(processState?.tankLevelPct) ? Math.max(0, Math.min(100, processState.tankLevelPct)) : (Number.isFinite(rawLevel) ? Math.max(0, Math.min(100, rawLevel)) : 50);
  const flowStatus = !running ? 'واحد متوقف' : !valveOpen ? 'جریان مسدود؛ شیر بسته' : !pumpReady ? 'جریان مسدود؛ پمپ آماده نیست' : !flowActive ? 'پمپ بدون دبی / MV صفر' : 'جریان برقرار';
  const colorFor = item => item.f ? 'var(--bad)' : item.h < 30 ? 'var(--warn)' : running ? 'var(--ok)' : 'var(--mut)';
  const statusFor = item => item.f ? 'خراب' : item.h < 30 ? 'سلامت پایین' : running ? 'در سرویس' : 'آماده / متوقف';
  const nodes = (unit.eq || []).map((item, index) => {
    const x = start + index * step;
    return equipmentSymbol(definition.e[index]?.[0] || `تجهیز ${index+1}`, x, y, colorFor(item), statusFor(item), index, selectedIndex);
  }).join('');
  const equipmentXs = (unit.eq || []).map((_, index) => start + index * step);
  const firstX = equipmentXs[0] ?? start;
  const lastX = equipmentXs[equipmentXs.length-1] ?? start;
  const feedX = 55, productX = width - 45;
  const pathStart = feedX + 45;
  const pathEnd = productX - 45;
  const flow = `<path class="mimic-pipe ${flowActive ? 'is-flow' : ''}" d="M ${pathStart} ${y} H ${pathEnd}"/><path d="M ${feedX+35} ${y-7} L ${feedX+45} ${y} L ${feedX+35} ${y+7}" fill="none" stroke="var(--mut)" stroke-width="2"/><path d="M ${productX-35} ${y-7} L ${productX-45} ${y} L ${productX-35} ${y+7}" fill="none" stroke="var(--mut)" stroke-width="2"/>`;
  const links = equipmentXs.map((x, index) => {
    const left = index === 0 ? pathStart : equipmentXs[index-1] + 35;
    const right = x - 35;
    return right > left ? `<path class="mimic-pipe ${flowActive ? 'is-flow' : ''}" d="M ${left} ${y} H ${right}"/>` : '';
  }).join('');
  const tags = (definition.v || []).slice(0, 4).map((variable, index) => {
    const value = unit.v?.[index];
    return `<span class="mimic-tag"><b>${esc(variable[0])}</b><strong>${formatNumber(value)} <small>${esc(variable[1])}</small></strong></span>`;
  }).join('');
  return `<section class="hmi-panel mimic-panel"><div class="hmi-panel-head"><h3>نقشه فرایند واحد</h3><span class="muted">نمای مفهومی مسیر خوراک تا محصول</span></div><p class="mimic-current-state">${flowStatus} · ${pumpStatus}</p><details class="mimic-measurements"><summary>مقادیر زنده، حلقه‌ها و موازنه</summary><div class="mimic-tags">${tags}<span class="mimic-tag mimic-flow-tag ${flowActive?'flow-on':'flow-off'}"><b>وضعیت جریان</b><strong>${flowStatus}</strong></span><span class="mimic-tag"><b>پمپ منتخب</b><strong>${pumpStatus}</strong></span>${processState ? `<span class="mimic-tag"><b>اثر متقابل فشار/دما بر دبی</b><strong>${formatNumber(processState.flowCouplingEffect || 0)} <small>${esc(definition.v[flowVariableIndex]?.[1] || '')}</small></strong></span><span class="mimic-tag"><b>موازنه مخزن · ورودی / خروجی</b><strong>${formatNumber(processState.inflow || 0)} / ${formatNumber(processState.outflow || 0)} <small>نسبی</small></strong></span><span class="mimic-tag"><b>وضعیت سطح</b><strong>${esc(processState.levelStatus || 'NORMAL')}</strong></span>` : ''}${Number.isFinite(flowVariable) ? `<span class="mimic-tag"><b>دبی فرایند</b><strong>${formatNumber(flowActive ? flowVariable : 0)} <small>${esc(definition.v[flowVariableIndex]?.[1] || '')}</small></strong></span>` : ''}</div></details><div class="mimic-scroll-tools"><span class="muted">تجهیز را برای جزئیات انتخاب کن؛ در موبایل نقشه قابل پیمایش است. ترتیب اتصال، آموزشی و مفهومی است.</span><div class="row"><button type="button" data-mimic-scroll="-1" aria-label="حرکت نقشه به راست">→</button><button type="button" data-mimic-scroll="1" aria-label="حرکت نقشه به چپ">←</button></div></div><div class="mimic-scroll" tabindex="0" role="region" aria-label="ناحیه پیمایش افقی نقشه فرایند"><svg class="process-mimic" viewBox="0 0 ${width} 355" role="img" aria-label="نقشه شماتیک مفهومی تجهیزات واحد ${esc(definition.n)}"><text x="${feedX+20}" y="${y-43}" class="mimic-end-label">خوراک</text><circle cx="${feedX+20}" cy="${y}" r="19" fill="var(--card)" stroke="var(--mut)" stroke-width="2"/><text x="${feedX+20}" y="${y+4}" class="mimic-end-symbol">F</text>${flow}${links}<path d="M ${pathStart} ${y} H ${firstX-35}" stroke="${flowActive ? '#e9a23b' : 'var(--mut)'}" stroke-width="5" fill="none"/><path d="M ${lastX+35} ${y} H ${pathEnd}" stroke="${flowActive ? '#2a9d8f' : 'var(--mut)'}" stroke-width="5" fill="none"/><g class="mimic-valve-symbol" transform="translate(155 ${y})"><path d="M -13 -12 L 0 0 L -13 12 Z M 13 -12 L 0 0 L 13 12 Z" fill="${valveOpen?'var(--ok)':'var(--bad)'}" stroke="${valveOpen?'var(--ok)':'var(--bad)'}" stroke-width="2"/><path d="M 0 -1 V -27 M -10 -27 H 10" stroke="var(--ink)" stroke-width="2"/><text x="0" y="-39" class="mimic-state" fill="var(--ink)">${valveOpen?'XV-101 OPEN':'XV-101 CLOSED'}</text></g>${nodes}<circle cx="${productX-20}" cy="${y}" r="19" fill="var(--card)" stroke="var(--mut)" stroke-width="2"/><text x="${productX-20}" y="${y+4}" class="mimic-end-symbol">P</text><text x="${productX-20}" y="${y+43}" class="mimic-end-label">محصول</text><text x="${width/2}" y="195" class="mimic-caption">${flowStatus}</text><g class="mimic-utility"><path d="M 80 218 H ${width-80}" stroke="#268bd2" stroke-width="4" stroke-dasharray="7 5" fill="none"/><text x="${width/2}" y="211" class="mimic-state" fill="#268bd2">یوتیلیتی / Utility</text></g><g class="mimic-tank" transform="translate(92 258)"><defs><clipPath id="mimicTankClip"><rect x="-29" y="-49" width="58" height="98" rx="17"/></clipPath></defs><rect x="-29" y="-49" width="58" height="98" rx="17" fill="var(--card)" stroke="var(--brand)" stroke-width="3"/><g clip-path="url(#mimicTankClip)"><rect x="-26" y="${49-(levelPct*.94)}" width="52" height="${levelPct*.94}" fill="#2a9d8f" opacity=".88"/><path d="M -26 ${49-(levelPct*.94)} Q 0 ${44-(levelPct*.94)} 26 ${49-(levelPct*.94)}" fill="none" stroke="#8ee0d4" stroke-width="2"/></g><text x="0" y="-58" class="mimic-state" fill="var(--ink)">TK-101</text><text x="0" y="5" class="mimic-tank-pct">${Math.round(levelPct)}%</text><text x="0" y="67" class="mimic-state" fill="var(--ink)">سطح مخزن</text></g><text x="${width/2}" y="340" class="mimic-caption">${flowStatus} · ${pumpStatus}</text></svg></div>${pidLoops.length ? `<div class="mimic-actuator-grid"><div class="mimic-actuator-head"><b>محرک‌های حلقه‌بسته PID</b><span class="muted">خروجی AUTO به عنصر نهایی کنترل نگاشت شده است.</span></div>${pidLoops.map(loop=>{const pc=loop.config||{},mv=Math.max(0,Math.min(100,Number(pc.mv??50)));return `<div class="mimic-actuator"><div><b>${esc(loop.name)}</b><small>${esc(pc.actuatorTag||'CV-101')} · ${esc(pc.actuatorLabel||'شیر کنترل فرایند')}</small></div><strong>${formatNumber(mv)}٪</strong><div class="mimic-mv-bar"><i style="width:${mv}%"></i></div></div>`}).join('')}</div>` : ''}<div class="mimic-legend"><span><i class="mimic-dot ok"></i>سالم</span><span><i class="mimic-dot warn"></i>نیازمند توجه</span><span><i class="mimic-dot bad"></i>خراب</span><span class="muted">برای مشاهده جزئیات، روی نماد تجهیز بزنید. این نقشه شماتیک است و جایگزین P&amp;ID مهندسی نیست.</span></div><div class="mimic-control-strip"><div class="mimic-control-status"><b>Permissive:</b> <span class="${running && pumpReady && pumpRunning?'ok':'wn'}">${running && pumpReady && pumpRunning?'READY':'NOT READY'}</span><small>فرمان‌ها صرفاً در صورت آماده‌بودن واحد و تجهیزات مجاز هستند.</small></div><div class="row"><button type="button" data-mimic-valve ${!running?'disabled':''}>${valveOpen?'بستن شیر XV-101 · قطع جریان':'بازکردن شیر XV-101 · برقراری جریان'}</button><button type="button" data-mimic-pump ${!running||!hasStandbyPump?'disabled':''}>${pumpStandby?'انتخاب پمپ اصلی':'انتخاب پمپ رزرو'}</button></div></div>${selectedIndex !== null && unit.eq?.[selectedIndex] ? (() => { const e=unit.eq[selectedIndex], name=definition.e[selectedIndex]?.[0] || `تجهیز ${selectedIndex+1}`, fault=e.f; const status=fault?(fault.st===0?'خراب · نیازمند قطعه':fault.st===1?'قطعه در مسیر تأمین':'قطعه آماده تعمیر'):e.h<30?'سلامت پایین':'سالم'; const actions=fault&&fault.st===0?`<button data-a="part" data-i="${unitIndex}" data-j="${selectedIndex}" data-f="0">سفارش قطعه</button><button data-a="part" data-i="${unitIndex}" data-j="${selectedIndex}" data-f="1">ارسال فوری قطعه</button>`:fault&&fault.st===2?`<button class="p" data-a="repair" data-i="${unitIndex}" data-j="${selectedIndex}">تعمیر تجهیز</button>`:fault?'<span class="muted">در انتظار رسیدن قطعه</span>':'<span class="tag run">تجهیز آماده به کار</span>'; return `<div class="mimic-equipment-detail"><div><b>${esc(name)}</b><span class="muted"> · ${status}</span><div class="muted">سلامت اصلی ${Math.round(e.h)}٪${e.reserve?` · سلامت رزرو ${Math.round(e.reserve.h)}٪`:''} · سطح تجهیز ${e.l} از ۴</div></div><div class="row">${actions}<button data-a="up" data-i="${unitIndex}" data-j="${selectedIndex}" ${e.l>=4?'disabled':''}>ارتقا (${formatNumber(definition.cost*.3*e.l)})</button><button type="button" data-mimic-close>بستن جزئیات</button></div></div>`; })() : `<div class="mimic-select-hint muted">برای جزئیات و فرمان‌های تجهیز، روی نماد آن بزن. وضعیت جریان و فرمان شیر و پمپ در همین نقشه در دسترس‌اند.</div>`}</section>`;
}
