import {cityDesign,districtDesign,STYLES,placementDefinition,industryAppearance,PALETTES,districtIndex} from '../systems/legacy-development.js';
import {cleanUnitName} from '../systems/unit-names.js';
import {SEA_LEVEL,hasSea,waterElevation} from './water-surface.js';
import {createVectorScene} from './map-vector.js';
import {layoutLots,sceneSignature,projectedLabelLayout,MAP_ROUTES,MAP_COLORS} from './map-design.js';
// v52.7 — صحنهٔ سه‌بعدی کشور، شهر، قطب‌ها، فراساحل، بندر و محوطهٔ صنعت (Three.js، موتور سبک جدید).
// رابط عمومی (mountCountryScene / countryCamera / disposeCountryScene و دادهٔ pick) همان نسخهٔ ۵۲٫۴ است؛ فقط نمایش عوض شده و state تغییر نمی‌کند.
import * as T from '../vendor/three.module.min.js';
import {industryPage} from './industry-view.js';
import {DISTRICTS,districtLots,countryViewKey} from '../systems/country-planning.js';
const SHORT_UNIT_NAMES=['پالایش نفت','تصفیه آب','LPG','پالایش گاز','بخار و برق','متانول','اتیلن','سیکل ترکیبی','هسته‌ای','میدان نفت','هیدروژن','آمونیاک','اوره','خورشیدی','فولاد','سیمان'];
const NEED={h:['power','gas','water','fuel'],f:['water','fuel'],k:['power','gas','fuel']};
const SEASON=[{g:'#79bf55',f:'#3f7f45'},{g:'#9bbd54',f:'#3f7840'},{g:'#b4a64b',f:'#a05f2c'},{g:'#e3ecef',f:'#a9bcbf'}];
const cl=(v,a,b)=>Math.min(b,Math.max(a,v)),sm=(a,b,x)=>{const t=cl((x-a)/(b-a),0,1);return t*t*(3-2*t)};
const gBox=new T.BoxGeometry(1,1,1),gCyl=new T.CylinderGeometry(1,1,1,14),gCone=new T.ConeGeometry(1,1,4),gCone8=new T.ConeGeometry(1,1,8),gSph=new T.SphereGeometry(1,10,8),gRing=new T.TorusGeometry(1,.025,6,48).rotateX(Math.PI/2);
let active=null,webglUnavailable=false;
export function disposeCountryScene(){if(!active)return;active.dispose();active=null}
export function countryCamera(command){active?.cameraAction(command)}
export function mountCountryScene(S,CITIES,onSelect){
 const host=document.getElementById(S.tab==='site'?'industry-three':'country-three');
 if(!['site','c'].includes(S.tab)){disposeCountryScene();return}
 if(!host?.nodeType){disposeCountryScene();return}
 const key=S.tab==='site'?'industry:'+industryPage(S).page:countryViewKey(S);
 if(active&&active.key!==key)disposeCountryScene();
 if(!active){if(webglUnavailable)active=createVectorScene(host,key,onSelect);else try{active=createScene(host,key,onSelect)}catch(error){webglUnavailable=true;active=createVectorScene(host,key,onSelect);console.info('Using lightweight isometric map');}}
 active.attach(host,onSelect);active.update(S,CITIES);
}
function createScene(host,key,onSelect){
 const renderer=new T.WebGLRenderer({antialias:true,powerPreference:'low-power'});
 renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.6));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
 const cv=renderer.domElement;cv.style.touchAction='pan-y';cv.setAttribute('aria-label','نقشهٔ سه‌بعدی');
 const scene=new T.Scene(),camera=new T.PerspectiveCamera(38,1,1,420),industry=key.startsWith('industry:'),atlas=key==='atlas';
 const hemi=new T.HemisphereLight('#e4f4ff','#52703d',1.2),sun=new T.DirectionalLight('#fff1d2',2.3);
 sun.position.set(-30,60,35);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.bias=-.0008;Object.assign(sun.shadow.camera,{left:-60,right:60,top:60,bottom:-60,near:10,far:180});scene.add(hemi,sun);
 renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;const dayBg=new T.Color('#ccd8cb'),nightBg=new T.Color('#203748');scene.background=dayBg.clone();scene.fog=new T.Fog('#ccd8cb',180,390);
 const home=industry?{tx:0,tz:0,d:108,az:.6,tilt:.95}:atlas?{tx:0,tz:7,d:96,az:.45,tilt:.9}:{tx:0,tz:0,d:key==='offshore'||key==='hub:port'?62:64,az:.35,tilt:.9},cs={...home},goal={...home};let ambience=0,showLabels=true,selectedDistrict='capital',focusPoint=null;const reducedMotion=typeof matchMedia==='function'&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 const root=new T.Group(),terrainG=new T.Group();scene.add(terrainG,root);
 const lit=new T.MeshStandardMaterial({color:'#efe2bd',emissive:'#ffc766',emissiveIntensity:0,roughness:.7}),em=(c,i)=>new T.MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:i}),
  bc={ok:em('#2ecc71',1.2),warn:em('#ffb52e',1),bad:em('#ff4a3d',1)},FLAME=em('#ff8a1f',1.6),materials=new Map();
 const mat=c=>materials.get(c)||(materials.set(c,new T.MeshStandardMaterial({color:c,roughness:.85})),materials.get(c));
 let labels=[],anim=[],srcs=[],signature='',terrainKey='',water=null,smoke=null,observer,select=onSelect,currentHost=host,enabled=false,raf=0,vis=true,last=0,H=()=>0;
 const ground=(x,z)=>atlas?Math.max(H(x,z),0)+.05:.1;
 const sharedGeometry=new Set([gBox,gCyl,gCone,gCone8,gSph,gRing]);
 const clearRoot=()=>{const disposed=new Set();root.traverse(o=>{if(o.geometry&&!sharedGeometry.has(o.geometry)&&!disposed.has(o.geometry)){o.geometry.dispose();disposed.add(o.geometry)}if(o.material){for(const m of Array.isArray(o.material)?o.material:[o.material])if(![lit,FLAME,...Object.values(bc),...materials.values()].includes(m)&&!disposed.has(m)){m.dispose();disposed.add(m)}}});root.clear()};
 function box(x,y,z,w,h,d,color,parent=root){const m=new T.Mesh(gBox,typeof color==='string'?mat(color):color);m.scale.set(w,h,d);m.position.set(x,y+h/2,z);m.castShadow=h>.25;m.receiveShadow=true;parent.add(m);return m}
 function cylinder(x,y,z,r,h,color,parent=root,top=r){const m=new T.Mesh(top===r?gCyl:new T.CylinderGeometry(top,r,h,12),mat(color));if(top===r)m.scale.set(r,h,r);m.position.set(x,y+h/2,z);m.castShadow=h>.25;m.receiveShadow=true;parent.add(m);return m}
 function tree(x,z,s=1){const y=ground(x,z)-.05;cylinder(x,y+.2,z,.17*s,1.1*s,'#927652');const m=new T.Mesh(gCone8,mat('#3f7a4c'));m.scale.set(.9*s,2.5*s,.9*s);m.position.set(x,y+2*s,z);m.castShadow=true;root.add(m)}
 const pick=(m,d)=>{m.userData.pick=d};
 const label=(text,x,z,y=4,priority=0)=>labels.push({text,point:new T.Vector3(x,y,z),priority});
 const ring=(x,y,z,r,c,pulse)=>{const m=new T.Mesh(gRing,new T.MeshBasicMaterial({color:c}));m.scale.set(r,1,r);m.position.set(x,y,z);root.add(m);if(pulse)anim.push(t=>{const s=r*(1+.05*Math.sin(t*4));m.scale.set(s,1,s)})};
 function beacon(g,st,y){const m=new T.Mesh(gSph,bc[st]);m.scale.setScalar(.06);m.position.y=y;g.add(m)}
 function building(x,z,type,level=1,scale=1,st=null,style=null){
  const g=new T.Group();g.position.set(x,type==='rig'?0:ground(x,z),z);g.scale.setScalar(scale);root.add(g);
  const P=(geo,c,sx,sy,sz,px,py,pz,ry=0)=>{const m=new T.Mesh(geo,typeof c==='string'?mat(style&&['#e6cfaa','#e8d9b0','#80b2af','#d6dec8'].includes(c)?style.wall:style&&['#b4533a','#c0866d','#517e79'].includes(c)?style.roof:c):c);m.scale.set(sx,sy,sz);m.position.set(px,py+sy/2,pz);m.rotation.y=ry;m.castShadow=m.receiveShadow=true;g.add(m);return m},l=cl(level|0||1,1,3),loc=[];
  const roofed=(px,pz,w,h,col,roof)=>{P(gBox,col,w,h,w,px,0,pz);P(gCone,roof,w*.85,.14,w*.85,px,h,pz,Math.PI/4)};
  if(type==='farm'||type==='f'){P(gBox,'#b99a4a',.92,.03,.92,0,0,0);for(let j=0;j<5;j++)P(gBox,l===3?'#e0c77e':'#76b94d',.1,.05,.8,-.34+j*.17,.03,0);P(gBox,'#c0654c',.28,.16+.04*l,.22,.3,.03,-.3);P(gCone,'#8a3d2a',.24,.1,.24,.3,.19+.04*l,-.3,Math.PI/4);if(l>1)P(gCyl,'#d7d9d4',.08,.3,.08,-.32,.03,-.3)}
  else if(type==='park'){P(gCyl,'#759a65',.46,.04,.46,0,0,0);P(gBox,'#ddca9e',.1,.05,.9,0,.04,0);for(let j=0;j<l+2;j++){const a=j*1.7,px=Math.cos(a)*.26,pz=Math.sin(a)*.26;P(gCyl,'#8c704e',.025,.14,.025,px,.04,pz);P(gCone8,'#4a8656',.13,.26,.13,px,.16,pz)}}
  else if(type==='shop'){P(gBox,'#80b2af',.8,.22+.1*l,.52,0,0,0);P(gBox,lit,.82,.07,.54,0,.1,0);P(gBox,'#c96d65',.84,.04,.2,0,.2,.34);P(gBox,'#517e79',.84,.05,.56,0,.22+.1*l,0)}
  else if(type==='service'){P(gBox,'#d6dec8',.62,.3+.12*l,.52,0,0,0);P(gBox,lit,.64,.08,.54,0,.12,0);P(gBox,'#c96d65',.08,.18,.3,0,.3+.12*l,0);P(gBox,'#c96d65',.3,.18,.08,0,.3+.12*l,0)}
  else if(type==='factory'||type==='k'){const h=.26+.07*l;P(gBox,'#a9b3b5',.78,h,.56,0,0,0);P(gBox,'#3b7474',.82,.05,.6,0,h,0);P(gBox,lit,.8,h*.3,.58,0,h*.3,0);for(let i=0;i<l;i++){const sx=-.24+i*.2,sh=.4+.08*i;P(gCyl,'#b84a3a',.055,sh,.055,sx,h,-.14);loc.push([sx,h+sh,-.14])}P(gCyl,'#e5d7ac',.14,.34,.14,.28,0,.14)}
  else if(type==='port'){P(gBox,'#b9b99b',1,.07,.8,0,0,.1);P(gBox,'#ded8b9',.34,.22,.28,-.3,.07,-.2);['#dc9771','#669b9f','#c0392b','#e1a21b','#8e44ad','#27ae60'].forEach((c,k)=>P(gBox,c,.2,.1,.1,-.4+(k%3)*.22,.07+Math.floor(k/3)*.1,.15));for(const dx of[.15,.4]){P(gBox,'#edc778',.025,.5,.025,dx-.06,.07,.45);P(gBox,'#edc778',.025,.5,.025,dx+.06,.07,.45);P(gBox,'#edc778',.3,.03,.04,dx,.57,.45)}}
  else if(type==='rig'){for(const[a,d]of[[-.3,-.3],[.3,-.3],[-.3,.3],[.3,.3]])P(gCyl,'#6d7b80',.025,1.1,.025,a,-.6,d);P(gBox,'#e7c982',.9,.07,.8,0,.5,0);P(gBox,'#dae1cf',.3,.2,.34,-.2,.57,.1);P(gCone,'#cba55c',.2,.9,.2,.2,.57,-.12,Math.PI/4);P(gCyl,'#9fc2bf',.1,.28,.1,.28,.57,.22);P(gCyl,'#555',.012,.7,.012,-.38,.57,-.3);const f=new T.Mesh(gCone,FLAME);f.scale.set(.05,.16,.05);f.position.set(-.38,1.35,-.3);g.add(f);anim.push(t=>{f.scale.y=.16*(1+.25*Math.sin(t*18))})}
  else if(type==='capital'||type==='city'){const R=(a=>()=>(a=(a*1664525+1013904223)>>>0)/4294967296)(type==='capital'?5:11),n=type==='capital'?7:6;P(gCyl,'#cfc7aa',.62,.05,.62,0,0,0);
   for(let k=0;k<n;k++){const a=k*1.05+.3,r=.34,w=.18+R()*.08,h=(.18+R()*.18)*(1+l*.3);const px=Math.cos(a)*r,pz=Math.sin(a)*r;P(gBox,['#d9c58d','#c7d6d0','#d5d8bd'][k%3],w,h,w,px,.05,pz);P(gBox,lit,w*1.05,h*.35,w*1.05,px,.05+h*.3,pz)}
   if(type==='capital'){const h=.7+l*.15;P(gBox,'#efe8d0',.16,h,.16,0,.05,0);P(gBox,lit,.17,h*.4,.17,0,.25,0);P(gCone,'#c9a24a',.12,.22,.12,0,.05+h,0,Math.PI/4)}else{P(gBox,'#d9c58d',.2,.3+l*.1,.2,0,.05,0);P(gBox,lit,.21,.12,.21,0,.14,0)}}
  else{const n=1+l,pos=[[-.22,-.22],[.22,-.22],[-.22,.22],[.22,.22]];for(let i=0;i<Math.min(4,n);i++)roofed(pos[i][0],pos[i][1],.34,.2+.05*l,i%2?'#e6cfaa':'#e8d9b0',i%2?'#b4533a':'#c0866d')}
  if(st)beacon(g,st,type==='home'||type==='h'?.7:1.05);
  g.updateMatrixWorld(true);loc.forEach(p=>srcs.push(g.localToWorld(new T.Vector3(...p)).toArray()));return g;
 }
 const stOf=(S,t,c)=>{const need=NEED[t];if(!need)return null;const sup=Math.min(1,...need.map(k=>S.fr?.[k]??1));return !need.every(k=>c?.[k])||sup<.5?'bad':sup<.9?'warn':'ok'};
 const flowTube=(pts,color,r,flow,lift=.45,on)=>{const q=pts.map(([x,z])=>new T.Vector3(x,(on?on(x,z):0)+lift,z)),curve=new T.CatmullRomCurve3(q);const tube=new T.Mesh(new T.TubeGeometry(curve,48,r,5),mat(color));tube.userData.own=true;root.add(tube);
  if(flow==null||flow<=0)return;const im=new T.InstancedMesh(gSph,new T.MeshBasicMaterial({color:flow<.15?'#ff6b5e':flow<.5?'#ffd54f':'#ffffff'}),9),d=new T.Object3D(),v=new T.Vector3();im.frustumCulled=false;root.add(im);let ph=0;
  anim.push((t,dt)=>{ph=(ph+dt*.05*(.1+flow))%1;for(let k=0;k<9;k++){curve.getPointAt((ph+k/9)%1,v);d.position.copy(v);d.scale.setScalar(r*1.9);d.updateMatrix();im.setMatrixAt(k,d.matrix)}im.instanceMatrix.needsUpdate=true})};
 function sea(w,d,color){const g=new T.PlaneGeometry(w,d,28,28).rotateX(-Math.PI/2);water=new T.Mesh(g,new T.MeshStandardMaterial({color,transparent:true,opacity:.90,depthWrite:false,roughness:.25,metalness:.10}));water.receiveShadow=true;water.name='map-water';water.position.y=SEA_LEVEL;terrainG.add(water)}
 function buildTerrain(si){
  terrainG.traverse(o=>o.geometry?.dispose());terrainG.clear();water=null;
  if(!atlas){if(hasSea(key))sea(180,180,'#2f86b0');return}
  const shore=x=>21.5+2.5*Math.sin(x*.13+1),pal=SEASON[si],gc=new T.Color(pal.g),fc=new T.Color(pal.f),sand=new T.Color('#ecd9a0'),rock=new T.Color('#8f8b83'),snow=new T.Color('#f4f8f8'),deep=new T.Color('#1f6288');
  H=(x,z)=>{const c=shore(x)-z;let h=c>0?Math.min(c,3)*.14:-Math.min(-c,8)*.3;const m=Math.exp(-(((x+24)**2)+((z+22)**2))/150)*7;h+=m*(c>0?1:0)+(c>0?(Math.sin(x*.21+z*.17)*Math.cos(z*.13-x*.09)+.5*Math.sin(x*.5+z*.43))*.35*(1+m*.3):0);
   const rx=-20+(z+18)*.3,rd=Math.abs(x-rx);if(c>0&&z>-18)h-=1.3*Math.exp(-((rd/1.8)**2));
   let w=0;for(const d of DISTRICTS)w=Math.max(w,sm(7.5,4.5,Math.hypot(x-d.x,z-d.z)));if(c>0)h=h*(1-w)+.35*w;
   const e=Math.max(Math.abs(x)-28,-z-26,0);return h*(1-sm(0,5,e))-3*sm(0,5,e)};
  const W=70,D=76,g=new T.PlaneGeometry(W,D,150,160).rotateX(-Math.PI/2),p=g.attributes.position,col=new Float32Array(p.count*3),c=new T.Color();g.translate(0,0,5);
  for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i),h=H(x,z);p.setY(i,h);const f=sm(1,4,h);c.copy(gc).lerp(fc,sm(-4,-2,(Math.sin(x*.4)*Math.cos(z*.35))*-3)*.6);c.lerp(rock,sm(2.2,4,h));c.lerp(snow,sm(5,6.5,h));if(h<.35)c.lerp(sand,sm(.35,.02,h));if(h<0)c.lerp(deep,Math.min(.9,-h*.4));col.set([c.r,c.g,c.b],i*3)}
  g.setAttribute('color',new T.BufferAttribute(col,3));g.computeVertexNormals();const m=new T.Mesh(g,new T.MeshStandardMaterial({vertexColors:true,roughness:.96}));m.receiveShadow=m.castShadow=true;terrainG.add(m);sea(160,170,'#3a93bd');water.position.z=8;
 }
 function atlasView(S,CITIES){
  const routes=MAP_ROUTES.filter(([a])=>!a.startsWith('water-')||S.waterSupply?.sources?.[a.slice(6)]?.connected).map(([a,b,kind])=>[DISTRICTS.findIndex(d=>d.id===a),DISTRICTS.findIndex(d=>d.id===b),MAP_COLORS[kind],kind==='road'?null:kind==='fuel'?'oil':kind]);
  for(const [a,b,col,kind]of routes){const p=DISTRICTS[a],q=DISTRICTS[b],mid=[(p.x+q.x)/2,(p.z+q.z)/2+(kind?0:1.5)],pts=[[p.x,p.z],mid,[q.x,q.z]];
   const flow=kind==='power'?S.fr?.power??1:['oil','gas'].includes(kind)?(S.offshore?.[kind]?.stage===5&&S.offshore?.[kind]?.pipelineLevel&&!S.offshore?.[kind]?.isolated&&!S.offshore?.[kind]?.incident?1:0):null;
   if(kind==='oil'||kind==='gas')pts.splice(1,0,[(p.x*2+q.x)/3,(p.z*2+q.z)/3]);
   flowTube(pts,col,kind?(S.mapLayer==='services'?.22:.09):.35,S.mapLayer==='services'?flow:null,kind?.42:.08,(x,z)=>Math.max(H(x,z),0))}
  const coast=Array.from({length:20},(_,i)=>{const x=-28+i*56/19;return [x,21.5+2.5*Math.sin(x*.13+1)]});flowTube(coast,'#d9e1c2',.1,null,.04);
  const R=(a=>()=>(a=(a*1664525+1013904223)>>>0)/4294967296)(S.seed||7),tm=new T.Matrix4();
  const crown=new T.InstancedMesh(gCone8,mat('#3f7a4c'),160),trunk=new T.InstancedMesh(gCyl,mat('#927652'),160);let n=0;
  for(let k=0;k<900&&n<160;k++){const x=(R()-.5)*54,z=-26+R()*46,h=H(x,z);if(h<.6||h>3.4||DISTRICTS.some(d=>Math.hypot(x-d.x,z-d.z)<7.5))continue;const s=.7+R()*.6;tm.compose(new T.Vector3(x,h+1.2*s,z),new T.Quaternion(),new T.Vector3(.9*s,2.5*s,.9*s));crown.setMatrixAt(n,tm);tm.compose(new T.Vector3(x,h+.3*s,z),new T.Quaternion(),new T.Vector3(.17*s,1*s,.17*s));trunk.setMatrixAt(n,tm);n++}
  crown.count=trunk.count=n;crown.castShadow=true;root.add(crown,trunk);
  DISTRICTS.forEach(d=>{const sel=d.id===(S.atlasSelected||'capital'),lots=districtLots(S,d.id),built=lots.filter(l=>l.type).length,city=d.city!=null?CITIES[d.city]:null,
    lv=city?1+(S.cities?.[city.name]?.level||0):d.kind==='rig'||d.kind==='port'?1:Math.min(3,1+Math.floor(built/4)),y=d.kind==='rig'?0:ground(d.x,d.z);
   const g=new T.Group();g.userData.pick={kind:'district',id:d.id};root.add(g);
   if(d.kind!=='rig'){const b=cylinder(d.x,y-.1,d.z,5,.3,sel?'#f2d58c':'#c7c9a1',g);}else if(S.offshore?.[d.id]?.stage!==5){cylinder(d.x,.0,d.z,1.2,.5,'#e7c77c',g);cylinder(d.x,.5,d.z,.14,3,'#e2ddbd',g)}
   if(d.water){cylinder(d.x,y+.8,d.z,1.8,1.6,'#82b4be',g);cylinder(d.x+2,y+.4,d.z+1,1,1,'#d4e9dd',g);box(d.x-1,y+.4,d.z+2,2,.5,.4,'#3e7f91',g)}else if(d.kind!=='rig'||S.offshore?.[d.id]?.stage===5){const b=building(d.x,d.z,d.kind,lv,d.kind==='port'?8:d.kind==='rig'?6:7,d.kind==='rig'?(S.offshore[d.id].incident?'bad':'ok'):null);root.remove(b);g.add(b)}
   if(!['rig','port'].includes(d.kind)){const t=d.kind==='capital'||d.kind==='city'?'home':d.kind,ex=Math.min(6,built);for(let j=0;j<ex;j++){const a=j*1.05+.5,r=7+(j%2),px=d.x+Math.cos(a)*r,pz=d.z+Math.sin(a)*r;if(H(px,pz)<.1)continue;const b=building(px,pz,t,lv>1?2:1,2.4);root.remove(b);g.add(b)}}
   if(sel)ring(d.x,y+.2,d.z,5.8,'#ffe08a',!reducedMotion);
   const st=S.offshore?.[d.id]?.stage;label(d.name+(d.kind==='rig'?(st===5?' · توسعه‌یافته':' · در انتظار توسعه'):city&&S.cities?.[city.name]?.level?` · سطح ${S.cities[city.name].level}`:''),d.x,d.z,d.kind==='rig'?7:9,sel?10:1)});
  if((S.inc?.ex||0)>0){const s=new T.Group();box(0,0,0,5,.9,1.6,'#b5382f',s);box(-1,.9,0,1.3,1.2,1.2,'#fff',s);s.position.y=.1;root.add(s);anim.push(t=>{const u=(t*.02)%2,k=u<1?u:2-u;s.position.set(-22+k*44,.1,27.5);s.rotation.y=u<1?0:Math.PI})}
 }
 function hubView(S,CITIES){
  const {city,cols,rows,lots,spacing:sp}=layoutLots(S,CITIES),hub=S.countryHub,north=hub==='north';
  box(0,-1.1,0,cols*sp+4,.7,rows*sp+4,'#5c7b68');box(0,-.4,0,cols*sp+3,.4,rows*sp+3,north?'#a4b77d':'#acbaa0');
  for(let c=0;c<=cols;c++){const x=(c-cols/2)*sp;box(x,.01,0,1.15,.04,rows*sp+1,'#647970');if(c%3===0)for(let z=-rows*sp/2;z<rows*sp/2;z+=4)box(x,.06,z,.07,.01,1.6,'#d5d6ae')}
  for(let r=0;r<=rows;r++){const z=(r-rows/2)*sp;box(0,.01,z,cols*sp+1,.04,1.15,'#647970')}
  lots.forEach((lot,j)=>{const x=lot.x,z=lot.z,sel=lot.selected,data={kind:city?'city-lot':'lot',id:lot.id};
   const design=city?districtDesign(S,CITIES[S.cityView].name,lot.id):null,placement=city?cityDesign(S,CITIES[S.cityView].name).placements[lot.id]:null;const tile=box(x,0,z,4.6,.12,4.6,sel?'#ebcd88':city?STYLES[design.style].ground:lot.type?'#c1c5a4':north?'#9aa977':'#b1be99');tile.receiveShadow=true;pick(tile,data);
   if(lot.type){const b=building(x,z,lot.type,lot.level,4.2,city?null:stOf(S,lot.type,lot.connected),city?STYLES[design.style]:null);b.userData.pick=data}
   if(placement)cityOrnament(x+(lot.type?1.5:0),z+(lot.type?1.2:0),placement,data,lot.type?.48:1);
   if(city&&[10,13,16,37,40,43,64,67,70].includes(lot.id)&&cityDesign(S,CITIES[S.cityView].name).districts[districtIndex(lot.id)])label(design.name,x,z+2,3);
   if(sel)ring(x,.25,z,3.1,'#ffe08a',!reducedMotion)});
  for(let i=0;i<cols;i++)tree((i-(cols-1)/2)*sp,-rows*sp/2-1.4,.7);
  label(city?CITIES[S.cityView].name:DISTRICTS.find(d=>d.id===hub)?.name||'',0,-rows*sp/2-3,7);
 }
 function cityOrnament(x,z,p,data,scale=1){const d=placementDefinition(p.item);if(!d)return;const g=new T.Group();g.userData.pick=data;g.position.set(x,.2,z);g.scale.setScalar(scale);root.add(g);const b=(x,y,z,w,h,l,c)=>box(x,y,z,w,h,l,c,g),c=(x,y,z,r,h,col)=>cylinder(x,y,z,r,h,col,g);const green='#79a66d',stone='#d3c6a6',metal='#648984';
 if(p.days>0){b(0,0,0,3.5,.15,3.5,'#c8b690');b(-1,0,0,.15,4,.15,'#c89b52');b(.3,4,0,2.7,.12,.12,'#c89b52');b(1.6,2.5,0,.06,1.6,.06,metal);return}
 const kind=d.kind,level=Math.max(1,Math.min(3,p.level||1));
 if(['tree','palm'].includes(kind)){c(0,0,0,.13,2,'#97794f');c(0,1.7,0,kind==='tree'?.85:1.15,kind==='tree'?1.5:.45,green)}
 else if(kind==='flowers'){b(0,0,0,3,.25,1.8,green);for(let i=0;i<6;i++)c((i%3-1)*.8,.25,Math.floor(i/3)*.8-.4,.25,.25,i%2?'#dba58f':'#e4ce7e')}
 else if(kind==='bench'){b(0,.6,0,2.5,.2,.7,'#b18f68');b(0,1,0.3,2.5,.8,.12,'#b18f68');for(const dx of [-.9,.9])b(dx,0,0,.1,.6,.5,metal)}
 else if(['lamp','solar'].includes(kind)){b(0,0,0,.14,3,.14,metal);b(.45,2.8,0,1,.14,.5,'#e9d39d');if(kind==='solar')b(-.2,3,0,1.8,.08,1,'#477d98')}
 else if(kind==='fountain'){c(0,0,0,1.6,.3,stone);c(0,.3,0,1.35,.12,'#79b8c7');c(0,.4,0,.15,1.5,'#badce0');c(0,1.1,0,.65,.12,stone)}
 else if(kind==='path'){b(0,0,0,3.8,.1,2.5,stone);for(let i=-1;i<=1;i++)b(i,0.12,0,.4,.04,2.5,metal)}
 else if(kind==='arch'){for(const dx of [-1,1])b(dx,0,0,.4,2.5,.5,stone);b(0,2.3,0,2.5,.5,.65,'#bf9e76')}
 else if(kind==='pavilion'){for(const dx of [-1,1])for(const dz of [-1,1])b(dx,0,dz,.15,1.8,.15,stone);b(0,1.8,0,2.8,.4,2.8,'#a97455')}
 else if(kind==='bike'){for(const dx of [-1,0,1]){c(dx,0,0,.12,1,metal);b(dx,.7,0,.12,.12,1.4,metal)}}
 else if(['statue','monument'].includes(kind)){b(0,0,0,1.8,.5,1.8,stone);c(0,.5,0,.45,2.5,metal);c(0,3,0,.55,.6,'#d1b577')}
 else if(kind==='park'){b(0,0,0,4,.1,4,green);b(0,.1,0,.5,.05,4,stone);for(const dx of [-1.2,1.2]){c(dx,.1,0,.12,1.1,'#95744a');c(dx,1.1,0,.7,.8,'#4f8b5e')}}
 else if(kind==='stadium'){c(0,0,0,2,.8,'#b4c9c6');c(0,.8,0,1.65,.05,green);b(0,.85,0,.08,.02,3,'#e9ebd1')}
 else if(kind==='promenade'){b(0,0,0,4,.15,3,'#88bcc4');b(0,.15,0,3.7,.12,1,stone);for(const dx of [-1.3,1.3]){b(dx,.3,0,.1,1.8,.1,metal);c(dx,2,0,.2,.2,'#ecd58e')}}
 else{b(0,0,0,3.5,1+level*.4,2.7,stone);b(0,1+level*.4,0,3.8,.3,3,'#56868a');for(let i=-1;i<=1;i++)c(i,0,1.5,.15,1.6+level*.3,'#e6e5cd');if(kind==='university')c(0,1.4+level*.4,0,.8,.9,'#c9aa77')}
 }
 function marineView(S,port){
  if(port){box(0,-.5,-10,40,.6,19,'#b5bf99');building(0,0,'port',1,14);label('بندر و پایانه مشترک',0,12,9);
   if((S.inc?.ex||0)>0){const s=new T.Group();box(0,0,0,6,1.1,2,'#b5382f',s);box(-1.4,1.1,0,1.6,1.4,1.4,'#fff',s);root.add(s);anim.push(t=>{const u=(t*.03)%2,k=u<1?u:2-u;s.position.set(-18+k*36,.1,14);s.rotation.y=u<1?0:Math.PI})}return}
  ['oil','gas'].forEach((id,i)=>{const x=i?11:-11,o=S.offshore[id],built=o.stage===5,g=new T.Group();
   if(built){const b=building(x,0,'rig',1,12,o.incident?'bad':(o.health??100)<50?'warn':'ok');b.userData.pick={kind:'district',id}}else{cylinder(x,0,0,1.3,.5,'#e7c77c');cylinder(x,.5,0,.14,3,'#e2ddbd');box(x,.05,0,8,.2,7,'#507e88')}
   const lv=o.pipelineLevel||0;flowTube([[x,0],[x,12],[0,15]],o.incident?.kind==='pipeline-leak'?'#ee5253':lv?'#d8b477':'#6b7f84',.18,built?lv?1:.1:null,.3);
   label((id==='oil'?'میدان نفت':'میدان گاز')+(built?' · توسعه‌یافته':' · در انتظار توسعه'),x,0,10)});
 }
 function industrialUnit(x,z,type,status,index,palette=PALETTES.teal){
  const g=new T.Group();g.position.set(x,.18,z);root.add(g);
  const {steel,dark,cream,accent}=palette;
  const b=(x,y,z,w,h,d,c=steel)=>box(x,y,z,w,h,d,c,g);
  const c=(x,y,z,r,h,col=steel,top=r)=>cylinder(x,y,z,r,h,col,g,top);
  const tower=(x,z,h=5,r=.45)=>{c(x,0,z,r,h);for(let i=1;i<h;i+=1.4){c(x,i,z,r+.14,.12,accent)}b(x+r+.2,.1,z,.08,h,.12,accent)};
  const hall=(x,z,w=4,d=3,h=1.5)=>{b(x,0,z,w,h,d,cream);b(x,h,z,w+.25,.2,d+.25,dark);for(let i=-w/2+.5;i<w/2;i+=.8)b(x+i,.6,z+d/2+.02,.4,.45,.04,dark)};
  const tank=(x,z,r=.9,h=1.5)=>{c(x,0,z,r,h);c(x,h,z,r+.08,.15,'#e5e5cc')};
  const rack=()=>{for(let z=-2.5;z<3;z+=2){b(0,0,z,5,.12,.12,dark);b(-2.4,0,z,.13,1.4,.13,dark);b(2.4,0,z,.13,1.4,.13,dark)}for(let i=0;i<3;i++)b(-1+i,1.4,0,.16,.16,6,i===1?accent:dark)};
  switch(type){
   case 0: hall(-1,1,3,2);tower(-2,-1.4,6,.55);tower(0,-1.7,7.4,.6);tower(1.8,-1.4,4.7);tank(2,1.4,.8);break;
   case 1: for(const x of [-1.5,1.5]){c(x,.1,-1,1.2,.45,'#567e87');c(x,.2,-1,1.05,.5,'#477f8c');b(x,.8,-1,2.7,.12,.1,cream)}hall(0,2,5,1.6,1.1);break;
   case 2: for(const x of [-2,0,2]){c(x,1,0,.8,2.5,steel);b(x,0,0,.15,1.1,.15,dark)}hall(0,-2,4,1.5);break;
   case 3: tower(-1.8,-1,7,.65);tower(.1,-1,5.8,.55);tower(1.7,-1,4.5,.5);rack();break;
   case 4: hall(0,0,5,4,2);for(const x of [-1.5,1.5])tower(x,-1.4,6,.3);c(2,0,2,.8,2.5,steel,.5);break;
   case 5: tower(-2,-1,7,.5);tower(0,-1,6,.5);hall(-1,1.5,3,2);tank(2,1,1,2);break;
   case 6: hall(-1,0,3.4,4,2.1);for(const z of [-1.5,0,1.5]){b(-1,2.3,z,3.8,.12,.12,accent)}tower(2,0,6,.55);break;
   case 7: hall(-1,1,4,3,2);for(const x of [-1,1.5])tower(x,-1.4,6,.35);c(2.3,0,1.8,.8,3.5,steel,.48);break;
   case 8: c(-1,0,0,1.5,2.6,cream);const dome=new T.Mesh(new T.SphereGeometry(1.5,12,8,0,Math.PI*2,0,Math.PI/2),mat(cream));dome.position.set(-1,2.6,0);g.add(dome);c(2,0,-1,1,4,steel,.65);hall(.7,2.4,3,1.3,1.1);break;
   case 9: b(0,0,0,1.6,.4,3.5,dark);b(-.8,.4,0,.15,2.6,.15,accent);b(.8,.4,0,.15,2.6,.15,accent);const beam=b(0,2.8,0,4,.3,.35,accent);beam.rotation.z=.25;b(1.7,.6,0,.08,2.8,.08,steel);tank(-2,-1.8,.75,1);break;
   case 10: hall(-1,1,3,3,1.5);tower(1.8,-.6,6,.5);tower(-1.5,-1.8,4,.5);break;
   case 11: for(const x of [-1.8,0,1.8])c(x,0,0,.7,4.8,steel);hall(0,2.2,5,1.2,1);break;
   case 12: tower(-1.8,-1,6,.65);hall(.7,1,3.8,4,2.2);c(2,0,-1.8,.6,3);break;
   case 13: for(let a=0;a<3;a++)for(let z=0;z<3;z++){const panel=b(-2+a*2,.9,-2+z*2,1.7,.12,1.4,'#315b79');panel.rotation.x=-.38;b(-2+a*2,0,-2+z*2,.12,1,.12,steel)}break;
   case 14: hall(0,1,5.5,3.2,2.2);tower(-2,-1.5,5,.55);c(1.8,0,-1.4,1,3,dark,.65);b(0,2.5,1,6.2,.2,.2,accent);break;
   case 15: for(const x of [-2,0,2])c(x,0,-1,.75,5,cream);hall(0,1.8,5.5,2,1.5);break;
  }
  const color=status==='run'?'#63bf9c':['trip','broken'].includes(status)?'#e57666':['build','ready'].includes(status)?'#dfb96a':'#91a9ac';
  b(0,.02,3.8,7.2,.15,.25,color);c(3.4,0,3.2,.16,2,dark);c(3.4,2,3.2,.3,.4,color);
  if(status==='build'){for(const x of [-3,3])b(x,0,-2,.16,6,.16,accent);b(0,5.9,-2,7,.2,.2,accent)}
  if(status==='run')srcs.push([x,5.5,z]);g.traverse(o=>{if(o.isMesh)pick(o,{kind:'unit',id:index})});
 }
 function industryCampus(S){
  const {units}=industryPage(S),appearance=industryAppearance(S),palette=PALETTES[appearance.palette];
  box(0,-1.1,0,78,1,59,'#597866');box(0,-.15,0,76,.15,57,'#a9b69b');
  // Road and maintenance corridor between production blocks.
  box(0,.02,0,72,.12,5.4,'#52696a');
  box(0,.04,0,2.5,.12,55,'#52696a');
  for(let x=-34;x<36;x+=4)box(x,.19,0,1.8,.02,.15,'#e4d5ac');
  for(const z of [-5,5]){box(0,.2,z,68,.1,.7,'#c9c8a8');for(let x=-33;x<35;x+=5){box(x,.3,z,.12,1.5,.12,'#5b7d7b')}for(let i=0;i<3;i++)box(0,1.8,z+i*.2-.2,69,.12,.12,i===1?'#c6a66e':'#6e9d9a')}
  for(let i=0;i<12;i++){
   const x=(i%6-2.5)*11,z=i<6?-15:15,entry=units[i];
   const base=box(x,.03,z,9.4,.12,11.5,entry&&entry.i===S.siteSelectedUnit?'#e6cb91':entry?'#c8cbb6':'#a1b08e');base;
   if(entry){industrialUnit(x,z,entry.u.t,entry.u.st,entry.i,palette);pick(base,{kind:'unit',id:entry.i});label((entry.i+1)+' · '+(cleanUnitName(entry.u.name)||SHORT_UNIT_NAMES[entry.u.t]),x,z+5.8)}
   else{const lines=new T.EdgesGeometry(new T.BoxGeometry(9.4,.12,11.5));const edge=new T.LineSegments(lines,new T.LineBasicMaterial({color:'#899d80'}));edge.position.set(x,.16,z);root.add(edge)}
  }
  // Perimeter, gate, administration and utilities are site scenery, never process equipment targets.
  for(const z of [-28,28]){box(0,.1,z,75,.12,.15,'#687e73');for(let x=-37;x<38;x+=3)box(x,0,z,.12,.9,.12,'#687e73')}
  for(const x of [-37,37]){box(x,.1,0,.15,.12,56,'#687e73');for(let z=-28;z<29;z+=3)box(x,0,z,.12,.9,.12,'#687e73')}
  building(-27,-25,'service',appearance.office||1,appearance.office?1+appearance.office*.25:.7);building(27,-25,'shop',1,.7);
  for(const x of [-32,-28,28,32])tree(x,25,.8);for(let i=0;i<appearance.garden*5;i++)tree(-28+i*4,24,.65);
  for(const x of [-5,5])box(x,0,28,.3,3,.3,'#d9cfaf');box(0,3,28,10,.3,.4,'#426b68');
  label(appearance.sign?appearance.name+' · '+({gear:'⚙',leaf:'❧',drop:'◉'})[appearance.logo]:'ورودی سایت',0,29);if(appearance.sign)box(0,2,28,12,1.5,.2,palette.dark);label('راه خدمات و انتقال',-28,1);
  for(let i=0;i<3;i++){cylinder(14+i*3,0,-25,1.1,1.7,'#d7d8c2');cylinder(14+i*3,1.7,-25,1.15,.1,'#e4e3cf')}
 }

 function update(S,CITIES){
  ambience=S.mapTime==='night'?1:0;showLabels=S.mapLabels!==false;selectedDistrict=S.atlasSelected||'capital';focusPoint=null;if(!atlas&&!industry&&!['offshore','hub:port'].includes(key)){const selected=layoutLots(S,CITIES).lots.find(l=>l.selected);if(selected)focusPoint=selected}
  const note=document.querySelector('.map-renderer-note');if(note)note.textContent='نمای سه‌بعدی';
  const si=Math.floor(((S.day-1)%360)/90),sig=sceneSignature(S,CITIES);
  if(sig===signature)return;signature=sig;
  if(terrainKey!==key+si){terrainKey=key+si;buildTerrain(si)}
  clearRoot();labels=[];anim=[];srcs=[];smoke=null;
  const marine=key==='offshore',port=key==='hub:port';
  if(industry)industryCampus(S);else if(atlas)atlasView(S,CITIES);else if(marine||port)marineView(S,port);else hubView(S,CITIES);
  if(srcs.length){const n=srcs.length*14,g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(new Float32Array(n*3),3));smoke=new T.Points(g,new T.PointsMaterial({color:'#d4d4d4',size:industry?1.6:1.2,transparent:true,opacity:.5,depthWrite:false}));smoke.frustumCulled=false;smoke.userData.own=true;root.add(smoke)}
  kick();
 }
 function frame(ms){
  raf=0;if(!currentHost.isConnected||document.hidden||!vis)return;raf=requestAnimationFrame(frame);if(ms-last<30)return;const dt=Math.min(.1,(ms-last)/1000);last=ms;const t=reducedMotion?0:ms/1000,n=ambience;
  const k=1-Math.pow(.001,dt);for(const q of['tx','tz','d','az','tilt'])cs[q]+=(goal[q]-cs[q])*k;
  const s=Math.sin(cs.tilt);const distance=cs.d*Math.max(1,1.35/camera.aspect);camera.position.set(cs.tx+distance*s*Math.sin(cs.az),distance*Math.cos(cs.tilt),cs.tz+distance*s*Math.cos(cs.az));camera.lookAt(cs.tx,0,cs.tz);
  hemi.intensity=1.2-.75*n;sun.intensity=2.3*(1-n*.85);scene.background.lerpColors(dayBg,nightBg,n);scene.fog.color.copy(scene.background);lit.emissiveIntensity=n*1.6;
  bc.bad.emissiveIntensity=.5+Math.abs(Math.sin(t*5));bc.warn.emissiveIntensity=.8+.4*Math.sin(t*2);
  if(water&&!reducedMotion){const p=water.geometry.attributes.position;for(let i=0;i<p.count;i++)p.setY(i,waterElevation(p.getX(i),p.getZ(i),t));p.needsUpdate=true}
  anim.forEach(f=>f(t,reducedMotion?0:dt));
  if(smoke){const a=smoke.geometry.attributes.position;srcs.forEach((q,i)=>{for(let j=0;j<14;j++){const ph=(t*.3+j/14)%1,o=(i*14+j)*3;a.array[o]=q[0]+Math.sin(j*1.7+i)*.4*ph+ph*1.4;a.array[o+1]=q[1]+ph*4;a.array[o+2]=q[2]+Math.cos(j*2.3)*.4*ph}});a.needsUpdate=true}
  renderer.render(scene,camera);drawLabels();
 }
 function drawLabels(){const ov=document.getElementById('atlas-labels');if(!ov)return;ov.hidden=!showLabels;if(!showLabels)return;const v=new T.Vector3(),w=currentHost.clientWidth,h=currentHost.clientHeight;
  const projected=labels.map((l,i)=>{v.copy(l.point).project(camera);return {...l,i,x:(v.x*.5+.5)*w,y:(-v.y*.5+.5)*h,behind:v.z>1||v.z< -1}});
  const layout=projectedLabelLayout(projected.filter(l=>!l.behind),w,h);while(ov.children.length<labels.length)ov.append(document.createElement('span'));[...ov.children].forEach(e=>e.style.display='none');
  for(const l of layout){const e=ov.children[l.i];if(!l.visible)continue;e.style.display='';e.textContent=l.text;e.style.left=l.x+'px';e.style.top=l.y+'px';e.classList.toggle('selected',l.priority>1)}
 }
 function kick(){if(!raf)raf=requestAnimationFrame(frame)}
 function resize(){const w=currentHost.clientWidth||700,h=currentHost.clientHeight||530;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();kick()}
 function syncInteraction(){cv.style.touchAction=enabled?'none':'pan-y';const button=document.querySelector('[data-a="atlas-camera"][data-k="toggle"]');if(button){button.setAttribute('aria-pressed',String(enabled));button.textContent=enabled?'پایان کنترل دوربین':'کنترل دوربین'}const caption=document.querySelector('.atlas-caption');if(caption)caption.textContent=enabled?'کنترل دوربین فعال است: کشیدن می‌چرخاند، دو انگشت یا چرخ ماوس زوم می‌کند، Shift+کشیدن جابه‌جا می‌کند. برای اسکرول صفحه «پایان کنترل دوربین» را بزن.':'اسکرول صفحه آزاد است؛ برای چرخش نقشه «کنترل دوربین» را فعال کن.'}
 function attach(node,callback){select=callback;currentHost=node;node.dataset.renderer='webgl';syncInteraction();if(cv.parentElement!==node){node.append(cv);observer?.disconnect();observer=new ResizeObserver(resize);observer.observe(node);io.disconnect();io.observe(node)}resize()}
 const io=new IntersectionObserver(([e])=>{vis=e.isIntersecting;if(vis)kick()}),ray=new T.Raycaster(),P=new Map();let down=null;
 cv.addEventListener('pointerdown',e=>{tap=null;P.set(e.pointerId,{x:e.clientX,y:e.clientY});down={x:e.clientX,y:e.clientY,n:P.size,m:0,pan:e.button===2||e.shiftKey};if(enabled)cv.setPointerCapture(e.pointerId)});
 cv.addEventListener('contextmenu',e=>{if(enabled)e.preventDefault()});
 cv.addEventListener('wheel',e=>{if(!enabled)return;e.preventDefault();goal.d=cl(goal.d*(e.deltaY>0?1.12:.89),18,170)},{passive:false});
 cv.addEventListener('pointermove',e=>{const p=P.get(e.pointerId);if(!p)return;if(down&&Math.hypot(e.clientX-down.x,e.clientY-down.y)>7)down.m=99;if(!enabled)return;const dx=e.clientX-p.x,dy=e.clientY-p.y;
  if(P.size===2){const o=[...P.entries()].find(([id])=>id!==e.pointerId)[1],d0=Math.hypot(p.x-o.x,p.y-o.y);p.x=e.clientX;p.y=e.clientY;const d1=Math.hypot(p.x-o.x,p.y-o.y);if(d0>0&&d1>0)goal.d=cl(goal.d*d0/d1,18,170);if(down)down.m=99;return}
  p.x=e.clientX;p.y=e.clientY;if(down)down.m+=Math.abs(dx)+Math.abs(dy);
  if(down?.pan){const sc=goal.d*2*Math.tan(camera.fov*Math.PI/360)/cv.clientHeight,f=sc/Math.max(.4,Math.cos(goal.tilt)),ca=Math.cos(goal.az),sa=Math.sin(goal.az);goal.tx=cl(goal.tx-dx*sc*ca-dy*f*sa,-45,45);goal.tz=cl(goal.tz+dx*sc*sa-dy*f*ca,-45,45)}
  else{goal.az-=dx*.006;goal.tilt=cl(goal.tilt+dy*.005,.25,1.3)}kick()});
 let tap=null;
 const up=e=>{if(!P.delete(e.pointerId))return;if(!P.size){tap=down&&e.type==='pointerup'&&down.m<7&&Math.hypot(e.clientX-down.x,e.clientY-down.y)<7&&down.n===1?{x:e.clientX,y:e.clientY}:null;down=null}};
 cv.addEventListener('click',e=>{const point=tap;tap=null;if(!point)return;const r=cv.getBoundingClientRect();ray.setFromCamera(new T.Vector2((point.x-r.left)/r.width*2-1,-(point.y-r.top)/r.height*2+1),camera);for(const hit of ray.intersectObject(root,true)){let o=hit.object;while(o&&!o.userData.pick)o=o.parent;if(o){select(o.userData.pick);break}}});
 cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
 const visibility=()=>kick();document.addEventListener('visibilitychange',visibility);
 attach(host,onSelect);
 return {key,attach,update,cameraAction(command){if(command==='toggle'){enabled=!enabled;syncInteraction();return}if(command==='reset')Object.assign(goal,home);else if(command==='focus'){const d=DISTRICTS.find(d=>d.id===selectedDistrict);if(atlas&&d){goal.tx=d.x;goal.tz=d.z;goal.d=48}else if(focusPoint){goal.tx=focusPoint.x;goal.tz=focusPoint.z;goal.d=30}}else goal.d=cl(goal.d*(command==='in'?.8:1.25),18,170);kick()},
  dispose(){if(raf)cancelAnimationFrame(raf);raf=0;observer?.disconnect();io.disconnect();clearRoot();[lit,FLAME,...Object.values(bc)].forEach(m=>m.dispose());terrainG.traverse(o=>o.geometry?.dispose());materials.forEach(m=>m.dispose());renderer.dispose();renderer.forceContextLoss?.();cv.remove();document.removeEventListener('visibilitychange',visibility)}};
}
