import {DISTRICTS,countryViewKey,districtLots} from '../systems/country-planning.js';
export const MAP_COLORS={land:'#b1be91',road:'#6c8175',water:'#357b8c',power:'#ecc372',gas:'#a7bac4',fuel:'#d49672',ok:'#67bca4',warn:'#e4ba68',bad:'#d98277'};
export const MAP_ROUTES=[['north','capital','road'],['capital','east','road'],['housing','capital','road'],['capital','energy','power'],['capital','port','road'],['oil','port','fuel'],['gas','energy','gas'],['water-groundwater','energy','water'],['water-surface','energy','water'],['water-reclaimed','energy','water'],['water-desal','energy','water']];
export function mapToolbar(S){return `<div class="map-toolbar" aria-label="نمایش نقشه"><div class="map-layer-switch" role="group" aria-label="لایه نقشه"><button data-a="atlas-display" data-k="overview" aria-pressed="${S.mapLayer!=='services'}">منظره</button><button data-a="atlas-display" data-k="services" aria-pressed="${S.mapLayer==='services'}">خدمات و ارتباطات</button></div><div class="row"><button data-a="atlas-display" data-k="labels" aria-pressed="${S.mapLabels!==false}">نام‌ها ${S.mapLabels===false?'خاموش':'روشن'}</button><button data-a="atlas-display" data-k="time">${S.mapTime==='night'?'نور شب':'نور روز'}</button><span class="map-renderer-note" role="status"></span></div></div>`}
export function mapCameraControls(S){const canFocus=S.tab!=='site'&&(countryViewKey(S)==='atlas'||S.cityView!=null&&S.cityCell!=null||['north','energy','housing'].includes(S.countryHub)&&S.sel!=null);return `<div class="atlas-camera"><button data-a="atlas-camera" data-k="toggle" aria-pressed="false">کنترل دوربین</button><button data-a="atlas-camera" data-k="reset">نمای کامل</button><button data-a="atlas-camera" data-k="focus" ${canFocus?'':'disabled'}>تمرکز</button><button data-a="atlas-camera" data-k="in" aria-label="بزرگ‌نمایی">＋</button><button data-a="atlas-camera" data-k="out" aria-label="کوچک‌نمایی">−</button></div>`}
export function layoutLots(S,CITIES){
 const city=S.cityView!=null,grid=city?(S.cityMaps?.[CITIES[S.cityView]?.name]||[]):null;
 const lots=city?Array.from({length:81},(_,id)=>({id,type:grid[id]?.type,level:grid[id]?.level||1})):districtLots(S,S.countryHub);
 const cols=city?9:Math.min(8,Math.max(1,Math.ceil(Math.sqrt(lots.length)))),rows=Math.ceil(lots.length/cols),spacing=6.2;
 return {city,cols,rows,spacing,lots:lots.map((l,j)=>({...l,x:(j%cols-(cols-1)/2)*spacing,z:(Math.floor(j/cols)-(rows-1)/2)*spacing,selected:l.id===(city?S.cityCell:S.sel)}))};
}
// Read-only scene snapshot. Daily cash and unshown offshore timers must not rebuild geometry.
export function sceneSignature(S,CITIES){
 const key=S.tab==='site'?'industry:'+Math.floor((Number(S.siteMapPage)||0)):countryViewKey(S);
 return JSON.stringify([key,S.mapLayer,S.mapLabels,S.mapTime,Math.floor(((S.day-1)%360)/90),S.atlasSelected,S.siteSelectedUnit,S.sel,S.cityCell,S.seed,S.legacy?.cities,S.legacy?.industry,Object.values(S.waterSupply?.sources||{}).map(a=>[a.level,!!a.project,a.connected,a.enabled]),
 S.tab==='site'?S.u.map(u=>[u.t,u.st,u.name]):S.grid,S.cityView!=null?S.cityMaps?.[CITIES[S.cityView]?.name]:null,S.cities,
 ['power','gas','water','fuel'].map(p=>Math.round((S.fr?.[p]??1)*10)),['oil','gas'].map(k=>{const o=S.offshore?.[k]||{};return [o.stage,Math.round((o.health??100)/10),o.pipelineLevel,o.incident?.kind,o.isolated]}),(S.inc?.ex||0)>0]);
}
export function projectedLabelLayout(items,width,height){
 const placed=[];return [...items].sort((a,b)=>(b.priority||0)-(a.priority||0)).map(item=>{
  const w=Math.min(width-16,Math.max(60,item.text.length*6.2+18)),h=25,x=Math.max(8+w/2,Math.min(width-8-w/2,item.x));
  for(const offset of [0,-29,29,-58,58]){const y=item.y+offset;if(y<52||y>height-48)continue;const rect={left:x-w/2,right:x+w/2,top:y-h/2,bottom:y+h/2};if(placed.some(b=>!(rect.right+5<b.left||rect.left-5>b.right||rect.bottom+3<b.top||rect.top-3>b.bottom)))continue;placed.push(rect);return {...item,x,y,visible:true}}
  return {...item,visible:false};
 });
}
export function districtStatus(S,d){if(d.kind==='rig'){const o=S.offshore?.[d.id];return o?.stage===5?(o.incident?'اختلال فعال':'توسعه‌یافته'):'اکتشاف و توسعه'}const lots=districtLots(S,d.id);return lots.length?lots.filter(l=>l.type).length.toLocaleString('fa-IR')+' بنای ساخته‌شده':d.kind==='port'?Math.round(S.portRemainingToday??S.port).toLocaleString('fa-IR')+' ظرفیت آزاد':'مدیریت شهر'}
