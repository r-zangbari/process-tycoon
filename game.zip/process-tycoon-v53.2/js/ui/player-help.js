import {hasEquipmentFaults} from '../systems/unit-recovery.js';
export function projectEstimate(S,d,PR,multiplier,feed){
 const n=d.e.length,steel=d.cost*.0004*n,cement=d.cost*.0006*n;
 const materials=Math.max(0,steel-(S.tanks.steel||0))*PR.steel[2]*multiplier+Math.max(0,cement-(S.tanks.cement||0))*PR.cement[2]*multiplier;
 const land=d.cost*.3,install=d.cost*.2*n;
 return {land,install,materials,feed,total:land+install+materials+feed,controllers:d.cost*.15*d.v.length};
}
export function unitExplanation(u){
 if(u.prob)return 'نصب با ایراد مواجه شده است؛ رفع فوری یا ادامه با ریسک را انتخاب کن.';
 if(u.st==='build')return 'ساخت کامل نیست؛ تجهیز بعدی را نصب کن.';
 if(u.st==='ready')return u.su?'مراحل راه‌اندازی را از بررسی ایمنی شروع کن.':'نصب کامل است؛ با پرداخت خوراک اولیه راه‌اندازی را شروع کن.';
 if(u.st==='broken')return hasEquipmentFaults(u)?'خرابی در تجهیز اصلی یا رزرو ثبت شده؛ وضعیت قطعه و تعمیر را بررسی کن.':'خرابی تجهیز ثبت نشده است؛ واحد منتظر تأیید بازگشت به سرویس است. در DCS فرمان بازگشت و موانع آمادگی را بررسی کن.';
 if(u.st==='tar')return 'تعمیرات اساسی در جریان است؛ روزهای باقی‌مانده را بررسی کن.';
 if(u.st==='off')return 'واحد با فرمان توقف خارج شده است؛ برای بازگشت، راه‌اندازی مجدد را انتخاب کن.';
 if(u.st==='trip')return u.processState?.valveOpen===false?'شیر ورودی بسته است؛ مسیر جریان را در اتاق کنترل بررسی کن.':'حفاظت واحد عمل کرده است؛ آلارم‌ها، خوراک و تجهیزات را پیش از راه‌اندازی مجدد بررسی کن.';
 if(u.fs!=null&&u.fs<1)return 'تأمین خوراک کامل نیست؛ موجودی، نقدینگی و ظرفیت واردات را بررسی کن.';
 return 'واحد در سرویس است؛ سود، خوراک و سلامت تجهیزات را پایش کن.';
}
export function nextAction(S,D,diagnosticItems=[]){
 const urgent=diagnosticItems[0];
 if(urgent)return {text:urgent.title+'؛ '+urgent.evidence,fix:urgent.fix,target:urgent.target,index:urgent.index,product:urgent.product,label:undefined,tab:['controls'].includes(urgent.target)?'hmi':['unit','personnel','crisis'].includes(urgent.target)?'i':'m'};
 const ranks={broken:100,trip:95,ready:40,build:35};
 const candidate=S.u.map((u,index)=>({u,index,rank:ranks[u.st]||0})).filter(x=>x.rank>0).sort((a,b)=>b.rank-a.rank)[0];
 if(candidate){const {u,index}=candidate;return {text:D[u.t].n+'؛ '+unitExplanation(u),tab:'i',index,label:'رفتن به واحد'}};
 if(!S.u.length)return {text:'برای شروع، پالایشگاه نفت را بررسی کن؛ برآورد تکمیل و ذخیره هزینه خوراک را قبل از خرید ببین.',tab:'i',label:'دیدن پروژه‌های جدید'};
 return {text:S.paused?'زمان متوقف است. در داده‌های موجود اولویت فوری شناسایی نشد؛ برای محاسبه تولید و فروش، زمان را ادامه بده.':'در داده‌های موجود اولویت فوری شناسایی نشد؛ روند سود، خوراک و فروش را پایش کن.',tab:'m',label:'بررسی انبار و فروش'};
}
