export const LOCAL_TRADE=new Set(['power','gas','water','rawwater','steam']);
export function effectiveTradePort(S){return Math.max(0,Number(S.port)||0)*(S.fx?.sanc?.65:1)*(S.economy?.shock?.type==='supply'?.75:1)}
export function importTradeFactor(S,p){return LOCAL_TRADE.has(p)?1:(S.fx?.sanc?1.25:1)*(S.fx?.spike?1.4:1)}
export function tradeConditionsText(S){return [S.fx?.sanc?'تحریم: هزینه واردات خارجی ×۱٫۲۵، قیمت صادرات ×۰٫۷، ظرفیت پایانه ۶۵٪':'',S.fx?.spike?'جهش جهانی: قیمت خرید خارجی و فروش صادراتی ×۱٫۴':'',S.economy?.shock?.type==='supply'?'اختلال عرضه: هزینه تأمین بیشتر و ظرفیت پایانه ۷۵٪':'',S.economy?.shock?.type==='demand'?'رکود: کاهش تقاضای فروش':'',S.fx?.rival?'قیمت‌شکنی رقیب: افت قیمت صادرات':''].filter(Boolean).join(' · ')||'محدودیت تجاری ویژه‌ای فعال نیست.'}
