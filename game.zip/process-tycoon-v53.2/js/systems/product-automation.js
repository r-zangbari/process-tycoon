import {quoteProductTrade,executeProductTrade} from './product-market.js';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const value=(v,f)=>Number.isFinite(Number(v))?Number(v):f;
export function automationSettings(S){const a=S.marketAutomation||{};return {reserve:Math.max(0,value(a.reserve,0)),dailyLimit:Math.max(0,value(a.dailyLimit,0)),enabled:a.enabled!==false}}
export function productRule(S,p,PR){const a=S.marketAutomation?.rules?.[p]||{},min=clamp(value(a.min,20),0,80),max=clamp(value(a.max,85),min+10,100);return {buy:a.buy===true,emergency:a.emergency!==false,sellMode:['legacy','threshold','off'].includes(a.sellMode)?a.sellMode:PR[p]?.[3]?'legacy':'off',min,target:clamp(value(a.target,55),min+5,max-5),max,reserve:clamp(value(a.reserve,30),0,100),maxBuy:Math.max(0,value(a.maxBuy,0)),minSell:Math.max(0,value(a.minSell,0)),quantityLimit:Math.max(0,value(a.quantityLimit,0))}}
export function saveProductRule(S,p,raw,PR){if(!Object.hasOwn(PR,p))return false;S.marketAutomation||={};S.marketAutomation.rules||={};S.marketAutomation.rules[p]=raw;S.marketAutomation.rules[p]=productRule(S,p,PR);return true}
export function automationDay(S){if(S.autoMarketDay?.day!==S.day)S.autoMarketDay={day:S.day,sold:{},bought:{},income:0,expense:0,emergency:{},spent:0};return S.autoMarketDay}
export function expectedProductNeed(S,p,IN){return Math.max(0,S.dem?.[p]||0)+(S.ct||[]).reduce((n,c)=>n+(c.p===p?c.q||0:0),0)+(S.u||[]).reduce((n,u)=>n+(u.st==='run'?(IN[u.t]?.[p]||0)*(u.load||100)/100:0),0)}
function expectedOutput(S,p,OUT){return (S.u||[]).reduce((n,u)=>n+(u.st==='run'?(OUT[u.t]?.[p]||0)*(u.load||100)/100*(1+.35*Math.max(0,(u.eq||[]).reduce((a,e)=>a+(e.l||1),0)/Math.max(1,u.eq?.length||0)-1)):0),0)}
export function runProductAutomation(S,ctx){
 const {PR,cap,IN={},OUT={}}=ctx;S.marketAutomation||={};const program=S.marketAutomation;if(program.lastDay===S.day)return;program.lastDay=S.day;const settings=automationSettings(S),day=automationDay(S);S.autoTradeStatus={};S.emergencyTradeStatus={};
 if(!settings.enabled){S.autoTradeStatus.global='خرید مخزنی و فروش آستانه‌ای متوقف‌اند؛ تأمین فوری هر محصول تنظیم مستقل دارد.';return}
 const products=Object.keys(PR),status=(p,t)=>{S.autoTradeStatus[p]=(S.autoTradeStatus[p]?S.autoTradeStatus[p]+' · ':'')+t};
 // Release storage before today's production; never sell the estimated next-day feed reserve.
 for(const p of products){const a=productRule(S,p,PR);if(a.sellMode!=='threshold')continue;const stock=S.tanks[p]||0,c=cap(p),need=expectedProductNeed(S,p,IN),floor=Math.min(c,Math.max(c*a.reserve/100,need)),incoming=expectedOutput(S,p,OUT);
  if(stock<=c*a.max/100&&stock+incoming<=c){status(p,'فروش: هنوز به آستانه یا خطر پرشدن نرسیده');continue}
  const qty=Math.max(0,Math.min(stock-floor,stock-c*a.target/100)),quote=quoteProductTrade(S,p,'sell',qty,ctx);if(quote.price<a.minSell){status(p,'فروش متوقف: قیمت کمتر از کف تعیین‌شده');continue}
  const limit=a.quantityLimit||Infinity,r=executeProductTrade(S,p,'sell',Math.min(qty,limit),{...ctx,source:'auto'});status(p,r.ok?'فروش خودکار '+r.quantity.toLocaleString('fa-IR',{maximumFractionDigits:2})+'؛ '+r.reason:qty<=0?'ذخیره لازم خوراک یا حداقل موجودی حفظ شد':r.reason);
 }
 // Buy urgent feed inventories first. The existing per-unit fallback consumes only any remaining deficit.
 products.sort((a,b)=>expectedProductNeed(S,b,IN)-expectedProductNeed(S,a,IN));
 for(const p of products){const a=productRule(S,p,PR);if(!a.buy)continue;const c=cap(p),stock=S.tanks[p]||0,need=expectedProductNeed(S,p,IN);if(stock>=c*a.min/100&&stock>=need){status(p,'خرید: موجودی بالاتر از حداقل است');continue}if((day.sold[p]||0)>0){status(p,'خرید پس از فروش همین روز انجام نمی‌شود');continue}
  const qty=Math.max(0,Math.min(c,Math.max(c*a.target/100,expectedProductNeed(S,p,IN)))-stock),q=quoteProductTrade(S,p,'buy',qty,ctx);if(a.maxBuy>0&&q.price>a.maxBuy){status(p,'خرید متوقف: قیمت بالاتر از سقف تعیین‌شده');continue}
  const budget=Math.max(0,Math.min(S.money-settings.reserve,settings.dailyLimit>0?settings.dailyLimit-day.spent:Infinity)),limit=a.quantityLimit||Infinity;
  const r=executeProductTrade(S,p,'buy',Math.min(qty,limit,budget/q.price),{...ctx,source:'auto'});status(p,r.ok?'خرید خودکار '+r.quantity.toLocaleString('fa-IR',{maximumFractionDigits:2})+'؛ '+r.reason:budget<=0?'خرید متوقف: ذخیره نقد یا سقف هزینه روزانه':r.reason);
 }
}
export function emergencyImportAllowance(S,p,qty,price,PR){const a=productRule(S,p,PR),settings=automationSettings(S),day=automationDay(S);S.emergencyTradeStatus||={};if(!a.emergency){S.emergencyTradeStatus[p]='تأمین فوری خاموش است';return 0}if(a.maxBuy>0&&price>a.maxBuy){S.emergencyTradeStatus[p]='تأمین فوری متوقف: قیمت واقعی بالاتر از سقف خرید';return 0}const allowed=Math.max(0,Math.min(qty,settings.dailyLimit>0?(settings.dailyLimit-day.spent)/price:Infinity));if(allowed<qty-.001)S.emergencyTradeStatus[p]='تأمین فوری محدود به سقف هزینه روزانه';return allowed}

export function recordEmergencyImport(S,p,qty,price){if(qty<=0)return;const d=automationDay(S);d.emergency||={};const e=d.emergency[p]||(d.emergency[p]={quantity:0,cost:0});e.quantity+=qty;e.cost+=qty*price;d.spent=(d.spent||0)+qty*price}
