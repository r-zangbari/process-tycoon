export const hasEquipmentFaults=u=>(u.eq||[]).some(e=>e.f||e.reserve?.f);
// Validate before charging; a healthy, stopped unit needs a return command, not a fictitious repair.
export function recoveryBlock(S,u,index,D){
 const d=D[u.t];if(!d||u.eq.length<d.e.length)return 'نصب تجهیزات کامل نیست؛ مدیریت واحد را بررسی کن.';
 if(u.eq.some((e,j)=>e.f&&(!d.e[j][1]||e.f.dl<=0||!e.reserve||e.reserve.f||e.reserve.h<30)))return 'تجهیز عملیاتی آماده نیست؛ خرابی اصلی و وضعیت رزرو را بررسی کن.';
 if(u.eq.some(e=>e.h<30&&!e.f||e.reserve&&e.reserve.h<30&&!e.reserve.f&&e.f))return 'سلامت تجهیز کافی نیست؛ سرویس دوره‌ای را بررسی کن.';
 if(S.cr?.i===index)return 'رخداد فعال این واحد باید پیش از راه‌اندازی تعیین تکلیف شود.';
 if(u.st==='broken'&&(u.feedIncident?.days>0||u.coolingIncident?.days>0||u.instrumentIncident?.days>0))return 'اختلال عملیاتی هنوز فعال است؛ علت و زمان باقی‌مانده را در DCS بررسی کن.';
 return null;
}
export function renderReserveRepairs(u,d,i,fa){
 return u.eq.map((e,j)=>{const f=e.reserve?.f;if(!f)return '';const cost=d.cost*(d.e[j][1]?.08:.16);return `<div class="hmi-eq reserve-fault"><b>${d.e[j][0]} · تجهیز رزرو معیوب</b><p>${f.st===0?'قطعه سفارش نشده':f.st===1?'قطعه در راه · '+fa(f.eta)+' روز':'قطعه رسیده؛ آماده تعمیر'}</p><div class="row">${f.st===0?`<button data-a="part" data-i="${i}" data-j="${j}" data-role="reserve" data-f="0">قطعه رزرو · ${fa(cost)}</button><button data-a="part" data-i="${i}" data-j="${j}" data-role="reserve" data-f="1">قطعه رزرو فوری · ${fa(cost*2)}</button>`:f.st===2?`<button data-a="repair" data-i="${i}" data-j="${j}" data-role="reserve">تعمیر رزرو · ${fa(d.cost*.04)}</button>`:''}</div></div>`}).join('');
}
