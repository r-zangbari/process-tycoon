import {audioPreferences,audioScene,soundForMessage,MUSIC_CHORDS,MUSIC_MELODY} from './audio-scenes.js';
// Self-contained, synthesized score and environmental sound. No network or audio assets.
export function createGameAudio({getState,host=typeof window!=='undefined'?window:null,setTimer=setInterval,clearTimer=clearInterval}={}){
 let ctx=null,channels=null,timer=null,visible=true,disposed=false,beat=0,nextBeat=0,lastTrade,lastState,profile={kind:'quiet',activity:0,frequency:70},environment=null;
 const voices=new Set(),lastEvent=new Map();
 const ramp=(param,value,time=.08)=>{if(!ctx)return;param.cancelScheduledValues(ctx.currentTime);param.setTargetAtTime(value,ctx.currentTime,time)};
 function note(freq,time,duration,amp,channel='music',type='sine',endFrequency=null){
  if(!ctx||voices.size>=24||!Number.isFinite(freq)||freq<=0)return;
  const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.setValueAtTime(freq,time);if(endFrequency)o.frequency.exponentialRampToValueAtTime(endFrequency,time+duration);
  g.gain.setValueAtTime(.0001,time);g.gain.exponentialRampToValueAtTime(Math.max(.0002,amp),time+Math.min(.12,duration*.2));g.gain.exponentialRampToValueAtTime(.0001,time+duration);
  o.connect(g);g.connect(channels[channel]);voices.add(o);o.onended=()=>{voices.delete(o);o.disconnect();g.disconnect()};o.start(time);o.stop(time+duration+.02);
 }
 function buildEnvironment(){
  const length=Math.floor(ctx.sampleRate*3),buffer=ctx.createBuffer(1,length,ctx.sampleRate),data=buffer.getChannelData(0);let previous=0,noiseSeed=83051;const noiseRandom=()=>{noiseSeed=(Math.imul(noiseSeed,1664525)+1013904223)>>>0;return noiseSeed/4294967296};
  for(let i=0;i<length;i++){previous=(previous+.025*(noiseRandom()*2-1))/1.025;data[i]=previous*2.8*Math.min(1,i/256,(length-1-i)/256)}
  const noise=ctx.createBufferSource(),filter=ctx.createBiquadFilter(),air=ctx.createGain(),hum=ctx.createOscillator(),humGain=ctx.createGain(),harmonic=ctx.createOscillator(),harmonicGain=ctx.createGain();
  noise.buffer=buffer;noise.loop=true;filter.type='lowpass';filter.frequency.value=600;air.gain.value=0;noise.connect(filter);filter.connect(air);air.connect(channels.ambience);noise.start();
  hum.type='sine';hum.frequency.value=65;humGain.gain.value=0;hum.connect(humGain);humGain.connect(channels.ambience);hum.start();harmonic.type='triangle';harmonic.frequency.value=130;harmonicGain.gain.value=0;harmonic.connect(harmonicGain);harmonicGain.connect(channels.ambience);harmonic.start();
  environment={noise,filter,air,hum,humGain,harmonic,harmonicGain};
 }
 function sync(){if(!ctx)return;const S=getState(),a=audioPreferences(S);ramp(channels.master.gain,a.muted||!visible?0:a.master*.65);for(const key of ['music','ambience','effects'])ramp(channels[key].gain,a[key]);profile=audioScene(S);
  const e=environment,level=profile.activity;if(e){const industrial=profile.kind==='industrial',water=profile.kind==='water',sea=profile.kind==='sea';ramp(e.air.gain,level*(sea?.18:water?.11:industrial?.035:.035),.7);ramp(e.filter.frequency,water?1700:sea?500:industrial?800:350,.7);ramp(e.humGain.gain,industrial?level*.07:0,.7);ramp(e.harmonicGain.gain,industrial?level*.018:0,.7);ramp(e.hum.frequency,profile.frequency,.9);ramp(e.harmonic.frequency,profile.frequency*2,.9)}
  const trade=S.productTrades?.[0];if(lastState===S&&trade&&trade!==lastTrade)playEvent('trade');lastTrade=trade;lastState=S;
 }
 function schedule(){if(!ctx||ctx.state!=='running'||!visible||disposed)return;sync();const a=audioPreferences(getState());if(a.muted||a.master<=0)return;const now=ctx.currentTime;if(nextBeat<now-.5)nextBeat=now+.05;
  let scheduled=0;while(nextBeat<now+.65&&scheduled++<4){
   if(a.music>0){if(beat%4===0){const chord=MUSIC_CHORDS[Math.floor(beat/4)%4];for(const f of chord)note(f,nextBeat,3.8,.065,'music','sine');note(chord[0]/2,nextBeat,3.4,.045,'music','sine')}
    if(beat%2===0)note(MUSIC_MELODY[Math.floor(beat/2)%MUSIC_MELODY.length],nextBeat+.03,1.2,.055,'music','triangle');}
   if(a.ambience>0&&profile.kind==='field'&&beat%8===5){note(1450,nextBeat,.15,.018,'ambience','sine',1900);note(1850,nextBeat+.22,.12,.012,'ambience','sine',1400)}
   beat++;nextBeat+=60/72;
  }
 }
 async function unlock(){if(disposed||!host)return false;try{
  if(!ctx){const Audio=host.AudioContext||host.webkitAudioContext;if(!Audio)return false;ctx=new Audio();const master=ctx.createGain(),music=ctx.createGain(),ambience=ctx.createGain(),effects=ctx.createGain(),limiter=ctx.createDynamicsCompressor();master.gain.value=0;limiter.threshold.value=-18;limiter.ratio.value=8;limiter.knee.value=20;music.connect(master);ambience.connect(master);effects.connect(master);master.connect(limiter);limiter.connect(ctx.destination);channels={master,music,ambience,effects};buildEnvironment();nextBeat=ctx.currentTime+.08;timer=setTimer(schedule,400)}
  if(ctx.state==='suspended')await ctx.resume();sync();schedule();return ctx.state==='running';
 }catch(_){return false}}
 function playEvent(type){if(!ctx||ctx.state!=='running'||!visible||disposed)return;const a=audioPreferences(getState());if(a.muted||a.master<=0||a.effects<=0)return;const t=ctx.currentTime,cooldown=type==='alarm'?8:type==='click'?.09:.4;if(t-(lastEvent.get(type)??-Infinity)<cooldown)return;lastEvent.set(type,t);
  if(type==='alarm'){note(660,t,.18,.15,'effects');note(520,t+.26,.25,.13,'effects')}
  else if(type==='success'){[523.25,659.25,783.99].forEach((f,k)=>note(f,t+k*.13,.5,.12,'effects'))}
  else if(type==='build'){note(160,t,.2,.13,'effects','triangle',90);note(540,t+.15,.15,.045,'effects','triangle')}
  else if(type==='repair'){note(340,t,.22,.09,'effects','triangle');note(510,t+.2,.25,.08,'effects')}
  else if(type==='trade'){note(740,t,.1,.075,'effects');note(990,t+.11,.17,.055,'effects')}
  else if(type==='start')note(110,t,.7,.1,'effects','triangle',220);
  else if(type==='stop')note(180,t,.6,.08,'effects','triangle',70);
  else if(type==='deny')note(180,t,.15,.07,'effects');
  else note(420,t,.06,.035,'effects');
 }
 function setVisible(value){visible=!!value;if(!ctx)return;sync();if(!visible&&ctx.state==='running')ctx.suspend().catch(()=>{});else if(visible&&ctx.state==='suspended')ctx.resume().then(()=>{nextBeat=ctx.currentTime+.05;schedule()}).catch(()=>{})}
 function dispose(){disposed=true;if(timer!=null)clearTimer(timer);for(const o of voices){try{o.stop()}catch(_){}}voices.clear();if(environment)for(const k of ['noise','hum','harmonic']){try{environment[k].stop();environment[k].disconnect()}catch(_){}}ctx?.close?.().catch?.(()=>{});ctx=null}
 return {unlock,sync,playEvent,message:text=>{const type=soundForMessage(text);if(type)playEvent(type)},setVisible,dispose,status:()=>({ready:!!ctx&&ctx.state==='running',voices:voices.size,muted:audioPreferences(getState()).muted,scene:profile.kind})};
}
