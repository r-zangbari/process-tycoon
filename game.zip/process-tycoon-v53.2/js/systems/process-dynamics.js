// First-order process response. The actuator is the sole manipulated input.
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export function advanceProcessVariable({ pv, nominal, span, mv = 50, variableName = '', state = {}, disturbance = 0, interactionOffset = 0, noise = 0 }) {
  const s = Math.max(Math.abs(Number(span) || 0), 0.001);
  const name = String(variableName).toLowerCase();
  // Sign describes whether opening the final element raises or lowers the PV.
  let gain = 2.8, sign = 1;
  if (/فشار|pressure/.test(name)) sign = -1;
  else if (/سطح|لول|level/.test(name)) gain = 1.8;
  else if (/دبی|جریان|flow/.test(name)) gain = 2.8;
  else if (/دما|temperature/.test(name)) gain = 2.4;
  const position = clamp(Number(mv) || 50, 0, 100);
  const actuatorEffect = ((position - 50) / 50) * s * gain * sign;
  const d = Number(disturbance) || 0;
  const target = Number(nominal) + actuatorEffect + d + (Number(interactionOffset) || 0);
  const alpha = 0.18;
  const current = Number.isFinite(Number(pv)) ? Number(pv) : Number(nominal);
  const next = current + (target - current) * alpha + (Number(noise) || 0);
  state.disturbance = d * 0.92;
  state.target = target;
  state.actuatorEffect = actuatorEffect;
  return { pv: clamp(next, Number(nominal) - 3.5 * s, Number(nominal) + 3.5 * s), state };
}
export function applyProcessDisturbance(config, span) {
  const direction = config.disturbanceDirection === -1 ? -1 : 1;
  config.disturbance = clamp((Number(config.disturbance) || 0) + direction * Math.max(Math.abs(Number(span) || 0) * 0.45, 0.01), -1.5 * Math.abs(span), 1.5 * Math.abs(span));
  config.disturbanceDirection = direction * -1;
  return config.disturbance;
}

// Simplified process coupling: pressure, temperature and throughput interact.
// The offsets are intentionally bounded and are teaching/gameplay abstractions.
export function calculateProcessCoupling(variables, values) {
  const vars = variables || [], pv = values || [];
  const find = re => vars.findIndex(v => re.test(String(v?.[0] || '')));
  const p = find(/فشار|pressure/i), t = find(/دما|temperature/i), f = find(/دبی|جریان|flow/i), l = find(/سطح|لول|level/i);
  const norm = i => i < 0 ? 0 : clamp((Number(pv[i]) - Number(vars[i][2])) / Math.max(Math.abs(Number(vars[i][3])) || 1, .001), -3, 3);
  const pn = norm(p), tn = norm(t), fn = norm(f), ln = norm(l);
  const offsets = vars.map(() => 0);
  vars.forEach((v, i) => {
    const name = String(v?.[0] || ''), span = Math.max(Math.abs(Number(v?.[3]) || 1), .001);
    if (i === p) offsets[i] = span * (tn * .08 + fn * .025);
    else if (i === t) offsets[i] = span * (pn * .07 + fn * .045);
    else if (i === f) offsets[i] = span * (pn * .14 + tn * .035 + ln * .025);
    else if (/نسبت|کدورت|ارتعاش|اکسیژن|pH|گرد و غبار|آب به نفت/i.test(name)) offsets[i] = span * (Math.abs(pn) * .035 + Math.abs(tn) * .07 + Math.abs(fn) * .055);
    offsets[i] = clamp(offsets[i], -span * .35, span * .35);
  });
  return offsets;
}

// A continuous quality/yield score. A unit can make more saleable product
// when its process variables stay near their active operating targets.
export function calculateProductQuality({ variables, values, pid = {}, unitIndex = 0, equipment = [] }) {
  if (!variables?.length) return 100;
  const deviations = variables.map((v, k) => {
    const cfg = pid[`${unitIndex}:${k}`] || {};
    const target = cfg.mode === 'auto' && Number.isFinite(cfg.sp) ? cfg.sp : Number(v[2]);
    return Math.min(3, Math.abs((Number(values?.[k]) - target) / Math.max(Math.abs(Number(v[3])) || 1, .001)));
  });
  const avg = deviations.reduce((a, b) => a + b, 0) / deviations.length;
  const peak = Math.max(...deviations);
  const health = equipment.length ? equipment.reduce((a, e) => a + clamp(Number(e.h), 0, 100), 0) / equipment.length : 100;
  return clamp(100 - avg * 13 - peak * 9 - (100 - health) * .12, 35, 100);
}
