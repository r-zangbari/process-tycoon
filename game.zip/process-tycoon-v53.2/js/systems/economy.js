// Economic calculations and cash-flow primitives.
export function createEconomy({getState,PR,IN,OUT,IMP,fa,log}){
 const cap=p=>150*(1+.5*(getState().tl[p]||0));
 const feedTxt=t=>Object.entries(IN[t]).map(([p,v])=>PR[p][0]+' '+fa(v)+' در روز').join('، ');
 const feedCost=t=>Object.entries(IN[t]).reduce((a,[p,v])=>a+v*PR[p][2]*IMP(),0);
 const prodTxt=t=>Object.entries(OUT[t]).map(([p,v])=>PR[p][0]+' '+fa(v)+' در روز').join('، ');
 const pay=x=>{const S=getState();if(S.money<x){log('سرمایه کافی نیست ('+fa(x)+' لازم است).');return false}S.money-=x;return true};
 return{cap,feedTxt,feedCost,prodTxt,pay};
}
