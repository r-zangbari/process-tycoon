import {effectiveTradePort} from './trade-conditions.js';
// Read-only connection checks; never mutates game state or advances the simulation.
// Intended to surface actual dependencies, bottlenecks and currently simplified links.
export function auditSystemLinks(S){
 const links=[];
 const add=(label,status,detail,next='')=>links.push({label,status,detail,next});
 const units=Array.isArray(S.u)?S.u:[];
 const active=units.filter(u=>u.st==='run');
 const oil=S.offshore?.oil||{},gas=S.offshore?.gas||{};
 const feedUse={crude:active.some(u=>u.t===0),sourgas:active.some(u=>[2,3].includes(u.t))};
 for(const [key,o,p,used] of [['oil',oil,'crude',feedUse.crude],['gas',gas,'sourgas',feedUse.sourgas]]){
  const title=key==='oil'?'نفت خام / سکوی نفتی':'گاز خام / سکوی گازی';
  if((o.stage||0)<5){
   add(title,used?'warn':'info',`استخراج فراساحلی قفل است (مرحله ${o.stage||0} از ۵). ${used?'واحدهای فعال خوراک را از مخزن یا واردات فرایندی دریافت می‌کنند.':'تأمین خوراک در این مرحله مبتنی بر واردات است.'}`,'ادامه اکتشاف و ساخت سکو در مدیریت فراساحلی.');
  }else if(!(o.pipelineLevel>0)){
   add(title,'warn','سکو نصب شده ولی خط زیردریایی وجود ندارد؛ خوراک از بافر دریایی به خشکی منتقل نمی‌شود.','خط لوله سطح ۱ را احداث کنید.');
  }else if(o.incident||o.pipelineIsolated){
   add(title,'warn','به‌دلیل رخداد یا ESD، انتقال فراساحلی محدود/متوقف است.','رفع حادثه، پایان تعمیر و بازگشایی ایمن خط.');
  }else if((o.buffer||0)>0 && (S.tanks?.[p]||0)>=150*(1+.5*(S.tl?.[p]||0))-.01){
   add(title,'warn','مخزن خشکی پر است؛ انتقال سکوی دریایی با گلوگاه ذخیره مواجه می‌شود.','مصرف/فروش خوراک یا ارتقای مخزن خشکی.');
  }else add(title,'ok',`سکوی سطح عملیاتی فعال است و خط انتقال سطح ${o.pipelineLevel} دارد؛ ورود خوراک فقط از مسیر بافر و خط لوله انجام می‌شود.`);
 }
 const shortages=['power','gas','water','fuel'].filter(p=>(S.dem?.[p]||0)>0&&(S.fr?.[p]??1)<.9);
 if(shortages.length){const names={power:'برق',gas:'گاز',water:'آب',fuel:'سوخت'};add('تأمین کشور','warn',`کسری خدمات: ${shortages.map(p=>`${names[p]} ${Math.round((S.fr[p]||0)*100)}٪`).join('، ')}.`,'افزایش تولید/موجودی و ارتقای شبکه توزیع.');}
 else add('تأمین کشور','ok','خدمات شهری از مخازن و شبکه‌های ملی تغذیه می‌شوند؛ ارتقای شبکه تلفات را کاهش می‌دهد.');
 const urban=S.urbanToday||{};
 add('شهرهای مستقل ↔ اقتصاد ملی',urban.developed>0?'ok':'info',urban.developed>0?`${urban.developed} سطح توسعه افزوده شده؛ تقاضای خدمات، جمعیت و درآمد شهری در محاسبات ملی لحاظ می‌شوند.`:'محله‌های اولیه به‌عنوان خط مبنا محسوب می‌شوند؛ ساخت و ارتقای شهرها تقاضا و مالیات ملی را تغییر می‌دهد.');
 const runningShort=active.filter(u=>Number.isFinite(u.fs)&&u.fs<.7);
 if(runningShort.length)add('خوراک واحدهای فرایندی','warn',`${runningShort.length} واحد فعال کمتر از ۷۰٪ خوراک موردنیاز را دریافت می‌کنند.`,'موجودی خوراک، توان واردات و نقدینگی را بررسی کنید.');
 else add('خوراک واحدهای فرایندی','ok','برداشت از مخزن و واردات فرایندی بر اساس موجودی و بودجه خرید محاسبه می‌شود.');
 const port=effectiveTradePort(S),remaining=Math.max(0,Math.min(Number(S.portRemainingToday??port),port-(S.portUsedToday||0)));
 if(remaining<port*.1)add('پایانه واردات / صادرات','warn',`تنها ${Math.round(remaining)} از ${Math.round(port)} واحد ظرفیت روزانه باقی مانده است.`,'توسعه پایانه یا تغییر زمان‌بندی واردات/فروش.');
 else add('پایانه واردات / صادرات','ok',`ظرفیت باقی‌مانده روزانه ${Math.round(remaining)} از ${Math.round(port)} است؛ قراردادها و فروش نقدی/واردات سقف مشترک دارند.`);
 const contracts=Array.isArray(S.tradeContracts)?S.tradeContracts:[];
 if(contracts.some(c=>(c.remaining||0)>(c.days||0)*port))add('تعهدات صادراتی','warn','حداقل یک قرارداد با ظرفیت فعلی پایانه در مهلت باقی‌مانده قابل تحویل نیست.','افزایش ظرفیت بندر، تأمین موجودی، یا بازنگری قراردادها.');
 else add('تعهدات صادراتی',contracts.length?'ok':'info',contracts.length?'ظرفیت قابل استفاده پایانه برای زمان باقی‌مانده قراردادها کفایت دارد؛ موجودی باید جداگانه تأمین شود.':'قرارداد فعالی وجود ندارد.');
 if(S.money<0)add('نقدینگی / تأمین مالی','warn','موجودی نقد منفی است؛ برخی خریدها ممکن نیستند اما هزینه‌های ثابت ادامه دارند.','توقف واحد زیان‌ده، مدیریت هزینه و وام/بازسازی اضطراری.');
 else add('نقدینگی / تأمین مالی','ok','سرمایه نقدی برای تصمیم‌گیری‌های بعدی قابل استفاده است؛ بودجه عمومی حسابی مجزا دارد.');
 if((S.safe??100)<60)add('HSE و اپراتورها','warn','شاخص ایمنی پایین است و ریسک حوادث و هزینه‌های آن افزایش یافته است.','آموزش و اقدام HSE.');
 else add('HSE و اپراتورها','ok','آموزش، حوادث، سلامت تجهیزات و وضعیت نیروی انسانی در عملکرد بازی اثر دارند.');
 add('پروژه‌های توسعه ملی','info','در این نسخه بیشتر روی شاخص‌های ملی، امنیت تأمین و پایداری اثر می‌گذارند؛ تولید فیزیکی مستقلِ پروژه‌های ملی هنوز مدل نشده است.');
 return {links,issues:links.filter(x=>x.status==='warn').length};
}
