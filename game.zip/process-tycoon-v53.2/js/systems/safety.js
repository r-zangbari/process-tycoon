// Game HSE ledger: successful protection is distinct from actual harm or continued exposure.
const clamp=(v,a=0,b=100)=>Math.max(a,Math.min(b,v));
export const ROUTINE_DAILY_LIMIT=1.5,ROUTINE_COOLDOWN=5;
export function normalizeSafety(S){
 S.safe=clamp(Number.isFinite(S.safe)?S.safe:100);
 const h=S.safetyReport&&typeof S.safetyReport==='object'?S.safetyReport:{};
 h.history=Array.isArray(h.history)?h.history.slice(0,80):[];h.recent=h.recent&&typeof h.recent==='object'?h.recent:{};h.cleanDays=Number.isFinite(h.cleanDays)?Math.max(0,h.cleanDays):0;
 if(h.day!==S.day){h.day=S.day;h.routineSpent=0}h.routineSpent=Number.isFinite(h.routineSpent)?clamp(h.routineSpent,0,ROUTINE_DAILY_LIMIT):0;S.safetyReport=h;return h;
}
export function changeSafety(S,delta,reason,{routine=false,key='',unit=null,target='controls',product=null}={}){
 const h=normalizeSafety(S),before=S.safe;let applied=Number.isFinite(delta)?delta:0,suppressed='';
 if(routine&&applied<0){
  if(key&&h.recent[key]!=null&&S.day-h.recent[key]<ROUTINE_COOLDOWN){applied=0;suppressed='تکرار علت در فاصله کمتر از ۵ روز؛ افت دوباره اعمال نشد'}
  else{const amount=Math.min(-applied,Math.max(0,ROUTINE_DAILY_LIMIT-h.routineSpent));applied=-amount;h.routineSpent+=amount;if(key&&amount>0)h.recent[key]=S.day;if(amount===0)suppressed='سقف افت رخدادهای حفاظتی عادی این روز تکمیل شده است'}
 }
 S.safe=clamp(before+applied);applied=S.safe-before;
 if(delta<0)h.cleanDays=0;
 h.history.unshift({day:S.day,delta:applied,reason,suppressed,unit,target,product,adverse:delta<0});h.history.length=Math.min(h.history.length,80);
 // Old per-unit cooldown keys are irrelevant once outside the five-day window.
 for(const k of Object.keys(h.recent))if(S.day-h.recent[k]>=ROUTINE_COOLDOWN)delete h.recent[k];
 return applied;
}
export function reviewSafetyDay(S,{D,availableOperators=Infinity,requiredOperators=0}={}){
 const h=normalizeSafety(S);if(h.reviewDay===S.day)return;h.reviewDay=S.day;
 const running=(S.u||[]).filter(u=>u.st==='run'),fields=Object.values(S.offshore||{}).filter(o=>o.stage===5&&o.online&&!o.maintenance);let block='';
 if(h.history.some(e=>e.day===S.day&&(e.adverse||e.delta<0)))block='امروز کاهش ایمنی ثبت شده است';
 else if(S.cr||S.gridIncident?.days>0)block='بحران یا اختلال شبکه هنوز فعال است';
 else if(Object.values(S.offshore||{}).some(o=>o.incident))block='رخداد فراساحلی هنوز بسته نشده است';
 else if(!running.length&&!fields.length)block='واحد یا سکوی فعالی برای ثبت بهره‌برداری پایدار وجود ندارد';
 else if(fields.some(o=>o.health<30||o.pipelineLevel>0&&!o.pipelineIsolated&&o.pipeHealth<30))block='سلامت سکو یا خط انتقال فعال کافی نیست';
 else if(availableOperators<requiredOperators)block='تعداد اپراتور حاضر کمتر از نیاز است';
 else for(const u of running){
  const d=D?.[u.t];
  if(u.feedIncident?.days>0||u.coolingIncident?.days>0||u.instrumentIncident?.days>0){block='اختلال عملیاتی واحد در سرویس فعال است';break}
  if(u.eq?.some(e=>e.f||e.reserve?.f||e.h<30)){block='تجهیز معیوب یا کم‌سلامت در واحد فعال نیاز به رسیدگی دارد';break}
  if((u.load||100)>(u.ratedCapacity||100)){block='بار واحد فعال بالاتر از ظرفیت نامی است';break}
  if(d?.v.some((v,k)=>!Number.isFinite(u.v?.[k])||Math.abs(u.v[k]-v[2])/Math.max(.001,v[3])>1.5)){block='متغیر فرایند خارج از باند پایدار است';break}
 }
 if(block){h.cleanDays=0;h.recoveryStatus=block;return}
 h.cleanDays++;if(h.cleanDays<5){h.recoveryStatus=`بهره‌برداری پایدار: ${h.cleanDays} از ۵ روز لازم`;return}
 if(S.safe>=100){h.recoveryStatus='ایمنی کامل؛ بهره‌برداری پایدار ادامه دارد';return}
 const gain=.25+Math.min(3,Math.max(0,S.tr||0))*.05+(h.trainingUntil>=S.day?.1:0);
 const applied=changeSafety(S,gain,'بهبود تدریجی پس از پنج روز بهره‌برداری پایدار',{target:'personnel'});
 h.recoveryStatus='بهبود روزانه '+applied.toLocaleString('fa-IR',{maximumFractionDigits:2})+' امتیاز؛ بدون هزینه خودکار';
}
export function completeSafetyTraining(S){
 const h=normalizeSafety(S);const applied=changeSafety(S,15,'دوره ایمنی HSE؛ هزینه ۲۰۰۰ و تقویت بهبود پایدار برای ۳۰ روز',{target:'personnel'});h.trainingUntil=S.day+30;return applied;
}
