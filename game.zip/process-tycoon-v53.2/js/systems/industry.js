import {cleanUnitName,unitName} from './unit-names.js';
import {completeSafetyTraining} from './safety.js';
import {requestPart,finishRepair} from './auto-maintenance.js';
// Industrial project lifecycle and operating actions.
export function createIndustryActions(ctx){
 let {S}=ctx;
 const {D,INF,TECHN,PR,IMP,PROB,feedCost,partCost,pay,log,r,fa,anyOut}=ctx;
 const actions={
 buy(t,name){if(!D[t])return;if(INF[t]>(S.infra||0)){log('ابتدا زیرساخت سطح '+fa(INF[t])+' را توسعه دهید.');return}if(D[t].tech&&!(S.tech||{})[D[t].tech]){log('ابتدا فناوری «'+TECHN[D[t].tech]+'» را تحقیق کنید.');return}if(D[t].nuc&&(S.tr<2||S.safe<80)){log('مجوز نیروگاه هسته‌ای صادر نمی‌شود: آموزش اپراتورها حداقل سطح ۲ و نمره‌ی ایمنی حداقل ۸۰ لازم است.');return}if(pay(D[t].cost*.3)){S.u.push({t,name:cleanUnitName(name)||D[t].n+' '+(S.u.length+1),st:'build',eq:[],v:D[t].v.map(x=>0),au:D[t].v.map(x=>0),prob:null,h:D[t].v.map(x=>[])});log('زمین و مجوز «'+D[t].n+'» گرفته شد.')}},
 install(i){const u=S.u[i],d=D[u.t];if(u.prob||u.eq.length>=d.e.length)return;const ms=d.cost*.0004,mc=d.cost*.0006,ts=Math.min(S.tanks.steel,ms),tc=Math.min(S.tanks.cement,mc),xt=(ms-ts)*PR.steel[2]*IMP()+(mc-tc)*PR.cement[2]*IMP();if(!pay(d.cost*.2+xt))return;S.tanks.steel-=ts;S.tanks.cement-=tc;
  const eq={h:100,l:1,f:null,running:true};if(d.e[u.eq.length]?.[1])eq.reserve={h:100,f:null,running:false};u.eq.push(eq);const nm=d.e[u.eq.length-1][0];
  if(r()<.4){u.prob=PROB[Math.floor(r()*PROB.length)];log('مشکل نصب '+nm+': '+u.prob)}else log(nm+' نصب شد.');
  if(u.eq.length===d.e.length&&!u.prob)u.st='ready'},
 fix(i,now){const u=S.u[i],d=D[u.t];if(now){if(!pay(d.cost*.08))return}else{u.eq[u.eq.length-1].h=55;log('بدون رفع کامل ادامه دادید؛ سلامت قطعه ۵۵٪ است.')}
  u.prob=null;if(u.eq.length===d.e.length)u.st='ready'},
 start(i){const u=S.u[i],d=D[u.t];if(u.su)return;if(!pay(feedCost(u.t)))return;u.su={pos:0,miss:0,o:[0,1,2,3,4].sort(()=>r()-.5)};log('راه‌اندازی «'+d.n+'»: مراحل را به ترتیب درست انجام دهید.')},
 adj(i,k,s){const u=S.u[i],d=D[u.t];if(u.st==='run')u.v[k]+=s*d.v[k][3]/3},
 pm(i){const u=S.u[i],d=D[u.t],wear=u.eq.reduce((a,e)=>a+(100-e.h)+(e.reserve?100-e.reserve.h:0),0),c=d.cost*.012+wear*d.cost/6500;if(!wear)return;if(pay(c)){u.eq.forEach(e=>{if(!e.f)e.h=100;if(e.reserve&&!e.reserve.f)e.reserve.h=100});log('سرویس دوره‌ای «'+d.n+'» انجام شد؛ سلامت تجهیزات اصلی و رزرو بازیابی شد. هزینه: '+fa(c)+'.')}},
 part(i,j,fast,role='main'){const u=S.u[i],d=D[u.t];const result=requestPart({u,d,j,role,fast,pay,random:r});if(result)log('سفارش قطعه «'+d.e[j][0]+'» ثبت شد؛ رسیدن: '+fa(result.days)+' روز.')},
 repair(i,j,role='main'){const u=S.u[i],d=D[u.t];const result=finishRepair({u,d,j,role,pay});if(result){if(u.maintenance)u.maintenance.recoveryPending=true;log(d.e[j][0]+(role==='reserve'?' رزرو':' اصلی')+' تعمیر شد؛ وضعیت بازگشت را در اتاق کنترل بررسی کن.')}},
 restart(i){const u=S.u[i],d=D[u.t];if(pay(d.cost*.04)){u.v=d.v.map(x=>x[2]+(r()<.5?-1:1)*x[3]*1.8);u.st='run';log('راه‌اندازی مجدد پس از تریپ.')}},
 up(i,j){const u=S.u[i],d=D[u.t],e=u.eq[j];if(e.l>=4)return;if(pay(d.cost*.3*e.l)){e.l++;log(d.e[j][0]+' به سطح '+fa(e.l)+' ارتقا یافت.')}},
 auto(i,k){const u=S.u[i],d=D[u.t];if(!u||u.st==='build'||u.st==='ready'||u.au[k])return;if(pay(d.cost*.15)){u.au[k]=1;log('کنترلر PID «'+d.v[k][0]+'» خریداری و نصب شد؛ اکنون امکان استفاده از حالت AUTO وجود دارد.')}},
 hire(){if(pay(1200)){S.ops++;log('یک اپراتور جدید استخدام شد.')}},
 train(){if(S.tr<3&&pay(1500*(S.tr+1))){S.tr++;log('دوره‌ی آموزش اپراتورها برگزار شد (سطح '+fa(S.tr)+').')}},
 hse(){if(S.safe<100&&pay(2000)){completeSafetyTraining(S);log('دوره ایمنی HSE برگزار شد؛ تا ۱۵ امتیاز بهبود فوری و تقویت بهبود پایدار برای ۳۰ روز.')}},
 offer(o,yes){const f=S.offers[o];if(!f)return;S.offers.splice(o,1);
  if(f.t==='exp'){if(yes){S.fx.exp=20;log('قرارداد صادراتی پذیرفته شد: ۲۰ روز درآمد بالاتر.')}}
  else if(f.t==='strike'){if(yes){if(pay(1500))log('با نمایندگان نیروها توافق شد.');else S.fx.strike=8}else{S.fx.strike=8;log('اعتصاب شروع شد؛ ۸ روز تولید به نصف می‌رسد.')}}}
};
 actions.setState=next=>{S=next};
 return actions;
}
