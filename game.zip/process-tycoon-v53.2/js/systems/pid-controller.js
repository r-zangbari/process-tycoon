// Discrete PI/PID controller with bounded output, conditional integration and bumpless transfer.
export function createPIDController({ clamp }) {
  const limit = clamp || ((v, lo, hi) => Math.max(lo, Math.min(hi, v)));
  function step({ pv, sp, span, config }) {
    const scale = Math.max(Math.abs(Number(span) || 0), 1e-4);
    const error = limit((Number(sp) - Number(pv)) / scale, -4, 4);
    const previous = Number.isFinite(config.previousError) ? config.previousError : error;
    const dt = 1;
    const kp = limit(Number(config.kp) || 0.55, 0, 2);
    const ki = limit(Number(config.ki) || 0.10, 0, 0.5);
    const kd = limit(Number(config.kd) || 0, 0, 0.2);
    const derivative = (error - previous) / dt;
    const oldIntegral = Number(config.integral) || 0;
    const candidateIntegral = limit(oldIntegral + error * dt, -8, 8);
    const raw = kp * error + ki * candidateIntegral + kd * derivative;
    const output = limit(raw, -1, 1);
    const pushesFurtherIntoLimit = (raw > 1 && error > 0) || (raw < -1 && error < 0);
    config.integral = pushesFurtherIntoLimit ? oldIntegral : candidateIntegral;
    config.previousError = error;
    config.output = output;
    return { correction: output, output, error };
  }
  function reset(config, { preserveOutput = false } = {}) {
    config.integral = 0;
    config.previousError = 0;
    if (!preserveOutput) config.output = 0;
  }
  return { step, reset };
}
