import {appearanceBonus} from './legacy-development.js';
import {collectUrbanWastewater} from './water-supply.js';
import {productRule} from './product-automation.js';
import {effectiveTradePort} from './trade-conditions.js';
// Country-level utility demand, delivery, taxation and export settlement.
import {summarizeUrbanDevelopment} from './urban-economy.js';
export function createProcessModel(ctx){
 let {S}=ctx;
 const {TY,SF,PR,MK,cl,r,log}=ctx;
 function country(fm,remainingPort=S.port,cities=[]){
 const dem={power:0,gas:0,fuel:0,water:0},del={},fr={};let dom=0,tax=0,eco=0,ex=0,pop=0,sat=[];
 S.grid.forEach(b=>{if(!b)return;const t=TY[b.t];for(const p in t.need)if(b.c[p])dem[p]+=t.need[p]*b.l});
 const urban=summarizeUrbanDevelopment(S.cityMaps,cities);
 for(const p in urban.demand)dem[p]+=urban.demand[p];
 {const sf=SF[Math.floor(((S.day-1)%360)/90)];dem.gas*=sf.g;dem.power*=sf.p}
 for(const p in dem){const level=Math.max(0,Math.min(4,Number(S.network?.[p])||0));const loss=Math.max(.02,.10-level*.02);const withdrawal=Math.min(S.tanks[p],dem[p]/(1-loss));del[p]=withdrawal*(1-loss);S.tanks[p]-=withdrawal;fr[p]=dem[p]?Math.min(1,del[p]/dem[p]):1;dom+=del[p]*PR[p][2]}
 S.grid.forEach(b=>{if(!b)return;const t=TY[b.t],ks=Object.keys(t.need),m=ks.map(p=>b.c[p]?fr[p]:0);
  if(b.t==='h'){const a=m.reduce((x,y)=>x+y,0)/ks.length;tax+=t.tax*b.l*a;pop+=4*b.l;sat.push(a)}else{const q=t.q*b.l*Math.min(...m);S.pd[t.key]=(S.pd[t.key]||0)+q;eco+=q*MK[t.key][1]*(S.pm[t.key]||1)}});
 pop+=urban.population;tax+=urban.tax*(.4+.6*(fr.power+fr.gas+fr.water+fr.fuel)/4);S.urbanToday={population:urban.population,tax:urban.tax,demand:urban.demand,developed:urban.developed};
 for(const k in MK)S.pm[k]=cl((S.pm[k]||1)+(r()-.5)*.08,.6,1.6);
 let ctInc=0,cp=Math.max(0,Math.min(Number(S.port)||0,Number(remainingPort)||0));const sv={};for(const p in del)sv[p]=del[p]*PR[p][2];for(const p in S.ic)sv[p]=(sv[p]||0)+S.ic[p]*PR[p][2];S.ct=(S.ct||[]).filter(c=>{const dl=Math.min(S.tanks[c.p],c.q,cp),bs=PR[c.p][2];S.tanks[c.p]-=dl;cp-=dl;ctInc+=dl*bs*c.pr-(c.q-dl)*bs*c.pen;sv[c.p]=(sv[c.p]||0)+dl*bs*c.pr;if(dl<c.q&&S.day%5===0)log('کسری تحویل قرارداد '+PR[c.p][0]+'؛ جریمه می‌شوید.');if(--c.d<=0){log('قرارداد '+PR[c.p][0]+' به پایان رسید.');return false}return true});
 const le=Math.min(S.tanks.power,S.line||0);S.tanks.power-=le;ex+=le*6*fm;sv.power=(sv.power||0)+le*6*fm;
 // Spot market: price strategy changes both realized price and market demand.
 const marketBase={methanol:70,ethylene:85,sulfur:35,crude:120,naphtha:55,ammonia:55,urea:65,propane:45,butane:45,fueloil:60,steel:35,cement:65};
 const marketDay={};for(const p in PR)if(PR[p][3]){S.pm[p]=cl((S.pm[p]||1)+(r()-.5)*.1,.5,1.8);const strategy=cl(Number(S.salePrice?.[p])||1,.7,1.5),baseDemand=marketBase[p]||40;const demandFactor=cl(1.25-(strategy-1)*.78,.35,1.45),shockFactor=S.economy?.shock?.type==='demand'?.72:1,demand=baseDemand*demandFactor*shockFactor;const unitPrice=PR[p][2]*S.pm[p]*strategy*fm*(S.mkt||1);let sold=0,revenue=0;if(productRule(S,p,PR).sellMode==='legacy'&&!S.hold[p]&&cp>0&&unitPrice>=productRule(S,p,PR).minSell&&!(S.autoMarketDay?.day===S.day&&S.autoMarketDay.bought?.[p]>0)){sold=Math.min(Math.max(0,S.tanks[p]-(S.marketAutomation?.rules?.[p]?Math.max(150*(1+.5*(S.tl?.[p]||0))*productRule(S,p,PR).reserve/100,(S.cs?.[p]||0)+(dem[p]||0)):0)),cp,Math.max(0,demand-(S.autoMarketDay?.day===S.day?S.autoMarketDay.sold?.[p]||0:0)));S.tanks[p]-=sold;cp-=sold;revenue=sold*unitPrice;ex+=revenue;sv[p]=(sv[p]||0)+revenue;}marketDay[p]={demand,sold,revenue,unitPrice,strategy};}
 S.marketDay=marketDay;S.portRemainingToday=cp;S.portUsedToday=Math.max(0,(S.portCapacityToday??effectiveTradePort(S))-cp);
 S.rp={};for(const p in PR){const pd=S.pd[p]||0;S.rp[p]=pd>0?(PR[p][3]&&S.hold[p]?PR[p][2]:Math.min(PR[p][2]*1.8,(sv[p]||0)/pd)):0}
 const beauty=appearanceBonus(S);if(sat.length)S.sat=.9*S.sat+.1*Math.min(100,100*sat.reduce((x,y)=>x+y,0)/sat.length+beauty);else if(beauty>0&&urban.population>0)S.sat=.9*S.sat+.1*Math.min(100,25*(fr.power+fr.gas+fr.water+fr.fuel)+beauty);
 let pen=0;if(S.day>30&&S.sat<35){pen=25;if(S.day%10===0)log('نارضایتی شهروندان بالاست؛ اعتراض‌ها هزینه دارد.')}
 if(fr.power<.7&&dem.power&&S.day%7===0)log('خاموشی در شهر: برق کافی نیست.');
 collectUrbanWastewater(S,{urbanDemand:urban.demand.water||0,housingDemand:S.grid.reduce((n,b)=>n+(b?.t==='h'&&b.c?.water?(TY.h?.need?.water||0)*b.l:0),0),deliveryRatio:fr.water});
 S.dem=dem;S.fr=fr;S.pop=pop;S.inc={dom,tax,eco,ex,pen,ct:ctInc};return dom+tax+eco+ex-pen+ctInc};
 return {country,setState(next){S=next}};
}
