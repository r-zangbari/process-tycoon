import {changeSafety} from './safety.js';
// v49 — finite offshore reserves + subsea transfer + integrity, isolation and assisted recovery.
// Model is deliberately bounded for gameplay, not a reservoir engineering simulator.
export const OFFSHORE={
 oil:{name:'نفت خام',rig:'سکوی نفتی فراساحلی',product:'crude',rate:120,opex:70,
  reserve:24000,bufferCapacity:260,utility:'water',utilityPerLevel:3,
  recoveryName:'تزریق آب و نگهداشت فشار مخزن',recoveryProjects:[null,{cost:10000,days:12},{cost:14500,days:16}],
  pipelineCapacity:[0,85,160,260],pipelineOpex:[0,12,20,32],
  pipelineProjects:[null,{cost:7500,days:10},{cost:11000,days:12},{cost:16000,days:15}]},
 gas:{name:'گاز خام (گاز ترش)',rig:'سکوی گازی فراساحلی',product:'sourgas',rate:180,opex:85,
  reserve:36000,bufferCapacity:380,utility:'power',utilityPerLevel:4,
  recoveryName:'کمپرسور تقویت فشار گاز',recoveryProjects:[null,{cost:13000,days:14},{cost:18500,days:18}],
  pipelineCapacity:[0,130,235,370],pipelineOpex:[0,16,26,38],
  pipelineProjects:[null,{cost:8500,days:12},{cost:12500,days:14},{cost:19000,days:17}]}
};
export const offshoreStages=key=>[null,
 {name:'مطالعات لرزه‌نگاری',cost:2500,days:8},
 {name:'حفاری اکتشافی',cost:6500,days:12},
 {name:'ارزیابی و تأیید ذخیره',cost:14500,days:18},
 {name:'اخذ مجوز توسعه میدان',cost:5500,days:6},
 {name:'ساخت و نصب سکوی دریایی',cost:key==='oil'?28000:32000,days:25}];
const bound=(v,low,high)=>Math.max(low,Math.min(high,v));
const finite=v=>typeof v==='number'&&Number.isFinite(v);
const validProject=(p,min,max)=>p&&finite(p.target)&&finite(p.days)&&Number.isInteger(p.target)&&p.target>=min&&p.target<=max&&p.days>0;
export const seaCondition=day=>(day%90>=59&&day%90<=67)?'متلاطم':'آرام';
export function normalizeOffshoreState(state){
 state.offshore=state.offshore&&typeof state.offshore==='object'?state.offshore:{};
 for(const [key,def] of Object.entries(OFFSHORE)){
  const o=state.offshore[key]&&typeof state.offshore[key]==='object'?state.offshore[key]:{};state.offshore[key]=o;
  o.stage=finite(o.stage)?Math.floor(bound(o.stage,0,5)):0;
  o.health=finite(o.health)?bound(o.health,0,100):100;
  o.pipeHealth=finite(o.pipeHealth)?bound(o.pipeHealth,0,100):100;
  if(!validProject(o.project,o.stage+1,5))o.project=null;
  o.pipelineLevel=finite(o.pipelineLevel)?Math.floor(bound(o.pipelineLevel,0,3)):0;
  if(!validProject(o.pipeProject,o.pipelineLevel+1,o.pipelineLevel+1)||o.pipeProject?.target>3)o.pipeProject=null;
  o.productionTarget=[50,75,100].includes(o.productionTarget)?o.productionTarget:100;
  o.online=o.online!==false;
  o.pipelineIsolated=o.pipelineIsolated===true;
  o.buffer=finite(o.buffer)?bound(o.buffer,0,def.bufferCapacity):0;
  o.recoveryLevel=finite(o.recoveryLevel)?Math.floor(bound(o.recoveryLevel,0,2)):0;
  o.recoveryEnabled=o.recoveryEnabled!==false;
  if(!validProject(o.recoveryProject,o.recoveryLevel+1,o.recoveryLevel+1)||o.recoveryProject?.target>2)o.recoveryProject=null;
  if(!o.maintenance||!['rig','pipeline'].includes(o.maintenance.kind)||!finite(o.maintenance.days)||o.maintenance.days<=0)o.maintenance=null;
  if(!o.incident||!['pipeline-leak','rig-failure'].includes(o.incident.kind))o.incident=null;
  if(o.stage>=3){
   // Migrate v46/v47 saves without resetting previously confirmed or depleted reserves.
   o.reserveInitial=finite(o.reserveInitial)&&o.reserveInitial>0?o.reserveInitial:def.reserve;
   o.reserveRemaining=finite(o.reserveRemaining)?bound(o.reserveRemaining,0,o.reserveInitial):o.reserveInitial;
  }
  for(const k of ['producedToday','deliveredToday','shutInToday','operatingCostToday','utilityUsedToday','fineToday'])if(!finite(o[k]))o[k]=0;
 }
}
export function reservoirMetrics(field){
 const initial=Math.max(1,field.reserveInitial||1),remaining=Math.max(0,field.reserveRemaining||0);
 const fraction=bound(remaining/initial,0,1);
 const pressurePct=Math.round(100*Math.pow(fraction,.43));
 const capacityFactor=.45+.55*(pressurePct/100);
 return {fraction,pressurePct,capacityFactor};
}
export function recoveryReady(o){return o.stage===5&&o.pipelineLevel>0&&o.reserveInitial>0&&o.reserveRemaining/o.reserveInitial<=.9;}
export function recoveryAvailable(o,key,state){
 const def=OFFSHORE[key],amount=o.recoveryLevel*def.utilityPerLevel;
 return !!(o.online&&o.recoveryEnabled&&amount>0&&!o.maintenance&&o.incident?.kind!=='rig-failure'&&(state.tanks?.[def.utility]||0)>=amount);
}
export function advanceOffshoreProjects(state,log){
 for(const [key,def] of Object.entries(OFFSHORE)){
  const o=state.offshore[key];
  if(o.project&&--o.project.days<=0){
   o.stage=o.project.target;o.project=null;
   const stage=offshoreStages(key)[o.stage];
   if(o.stage===3){o.reserveInitial=def.reserve;o.reserveRemaining=def.reserve;log(`ذخیره قابل برداشت میدان ${def.name} تأیید شد: ${def.reserve.toLocaleString('fa-IR')} واحد (برآورد مدل بازی).`)}
   log(`میدان ${def.name}: مرحله «${stage.name}» تکمیل شد.`);
   if(o.stage===5)log(`سکوی ${def.name} نصب شد؛ برای انتقال خوراک به مخزن خشکی، خط لوله زیردریایی را راه‌اندازی کنید.`);
  }
  if(o.pipeProject&&--o.pipeProject.days<=0){
   o.pipelineLevel=o.pipeProject.target;o.pipeProject=null;
   log(`خط لوله زیردریایی ${def.name} به سطح ${o.pipelineLevel.toLocaleString('fa-IR')} رسید؛ ظرفیت انتقال روزانه ${def.pipelineCapacity[o.pipelineLevel].toLocaleString('fa-IR')} واحد است.`);
  }
  if(o.recoveryProject&&--o.recoveryProject.days<=0){
   o.recoveryLevel=o.recoveryProject.target;o.recoveryProject=null;
   log(`طرح «${def.recoveryName}» در میدان ${def.name} به سطح ${o.recoveryLevel.toLocaleString('fa-IR')} رسید؛ فعال شدن آن به تأمین یوتیلیتی وابسته است.`);
  }
  if(o.maintenance&&--o.maintenance.days<=0){
   const {kind,emergency}=o.maintenance;
   if(kind==='rig')o.health=bound(Math.max(o.health+34,emergency?85:0),0,100);
   else o.pipeHealth=bound(Math.max(o.pipeHealth+35,emergency?85:0),0,100);
   if(emergency&&o.incident?.kind===(kind==='rig'?'rig-failure':'pipeline-leak'))o.incident=null;
   o.maintenance=null;
   log(`تعمیرات ${kind==='rig'?'سکو':'خط لوله'} میدان ${def.name} تکمیل شد. بازگشت به سرویس نیازمند فرمان اپراتور است.`);
  }
 }
}
export function startOffshoreMaintenance(state,key,kind,log,pay){
 const o=state.offshore?.[key],def=OFFSHORE[key];
 if(!o||!def||o.stage!==5||!['rig','pipeline'].includes(kind)||o.maintenance)return false;
 if(kind==='pipeline'&&o.pipelineLevel===0)return false;
 const emergency=!!o.incident;
 if(emergency&&((kind==='rig'&&o.incident.kind!=='rig-failure')||(kind==='pipeline'&&o.incident.kind!=='pipeline-leak')))return false;
 if(emergency&&kind==='pipeline'&&!o.pipelineIsolated){log('پیش از تعمیر نشتی خط، باید جداسازی اضطراری را اجرا کنید.');return false}
 const cost=kind==='pipeline'?(emergency?4200:1450):(emergency?3200:1250),days=kind==='pipeline'?(emergency?6:4):(emergency?5:3);
 if(!pay(cost))return false;
 o.online=false;
 if(kind==='pipeline')o.pipelineIsolated=true;
 o.maintenance={kind,days,emergency};
 log(`${emergency?'تعمیر اضطراری':'سرویس پیشگیرانه'} ${kind==='rig'?'سکو':'خط لوله'} ${def.name} آغاز شد؛ ${days.toLocaleString('fa-IR')} روز تا تکمیل، هزینه ${cost.toLocaleString('fa-IR')}.`);
 return true;
}
export function isolateOffshore(state,key,log){
 const o=state.offshore?.[key];if(!o||o.stage!==5||o.pipelineLevel===0)return false;
 o.online=false;o.pipelineIsolated=true;
 log(`ESD / ایزولاسیون خط لوله ${OFFSHORE[key].name} اجرا شد؛ برداشت و انتقال دریایی متوقف شد.`);
 return true;
}
export function resumeOffshorePipeline(state,key,log){
 const o=state.offshore?.[key];
 if(!o||o.stage!==5||!o.pipelineIsolated||o.incident||o.maintenance||o.pipeHealth<30){log('وصل مجدد خط ممکن نیست؛ رفع حادثه، تکمیل تعمیرات و سلامت حداقل ۳۰٪ الزامی است.');return false}
 o.pipelineIsolated=false;
 log(`ایزولاسیون خط لوله ${OFFSHORE[key].name} پس از کنترل سلامت برداشته شد؛ انتقال بافر مجاز است.`);
 return true;
}
export function simulateOffshoreDay(state,capacity,log,random=null,recordSOE=()=>{}){
 let totalOperatingCost=0;
 const storm=seaCondition(state.day)==='متلاطم';
 for(const [key,def] of Object.entries(OFFSHORE)){
  const o=state.offshore[key];
  o.producedToday=0;o.deliveredToday=0;o.shutInToday=0;o.operatingCostToday=0;o.utilityUsedToday=0;o.fineToday=0;
  if(o.stage!==5||o.project)continue;
  // A severe defect is an immediate permissive failure, irrespective of chance.
  // Random failures are opt-in through the runtime random callback; automated tests stay deterministic.
  if(!o.incident&&!o.maintenance){
   let fault=null;
   const activeRig=o.online&&o.reserveRemaining>0;
   const activePipe=o.pipelineLevel>0&&!o.pipelineIsolated&&(o.buffer>0||activeRig);
   if(activeRig&&(o.health<20||(random&&random()<((o.health<45?.018:o.health<65?.003:.00035)*(storm?2.5:1)*bound(1+(75-(state.safe??100))*.009,.5,1.65)))))fault='rig-failure';
   if(!fault&&activePipe&&(o.pipeHealth<25||(random&&random()<((o.pipeHealth<45?.022:o.pipeHealth<65?.004:.00045)*(storm?2.5:1)*bound(1+(75-(state.safe??100))*.009,.5,1.65)))))fault='pipeline-leak';
   if(fault){
    o.incident={kind:fault,day:state.day};
    if(fault==='rig-failure')o.online=false;
    changeSafety(state,-(fault==='pipeline-leak'?3:.75),fault==='pipeline-leak'?'نشتی خط زیردریایی '+def.name:'خرابی مهارشده سکوی '+def.name,{routine:fault!=='pipeline-leak',key:'offshore:'+key+':rig',target:'offshore'});
    const msg=fault==='pipeline-leak'?`هشدار نشتی احتمالی خط زیردریایی ${def.name}: شیر قطع اضطراری جریان را متوقف کرده، ولی ایزولاسیون کامل برای تعمیر لازم است.`:`خرابی بحرانی سکوی ${def.name}: تولید به‌طور خودکار متوقف شد؛ تعمیر اضطراری الزامی است.`;
    log(msg);recordSOE(msg,'HIGH');
   }
  }
  const metrics=reservoirMetrics(o);
  const canOperate=o.online&&!o.maintenance&&o.incident?.kind!=='rig-failure';
  const utilityAmount=o.recoveryLevel*def.utilityPerLevel;
  const useRecovery=canOperate&&recoveryAvailable(o,key,state)&&o.reserveRemaining>0&&o.buffer<def.bufferCapacity;
  const boost=useRecovery?Math.min(.3,.15*o.recoveryLevel):0;
  const desired=canOperate?def.rate*(o.productionTarget/100)*Math.min(1.25,metrics.capacityFactor+boost)*(o.health/100)*(storm?.88:1):0;
  const actual=Math.max(0,Math.min(desired,o.reserveRemaining,def.bufferCapacity-o.buffer));
  if(actual>0&&useRecovery){state.tanks[def.utility]-=utilityAmount;o.utilityUsedToday=utilityAmount;}
  o.reserveRemaining=Math.max(0,o.reserveRemaining-actual);o.buffer+=actual;o.producedToday=actual;
  o.shutInToday=Math.max(0,Math.min(desired,o.reserveRemaining+actual)-actual);
  const free=Math.max(0,capacity(def.product)-(state.tanks[def.product]||0));
  // No throughput during isolation, integrity work or an unresolved subsea leak.
  const availablePipe=o.pipelineLevel>0&&!o.pipelineIsolated&&!o.incident?.kind?.includes('pipeline')&&o.maintenance?.kind!=='pipeline';
  const effectivePipeCap=availablePipe?def.pipelineCapacity[o.pipelineLevel]*(storm?.72:1)*Math.min(1,Math.max(0,o.pipeHealth)/40):0;
  const move=Math.max(0,Math.min(o.buffer,effectivePipeCap,free));
  o.buffer=Math.max(0,o.buffer-move);
  state.tanks[def.product]=(state.tanks[def.product]||0)+move;
  state.pd[def.product]=(state.pd[def.product]||0)+move;
  o.deliveredToday=move;
  if(actual>0)o.health=bound(o.health-(.055+.045*o.productionTarget/100)*(storm?1.6:1),0,100);
  if(move>0)o.pipeHealth=bound(o.pipeHealth-(.05+.055*move/Math.max(1,effectivePipeCap))*(storm?1.7:1),0,100);
  const rigCost=canOperate?def.opex*(actual>0?(.28+.72*o.productionTarget/100):.28):0;
  const pipeCost=availablePipe&&(canOperate||move>0)?def.pipelineOpex[o.pipelineLevel]:0;
  const recoveryCost=actual>0&&useRecovery?18*o.recoveryLevel:0;
  // Open leak causes recurring environmental and emergency-response cost, ending at isolation.
  const incidentCost=o.incident?.kind==='pipeline-leak'&&!o.pipelineIsolated?180:0;
  if(incidentCost){changeSafety(state,-.5,'ادامه مواجهه با نشتی ایزوله‌نشده خط '+def.name,{target:'offshore'});o.fineToday=incidentCost;if(state.day%3===0)log(`هشدار HSE فراساحلی ${def.name}: نشتی هنوز ایزوله نشده و هزینه/جریمه روزانه ${incidentCost.toLocaleString('fa-IR')} اعمال شد.`)}
  o.operatingCostToday=Math.round(rigCost+pipeCost+recoveryCost+incidentCost);
  totalOperatingCost+=o.operatingCostToday;
  if(o.shutInToday>5&&state.day%5===0){
   const reason=o.pipelineLevel===0?'نبود خط لوله':free<=0?'پر بودن مخزن خشکی':'محدودیت ظرفیت انتقال / مخزن موقت';
   log(`کاهش تولید میدان ${def.name}: ${reason}؛ ${Math.round(o.shutInToday).toLocaleString('fa-IR')} واحد ظرفیت چاه بلااستفاده ماند (ذخیره مصرف نشد).`);
  }
  if(o.reserveRemaining<=0&&o.producedToday>0)log(`ذخیره قابل برداشت میدان ${def.name} به پایان رسید؛ سکو از این پس تولید نخواهد داشت.`);
 }
 return totalOperatingCost;
}
