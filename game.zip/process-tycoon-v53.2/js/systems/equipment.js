// Shared equipment condition and maintenance calculations.
export function createEquipmentTools({D}){
 const level=u=>u.eq.reduce((a,e)=>a+e.l,0)/Math.max(1,u.eq.length);
 const partCost=(d,j)=>d.cost*(d.e[j][1]?.08:.16);
 const isOut=(d,e,j)=>e.f&&(!d.e[j][1]||e.f.dl<=0);
 const anyOut=u=>u.eq.some((e,j)=>isOut(D[u.t],e,j));
 return{level,partCost,isOut,anyOut};
}
