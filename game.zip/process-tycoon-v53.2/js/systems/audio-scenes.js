const clamp=v=>Math.max(0,Math.min(1,Number.isFinite(Number(v))?Number(v):0));
export function audioPreferences(S){const a=S.audio||{};return {master:clamp(a.master??.7),music:clamp(a.music??.25),ambience:clamp(a.ambience??.3),effects:clamp(a.effects??.6),muted:!!S.mute}}
export function soundForMessage(text){
 if(typeof text!=='string')return null;
 if(/انجام نشد|کافی نیست|آماده نیست|نامعتبر|مجاز نیست/.test(text))return 'deny';
 if(/تریپ|نشتی|بحران|حادثه|هشدار|خراب شد/.test(text))return 'alarm';
 if(/مأموریت انجام|تبریک|کامل شد|پاداش.*افزوده شد|آیتم روی نقشه/.test(text))return 'success';
 if(/دوباره وارد سرویس|راه‌اندازی مجدد|به کار برگشت/.test(text))return 'start';
 if(/توقف|متوقف|خارج.*سرویس|شات‌داون/.test(text))return 'stop';
 if(/تعمیر|سرویس دوره/.test(text))return 'repair';
 if(/نصب شد|ساخته شد|شروع پروژه|ساخت.*کامل|زمین و مجوز|پروژه آغاز شد|ظاهر سایت ارتقا/.test(text))return 'build';
 if(/خرید|فروش|واردات|صادرات|سفارش|قرارداد/.test(text))return 'trade';return null;
}
export function audioScene(S){
 const factor=S.paused?.3:1,selected=S.tab==='hmi'?S.u?.[S.hmiUnit]:S.tab==='site'?S.u?.[S.siteSelectedUnit]:null;
 if(selected)return {kind:selected.t===1?'water':selected.t===13?'field':'industrial',activity:selected.st==='run'?factor:0,frequency:[62,85,73,58,92,68,78,105,112,53,88,75,71,66,49,57][selected.t]||65};
 if(S.tab==='site')return {kind:'industrial',activity:S.u?.some(u=>u.st==='run')?factor*.7:0,frequency:64};
 if(S.tab==='c'){if(S.offshoreView||S.countryHub==='port')return {kind:'sea',activity:.7,frequency:75};if(S.countryHub==='energy')return {kind:'industrial',activity:.4*factor,frequency:74};return {kind:'field',activity:.45,frequency:90}}
 return {kind:'quiet',activity:0,frequency:70};
}
export const MUSIC_CHORDS=[[146.832,174.614,220],[130.813,164.814,196],[174.614,220,261.626],[110,146.832,164.814]];
export const MUSIC_MELODY=[293.665,349.228,440,391.995,349.228,293.665,261.626,220];
