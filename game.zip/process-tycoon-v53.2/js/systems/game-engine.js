// Simulation clock and lifecycle orchestration.
export function createProcessClock({tick,getState,draw,save}){
 let acc=0,last=performance.now(),timer=null;
 return{start(){if(timer)return;timer=setInterval(()=>{const S=getState(),n=performance.now();acc+=(n-last)*(S.paused?0:S.spd);last=n;while(acc>=1500){acc-=1500;tick()}draw();save()},500)},stop(){if(timer){clearInterval(timer);timer=null}}};
}
